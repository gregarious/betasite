--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: accounts_betamember; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE accounts_betamember (
    id integer NOT NULL,
    email character varying(75) NOT NULL
);


ALTER TABLE public.accounts_betamember OWNER TO postgres;

--
-- Name: accounts_betamember_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE accounts_betamember_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_betamember_id_seq OWNER TO postgres;

--
-- Name: accounts_betamember_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE accounts_betamember_id_seq OWNED BY accounts_betamember.id;


--
-- Name: accounts_betamember_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('accounts_betamember_id_seq', 1078, true);


--
-- Name: accounts_organization; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE accounts_organization (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    dtcreated timestamp with time zone NOT NULL,
    image character varying(100),
    url character varying(200) NOT NULL,
    fb_id character varying(50) NOT NULL,
    twitter_username character varying(15) NOT NULL
);


ALTER TABLE public.accounts_organization OWNER TO postgres;

--
-- Name: accounts_organization_administrators; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE accounts_organization_administrators (
    id integer NOT NULL,
    organization_id integer NOT NULL,
    user_id integer NOT NULL
);


ALTER TABLE public.accounts_organization_administrators OWNER TO postgres;

--
-- Name: accounts_organization_administrators_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE accounts_organization_administrators_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_organization_administrators_id_seq OWNER TO postgres;

--
-- Name: accounts_organization_administrators_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE accounts_organization_administrators_id_seq OWNED BY accounts_organization_administrators.id;


--
-- Name: accounts_organization_administrators_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('accounts_organization_administrators_id_seq', 19, true);


--
-- Name: accounts_organization_establishments; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE accounts_organization_establishments (
    id integer NOT NULL,
    organization_id integer NOT NULL,
    place_id integer NOT NULL
);


ALTER TABLE public.accounts_organization_establishments OWNER TO postgres;

--
-- Name: accounts_organization_establishments_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE accounts_organization_establishments_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_organization_establishments_id_seq OWNER TO postgres;

--
-- Name: accounts_organization_establishments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE accounts_organization_establishments_id_seq OWNED BY accounts_organization_establishments.id;


--
-- Name: accounts_organization_establishments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('accounts_organization_establishments_id_seq', 17, true);


--
-- Name: accounts_organization_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE accounts_organization_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_organization_id_seq OWNER TO postgres;

--
-- Name: accounts_organization_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE accounts_organization_id_seq OWNED BY accounts_organization.id;


--
-- Name: accounts_organization_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('accounts_organization_id_seq', 19, true);


--
-- Name: accounts_userprofile; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE accounts_userprofile (
    id integer NOT NULL,
    user_id integer NOT NULL,
    points integer DEFAULT 0 NOT NULL,
    fb_id character varying(50) NOT NULL,
    twitter_username character varying(15) NOT NULL,
    display_name character varying(30) NOT NULL,
    gender character varying(1) NOT NULL,
    neighborhood character varying(50) NOT NULL,
    fb_id_public boolean NOT NULL,
    twitter_username_public boolean NOT NULL,
    avatar character varying(100),
    birth_date date,
    public_favorites boolean NOT NULL,
    public_attendance boolean NOT NULL,
    public_coupons boolean NOT NULL
);


ALTER TABLE public.accounts_userprofile OWNER TO postgres;

--
-- Name: accounts_userprofile_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE accounts_userprofile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.accounts_userprofile_id_seq OWNER TO postgres;

--
-- Name: accounts_userprofile_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE accounts_userprofile_id_seq OWNED BY accounts_userprofile.id;


--
-- Name: accounts_userprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('accounts_userprofile_id_seq', 107, true);


--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_group (
    id integer NOT NULL,
    name character varying(80) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_id_seq OWNER TO postgres;

--
-- Name: auth_group_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_group_id_seq OWNED BY auth_group.id;


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_group_permissions (
    id integer NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_group_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_group_permissions_id_seq OWNED BY auth_group_permissions.id;


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_message; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_message (
    id integer NOT NULL,
    user_id integer NOT NULL,
    message text NOT NULL
);


ALTER TABLE public.auth_message OWNER TO postgres;

--
-- Name: auth_message_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_message_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_message_id_seq OWNER TO postgres;

--
-- Name: auth_message_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_message_id_seq OWNED BY auth_message.id;


--
-- Name: auth_message_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_message_id_seq', 1, false);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_permission (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_permission_id_seq OWNER TO postgres;

--
-- Name: auth_permission_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_permission_id_seq OWNED BY auth_permission.id;


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_permission_id_seq', 96, true);


--
-- Name: auth_user; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user (
    id integer NOT NULL,
    username character varying(30) NOT NULL,
    first_name character varying(30) NOT NULL,
    last_name character varying(30) NOT NULL,
    email character varying(75) NOT NULL,
    password character varying(128) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    is_superuser boolean NOT NULL,
    last_login timestamp with time zone NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO postgres;

--
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user_groups (
    id integer NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_groups_id_seq OWNER TO postgres;

--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_groups_id_seq OWNED BY auth_user_groups.id;


--
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_groups_id_seq', 1, false);


--
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_id_seq OWNER TO postgres;

--
-- Name: auth_user_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_id_seq OWNED BY auth_user.id;


--
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_id_seq', 108, true);


--
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE auth_user_user_permissions (
    id integer NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.auth_user_user_permissions_id_seq OWNER TO postgres;

--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE auth_user_user_permissions_id_seq OWNED BY auth_user_user_permissions.id;


--
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('auth_user_user_permissions_id_seq', 1, false);


--
-- Name: chatter_post; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE chatter_post (
    id integer NOT NULL,
    dtcreated timestamp with time zone NOT NULL,
    content character varying(140) NOT NULL,
    author_id integer NOT NULL
);


ALTER TABLE public.chatter_post OWNER TO postgres;

--
-- Name: chatter_post_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE chatter_post_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.chatter_post_id_seq OWNER TO postgres;

--
-- Name: chatter_post_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE chatter_post_id_seq OWNED BY chatter_post.id;


--
-- Name: chatter_post_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('chatter_post_id_seq', 48, true);


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    user_id integer NOT NULL,
    content_type_id integer,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_admin_log_id_seq OWNER TO postgres;

--
-- Name: django_admin_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_admin_log_id_seq OWNED BY django_admin_log.id;


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_admin_log_id_seq', 165, true);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_content_type (
    id integer NOT NULL,
    name character varying(100) NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_content_type_id_seq OWNER TO postgres;

--
-- Name: django_content_type_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_content_type_id_seq OWNED BY django_content_type.id;


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_content_type_id_seq', 32, true);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO postgres;

--
-- Name: django_site; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE django_site (
    id integer NOT NULL,
    domain character varying(100) NOT NULL,
    name character varying(50) NOT NULL
);


ALTER TABLE public.django_site OWNER TO postgres;

--
-- Name: django_site_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE django_site_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.django_site_id_seq OWNER TO postgres;

--
-- Name: django_site_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE django_site_id_seq OWNED BY django_site.id;


--
-- Name: django_site_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('django_site_id_seq', 1, true);


--
-- Name: events_attendee; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE events_attendee (
    id integer NOT NULL,
    user_id integer NOT NULL,
    event_id integer NOT NULL,
    dtcreated timestamp with time zone NOT NULL
);


ALTER TABLE public.events_attendee OWNER TO postgres;

--
-- Name: events_attendee_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE events_attendee_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_attendee_id_seq OWNER TO postgres;

--
-- Name: events_attendee_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE events_attendee_id_seq OWNED BY events_attendee.id;


--
-- Name: events_attendee_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('events_attendee_id_seq', 35, true);


--
-- Name: events_event; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE events_event (
    id integer NOT NULL,
    name character varying(200) NOT NULL,
    description text NOT NULL,
    dtcreated timestamp with time zone NOT NULL,
    dtmodified timestamp with time zone NOT NULL,
    dtstart timestamp with time zone NOT NULL,
    dtend timestamp with time zone NOT NULL,
    allday boolean DEFAULT false NOT NULL,
    url character varying(200) NOT NULL,
    place_id integer,
    place_primitive character varying(200) NOT NULL,
    listed boolean NOT NULL,
    image character varying(100)
);


ALTER TABLE public.events_event OWNER TO postgres;

--
-- Name: events_event_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE events_event_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_event_id_seq OWNER TO postgres;

--
-- Name: events_event_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE events_event_id_seq OWNED BY events_event.id;


--
-- Name: events_event_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('events_event_id_seq', 85, true);


--
-- Name: events_event_tags; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE events_event_tags (
    id integer NOT NULL,
    event_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.events_event_tags OWNER TO postgres;

--
-- Name: events_event_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE events_event_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_event_tags_id_seq OWNER TO postgres;

--
-- Name: events_event_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE events_event_tags_id_seq OWNED BY events_event_tags.id;


--
-- Name: events_event_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('events_event_tags_id_seq', 103, true);


--
-- Name: events_eventmeta; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE events_eventmeta (
    id integer NOT NULL,
    event_id integer NOT NULL,
    key character varying(32) NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.events_eventmeta OWNER TO postgres;

--
-- Name: events_eventmeta_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE events_eventmeta_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_eventmeta_id_seq OWNER TO postgres;

--
-- Name: events_eventmeta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE events_eventmeta_id_seq OWNED BY events_eventmeta.id;


--
-- Name: events_eventmeta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('events_eventmeta_id_seq', 37, true);


--
-- Name: events_icalendarfeed; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE events_icalendarfeed (
    id integer NOT NULL,
    url character varying(300) NOT NULL,
    owner_id integer,
    name character varying(100) NOT NULL
);


ALTER TABLE public.events_icalendarfeed OWNER TO postgres;

--
-- Name: events_icalendarfeed_candidate_places; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE events_icalendarfeed_candidate_places (
    id integer NOT NULL,
    icalendarfeed_id integer NOT NULL,
    place_id integer NOT NULL
);


ALTER TABLE public.events_icalendarfeed_candidate_places OWNER TO postgres;

--
-- Name: events_icalendarfeed_candidate_places_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE events_icalendarfeed_candidate_places_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_icalendarfeed_candidate_places_id_seq OWNER TO postgres;

--
-- Name: events_icalendarfeed_candidate_places_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE events_icalendarfeed_candidate_places_id_seq OWNED BY events_icalendarfeed_candidate_places.id;


--
-- Name: events_icalendarfeed_candidate_places_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('events_icalendarfeed_candidate_places_id_seq', 5, true);


--
-- Name: events_icalendarfeed_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE events_icalendarfeed_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_icalendarfeed_id_seq OWNER TO postgres;

--
-- Name: events_icalendarfeed_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE events_icalendarfeed_id_seq OWNED BY events_icalendarfeed.id;


--
-- Name: events_icalendarfeed_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('events_icalendarfeed_id_seq', 9, true);


--
-- Name: events_role; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE events_role (
    id integer NOT NULL,
    event_id integer NOT NULL,
    role_type character varying(50) NOT NULL,
    organization_id integer NOT NULL
);


ALTER TABLE public.events_role OWNER TO postgres;

--
-- Name: events_role_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE events_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.events_role_id_seq OWNER TO postgres;

--
-- Name: events_role_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE events_role_id_seq OWNED BY events_role.id;


--
-- Name: events_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('events_role_id_seq', 23, true);


--
-- Name: feedback_genericfeedbackcomment; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE feedback_genericfeedbackcomment (
    id integer NOT NULL,
    user_id integer NOT NULL,
    feedback text NOT NULL
);


ALTER TABLE public.feedback_genericfeedbackcomment OWNER TO postgres;

--
-- Name: feedback_genericfeedbackcomment_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE feedback_genericfeedbackcomment_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.feedback_genericfeedbackcomment_id_seq OWNER TO postgres;

--
-- Name: feedback_genericfeedbackcomment_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE feedback_genericfeedbackcomment_id_seq OWNED BY feedback_genericfeedbackcomment.id;


--
-- Name: feedback_genericfeedbackcomment_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('feedback_genericfeedbackcomment_id_seq', 35, true);


--
-- Name: news_article; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE news_article (
    id integer NOT NULL,
    dtcreated timestamp with time zone NOT NULL,
    title character varying(80) NOT NULL,
    blurb text NOT NULL,
    fulltext_url character varying(400) NOT NULL,
    source_name character varying(100) NOT NULL,
    source_site character varying(400) NOT NULL,
    image_url character varying(400) NOT NULL,
    publication_date date NOT NULL
);


ALTER TABLE public.news_article OWNER TO postgres;

--
-- Name: news_article_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE news_article_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.news_article_id_seq OWNER TO postgres;

--
-- Name: news_article_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE news_article_id_seq OWNED BY news_article.id;


--
-- Name: news_article_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('news_article_id_seq', 29, true);


--
-- Name: news_article_related_events; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE news_article_related_events (
    id integer NOT NULL,
    article_id integer NOT NULL,
    event_id integer NOT NULL
);


ALTER TABLE public.news_article_related_events OWNER TO postgres;

--
-- Name: news_article_related_events_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE news_article_related_events_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.news_article_related_events_id_seq OWNER TO postgres;

--
-- Name: news_article_related_events_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE news_article_related_events_id_seq OWNED BY news_article_related_events.id;


--
-- Name: news_article_related_events_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('news_article_related_events_id_seq', 1, true);


--
-- Name: news_article_related_places; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE news_article_related_places (
    id integer NOT NULL,
    article_id integer NOT NULL,
    place_id integer NOT NULL
);


ALTER TABLE public.news_article_related_places OWNER TO postgres;

--
-- Name: news_article_related_places_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE news_article_related_places_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.news_article_related_places_id_seq OWNER TO postgres;

--
-- Name: news_article_related_places_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE news_article_related_places_id_seq OWNED BY news_article_related_places.id;


--
-- Name: news_article_related_places_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('news_article_related_places_id_seq', 20, true);


--
-- Name: places_favorite; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE places_favorite (
    id integer NOT NULL,
    user_id integer NOT NULL,
    place_id integer NOT NULL,
    dtcreated timestamp with time zone NOT NULL
);


ALTER TABLE public.places_favorite OWNER TO postgres;

--
-- Name: places_favorite_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE places_favorite_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.places_favorite_id_seq OWNER TO postgres;

--
-- Name: places_favorite_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE places_favorite_id_seq OWNED BY places_favorite.id;


--
-- Name: places_favorite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('places_favorite_id_seq', 46, true);


--
-- Name: places_location; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE places_location (
    id integer NOT NULL,
    country character varying(2) DEFAULT 'US'::character varying NOT NULL,
    state character varying(2) NOT NULL,
    town character varying(60) NOT NULL,
    postcode character varying(10) NOT NULL,
    address text NOT NULL,
    latitude numeric(9,6),
    longitude numeric(9,6)
);


ALTER TABLE public.places_location OWNER TO postgres;

--
-- Name: places_location_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE places_location_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.places_location_id_seq OWNER TO postgres;

--
-- Name: places_location_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE places_location_id_seq OWNED BY places_location.id;


--
-- Name: places_location_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('places_location_id_seq', 286, true);


--
-- Name: places_place; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE places_place (
    id integer NOT NULL,
    dtcreated timestamp with time zone NOT NULL,
    name character varying(200) NOT NULL,
    location_id integer,
    description text NOT NULL,
    hours text NOT NULL,
    parking character varying(200) NOT NULL,
    phone character varying(200) NOT NULL,
    url character varying(200) NOT NULL,
    fb_id character varying(50) NOT NULL,
    twitter_username character varying(15) NOT NULL,
    listed boolean NOT NULL,
    image character varying(100)
);


ALTER TABLE public.places_place OWNER TO postgres;

--
-- Name: places_place_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE places_place_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.places_place_id_seq OWNER TO postgres;

--
-- Name: places_place_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE places_place_id_seq OWNED BY places_place.id;


--
-- Name: places_place_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('places_place_id_seq', 415, true);


--
-- Name: places_place_tags; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE places_place_tags (
    id integer NOT NULL,
    place_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.places_place_tags OWNER TO postgres;

--
-- Name: places_place_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE places_place_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.places_place_tags_id_seq OWNER TO postgres;

--
-- Name: places_place_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE places_place_tags_id_seq OWNED BY places_place_tags.id;


--
-- Name: places_place_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('places_place_tags_id_seq', 1011, true);


--
-- Name: places_placemeta; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE places_placemeta (
    id integer NOT NULL,
    place_id integer NOT NULL,
    key character varying(32) NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.places_placemeta OWNER TO postgres;

--
-- Name: places_placemeta_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE places_placemeta_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.places_placemeta_id_seq OWNER TO postgres;

--
-- Name: places_placemeta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE places_placemeta_id_seq OWNED BY places_placemeta.id;


--
-- Name: places_placemeta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('places_placemeta_id_seq', 595, true);


--
-- Name: south_migrationhistory; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE south_migrationhistory (
    id integer NOT NULL,
    app_name character varying(255) NOT NULL,
    migration character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.south_migrationhistory OWNER TO postgres;

--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE south_migrationhistory_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.south_migrationhistory_id_seq OWNER TO postgres;

--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE south_migrationhistory_id_seq OWNED BY south_migrationhistory.id;


--
-- Name: south_migrationhistory_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('south_migrationhistory_id_seq', 1, true);


--
-- Name: specials_coupon; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE specials_coupon (
    id integer NOT NULL,
    special_id integer NOT NULL,
    user_id integer NOT NULL,
    dtcreated timestamp with time zone NOT NULL,
    dtused timestamp with time zone,
    was_used boolean DEFAULT false NOT NULL,
    uuid character varying(36) NOT NULL
);


ALTER TABLE public.specials_coupon OWNER TO postgres;

--
-- Name: specials_coupon_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE specials_coupon_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.specials_coupon_id_seq OWNER TO postgres;

--
-- Name: specials_coupon_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE specials_coupon_id_seq OWNED BY specials_coupon.id;


--
-- Name: specials_coupon_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('specials_coupon_id_seq', 14, true);


--
-- Name: specials_special; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE specials_special (
    id integer NOT NULL,
    title character varying(140) NOT NULL,
    description text NOT NULL,
    points integer NOT NULL,
    place_id integer NOT NULL,
    dexpires date,
    dstart date,
    total_available integer,
    total_sold integer DEFAULT 0 NOT NULL,
    dtcreated timestamp with time zone NOT NULL
);


ALTER TABLE public.specials_special OWNER TO postgres;

--
-- Name: specials_special_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE specials_special_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.specials_special_id_seq OWNER TO postgres;

--
-- Name: specials_special_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE specials_special_id_seq OWNED BY specials_special.id;


--
-- Name: specials_special_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('specials_special_id_seq', 7, true);


--
-- Name: specials_special_tags; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE specials_special_tags (
    id integer NOT NULL,
    special_id integer NOT NULL,
    tag_id integer NOT NULL
);


ALTER TABLE public.specials_special_tags OWNER TO postgres;

--
-- Name: specials_special_tags_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE specials_special_tags_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.specials_special_tags_id_seq OWNER TO postgres;

--
-- Name: specials_special_tags_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE specials_special_tags_id_seq OWNED BY specials_special_tags.id;


--
-- Name: specials_special_tags_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('specials_special_tags_id_seq', 11, true);


--
-- Name: specials_specialmeta; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE specials_specialmeta (
    id integer NOT NULL,
    special_id integer NOT NULL,
    key character varying(32) NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.specials_specialmeta OWNER TO postgres;

--
-- Name: specials_specialmeta_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE specials_specialmeta_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.specials_specialmeta_id_seq OWNER TO postgres;

--
-- Name: specials_specialmeta_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE specials_specialmeta_id_seq OWNED BY specials_specialmeta.id;


--
-- Name: specials_specialmeta_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('specials_specialmeta_id_seq', 1, false);


--
-- Name: tags_tag; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tags_tag (
    id integer NOT NULL,
    name character varying(50) NOT NULL,
    dtcreated timestamp with time zone NOT NULL
);


ALTER TABLE public.tags_tag OWNER TO postgres;

--
-- Name: tags_tag_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tags_tag_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tags_tag_id_seq OWNER TO postgres;

--
-- Name: tags_tag_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tags_tag_id_seq OWNED BY tags_tag.id;


--
-- Name: tags_tag_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tags_tag_id_seq', 212, true);


--
-- Name: tastypie_apiaccess; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tastypie_apiaccess (
    id integer NOT NULL,
    identifier character varying(255) NOT NULL,
    url character varying(255) DEFAULT ''::character varying NOT NULL,
    request_method character varying(10) DEFAULT ''::character varying NOT NULL,
    accessed integer NOT NULL,
    CONSTRAINT tastypie_apiaccess_accessed_check CHECK ((accessed >= 0))
);


ALTER TABLE public.tastypie_apiaccess OWNER TO postgres;

--
-- Name: tastypie_apiaccess_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tastypie_apiaccess_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tastypie_apiaccess_id_seq OWNER TO postgres;

--
-- Name: tastypie_apiaccess_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tastypie_apiaccess_id_seq OWNED BY tastypie_apiaccess.id;


--
-- Name: tastypie_apiaccess_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tastypie_apiaccess_id_seq', 1, false);


--
-- Name: tastypie_apikey; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE tastypie_apikey (
    id integer NOT NULL,
    user_id integer NOT NULL,
    key character varying(256) DEFAULT ''::character varying NOT NULL,
    created timestamp with time zone DEFAULT '2012-04-25 10:03:27.939445-04'::timestamp with time zone NOT NULL
);


ALTER TABLE public.tastypie_apikey OWNER TO postgres;

--
-- Name: tastypie_apikey_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE tastypie_apikey_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.tastypie_apikey_id_seq OWNER TO postgres;

--
-- Name: tastypie_apikey_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE tastypie_apikey_id_seq OWNED BY tastypie_apikey.id;


--
-- Name: tastypie_apikey_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('tastypie_apikey_id_seq', 1, false);


--
-- Name: thumbnail_kvstore; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE thumbnail_kvstore (
    key character varying(200) NOT NULL,
    value text NOT NULL
);


ALTER TABLE public.thumbnail_kvstore OWNER TO postgres;

--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY accounts_betamember ALTER COLUMN id SET DEFAULT nextval('accounts_betamember_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY accounts_organization ALTER COLUMN id SET DEFAULT nextval('accounts_organization_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY accounts_organization_administrators ALTER COLUMN id SET DEFAULT nextval('accounts_organization_administrators_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY accounts_organization_establishments ALTER COLUMN id SET DEFAULT nextval('accounts_organization_establishments_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY accounts_userprofile ALTER COLUMN id SET DEFAULT nextval('accounts_userprofile_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group ALTER COLUMN id SET DEFAULT nextval('auth_group_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions ALTER COLUMN id SET DEFAULT nextval('auth_group_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_message ALTER COLUMN id SET DEFAULT nextval('auth_message_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission ALTER COLUMN id SET DEFAULT nextval('auth_permission_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user ALTER COLUMN id SET DEFAULT nextval('auth_user_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups ALTER COLUMN id SET DEFAULT nextval('auth_user_groups_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions ALTER COLUMN id SET DEFAULT nextval('auth_user_user_permissions_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY chatter_post ALTER COLUMN id SET DEFAULT nextval('chatter_post_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log ALTER COLUMN id SET DEFAULT nextval('django_admin_log_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_content_type ALTER COLUMN id SET DEFAULT nextval('django_content_type_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_site ALTER COLUMN id SET DEFAULT nextval('django_site_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY events_attendee ALTER COLUMN id SET DEFAULT nextval('events_attendee_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY events_event ALTER COLUMN id SET DEFAULT nextval('events_event_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY events_event_tags ALTER COLUMN id SET DEFAULT nextval('events_event_tags_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY events_eventmeta ALTER COLUMN id SET DEFAULT nextval('events_eventmeta_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY events_icalendarfeed ALTER COLUMN id SET DEFAULT nextval('events_icalendarfeed_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY events_icalendarfeed_candidate_places ALTER COLUMN id SET DEFAULT nextval('events_icalendarfeed_candidate_places_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY events_role ALTER COLUMN id SET DEFAULT nextval('events_role_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY feedback_genericfeedbackcomment ALTER COLUMN id SET DEFAULT nextval('feedback_genericfeedbackcomment_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY news_article ALTER COLUMN id SET DEFAULT nextval('news_article_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY news_article_related_events ALTER COLUMN id SET DEFAULT nextval('news_article_related_events_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY news_article_related_places ALTER COLUMN id SET DEFAULT nextval('news_article_related_places_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY places_favorite ALTER COLUMN id SET DEFAULT nextval('places_favorite_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY places_location ALTER COLUMN id SET DEFAULT nextval('places_location_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY places_place ALTER COLUMN id SET DEFAULT nextval('places_place_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY places_place_tags ALTER COLUMN id SET DEFAULT nextval('places_place_tags_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY places_placemeta ALTER COLUMN id SET DEFAULT nextval('places_placemeta_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY south_migrationhistory ALTER COLUMN id SET DEFAULT nextval('south_migrationhistory_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY specials_coupon ALTER COLUMN id SET DEFAULT nextval('specials_coupon_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY specials_special ALTER COLUMN id SET DEFAULT nextval('specials_special_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY specials_special_tags ALTER COLUMN id SET DEFAULT nextval('specials_special_tags_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY specials_specialmeta ALTER COLUMN id SET DEFAULT nextval('specials_specialmeta_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tags_tag ALTER COLUMN id SET DEFAULT nextval('tags_tag_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tastypie_apiaccess ALTER COLUMN id SET DEFAULT nextval('tastypie_apiaccess_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tastypie_apikey ALTER COLUMN id SET DEFAULT nextval('tastypie_apikey_id_seq'::regclass);


--
-- Data for Name: accounts_betamember; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY accounts_betamember (id, email) FROM stdin;
1048	sam@iamnotsam.com
570	shawn@shawnpatton.com
572	mcardlebooker@gmail.com
587	jwmullennix@gmail.com
603	outbackapache@gmail.com
616	davidaromanphotography@gmail.com
634	amanda.leff@gmail.com
649	jackie.nameth@gmail.com
664	mrattigan@bc.pitt.edu
681	knitgnosis@hotmail.com
694	cunxiawang@gmail.com
709	tjkelly@alumni.cmu.edu
713	atkins_1@live.com
716	maximilian.bolling@gmail.com
731	brentzel94@gmail.com
746	files@jollybengali.net
761	emily.wolfe@gmail.com
776	katy.peace@gmail.com
793	pilar@unearthlyevil.com
808	deb.lyons@gmail.com
819	jaci.malecki@gmail.com
835	oakcliffehousingclub@gmail.com
851	kkengor@andrew.cmu.edu
855	jamieleonardi@gmail.com
868	princesschaos_z@hotmail.com
881	jenniferannemiller1@gmail.com
898	withlovefrompittsburgh@gmail.com
918	maggieberry74@gmail.com
934	kateas@gmail.com
943	mattphillips1159pm@gmail.com
964	georg.treu@gmail.com
977	andrea.foncerrada@gmail.com
993	hydrospanner@gmail.com
1050	lynne@3guysoptical.com
1051	ali.godfrey29@gmail.com
1053	lizabethgray@gmail.com
1056	nate@parkviewavenue.com
1062	murphyjw@westinghouse.com
1067	mabney2008@gmail.com
1057	kirstenhaliko@gmail.com
1052	cbhurtt@gmail.com
1054	phil@garrow.com
1063	zach.wicks@rhea.us
1068	mwschultz@gmail.com
1058	mcw23@pitt.edu
1055	markopgh@aol.com
1059	bsatt37@directv.net
1064	jrowe@centralcatholichs.com
524	we.wore.a@gmail.com
525	christina.cann@gmail.com
526	samidani2001@yahoo.com
527	jkurjakovic@gmail.com
528	bgbm67@gmail.com
529	sh33la@yahoo.com
530	hickeykate8@gmail.com
531	rezosilverleaf@gmail.com
532	nakiabeasley@gmail.com
533	brett@onlyinpgh.com
534	sueheadley@comcast.net
535	beachgirlroxy@gmail.com
536	eric_aixelsyd@yahoo.com
537	timcook08@gmail.com
538	carolyn0219@gmail.com
539	jasst282@gmail.com
540	mona.abdelhalim@gmail.com
541	tristamj@hotmail.com
542	dabeny4@gmail.com
543	becky.utech@gmail.com
544	jocaur@earthlink.net
545	frieze@pitt.edu
546	megology@gmail.com
547	poninsky@hotmail.com
548	inxsfan11@gmail.com
549	spmckain@gmail.com
550	oneregalbeagle@gmail.com
551	odana.chaney@gmail.com
552	lilpolowy@gmail.com
553	askannienow@gmail.com
554	lee@3rd-river.com
555	dlecker@hotmail.com
556	sugarmag@live.com
557	pghgurl30@gmail.com
558	jegrasso@gmail.com
559	b.orionis@gmail.com
560	dly0509@gmail.com
561	cmt2k2@gmail.com
562	erinmarink@gmail.com
563	crafton5@gmail.com
564	martybobb@yahoo.com
565	mbelblidia@gmail.com
566	mumiller333@gmail.com
567	chuck.alcorn@gmail.com
568	mccracken.joel@gmail.com
569	photobones@gmail.com
1060	vkrishnamurthy@ptilabs.com
1065	rdillie@gmail.com
571	jlongstreth@comcast.net
573	aetaylor@gmail.com
574	luminousechoes@gmail.com
575	onlyinpgh@orangewombat.com
576	katie.vojtko@gmail.com
577	jschubert@cmu.edu
578	amycity911@yahoo.com
579	charlene.gentile@comcast.net
580	brian.donovan1@verizon.net
581	lpchad@gmail.com
582	aliciamhawkins@gmail.com
583	danpotter13@yahoo.com
584	hill.cmh@gmail.com
585	pgreenwood11@gmail.com
586	kb3fxi@yahoo.com
588	digitalalan@gmail.com
589	biggandyy@gmail.com
590	talia.piazza@yahoo.com
591	eringill9@gmail.com
592	habeggerrl@gmail.com
593	laras126@gmail.com
594	murphy8486@gmail.com
595	jdgallagher79@gmail.com
596	earabu@yahoo.com
597	greg.nicholas@gmail.com
598	ajbutkus@gmail.com
599	kura.stephen@gmail.com
600	madsen.elizabeth@gmail.com
601	mary@oaklandbid.org
602	tak_15217@yahoo.com
604	kerryherrmann@aol.com
605	gary-marty@att.net
606	julie_smith@ymail.com
607	skqkorn@gmail.com
608	xto951@yahoo.com
609	halley@taeradio.com
610	chachisays@gmail.com
611	wrry.ebayk1d@gmail.com
612	alan@laickdesign.com
613	douglaslgraham@verizon.net
614	joe.manno@gmail.com
615	lourainaldi@gmail.com
617	acsingh@andrew.cmu.edu
618	jiasheng@andrew.cmu.edu
619	mayf.mark@gmail.com
620	maisiesdaddy@gmail.com
621	amishjim@amishjim.com
622	jaredj@frontiernet.net
623	poehler@interworx.com
624	mmjsims89@yahoo.com
625	sub@brillout.com
626	gabbro.mario@gmail.com
627	wlaboon@yahoo.com
628	gregory.seaman@gmail.com
629	harperlafave@gmail.com
630	j.frech@hotmail.com
631	scubapeter@gmail.com
632	jtyak1@gmail.com
633	aayushkumar@gmx.com
635	tobejohngalt2@gmail.com
636	theresa.gourash@gmail.com
637	ilovemyglasses@gmail.com
638	rosecreek@ymail.com
639	allison.kole@gmail.com
640	deving44@gmail.com
641	john.ladue@gmail.com
642	bbavar@gmail.com
643	cobracommandrew@gmail.com
644	oakland15213@gmail.com
645	seltzerkid1@yahoo.com
646	odonnellrb@yahoo.com
647	richeditor@hotmail.com
648	jpayne10@gmail.com
650	kboehne@cmu.edu
651	becca@cmu.edu
652	elizabethcullinan@gmail.com
653	sandystlouis@gmail.com
654	ian.everhart@gmail.com
655	kvasilev@cmu.edu
656	itisbenjamin@yahoo.com
657	hayleyerin6@hotmail.com
658	douhavkukudarosis@yahoo.com
659	jtoy@chatham.edu
660	myritas@yahoo.com
661	wakened@gmail.com
662	dianem677@gmail.com
663	wynglasses@gmail.com
665	elliottw@gmail.com
666	beaker555@aol.com
667	damianliska@gmail.com
668	nathankinnicutt@gmail.com
669	jspeedy@cmu.edu
670	ashleyedavies@gmail.com
671	jcohan@andrew.cmu.edu
672	patriciadbeasley@gmail.com
673	angelashley@gmail.com
674	soundarya.c@gmail.com
675	ketakid@andrew.cmu.edu
676	sstroney@andrew.cmu.edu
677	kt.takai@gmail.com
678	mannar_kns@yahoo.co.in
679	danaerinw@gmail.com
680	bstephenson@cmu.edu
682	eubanks@telys.net
683	aaronmsiegel@gmail.com
684	jaydp1@gmail.com
685	jonathan.ortiz4@gmail.com
686	litan880620@gmail.com
687	ndellomo@cmu.edu
688	james.m.ranson@gmail.com
689	sandrzej@andrew.cmu.edu
690	ayshwaryasubramanian@gmail.com
691	panguili9@gmail.com
692	jalleyne@tepper.cmu.edu
693	aabhavna@andrew.cmu.edu
695	laurazwicker@gmail.com
696	htaytslin@gmail.com
697	mbiggs@andrew.cmu.edu
698	ackilly@gmail.com
699	elyssagj@gmail.com
700	djw382@gmail.com
701	rewilkin@andrew.cmu.edu
702	audmusic@gmail.com
703	cah920@yahoo.com
704	anupshete@gmail.com
705	bryan.r.spencer@gmail.com
706	markmusolino@gmail.com
707	abdallamusmar@hotmail.com
708	dwaterma@andrew.cmu.edu
710	eteves@gmail.com
711	jmh@nilbog.com
712	alishams@gmail.com
714	ekitzerow@gmail.com
715	davemc9ee@gmail.com
717	yusanc@andrew.cmu.edu
718	pachicka@gmail.com
719	oconaire@gmail.com
720	zhaomengqian@gmail.com
721	april.clisura@gmail.com
722	elizabethq15@yahoo.com
723	tammyy@andrew.cmu.edu
724	liz.tillman@ymail.com
725	ieverhar@andrew.cmu.edu
726	alisonkelley@gmail.com
727	ken15135@yahoo.com
728	danahardek@gmail.com
729	leahmarie22@gmail.com
730	a_n_kougher@yahoo.com
732	susanapa28@gmail.com
733	em14809@gmail.com
734	jtrack18@hotmail.com
735	stacys@wendtonline.net
736	4heidihay@bellsouth.net
737	zafodsgirl@gmail.com
738	rtunsel@yahoo.com
739	ssc1478@aim.com
740	christinagroschwitz@ymail.com
741	jcatarc@hotmail.com
742	elysia@groschwitz.com
743	kohler_ryan@hotmail.com
744	bethany.getgen@gmail.com
745	tpclougherty@gmail.com
747	blueeley@gmail.com
748	brandibonkowski@hotmail.com
749	junebug228503@yahoo.com
750	gonzales_ac@yahoo.com
751	erinleepayne@gmail.com
752	egriffin@aii.edu
753	jbcoleburger@yahoo.com
754	smarchit@yahoo.com
755	amonet720@hotmail.com
756	anitaadalja@gmail.com
757	helenteri@gmail.com
758	mgs39@pitt.edu
759	hmcelwee@gmail.com
760	tarat@opdc.org
762	irishsince78@gmail.com
763	bigdaddy000078@yahoo.com
764	spaz86@gmail.com
765	oewing@knights.ucf.edu
766	flora.chesnalee@sfr.fr
767	mull809@comcast.net
768	bigben@gmail.com
769	matt.mccauley@gmail.com
770	spanishweasel@hotmail.com
771	shawnsnyder@gmail.com
772	bobs@dicks.com
773	mumbo320@hotmail.com
774	sbeaches@gmail.com
775	shawnsnyder2@gmail.com
777	andrewdkilmer@gmail.com
778	alisonlucci@gmail.com
779	bthsafran@gmail.com
780	grecoj13@yahoo.com
781	squirrelsndeer@gmail.com
782	sfina28@yahoo.com
783	hannah.wirginis@gmail.com
784	bradley_roth@rbradleyinvests.com
785	carrie.peter521@gmail.com
786	renee.williams@rosebudmining.com
787	djpjata@aol.com
788	vicki.linn4@gmail.com
789	reginaann22@hotmail.com
790	butt@fucker.com
791	crlynton06@aol.com
792	darrlr@zbzoom.net
794	nannerz10115210@yahoo.com
795	tomlawson412@gmail.com
796	erkemcgrath@gmail.com
797	kimrader111@yahoo.com
798	marianne.massey@ymail.com
799	eliza.kohler@gmail.com
800	reisy20@yahoo.com
801	popsi@live.com
802	asnyder@ondemandenergy.com
803	cgibbons14@gmail.com
804	lukemortimer@hotmail.com
805	mandyholbrook@gmail.com
806	wendylan2@aol.com
807	looricjm@yahoo.com
809	mmhughes61@gmail.com
810	paulie.anne@gmail.com
811	erin.lin.hubbard@gmail.com
812	tiggerd524@hotmail.com
813	alex_prvanovic@yahoo.com
814	romabby@gmail.com
815	terrayoungblood@yahoo.com
816	jrusso@pittohio.com
817	tapestrygirl@gmail.com
818	klyons71@gmail.com
820	lilmissbossypants@gmail.com
821	laura.kelly1987@gmail.com
822	loribknox@yahoo.com
823	seancluther@gmail.com
824	ajkuftic@gmail.com
825	gaross@gmail.com
826	beth910@me.com
827	amy_j_watson@yahoo.com
828	brianlinn07@gmail.com
829	alecisalec@gmail.com
830	jchristopher2@aol.com
831	cc@cc.com
832	jonnysunsett@yahoo.com
833	havieramaci@gmail.com
834	david@djoven.com
836	wbt+sceneable@cs.cmu.edu
837	gauglerj@carnegiemuseums.org
838	rmm411@hotmail.com
839	yunziyinz@gmail.com
840	dewayne.mikkelson@wellsfargo.com
841	kjsaftner@gmail.com
842	hkgurl89@aol.com
843	daniel.brown@yahoo.com
844	rjarabeck@bc.pitt.edu
845	jdigioia@mac.com
846	pseisele@gmail.com
847	catoneiv@yahoo.com
848	bamiano@me.com
849	kdiddy.org@gmail.com
850	epagelhogan@gmail.com
852	cupongunny@gmail.com
853	ginamgodfrey@gmail.com
854	nat.bowman1@gmail.com
856	annegeever@yahoo.com
857	flyingz.news@me.com
858	rarickard@yahoo.com
859	bkatz51@gmail.com
860	kristen_h@hotmail.com
861	alisonboden@gmail.com
862	sylvia@groschwitz.com
863	sayray18@gmail.com
864	marionwolfe@gmail.com
865	joseph.c.laneve@gmail.com
866	sara.norelli@gmail.com
867	ernie@ernieandtheberts.com
869	pghmedia@gmail.com
870	kymmyharper@gmail.com
871	samuel.mudrick@gmail.com
872	jesse.andrews@gmail.com
873	chachnet@hotmail.com
874	josuch@aol.com
875	andyarnt+scenable@gmail.com
876	camogirl1206@gmail.com
877	drock.djb@gmail.com
878	cassidygruber@gmail.com
879	chihli.dog@gmail.com
880	ken@calebwalker.com
882	jon.dawood@gmail.com
883	sbularzik@gmail.com
884	adammusic@yahoo.com
885	williams.jaydee@gmail.com
886	samuelweissberg@hotmail.com
887	r.fausz@yahoo.com
888	krinsin@sbcglobal.net
889	cpembleton7@comcast.net
890	taz19m@hotmail.com
891	skamzelski@hotmail.com
892	redvel442@hotmail.com
893	casey.harvilla@gmail.com
894	tributesinger@gmail.com
895	scottydont715@comcast.net
896	shannon.lindemer@gmail.com
897	j.q.sanders@gmail.com
899	dawida.novelly@gmail.com
900	breanna.jay@gmail.com
901	michaeldpound@gmail.com
902	nicole.talak@live.com
903	albamaria30@verizon.net
904	andreadisaster@gmail.com
905	jessica.rudmin@gmail.com
906	carla.swank@gmail.com
907	flynniejenn81@aol.com
908	todd.barr@gmail.com
909	tvsociety@gmail.com
910	anniebarge@atlanticbb.net
911	jodysampson@gmail.com
912	kwedwards99@hotmail.com
913	mcecil@hunterconsulting.com
914	curvesaheadll@yahoo.com
915	rwild1s@aol.com
916	susan.lee0816@yahoo.com
917	treen2113@gmail.com
919	hubie716@hotmail.com
920	kelly.a.stewart@gmail.com
921	happek@gmail.com
922	kfneedham@comcast.net
923	erincclark@gmail.com
924	cperry1@gmail.com
925	burrowrodney@yahoo.com
926	johnst.leger@gmail.com
927	yeradhere@yahoo.com
928	sarahsudar@gmail.com
929	ceh74@hotmail.com
930	skv8224@yahoo.com
931	jtienes@gmail.com
932	bjles@verizon.net
933	izzy54@excite.com
935	jim@blindb.com
936	ambriski@yahoo.com
937	jackie.sorg@gmail.com
938	emily.wachelka@gmail.com
939	kml45@pitt.edu
940	leeannsell@gmail.com
941	saraeckelberry@yahoo.com
942	rolan1bp@gmail.com
944	mimiusa@comcast.net
945	jpozum@hotmail.com
946	kxm72@yahoo.com
947	welshwitch78@hotmail.com
948	nurseshort@gmail.com
949	babs@carryer.com
950	rytwalker@gmail.com
951	erikaw@tepper.cmu.edu
952	aubrey.bruggeman@gmail.com
953	dmcfadden60@yahoo.com
954	deja.locust@cityhigh.com
955	abbynkeil@gmail.com
956	jensley@vons-ub.com
957	contact@logiclounge.com
958	rd@vbgroup.org
959	brittanyreno@gmail.com
960	rranallo@opdc.org
961	seanpodonnell@gmail.com
962	jld2@pitt.edu
963	panasiukm@aol.com
965	tarrja@upmc.edu
966	spranis@vistahost.net
967	jeremydamon@gmail.com
968	jordonbiondi@gmail.com
969	jieshic@andrew.cmu.edu
970	akilh@andrew.cmu.edu
971	smathers@andrew.cmu.edu
972	zechery@hanmail.net
973	mcelhanyka@gmail.com
974	jessicatvarone@gmail.com
975	ben@avenirex.com
976	jis51@pitt.edu
978	rachelszewczyk@gmail.com
979	liuyaner@live.cn
980	ckeene@tepper.cmu.edu
981	drrick106@aol.com
982	vrabell@carnegielibrary.org
983	holly.anderton@gmail.com
984	pbghgirl@gmail.com
985	rlholljr1@att.net
986	klbarnesrn@gmail.com
987	sarahhaley66@gmail.com
988	hansonkappelman@gmail.com
989	mark@revvoakland.com
990	ahb21@pitt.edu
991	gopens1950@aol.com
992	lak14@pitt.edu
994	esalinge@gmail.com
995	janicelorenz@gmail.com
996	bev55k@yahoo.com
998	rruppen@ucpclass.org
999	hollyleaf1@verizon.net
1000	ccolledge1@verizon.net
1001	mark@mnkramer.com
1002	cmekramer@gmail.com
1003	georgia@oaklandbid.org
1004	alex@oaklandbid.org
1005	seanammirati@gmail.com
1006	jjen@innovationworks.org
1007	mwoycheck@alphalab.org
1008	mrmawhinney@gmail.com
1009	kit@cs.cmu.edu
1010	mdepaul@gmail.com
1011	bdavidson@pcrg.org
1012	tjzak@andrew.cmu.edu
1013	c.koch@gtechstrategies.org
1014	manderson@penncom.com
1015	rranallo@opdc.org
1016	carolhurley@hurley2.com
1017	bhurley@hurleybrokers.com
1018	elizabeth@dentalpgh.com
1019	mrattigan@bc.pitt.edu
1020	togs3800@verizon.net
1021	qsl.oakland@gmail.com
1022	lynne@eyetique.com
1023	ting@sushifuku.com
1024	drrick106@aol.com
1025	jrutkowski@familyhouse.org
1026	sirspeedy@choiceonemail.com
1027	lclaytor@s2c.opdc.org
1028	townsendbooksellers@earthlink.net
1029	rlb13@pitt.edu
1030	nate.newbalancepgh@gmail.com
1031	kathy.degler@pittsburghpa.gov
1032	wilds@pitt.edu
1033	dgancy@yahoo.com
1034	milanospizza2@comcast.net
1035	tschmittataceathletic@verizon.net
1036	lcsciannameo@carlow.edu
1037	nate.newbalancepgh@gmail.com
1038	joe@hiebers.com
1039	med.center.opt@gmail.com
1040	abriolamp@aol.com
1041	peaceloveandlittledonuts@yahoo.com
1042	jas.bhangal@gmail.com
1043	jdopirak@undergroundshirts.com
1044	bhkbusiness@gmail.com
1045	attic@aol.com
1046	kmcbroom872@dollarbank.com
1047	nickpawlenko@gmail.com
1061	km3701@yahoo.com
1066	ebt256@gmail.com
1069	bperry@opdc.org
1070	hilary@muffinmanstudios.com
1071	painholic@gmail.com
1072	zachery.ambrose@alleghenycounty.us
1073	kkunak@gmail.com
1074	candice.gonzalez@pittsburghpa.gov
1075	customerservice@pittsburghpretzel.com
1076	ablavin@gmail.com
1077	smileandlaughoften@gmail.com
1078	demarco@hilton.com
\.


--
-- Data for Name: accounts_organization; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY accounts_organization (id, name, dtcreated, image, url, fb_id, twitter_username) FROM stdin;
1	Oakland Business Improvement District	2012-04-13 08:41:02.082844-04				
3	Rick Gottlieb DMD	2012-04-13 10:57:57.812528-04				
2	Touch of Gold and Silver Jewelry Store	2012-04-13 10:26:14.28268-04				
4	Drs. Werrin, Gruendel & Boles	2012-04-12 11:10:05.422127-04				
5	Scenable	2012-04-13 11:06:18.160706-04				
6	Maggie & Stella's 	2012-04-17 15:58:28.285827-04				
7	Oakland Planning and Development Corporation	2012-04-18 18:16:02.457217-04				
8	Red oak	2012-04-19 14:09:54.824356-04				
9	Carnegie Library of Pittsburgh	2012-04-28 13:59:24.697035-04				
10	Underground Printing	2012-05-01 16:55:52.13227-04				
11	New Balance Pittsburgh	2012-05-02 08:58:04.736243-04				
12	Pennsylvania Commercial Real Estate, Inc.	2012-05-02 09:46:48.969568-04				
13	Carnegie Museum of Art	2012-05-03 14:10:36.364179-04				
14	Quaker Steak & Lube	2012-05-09 11:06:03.604793-04				
15	3 Guys Optical	2012-05-09 14:55:04.184653-04				
16	Hurley Insurance Brokers, Inc.	2012-05-09 15:20:50.587286-04				
17	Original Milano Pizza	2012-05-12 10:17:45.716686-04				
18	Hurley Insurance Brokers, Inc.	2012-05-22 15:23:55.652925-04				
\.


--
-- Data for Name: accounts_organization_administrators; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY accounts_organization_administrators (id, organization_id, user_id) FROM stdin;
1	1	1
2	1	2
3	3	5
4	2	3
5	4	4
6	5	6
7	6	7
8	7	8
9	8	9
10	9	10
11	10	11
12	11	12
13	12	13
14	13	54
15	14	69
16	15	70
17	16	71
18	17	87
19	18	102
\.


--
-- Data for Name: accounts_organization_establishments; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY accounts_organization_establishments (id, organization_id, place_id) FROM stdin;
1	1	60
2	3	405
3	2	404
4	4	109
5	5	62
6	6	7
7	7	62
8	8	282
9	9	195
10	10	279
11	11	166
12	13	196
13	14	118
14	15	233
15	17	122
16	5	78
17	5	410
\.


--
-- Data for Name: accounts_userprofile; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY accounts_userprofile (id, user_id, points, fb_id, twitter_username, display_name, gender, neighborhood, fb_id_public, twitter_username_public, avatar, birth_date, public_favorites, public_attendance, public_coupons) FROM stdin;
3	3	0						t	t	\N	\N	t	f	t
4	4	0						t	t	\N	\N	t	f	t
5	5	0						t	t	\N	\N	t	f	t
7	7	0						t	t	\N	\N	t	f	t
8	8	0						t	t	\N	\N	t	f	t
9	9	0						t	t	\N	\N	t	f	t
10	10	0						t	t	\N	\N	t	f	t
11	11	0						t	t	\N	\N	t	f	t
12	12	0						t	t	\N	\N	t	f	t
13	13	0						t	t	\N	\N	t	f	t
49	50	0				F	Plum	f	f		1983-08-29	f	f	f
50	51	0				M	Oakland	f	f		1956-12-17	f	f	f
45	46	0				F	North Oakland	f	f		1949-03-23	f	f	f
51	52	0						f	f		\N	f	f	f
52	53	0				F	Squirrel Hill	f	f		2059-12-22	f	f	f
53	54	0						t	t		\N	t	f	t
54	55	0				F	Glenshaw	f	f		1982-09-12	f	f	f
6	6	0		ScenableApp				f	f	img/a/Brett_headshot.jpg	\N	t	f	t
55	56	0						f	f		\N	f	f	f
71	72	0				F	Shadyside	f	f		1987-04-13	f	f	f
19	20	0		minty985	Patti	F	North Side	f	f	img/a/Profile.jpg	1985-09-24	f	f	f
14	15	0		laras126	laroo	F	Friendship	f	f	img/a/photo.jpg	1989-12-03	t	f	t
16	17	0				F	Grindstone	f	f		1970-09-25	f	f	f
17	18	0				M	Lawrenceville	f	f		1981-07-27	f	f	f
18	19	0				F	Squirrel Hill	f	f		1961-08-15	f	f	f
15	16	0		gregariousdev	Greg Nicholas	M	Lawrenceville	f	f	img/a/greg.jpg	1984-03-22	t	t	t
20	21	0				M		f	f		1986-03-20	f	f	f
21	22	0				F	Highland Park	f	f		1984-05-27	f	f	f
56	57	0						f	f		\N	f	f	f
24	25	0				M	O'Hara Township	f	f		1985-05-16	f	f	f
57	58	0				M	Cranberry	f	f		1966-03-30	f	f	f
58	59	0				F	Shadyside	f	f		1986-08-03	f	f	f
23	24	0		alisonvoss		F	SF	f	f		1983-05-08	f	f	f
25	26	0						f	f		\N	f	f	f
26	27	0				F	Oakland	f	f		1965-02-28	f	f	f
27	28	0				M	Shadyside	f	f		1967-04-11	f	f	f
28	29	0				M	Carrick	f	f		1982-10-05	f	f	f
29	30	0				F	Highland Park	f	f		1987-06-01	f	f	f
30	31	0				F	Highland Park	f	f		1953-08-30	f	f	f
31	32	0				M	Johnstown	f	f		1986-03-25	f	f	f
32	33	0				F	turtle creek, pa	f	f		1989-01-29	f	f	f
33	34	0				F	Park Place	f	f		1972-12-27	f	f	f
34	35	0				M	Oakland	f	f		1978-02-14	f	f	f
35	36	0				F	Mt. Lebanon	f	f		1967-07-09	f	f	f
36	37	0				M	North Point Breeze	f	f		1984-02-27	f	f	f
37	38	0				F	Squirrel Hill	f	f		1960-04-07	f	f	f
38	39	0				M	North Oakland	f	f		1956-04-01	f	f	f
39	40	0				M	North Point Breeze	f	f		1980-08-01	f	f	f
59	60	0				F	Greenfield	f	f		1973-04-27	f	f	f
2	2	0		Only_in_Oakland				f	f		\N	t	t	t
40	41	0				F	Regent Square	f	f		2068-07-31	f	f	f
41	42	0				F	Greenfield	f	f		1984-03-14	f	f	f
42	43	0				F	Squirrel Hill	f	f		1982-10-22	f	f	f
43	44	0				M	Squirrel Hill	f	f		1964-07-30	f	f	f
60	61	0				M	Greenfield	f	f		1987-03-16	f	f	f
61	62	0				M	South Side Slopes	f	f		1982-10-10	f	f	f
62	63	0				F	oakland	f	f		1991-01-30	f	f	f
46	47	0				M	highland park	f	f		1982-07-11	f	f	f
1	1	0		ScenableApp				f	f	img/a/app-icon-square.png	\N	t	f	t
72	73	0				F	Oakland	f	f		1990-06-29	f	f	f
44	45	0			TC		Bloomfield	f	f	img/a/GAPCandOtrip2009_543_1.jpg	\N	t	f	f
22	23	0				M	Oakland	f	f		1907-04-16	f	f	f
47	48	0				F	Dormont	f	f		1981-06-01	f	f	f
48	49	0				M	West Oakland	f	f		1974-01-07	f	f	f
63	64	0		avenirex	Benjamin	M	Shadyside	f	f		1981-10-29	t	t	f
73	74	0				M	South Oakland	f	f		1963-12-08	f	f	f
74	75	0				F	Oakcliffe	f	f		1956-03-09	f	f	f
65	66	0					Lawrenceville	f	f		\N	f	f	f
66	67	0						f	f		\N	f	f	f
67	68	0				M	Bloomfield	f	f		1977-12-05	f	f	f
68	69	0						t	t		\N	t	f	t
69	70	0						t	t		\N	t	f	t
70	71	0						t	t		\N	t	f	t
75	76	0				F		f	f		1989-01-14	f	f	f
76	77	0				F	Oakland	f	f		1989-04-26	f	f	f
77	78	0				M	Greenfield	f	f		1979-05-20	f	f	f
78	79	0				M	Lawrenceville	f	f		1976-10-04	f	f	f
80	81	0				M	Charlotte	f	f		1958-01-14	f	f	f
79	80	0				F	Shadyside	f	f	img/a/316752_10150364109521797_505861796_7934370_1084012133_n.jpg	1986-11-24	f	f	f
81	82	0				F	Shadyside	f	f		1979-05-23	f	f	f
82	83	0				F	Shadyside	f	f		1990-08-02	f	f	f
83	84	0				M	Friendship	f	f		1985-12-17	f	f	f
84	85	0				M	Forest Hills	f	f		1981-08-05	f	f	f
85	86	0				F	Southside	f	f		1991-03-17	f	f	f
86	87	0						t	t		\N	t	f	t
87	88	0				M	Shadyside	f	f		1985-07-28	f	f	f
88	89	0				F	Squirrel Hill	f	f		1990-01-19	f	f	f
89	90	0				F	Shadyside	f	f		1987-10-07	f	f	f
90	91	0				F	Squirrel Hill	f	f		1985-12-29	f	f	f
91	92	0				F	Dormont	f	f		\N	f	f	f
92	93	0				M	Shadyside	f	f		1984-08-21	f	f	f
93	94	0				F	Kennedy	f	f		1993-08-14	f	f	f
94	95	0				F	friendship	f	f		1985-10-01	f	f	f
95	96	0				F	Shadyside	f	f		2058-07-19	f	f	f
96	97	0					Fox Chapel	f	f		\N	f	f	f
97	98	0				F	Regent Square	f	f		1983-03-10	f	f	f
98	99	0				F	Highland Park	f	f		1971-11-28	f	f	f
64	65	0		jasst282	JenS	F	Oakland	f	f	img/a/P1050012.JPG	1982-01-03	f	f	f
99	100	0				M	Oakland	f	f		1974-05-17	f	f	f
100	101	0				M	Northside	f	f		1983-08-06	f	f	f
101	102	0						t	t		\N	t	f	t
102	103	0					Oakland	f	f		\N	f	f	f
103	104	0				M	Shadyside	f	f		\N	f	f	f
104	105	0				F	Oakland	f	f		1990-07-06	f	f	f
105	106	0				F	Brighton Heights	f	f		1982-01-15	f	f	f
106	107	0				M	Shadyside	f	f		1980-02-24	f	f	f
107	108	0						t	t		\N	t	f	t
\.


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_message; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_message (id, user_id, message) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add permission	1	add_permission
2	Can change permission	1	change_permission
3	Can delete permission	1	delete_permission
4	Can add group	2	add_group
5	Can change group	2	change_group
6	Can delete group	2	delete_group
7	Can add user	3	add_user
8	Can change user	3	change_user
9	Can delete user	3	delete_user
13	Can add content type	5	add_contenttype
14	Can change content type	5	change_contenttype
15	Can delete content type	5	delete_contenttype
16	Can add session	6	add_session
17	Can change session	6	change_session
18	Can delete session	6	delete_session
19	Can add site	7	add_site
20	Can change site	7	change_site
21	Can delete site	7	delete_site
22	Can add log entry	8	add_logentry
23	Can change log entry	8	change_logentry
24	Can delete log entry	8	delete_logentry
25	Can add migration history	9	add_migrationhistory
26	Can change migration history	9	change_migrationhistory
27	Can delete migration history	9	delete_migrationhistory
28	Can add kv store	10	add_kvstore
29	Can change kv store	10	change_kvstore
30	Can delete kv store	10	delete_kvstore
31	Can add user profile	11	add_userprofile
32	Can change user profile	11	change_userprofile
33	Can delete user profile	11	delete_userprofile
34	Can add tag	12	add_tag
35	Can change tag	12	change_tag
36	Can delete tag	12	delete_tag
37	Can add location	13	add_location
38	Can change location	13	change_location
39	Can delete location	13	delete_location
40	Can add place	14	add_place
41	Can change place	14	change_place
42	Can delete place	14	delete_place
43	Can add place meta	15	add_placemeta
44	Can change place meta	15	change_placemeta
45	Can delete place meta	15	delete_placemeta
46	Can add favorite	16	add_favorite
47	Can change favorite	16	change_favorite
48	Can delete favorite	16	delete_favorite
49	Can add organization	17	add_organization
50	Can change organization	17	change_organization
51	Can delete organization	17	delete_organization
52	Can add event	18	add_event
53	Can change event	18	change_event
54	Can delete event	18	delete_event
55	Can add event meta	19	add_eventmeta
56	Can change event meta	19	change_eventmeta
57	Can delete event meta	19	delete_eventmeta
58	Can add role	20	add_role
59	Can change role	20	change_role
60	Can delete role	20	delete_role
61	Can add attendee	21	add_attendee
62	Can change attendee	21	change_attendee
63	Can delete attendee	21	delete_attendee
64	Can add i calendar feed	22	add_icalendarfeed
65	Can change i calendar feed	22	change_icalendarfeed
66	Can delete i calendar feed	22	delete_icalendarfeed
67	Can add special	23	add_special
68	Can change special	23	change_special
69	Can delete special	23	delete_special
70	Can add special meta	24	add_specialmeta
71	Can change special meta	24	change_specialmeta
72	Can delete special meta	24	delete_specialmeta
73	Can add coupon	25	add_coupon
74	Can change coupon	25	change_coupon
75	Can delete coupon	25	delete_coupon
76	Can add api access	26	add_apiaccess
77	Can change api access	26	change_apiaccess
78	Can delete api access	26	delete_apiaccess
79	Can add api key	27	add_apikey
80	Can change api key	27	change_apikey
81	Can delete api key	27	delete_apikey
82	Can add beta member	28	add_betamember
83	Can change beta member	28	change_betamember
84	Can delete beta member	28	delete_betamember
85	Can add article	29	add_article
86	Can change article	29	change_article
87	Can delete article	29	delete_article
88	Can add post	30	add_post
89	Can change post	30	change_post
90	Can delete post	30	delete_post
91	Can add generic feedback comment	31	add_genericfeedbackcomment
92	Can change generic feedback comment	31	change_genericfeedbackcomment
93	Can delete generic feedback comment	31	delete_genericfeedbackcomment
94	Can add organization	32	add_organization
95	Can change organization	32	change_organization
96	Can delete organization	32	delete_organization
\.


--
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user (id, username, first_name, last_name, email, password, is_staff, is_active, is_superuser, last_login, date_joined) FROM stdin;
30	reflechir			jieshic@andrew.cmu.edu	pbkdf2_sha256$10000$BLT7njc4nNXk$YNlst5mReYcz3D3cEdQgMtTYLg+ffPBC5ZzCx9gZ89w=	f	t	f	2012-05-21 22:17:27.981226-04	2012-05-03 07:54:13.662706-04
12	nbpgh			nate.newbalancepgh@gmail.com	pbkdf2_sha256$10000$z91vCwyvQSxs$PHP5o1zcj9y61JeNBc98P5qWaYsWioFMETOVnR0sciU=	f	t	f	2012-05-02 08:58:04.874782-04	2012-05-02 08:58:04.555023-04
4	wgbdentist			elizabeth@dentalpgh.com\t	sha1$f2d75$3bcc3322bccdc5aee711845cce7baf0fcfbc8c3b	f	t	f	2012-04-12 11:31:34.014021-04	2012-04-12 11:10:05.387077-04
13	manderson			manderson@penncom.com	pbkdf2_sha256$10000$DO9wG22TWlzD$PNTHhXbqayVwh6WDPS1AIUQjYxGupCqZkJ44gC3gxhA=	f	t	f	2012-05-02 09:46:49.11746-04	2012-05-02 09:46:48.828339-04
19	tak_15217			tak_15217@yahoo.com	pbkdf2_sha256$10000$Xh0JtYZcduLP$vcqpgC/GBq8jSqUG+IrSaRuD9i9ZfKAmKYFENCwHzZs=	f	t	f	2012-05-02 23:14:14.213991-04	2012-05-02 23:14:13.840806-04
26	dmurph10			murphy8486@gmail.com	pbkdf2_sha256$10000$mv9U9lwBqWzP$nr0/SDE6mj3fuLbYJJiBpvKfCT/bjzOaf1jh9fKz9WM=	f	t	f	2012-05-11 16:54:56.188418-04	2012-05-03 01:08:20.349379-04
21	hydrospanner			hydrospanner@gmail.com	pbkdf2_sha256$10000$E5wMmrtyo07L$Qe8FRwFe92ngPXaKjzGa3+1OQaPjod19HhEfO3FR7uE=	f	t	f	2012-05-02 23:20:50.155565-04	2012-05-02 23:20:49.862916-04
22	monafro			mona.abdelhalim@gmail.com	pbkdf2_sha256$10000$HnSLsb2FH2SZ$zVpZ+4BLx5VxFrckXJw+JUhvJwX5D8B3ylPbCXknYNI=	f	t	f	2012-05-02 23:21:16.972978-04	2012-05-02 23:21:16.68277-04
25	bbavar			bbavar@gmail.com	pbkdf2_sha256$10000$U4W9u3vVuLhi$rCEYh6ulEZv6vPENEgmTXiLWKZ4/kE2KdQax/OCaUX0=	f	t	f	2012-05-03 00:03:55.855248-04	2012-05-03 00:03:55.565181-04
27	hamptonpitok			spranis@vistahost.net	pbkdf2_sha256$10000$L1fJx4blWZdA$lbFs8cwmfJGpfLpiCVfx5horAUhJGVoPIQg7DTjE+0o=	f	t	f	2012-05-03 06:32:35.445111-04	2012-05-03 06:32:35.148446-04
28	xparxy			eubanks@telys.net	pbkdf2_sha256$10000$rznxY2GBInGL$PEnMugJfFLEIM6oPvAHA0vdUeuyZttGepxeE5vy4ioc=	f	t	f	2012-05-03 07:09:34.775231-04	2012-05-03 07:09:34.479663-04
5	rickgottliebdmd			drrick106@aol.com	pbkdf2_sha256$10000$QC0MlxnWKnT0$Bmz26PGp11O8qlo7MmMIAZmLt+3OwmJTycXGpOSITp4=	f	t	f	2012-05-05 04:55:35.035621-04	2012-04-13 10:57:57.805591-04
32	hullabaloo			jensley@vons-ub.com	pbkdf2_sha256$10000$wm7DnUDzLGO6$u8DkyMRob4a/hJ1QuzsCuZLw0tarLneVPBlo7P6Tl3I=	f	t	f	2012-05-03 08:10:10.152344-04	2012-05-03 08:10:09.862553-04
9	ROC			Oakland15213@gmail.com	sha1$929a1$d157ffa0e93dc831d8996fe6488065c705ce1a40	f	t	f	2012-04-19 14:09:54.836405-04	2012-04-19 14:09:54.627764-04
47	elliottw			elliottw@gmail.com	pbkdf2_sha256$10000$ce5em7zLUqOo$ZiTT0MDL3DiUXcks/AaJbYYiaE7W84Yoo9vD2lf6JJY=	f	t	f	2012-05-09 10:49:12.850487-04	2012-05-03 11:15:33.824373-04
17	chaos			oneregalbeagle@gmail.com	pbkdf2_sha256$10000$i0rGTBXwybcL$kwRaaDfC6brciluxY6tDqGAZR2FOivyF/dTXzoo73MU=	f	t	f	2012-05-02 23:02:41.258489-04	2012-05-02 23:02:40.913028-04
10	clpfirstfloor			newandfeatured@carnegielibrary.org	pbkdf2_sha256$10000$vwQgFtIaAUfM$eNFjKjF23ZV1kL31pTA8k843uqvYV19PicSp4Oq0iVU=	f	t	f	2012-04-30 15:15:49.699832-04	2012-04-28 13:59:24.46793-04
18	toothparade			shawnsnyder@gmail.com	pbkdf2_sha256$10000$tG5OnoXUu6Aw$D6bEkC1LB3HM9PPzHns9QLgvUQzQ21IM6do4IbD9p0U=	f	t	f	2012-05-02 23:04:39.639901-04	2012-05-02 23:04:39.342342-04
29	klhappe			happek@gmail.com	pbkdf2_sha256$10000$1ba8AnWTwkpr$xkzuU+rN5uU0abo1xQPiozfhiDm3+rkouTlDL4K7QFI=	f	t	f	2012-05-03 07:42:42.527161-04	2012-05-03 07:42:42.234548-04
31	babscarryer			babs@carryer.com	pbkdf2_sha256$10000$LaGYFegB45Z7$DGmdSji0IXwWZR1SfvyFS+e5vbPYkwCEaqTsx5Ph1dY=	f	t	f	2012-05-03 08:00:45.041482-04	2012-05-03 08:00:44.752166-04
33	mmjsims89			mmjsims89@yahoo.com	pbkdf2_sha256$10000$XoFN6M2hIlEy$m7aCVbn9optwPzcM6gL2nFg8f/ztnv41uHSXNAsWnvk=	f	t	f	2012-05-03 08:18:12.607572-04	2012-05-03 08:18:12.312684-04
3	togs3800			togs3800@verizon.net	pbkdf2_sha256$10000$uXCwNyO2YYVg$iZjgj8zfRRUW0p+7xi4FVj1ImV/33Jq/G3pFl9WfgG8=	f	t	f	2012-05-17 17:19:36.989982-04	2012-04-13 10:26:14.275239-04
36	bgbm67			bgbm67@gmail.com	pbkdf2_sha256$10000$Yer4TW74SSID$zTP56v6l/tkeU5quTLAqO5TKF6RCv2/4pFzEeO+DfHg=	f	t	f	2012-05-03 08:44:02.486509-04	2012-05-03 08:44:02.195977-04
37	dabeny4			dabeny4@gmail.com	pbkdf2_sha256$10000$Htpj8o4HtNTU$wF6HEcboGx3KSyu7r+w9u1fRoBdSS+GZGaHDUUfMfvo=	f	t	f	2012-05-03 08:49:39.926176-04	2012-05-03 08:49:39.628461-04
39	RonR			rruppen@ucpclass.org	pbkdf2_sha256$10000$ppCaFYMjYaBV$rQzjXBa/bMtueAmjb69/pvWLbNDXyESt4gZDDFxOLhc=	f	t	f	2012-05-03 09:15:22.019213-04	2012-05-03 09:15:21.72877-04
11	jdopirak			jdopirak@undergroundshirts.com	pbkdf2_sha256$10000$2vTvJya4oIp0$nLLBwELhtRbgEZTtsgYP690f98gAnb5NkWZHH7kBke4=	f	t	f	2012-05-17 16:44:14.044185-04	2012-05-01 16:55:51.917239-04
43	shanlin1022			shannon.lindemer@gmail.com	pbkdf2_sha256$10000$BsIvVuUQIdHM$H0HzQhycsILdGp/14fpEX559IA5RwHtG+kp/5Ot8rZ4=	f	t	f	2012-05-03 10:00:02.692869-04	2012-05-03 10:00:02.397241-04
38	Atkins_1			atkins_1@live.com	pbkdf2_sha256$10000$wKUoUnu2vjOM$hAlDffD3Pd9hVFT3jrLs6mM+yZXCuk2C5uYEUb8uVvQ=	f	t	f	2012-05-12 10:21:08.298806-04	2012-05-03 08:56:25.844928-04
7	mrattigan			mrattigan@bc.pitt.edu	pbkdf2_sha256$10000$ZO3ZM3o9yBZU$6yGDkf64YHHhyQkT3GRNKqFhJDXkdgXXw8tiQ5MvRX8=	f	t	f	2012-05-18 10:53:28.688092-04	2012-04-17 15:58:28.140744-04
41	gpmuir			georgia@oaklandbid.org	pbkdf2_sha256$10000$Z9N3wNuw4UHL$SjOQzAQdDE+8+E2rmC8w8R5e90h3F0qVaa5uDULKR6k=	f	t	f	2012-05-11 14:07:50.169902-04	2012-05-03 09:44:02.688577-04
45	gimpPAC			pachicka@gmail.com	pbkdf2_sha256$10000$Z754r8OEfIjz$xmGQl/N5d6SzA8HuXrMxNXOYumBGt1u6+LJIDMCJCFM=	f	t	f	2012-05-11 13:32:51.680134-04	2012-05-03 10:30:29.520805-04
34	kxm			kxm72@yahoo.com	pbkdf2_sha256$10000$sAkWZ1GnSc0x$CznCbwdOEWQbiytEKWmQDQDOJKi7Nd5jlfnJh1ZtQp0=	f	t	f	2012-05-13 19:52:38.740835-04	2012-05-03 08:23:10.410679-04
48	pearlbeachlady			mmhughes61@gmail.com	pbkdf2_sha256$10000$TGUQQQPlhQum$es0nnLvPJTudT1hhLGD7GOOe2uz9M4LvLTE9n3nTkD8=	f	t	f	2012-05-03 11:46:51.592094-04	2012-05-03 11:46:51.299796-04
49	mnkramer			mark@mnkramer.com	pbkdf2_sha256$10000$JuruZTBJ3SlE$tuUr1bbqw1dm2fW//DHt71VyTMOPf0mr1/LvY61kfjg=	f	t	f	2012-05-03 11:48:58.085864-04	2012-05-03 11:48:57.796205-04
68	iamnotsam			sam@iamnotsam.com	pbkdf2_sha256$10000$agKZZV0dfHJh$5Z0GeF3CLLzTVJUsoHcRawVlJyNkvZcbpQ8nzEG7wCY=	f	t	f	2012-05-09 10:51:20.066097-04	2012-05-09 10:51:19.667775-04
52	djoven			david@djoven.com	pbkdf2_sha256$10000$gL7c2mTXbKT2$pDRaAQkNi1YRVqSW6HgsSWSyJjCnqPRFVjgxflx9s+Y=	f	t	f	2012-05-03 12:58:35.34154-04	2012-05-03 12:58:35.047396-04
2	Only_in_Oakland			mary@oaklandbid.org	pbkdf2_sha256$10000$rBWgnBFuGXg4$fDUM+JmIqy/81SYreBC1zDDzN7x9Iue6U7G+fsWfI/8=	f	t	f	2012-06-14 17:00:09.243431-04	2012-04-13 08:41:01.888979-04
15	laras126			laras126@gmail.com	pbkdf2_sha256$10000$7J9q6MRZwZfA$bM6jcA+JQ34QLo/pilTLjuFRXt+3gem9Vc+r67U6MPY=	f	t	f	2012-06-15 15:51:30.444514-04	2012-05-02 21:31:59.296511-04
46	janice			janicelorenz@gmail.com	pbkdf2_sha256$10000$avsPyyTBACeH$u3BXKdm2W6hc7sldTX850HgnmcmLuDXAcAOEEk5fkQE=	f	t	f	2012-06-14 13:05:04.840816-04	2012-05-03 10:57:25.680574-04
24	alison			alisonboden@gmail.com	pbkdf2_sha256$10000$9h8DymyTiV4y$CaVvlS3pbVS7vnPhi1mgxHMXhKiX033QSE9ngXPZMvs=	f	t	f	2012-05-25 13:04:50.732598-04	2012-05-03 00:03:13.700328-04
44	tjzak			tjzak@andrew.cmu.edu	pbkdf2_sha256$10000$ZwwjHmopZWJu$5cnW8Jgk0CC01m9nj8ZAkmGs80R9Ps5s9T30APKk9gg=	f	t	f	2012-05-25 13:46:52.631367-04	2012-05-03 10:22:45.455274-04
8	Rranallo			rranallo@opdc.org	pbkdf2_sha256$10000$h4aZai8GyRXb$VcvmelucVKssw/BYjrM8qSlFczEA21d8PQF92mzoZq4=	f	t	f	2012-06-14 13:04:41.693648-04	2012-04-18 18:16:02.152494-04
42	christinacann			christina.cann@gmail.com	pbkdf2_sha256$10000$Jbzzw7mRtVn0$9wa5GDU23IDe13I/bBh0zGfG0WzeqyOGgc/t63FL6Fg=	f	t	f	2012-06-14 17:26:14.170528-04	2012-05-03 09:59:43.724929-04
40	odonnellsp			seanpodonnell@gmail.com	pbkdf2_sha256$10000$bfx4ymMa8o9g$rWoBPTEubT6hyOJwfNgJnT4KvNPketFsGWGs21aItNg=	f	t	f	2012-06-14 12:52:45.907367-04	2012-05-03 09:20:55.736905-04
35	Alex			alex@oaklandbid.org	pbkdf2_sha256$10000$ffLB2Cofkay9$zUlU/05PUSV/Qa+k5fsPhlc1lVDKV78DmChDPyEK+yU=	f	t	f	2012-06-14 12:50:34.742503-04	2012-05-03 08:32:21.728067-04
23	ajbutkus			ajbutkus@gmail.com	pbkdf2_sha256$10000$q9chqV9N64y4$ns5Wr62MpAAkWpbYdRMwN8jSd8qWUKVAuWUI7BM+K+Y=	f	t	f	2012-06-14 12:58:15.331448-04	2012-05-02 23:34:40.48441-04
20	pwachtman			pgreenwood11@gmail.com	pbkdf2_sha256$10000$GZjxa8QD0219$8EzQo6rblE3f4KFOyA03ltCNByfFmedwfZbL899Wius=	f	t	f	2012-06-14 17:57:22.850292-04	2012-05-02 23:19:02.529793-04
6	Brett			brett@scenable.com	pbkdf2_sha256$10000$8teridxsLTHt$v9H7o8yDe9e+cYUKYptVf8gWr7XKFgOsyhATWkYM6lk=	f	t	f	2012-06-18 14:23:45.433398-04	2012-04-13 11:06:18.153336-04
53	guineapig			lcsciannameo@carlow.edu	pbkdf2_sha256$10000$bjazvzPKdLZz$g7xMbloB6clZZ6mAMK9lyjdVa8mf15A7rMH6K1Ytmxw=	f	t	f	2012-05-03 13:25:30.614827-04	2012-05-03 13:25:30.330132-04
69	qsloakland			qsl.oakland@gmail.com	pbkdf2_sha256$10000$i8dasNlU7XL6$4nGPPDSZiUvEHSqmcxYQ8dglQHkFwoINMtUw1ZqIN5Y=	f	t	f	2012-05-09 11:06:03.776139-04	2012-05-09 11:06:03.463431-04
70	3guysoptical			lynne@3guysoptical.com	pbkdf2_sha256$10000$NiWQfkZCpee2$8/2wSe+eMfAgN6rQEId1yKbY4gObdzldBns7IBMZQd4=	f	t	f	2012-05-09 14:55:04.324987-04	2012-05-09 14:55:04.04005-04
55	Jelibee			leeannsell@gmail.com	pbkdf2_sha256$10000$B508yMwZBR4W$A2nwqsDlxT8vLqwu23tG/sjhGUi9JNUd/Ftvg5cxYtk=	f	t	f	2012-05-03 19:13:14.567907-04	2012-05-03 19:13:14.281841-04
56	Cynthia			cah920@yahoo.com	pbkdf2_sha256$10000$P03HOBLq5BGD$lWtksQvZ/6YVvzioPor8fBIo5W0Jj2nruFJJp1mdV6w=	f	t	f	2012-05-03 21:29:28.662197-04	2012-05-03 21:29:28.32465-04
57	Nakia9			nakiabeasley@gmail.com	pbkdf2_sha256$10000$FgzGik45kvzq$d1GZj17obL1HufXf2aYCZLWdjAE4v2hUGDWffvAnMhk=	f	t	f	2012-05-03 22:15:54.103472-04	2012-05-03 22:15:53.802128-04
58	jimcjen			jjen@innovationworks.org	pbkdf2_sha256$10000$wqa7pflL04hc$x1qWi+muTjRYAgt6tLplMk1AUFuz9uUAG9sdlSrwEzY=	f	t	f	2012-05-03 22:55:10.845825-04	2012-05-03 22:55:10.549135-04
83	rwilkinson			rewilkin@andrew.cmu.edu	pbkdf2_sha256$10000$cWnq5swdeuFP$HUcVv540dKeGkSVGjrcoFgnkRXWFCVY36EteAHIC9VA=	f	t	f	2012-05-11 14:28:13.072963-04	2012-05-11 14:28:12.787622-04
62	jclaneve			joseph.c.laneve@gmail.com	pbkdf2_sha256$10000$QdnWNyLG8DN5$ujfNSlV+/w3N5DPED5OsunM1aVKzqYlWTfHN9cRgXfo=	f	t	f	2012-05-05 10:00:52.937227-04	2012-05-05 10:00:52.507508-04
63	alexa130			ahb21@pitt.edu	pbkdf2_sha256$10000$MWgdzqLD4L5N$62SrueJOD+zjnL3o5N1u4/KcoCEyFKE91nMokezFv7o=	f	t	f	2012-05-05 12:15:28.566102-04	2012-05-05 12:13:11.418973-04
71	crhurley			carolhurley@hurley2.com	pbkdf2_sha256$10000$ikdP4y5gLWbr$F09/dBv+U7SuKgzlDeVAun6ioV1YK3W9kmeIEpckSrA=	f	t	f	2012-05-09 15:20:50.726903-04	2012-05-09 15:20:50.447869-04
67	Jtoy			jtoy@chatham.edu	pbkdf2_sha256$10000$a2pr2ywf6uuX$J1cUUfhahWVI8lofo55NZ+fPOUUsWs5XE+VgT8gCCLI=	f	t	f	2012-05-08 21:36:04.835551-04	2012-05-08 21:36:04.160821-04
73	ali9029			ali.godfrey29@gmail.com	pbkdf2_sha256$10000$5R5dzUbR8nlf$esqdp3Q3C+JKgCqZawUXaJsdsDvecamIVvnLM3dzp1o=	f	t	f	2012-05-10 14:20:31.170579-04	2012-05-10 14:20:30.759738-04
93	ieverhart			ian.everhart@gmail.com	pbkdf2_sha256$10000$ZkNx1yT531IA$CBE1Dij2voVAC7LjF4IvXBe0e2H3J8SghRkaLR9vAB8=	f	t	f	2012-05-21 11:03:41.654659-04	2012-05-14 14:55:04.207518-04
87	Milano1			Milanospizza@comcast.net	pbkdf2_sha256$10000$Kb0X2PfcShsI$87vJK6W/Z+9HgK7Y3Jp004G4lTUWaORn9BcckRkHpbw=	f	t	f	2012-05-12 10:17:45.870522-04	2012-05-12 10:17:45.452764-04
77	dew			danaerinw@gmail.com	pbkdf2_sha256$10000$x4mvr0JBeEOY$y1gKr04ptHOV+EtfiPu7BKcfjjeoAxM/5PsNF35UdOY=	f	t	f	2012-05-11 13:07:42.263288-04	2012-05-11 13:07:41.845335-04
89	birdbird			brittanyreno@gmail.com	pbkdf2_sha256$10000$RXHv81hrbr45$Izka9mh/o4sRIqUk/1f4TXwcW+K6WhY4KE16Nl4Hzu8=	f	t	f	2012-05-13 12:48:08.780508-04	2012-05-13 12:48:08.420581-04
78	poehler			poehler@interworx.com	pbkdf2_sha256$10000$MTQWCIwNEVcv$XjbXIuht9STnZZOenz9cBawl3hbVvnbMnfWA3zdmDnk=	f	t	f	2012-05-11 13:09:03.18874-04	2012-05-11 13:09:02.900605-04
79	HolyGoof			john.ladue@gmail.com	pbkdf2_sha256$10000$vjpsCOouTSNQ$GsaxmsqVL8CUKpsWuOYfB+tnf9XEychw8cw4mImcz8k=	f	t	f	2012-05-11 13:09:28.397177-04	2012-05-11 13:09:28.112613-04
80	saucypixel			luminousechoes@gmail.com	pbkdf2_sha256$10000$JzFG2gN402u9$HGJ78IBZxXfoU/68ecyg/Dhbp7wVTyzUT7iNrfbKo28=	f	t	f	2012-05-11 13:15:44.285608-04	2012-05-11 13:15:44.002278-04
81	mikkelsd			dewayne.mikkelson@wellsfargo.com	pbkdf2_sha256$10000$BGUaszN5vh6c$AmA885b09oq7vYJXq3+szQau6Ri9Rqn1VkxLdtM/1/s=	f	t	f	2012-05-11 13:17:49.390023-04	2012-05-11 13:17:49.098767-04
82	sheelie			sh33la@yahoo.com	pbkdf2_sha256$10000$Ukv3iEpeTjmD$/9H/5ziMiJijtq3grzSgffBrfSvQXsel9ppisNej5Cc=	f	t	f	2012-05-11 13:30:29.72031-04	2012-05-11 13:30:29.430617-04
61	WBT			wbt+sceneable@cs.cmu.edu	pbkdf2_sha256$10000$EGQcL9mDcUeS$8pCaXOaBrs5JU1kohDGdjKT84sdnDBNbI2Lk69LJrqA=	f	t	f	2012-05-11 13:44:26.647027-04	2012-05-04 19:34:15.726375-04
85	cobracommandrew			cobracommandrew@gmail.com	pbkdf2_sha256$10000$CZANMgZfIJk9$ExvTsKwrRrtRzfYC/mAvo/+Y6Oa7qYCtU81ysa6n7gs=	f	t	f	2012-05-11 15:25:31.780448-04	2012-05-11 15:25:31.494788-04
86	erinmarink			erinmarink@gmail.com	pbkdf2_sha256$10000$P00ajNqOWnO8$6VcAcllo7rlFGehStpY43Anz7ee0H3xnKs9Z+nNl2GA=	f	t	f	2012-05-11 18:00:32.727632-04	2012-05-11 18:00:32.396689-04
76	cbhurtt			cbhurtt@gmail.com	pbkdf2_sha256$10000$9Cq4k1tQ7YkO$35PVZS7bQrjRNOw37NKzLYgZcdmlYLWDNoaMwF/hzVA=	f	t	f	2012-05-12 11:39:04.976414-04	2012-05-11 00:53:45.782764-04
60	fasterthalight			vrabell@carnegielibrary.org	pbkdf2_sha256$10000$16gfq0G3QyL8$2zvRDeaa+dHW74U6qlU/boGw+MeNpEd0rdkWOCqB1mI=	f	t	f	2012-05-12 14:08:50.07362-04	2012-05-04 09:39:49.714618-04
88	herediamario			gabbro.mario@gmail.com	pbkdf2_sha256$10000$YrCj1iFjstC3$3QvXwoc4XTuTVwcBu1qydBWJb+MWtAS8mhRb0nVz9mU=	f	t	f	2012-05-13 02:01:54.471504-04	2012-05-13 02:01:54.017331-04
91	rszewczyk			rachelszewczyk@gmail.com	pbkdf2_sha256$10000$d3c4dhMFUX9z$g24R8uhCj3t/MBujdsVQr4arHAMy1oelOV8Vqetd7Ew=	f	t	f	2012-05-13 21:55:55.88841-04	2012-05-13 21:55:55.546284-04
92	lauriekoozer			lak14@pitt.edu	pbkdf2_sha256$10000$8cp1ZgZ2PMoR$hCU5PiDtmYFxwbCmcE/R9IhkfioAwHWyTXhpgApWj50=	f	t	f	2012-05-14 09:27:33.877448-04	2012-05-14 09:27:33.559031-04
54	Jonathan			gauglerj@carnegiemuseums.org	pbkdf2_sha256$10000$KgXIb0Um8szn$qePe60JMLh2KQf96XtJunT7YwDqm1bX9y00X+X9U45g=	f	t	f	2012-05-18 10:54:40.690199-04	2012-05-03 14:10:36.223668-04
94	skaycue			skqkorn@gmail.com	pbkdf2_sha256$10000$kCnu9w6v5aMc$E1/5OhaMxXXtBeZU3esaOd4HdqGJg+zNUwrJkwnCdtI=	f	t	f	2012-05-14 16:07:44.470448-04	2012-05-14 16:07:44.182049-04
84	rolan1bp			rolan1bp@gmail.com	pbkdf2_sha256$10000$RK5sPX0GFqUO$F5c1Vro18Rc6U9CvwX1V7km5JAHNfqxx3OkwhTdkcnw=	f	t	f	2012-05-16 18:46:22.02504-04	2012-05-11 14:47:03.117737-04
95	katymatic			katy.peace@gmail.com	pbkdf2_sha256$10000$t8QlFhOtgS8w$I2JBiVqgpqlMLqM81vdC9eqmaT3/4lphSSyiLyG+wxs=	f	t	f	2012-05-16 19:46:56.305594-04	2012-05-16 19:46:55.933787-04
51	ccolledge1			ccolledge1@verizon.net	pbkdf2_sha256$10000$HuPBj5niptj1$PJTlirKPhhfTGQ/+nTJlFtbMUoKm1p/5TlbseDqnwF8=	f	t	f	2012-05-18 18:59:18.667307-04	2012-05-03 12:52:21.904121-04
96	Luvoof			jocaur@earthlink.net	pbkdf2_sha256$10000$0FqItDir6F8s$aUcOSvNekxSnoWpgHomLd5uEFOV/4XCT2TcovATGmGg=	f	t	f	2012-05-16 23:12:20.526183-04	2012-05-16 23:12:20.158596-04
97	Kit			kit@cs.cmu.edu	pbkdf2_sha256$10000$aFYdgPrUA1p4$bGITona787EZiAIZ48d18St+jO6DUxyxj2yVxaR1LxY=	f	t	f	2012-05-17 11:14:18.837811-04	2012-05-17 11:03:18.942409-04
98	sbeaches			sbeaches@gmail.com	pbkdf2_sha256$10000$A3HwQCJEOAmo$38zQ9rF+G2uHyTF6QKt0Ggcuu2bRGNhpcmPxXQpmJJ0=	f	t	f	2012-05-17 13:01:07.964363-04	2012-05-17 13:01:07.674712-04
99	pghgurl			pghgurl30@gmail.com	pbkdf2_sha256$10000$IPa0TfRDCT9h$U+xIxy4c8P/UQTZ7Q117VcU8vJMC3VtHQRXWFis0Ty0=	f	t	f	2012-05-19 13:01:51.795654-04	2012-05-19 13:01:51.422792-04
64	benjaminweaver			ben@avenirex.com	pbkdf2_sha256$10000$B4Mptc4G6MVF$EOFc7ftIXJIYvaiqbGsWKXKqT/nWwB3hbmCPsKP+mSo=	f	t	f	2012-05-25 15:16:56.018758-04	2012-05-05 16:49:06.161563-04
59	yusanc			yusanc@andrew.cmu.edu	pbkdf2_sha256$10000$YOFVM7R6LqVB$YLgn1Y5AbZLzPejWt08I7rITVVxk6zseMQPs1C+f3jU=	f	t	f	2012-06-14 12:55:19.118356-04	2012-05-04 00:22:31.536529-04
65	jasst282			jasst282@Gmail.com	pbkdf2_sha256$10000$wIhPIE3KYFsP$weL3C06UeWqJcIrt8MWsPuu011NdYF6Ph94FXRDXQ5k=	f	t	f	2012-06-14 12:53:01.576726-04	2012-05-07 09:52:53.411724-04
66	erskiji			jis51@pitt.edu	pbkdf2_sha256$10000$uxVhqLYlVSB9$JucAAMsNk11UMY9cPRBbDl1gwNX9px4OTbsXKsUL+yc=	f	t	f	2012-06-14 13:12:05.225807-04	2012-05-07 11:24:26.18603-04
74	pgarrow			phil@garrow.com	pbkdf2_sha256$10000$iYetTfBRdLw1$/LvM0n9jxnw/8iuUuTTJSg/5m1wMFUDt4W9C6prpn30=	f	t	f	2012-06-14 13:18:51.338398-04	2012-05-10 14:54:15.129862-04
50	Briski			ambriski@yahoo.com	pbkdf2_sha256$10000$nzKIfaDDqKLp$Ej+Ha1UB3OYwkFjlxdC01YIB/BTKkNlxvd6InKaQskE=	f	t	f	2012-06-14 13:28:27.5145-04	2012-05-03 12:08:33.2221-04
75	lizabethgray			lizabethgray@gmail.com	pbkdf2_sha256$10000$NTWt3LbD9LN0$CqhDbuZNipTYp35H5aO7XygRKpZEcEi0bXLvIrhRqFA=	f	t	f	2012-06-14 14:53:10.885919-04	2012-05-10 15:08:23.91994-04
90	lzwicker			laurazwicker@gmail.com	pbkdf2_sha256$10000$Nw5cC84cq2wN$icwyU4RToUqtEK/hKR3j3KQ92TVbakSb9SwUiXp7CpM=	f	t	f	2012-06-14 15:04:00.376338-04	2012-05-13 18:22:14.431689-04
16	gregarious			greg.nicholas@gmail.com	pbkdf2_sha256$10000$nwwUHozxwcGs$DXuaPj3xuOWn+jf3ZnfXPR8/GyO8JgRELUmv8jIUq8M=	f	t	f	2012-06-14 17:07:48.968964-04	2012-05-02 21:45:25.924578-04
100	natehart			nate@parkviewavenue.com	pbkdf2_sha256$10000$6eBCRdtGjM9g$7qe/J7dnuJJbg4gkLlPtWQ8BTobf0ejZG2E4WZMhj4A=	f	t	f	2012-05-22 10:14:53.044202-04	2012-05-22 10:14:52.6868-04
101	jrowe			jrowe@centralcatholichs.com	pbkdf2_sha256$10000$KHTTgmLN5kHd$Bwcwl6wqlevQRWZXtAwaAlkKry5uWjcAm0gWluJhIvI=	f	t	f	2012-05-22 13:39:48.091055-04	2012-05-22 13:39:47.757453-04
102	Hurley			bhurley@hurleybrokers.com	pbkdf2_sha256$10000$5EGSoTLDYiDc$guy2Rz77Iw0Pnoebujy+3+xhrjvMuLUOLarxQR87wVI=	f	t	f	2012-05-22 15:30:08.668891-04	2012-05-22 15:23:55.512872-04
103	vaishkri			vkrishnamurthy@ptilabs.com	pbkdf2_sha256$10000$aTeLviXsnuNb$rpoAX4rjTYzqNbfWza3Czi9iXWmMFfQqhOYEESqUgI0=	f	t	f	2012-05-23 10:27:56.42076-04	2012-05-23 10:27:55.987765-04
104	davewaterman			dwaterma@andrew.cmu.edu	pbkdf2_sha256$10000$sAr2QiMclkKu$xmXj9kvRuZ5Wr7+9iuEocv3lrYc8880xKQ/ChWGBMlI=	f	t	f	2012-05-23 18:28:16.150321-04	2012-05-23 18:28:15.709683-04
105	ebt256			ebt256@gmail.com	pbkdf2_sha256$10000$SuAEvvC0A7cX$Lm+e570ksedQWLArXtK74qmt5DU4OkcWHHk4axf6GWM=	f	t	f	2012-05-29 15:44:12.254394-04	2012-05-29 15:44:11.801039-04
106	hilarymeurer			hilary@muffinmanstudios.com	pbkdf2_sha256$10000$Vd6pN2cidhXs$TjGMPxjvoyORRxHNU/LU4Wj+YHqNFiHq+taOFJW2ciQ=	f	t	f	2012-06-04 09:09:26.347385-04	2012-06-04 09:09:25.836891-04
107	ksquared			verdeamarela@mac.com	pbkdf2_sha256$10000$luYXPNWhIaCp$vcIBoXyTA+dLXdD5c2BxMuW4WCahQ1I9YSO/tvfNiL8=	f	t	f	2012-06-07 08:45:22.060201-04	2012-06-07 08:45:21.171479-04
72	kvojtko			katie.vojtko@gmail.com	pbkdf2_sha256$10000$mGEXmCRCUyZh$+ItiB5hqUHwcoFfWbpqv0rAezFsVGCiBUbswsBbFd24=	f	t	f	2012-06-14 12:54:58.419355-04	2012-05-09 16:08:02.674572-04
1	admin			admin@scenable.com	pbkdf2_sha256$10000$NHTyVB1vsjcZ$G6MPlRkU9K0/rvYcLoGJOCAc+fFkR4oWM+ACpkVOSTQ=	t	t	t	2012-06-14 19:05:05.121299-04	2012-04-11 18:02:48.760529-04
108	Kathydemarco			Kathy.demarco@hilton.com	pbkdf2_sha256$10000$vRHCgzCdHuqM$PKXVEjHQi+sxePL3s+CjV/WtjchWR/C/WBXMawW0p0Y=	f	t	f	2012-06-18 14:22:21.807036-04	2012-06-18 14:22:21.80706-04
\.


--
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: chatter_post; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY chatter_post (id, dtcreated, content, author_id) FROM stdin;
1	2012-05-02 21:20:13.956097-04	Hi! Welcome to Scenable Oakland!	6
2	2012-05-02 22:40:48.392574-04	We're heading to Fuel & Fuddle -- feel free to drop in and say hi!	1
3	2012-05-02 23:27:40.674009-04	Congrats on the beta launch!!! So excited for this!	22
4	2012-05-02 23:30:26.692165-04	Taking Beta site for a test drive!	19
5	2012-05-02 23:39:33.112915-04	Looks good, Brett!	23
6	2012-05-03 01:11:32.605629-04	Looks nice Lara, works well Greg! Nice Leadershhipp Brett	26
7	2012-05-03 06:35:09.903388-04	Looks great & excited to have this!	27
8	2012-05-03 07:25:09.845088-04	So excited about the launch of Scenable!  Thanks Lara, Greg and Brett!!!!	2
9	2012-05-03 08:23:59.913788-04	This site is cool, I am always looking for different events happening around town!  thx for the heads up!!	33
10	2012-05-03 08:44:26.080973-04	What a beautiful morning in Oakland! BTW -- I'll be at Red Oak today at 10 if anyone wants to say hi :)	6
11	2012-05-03 08:59:03.43289-04	Pretty cool stuff guys, the neighborhood of Oakland is better for it!	37
12	2012-05-03 09:48:24.11687-04	To the Oakland Scene team I say YEAH!!  I can not wait for the launch...the site is attractive, easy to read and to navigate!	41
13	2012-05-03 10:02:21.219303-04	Whoo hoo looking good! 	42
14	2012-05-03 10:38:12.675929-04	Looks great!  Hope all the bugs aren't too hard to work out!	45
15	2012-05-03 11:17:48.679743-04	Want your photo to show up when your write a chatter post? Click on your name in the top right to edit your user settings and add an avatar!	1
16	2012-05-03 12:59:47.025078-04	Mmmmm, heading to Fuel for lunch. Stop by and say hi!	6
17	2012-05-03 13:03:19.881541-04	Does Fuel & Fuddle serve alligator or did I make that up?	15
18	2012-05-03 13:18:45.314732-04	Mmmmm, heading to Fuel for lunch. Stop by and say hi!	6
19	2012-05-03 14:51:24.585801-04	Great to be on Oakland Scenable! http://tinyurl.com/6noofdt 	54
20	2012-05-03 19:43:03.736452-04	Who's excited about the Greek Food Festival next week?	6
21	2012-05-03 22:14:39.049737-04	Have you checked liked our Facebook page yet? We'll be posting news and updates about development there, so make sure to check it out!	1
22	2012-05-04 09:09:42.189714-04	Good morning, Oakland!	6
23	2012-05-04 09:25:49.179831-04	Congrats to tak_15217 -- you just won an Oakland Scene t-shirt! 	1
24	2012-05-04 09:26:39.117631-04	Want to enter the daily shirt drawing? Leave some feedback using the sidebar button and you're in!	1
25	2012-05-05 15:31:12.662549-04	Congrats to janice -- you just won the daily shirt drawing! Keep that feedback coming!	1
26	2012-05-07 13:10:43.032287-04	Heading to the Greek Food Festival -- come say hi!	6
27	2012-05-07 16:42:15.523386-04	Congrats to jasst28 -- you just won the today's Shirts-for-Feedback drawing! 	1
28	2012-05-10 13:05:10.913519-04	Congrats to monafro -- you just won the today's Shirts-for-Feedback drawing!	1
29	2012-05-11 14:05:05.309606-04	Today is a beautiful day to take in all that O-town has to offer!	42
30	2012-05-11 14:08:32.481981-04	Hanging out at the Art Museum with our friends at OBID!	1
31	2012-05-11 17:33:33.359174-04	Had a great afternoon with @admin at the art museum 	2
32	2012-05-12 14:09:36.922584-04	Working at the Carnegie Library today - come say hi!	60
33	2012-05-16 10:55:31.947116-04	Who's heading to the Children's Festival this week & weekend?	1
34	2012-05-16 11:05:58.036596-04	Congrats to gimpPAC -- won today's feedback drawing for an Oakland Scene T-shirt! Keep that feedback coming!	1
36	2012-05-16 17:33:36.128217-04	Complete the Scenable Oakland Survey for a chance to win an Oakland Scene T-shirt and FREE LUNCH w/the Scenable team! http://bit.ly/Jt8V60	1
37	2012-05-17 11:07:57.55882-04	I never would have known about the Live Music at Schenley. .  thanks!	97
38	2012-05-18 12:21:46.071717-04	The site will be a great addition to Oakland. We needed some kind of local newspaper, blog and all around community site. 	75
39	2012-05-18 12:34:34.372153-04	Congrats to ajbutkus -- you won the Scenable Team Lunch for filling out the survey!	1
40	2012-05-21 10:11:49.073896-04	What a beautiful day in Oakland!	6
41	2012-05-22 14:31:14.952062-04	Definitely planning to head to the WYEP Summer fest in Schenley http://scenable.com/oakland/events/69/	15
42	2012-05-24 13:13:16.06208-04	Love seeing the response fro	2
43	2012-05-24 13:13:53.474193-04	Oops! Love seeing the response to Scenable at theCDSummit today!	2
44	2012-05-24 13:20:26.418281-04	Oops! Love seeing the response to Scenable at theCDSummit today!	2
45	2012-05-25 12:10:48.18214-04	st. regis	8
46	2012-05-25 12:11:11.709845-04	disregard that post, I meant to type it into the "search" window! :)	8
47	2012-05-25 12:11:43.872093-04	Which reminds me, maybe there should be a way you can delete your own post, similar to Facebook/Twitter?	8
48	2012-06-14 12:38:43.2452-04	Join us tonight at the Innovation Oakland Happy Hour! https://www.scenable.com/oakland/events/85/	1
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_admin_log (id, action_time, user_id, content_type_id, object_id, object_repr, action_flag, change_message) FROM stdin;
1	2012-05-02 12:06:34.910762-04	1	23	4	Free soup	2	Changed title.
2	2012-05-02 12:06:50.178864-04	1	23	3	Ted	3	
3	2012-05-02 12:07:09.670024-04	1	12	170	test	3	
4	2012-05-02 12:18:36.988567-04	1	29	1	New 'Dark Knight Rises' trailer hits Web  	1	
5	2012-05-02 12:20:47.029984-04	1	29	2	CMU presents 10-year plan to city	1	
6	2012-05-02 12:22:39.183655-04	1	29	3	City school board delays sale of Schenley High School building	1	
7	2012-05-02 12:24:17.582066-04	1	29	4	Pitt suspends some areas of study to save money	1	
8	2012-05-02 12:25:49.616657-04	1	29	5	Pitt aims to prove therapy can offer new cancer hope	1	
9	2012-05-02 12:27:00.668914-04	1	29	6	University of Pittsburgh graduation goes smoothly 	1	
10	2012-05-02 12:29:20.221244-04	1	29	7	CMU student aims for top chess honors	1	
11	2012-05-02 12:31:01.168575-04	1	29	8	City Walkabout / Livehoods.orgs maps a different view of our neighborhoods	1	
12	2012-05-02 12:44:23.600172-04	1	29	9	VA to open new Oakland facility	1	
13	2012-05-02 12:45:51.913989-04	1	29	10	Anonymous group claims it hacked Pitt’s computer system	1	
14	2012-05-02 12:47:05.103451-04	1	29	11	Port Authority approves drastic cuts to service	1	
15	2012-05-02 17:25:40.844193-04	1	29	11	Port Authority approves drastic cuts to service	2	Changed publication_date.
16	2012-05-02 18:14:02.034202-04	1	18	44	Prosaic disasters	2	Changed description, image, url, place, place_primitive and tags.
17	2012-05-02 18:14:42.214214-04	1	18	35	SOPHOMORE REVIEW WARP UP & PICNIC	3	
18	2012-05-02 18:14:42.215845-04	1	18	36	SOPHOMORE REVIEW WARP UP & PICNIC	3	
19	2012-05-02 18:15:31.087601-04	1	18	41	End of the Year Art Awards/Picnic	3	
20	2012-05-02 18:19:09.132839-04	1	14	406	Purnell Center for the Arts (5000 Forbes Ave)	1	
21	2012-05-02 18:19:45.596087-04	1	18	40	Senior Art Exhibit Opening	2	Changed description, image, url, place, place_primitive and tags.
22	2012-05-02 18:22:01.911548-04	1	13	278	5200 Forbes Avenue	1	
23	2012-05-02 18:23:15.264871-04	1	18	38	Exhibition Reception: The Antiquarian Avant-Garde	2	Changed description, image, url and tags.
24	2012-05-02 18:24:46.330988-04	1	14	407	The Frame (5200 Forbes Avenue)	1	
25	2012-05-02 18:26:56.467539-04	1	14	407	The Frame (5200 Forbes Avenue)	2	Changed description and url.
26	2012-05-02 18:27:26.45447-04	1	18	38	Exhibition Reception: The Antiquarian Avant-Garde	2	Changed place, place_primitive and tags.
27	2012-05-02 18:27:53.480024-04	1	18	43	Art Council	3	
28	2012-05-02 18:28:58.368877-04	1	18	37	Exhibition Reception: Re-Thinking Suburbia	2	Changed description, image, url, place and tags.
29	2012-05-02 18:29:43.158296-04	1	18	42	Staff Meeting	3	
30	2012-05-02 18:29:43.160107-04	1	18	1	After Hours @ the Library: Late Night	3	
31	2012-05-02 18:29:43.161086-04	1	18	39	Commencement	3	
32	2012-05-02 18:30:41.093177-04	1	18	37	Exhibition Reception: Re-Thinking Suburbia	2	Changed dtstart and dtend.
33	2012-05-02 19:19:52.940265-04	1	18	45	"Doing" Politics w/ Poetry 	1	
34	2012-05-02 19:57:25.970937-04	1	18	10	A Taste of Oakland presented by Hurley Associates, Hurley Insurance Brokers	2	Changed description, place, place_primitive and tags. Added role "Role object".
35	2012-05-02 20:03:30.278776-04	1	13	279	Forbes Ave and McKee Place	1	
36	2012-05-02 20:03:38.960869-04	1	14	408	 (Forbes Ave and McKee Place)	1	
37	2012-05-02 20:04:00.104787-04	1	18	46	Oakland Alive! Pittsburgh Marathon Party!	1	
38	2012-05-02 20:04:43.563159-04	1	18	46	Oakland Alive! Pittsburgh Marathon Party!	2	Changed place and tags. Added role "Role object".
39	2012-05-02 20:10:36.383159-04	1	18	47	Maya Lin	1	
40	2012-05-02 20:12:33.081705-04	1	18	48	Carnegie Mellon Philharmonic	1	
41	2012-05-02 20:14:52.045553-04	1	18	49	Entrepreneurship For Job Seekers & Career Change	1	
42	2012-05-02 20:16:03.706412-04	1	18	50	Who Made Sherlock Holmes A Hit?	1	
43	2012-05-02 20:20:18.104996-04	1	18	51	Carnegie Science Awards	1	
44	2012-05-02 20:26:36.967037-04	1	13	280	4836 Ellsworth Avenue	1	
45	2012-05-02 20:27:23.15181-04	1	14	409	Friend's Meeting House (4836 Ellsworth Avenue)	1	
46	2012-05-02 20:27:28.624213-04	1	18	52	"Doing" Politics w/ Poetry 	1	
47	2012-05-02 20:27:45.132451-04	1	18	52	"Doing" Politics w/ Poetry 	2	Changed place.
48	2012-05-02 20:32:20.31562-04	1	18	53	Free Comic Book Day 	1	
49	2012-05-02 21:01:48.273581-04	1	14	89	The Comfort Zone (3400 Fifth Ave)	2	Changed image.
50	2012-05-02 22:12:48.900062-04	1	12	192	teens	1	
51	2012-05-02 22:13:04.051174-04	1	18	54	All Out Gaming	1	
52	2012-05-02 22:15:10.419946-04	1	18	55	Armadillos	1	
53	2012-05-03 11:16:01.729051-04	1	29	12	Sunny outlook for Pittsburgh Marathon runners this weekend	1	
54	2012-05-03 11:30:47.536174-04	1	13	281	3454 Forbes Ave	1	
55	2012-05-03 11:32:29.170831-04	1	31	19	It took me a minute to...	3	
56	2012-05-03 11:32:29.172636-04	1	31	20	It took me a minute to...	3	
57	2012-05-03 11:33:28.996545-04	1	14	410	Hilton Garden Inn (3454 Forbes Ave)	1	
58	2012-05-03 11:33:50.39222-04	1	18	10	A Taste of Oakland presented by Hurley Associates, Hurley Insurance Brokers	2	Changed description, url, place and listed.
59	2012-05-03 11:34:32.195369-04	1	18	10	A Taste of Oakland presented by Hurley Associates, Hurley Insurance Brokers	2	No fields changed.
60	2012-05-03 11:37:51.782358-04	1	13	282	Forbes Avenue and Bouquet Streets	1	
61	2012-05-03 11:38:10.267339-04	1	14	411	 (Forbes Avenue and Bouquet Streets)	1	
62	2012-05-03 11:38:44.804028-04	1	18	56	A Taste of Oakland presented by Hurley Associates, Hurley Insurance Brokers	1	
63	2012-05-03 11:39:27.509694-04	1	18	56	A Taste of Oakland presented by Hurley Associates, Hurley Insurance Brokers Ticket Site	2	Changed name and description.
64	2012-05-03 11:40:09.857898-04	1	18	10	A Taste of Oakland presented by Hurley Associates, Hurley Insurance Brokers! Ticket Site 1!	2	Changed name and description.
65	2012-05-03 11:40:26.219022-04	1	18	56	A Taste of Oakland presented by Hurley Associates, Hurley Insurance Brokers! Ticket Site 2!	2	Changed name.
66	2012-05-03 12:57:42.633179-04	1	18	54	All Out Gaming	2	Changed dtstart and dtend.
67	2012-05-03 19:35:33.227891-04	1	18	57	St. Nicholas' Greek Food Festival	1	
68	2012-05-03 19:35:57.733623-04	1	18	47	Maya Lin	2	Changed dtstart.
69	2012-05-04 14:57:16.750231-04	1	28	1048	sam@iamnotsam.com	1	
70	2012-05-05 10:20:53.31606-04	1	18	34	PCRG Community Development Summit	3	
71	2012-05-05 10:25:07.918041-04	1	29	13	Officials rescue seven ducklings	1	
72	2012-05-05 10:31:42.52671-04	1	18	58	Light, Code, and Technology: Photography in the 21st Century   	1	
73	2012-05-06 19:07:55.482801-04	1	18	59	The War on Cancer: The Next Forty Years   	1	
74	2012-05-06 19:09:13.025846-04	1	18	60	30 years of lung cancer research: How far we come?   	1	
75	2012-05-07 07:59:38.278808-04	1	29	14	19,000 marathoners bear the heat	1	
76	2012-05-07 09:33:16.508545-04	1	18	47	Maya Lin - Through May 13th!	2	Changed name.
77	2012-05-07 09:33:45.890895-04	1	18	57	St. Nicholas' Greek Food Festival (May 6-12)	2	Changed name.
78	2012-05-07 09:34:25.403202-04	1	18	60	30 years of lung cancer research: How far have we come?   	2	Changed name.
79	2012-05-07 16:46:41.222465-04	1	28	1049	testmcuppercase@moo.com	1	
80	2012-05-07 16:46:56.074964-04	1	28	1049	testmcuppercase@moo.com	3	
81	2012-05-09 14:48:47.784313-04	1	28	1050	lynne@3guysoptical.com	1	
82	2012-05-10 09:37:38.753959-04	1	29	15	Senate Appropriations Committee aims to restore Pitt funding	1	
83	2012-05-10 13:05:27.463722-04	1	28	1051	ali.godfrey29@gmail.com	1	
84	2012-05-10 13:05:43.135319-04	1	28	1052	cbhurtt@gmail.com	1	
85	2012-05-10 13:07:54.211878-04	1	28	1053	lizabethgray@gmail.com	1	
86	2012-05-10 13:08:09.364448-04	1	28	1054	phil@garrow.com	1	
87	2012-05-10 13:08:20.600402-04	1	28	1055	markopgh@aol.com	1	
88	2012-05-11 11:02:52.213098-04	1	29	16	CMU to pay $5 million for diocesan property	1	
89	2012-05-11 13:26:47.647324-04	1	29	17	One to hospital, one to jail after failed robbery outside McDonald's in Oakland	1	
90	2012-05-12 10:22:50.675436-04	1	18	61	May Market	1	
91	2012-05-12 10:25:33.557626-04	1	29	18	Pitt files lawsuit against Big East	1	
92	2012-05-12 11:00:19.056785-04	1	12	207	kids	1	
93	2012-05-12 11:00:26.627615-04	1	18	62	Discovery Garden Day	1	
94	2012-05-14 08:19:01.360326-04	1	29	19	Pittsburgh Race for the Cure brings thousands together	1	
95	2012-05-14 14:09:22.260577-04	1	28	997	j.wassermann@verizon.net	3	
96	2012-05-16 10:45:27.742551-04	1	29	20	Pitt awarded $1.3 million in grants for nuclear research	1	
97	2012-05-16 10:50:48.313845-04	1	13	283	Forbes Avenue and Schenley Drive	1	
98	2012-05-16 10:53:50.169856-04	1	14	412	Schenley Plaza (Forbes Avenue and Schenley Drive)	1	
99	2012-05-16 10:54:04.933871-04	1	18	63	Pittsburgh International Children's Festival	1	
100	2012-05-16 14:06:25.029989-04	1	30	35	"Congrats to ..." by admin	3	
101	2012-05-17 08:31:36.705451-04	1	18	64	Lunchtime Music at the Plaza!	1	
102	2012-05-17 08:32:45.526549-04	1	18	65	Lunchtime Music at the Plaza!	1	
103	2012-05-17 08:33:39.728026-04	1	18	66	Lunchtime Music at the Plaza!	1	
104	2012-05-17 08:34:46.276431-04	1	18	67	Lunchtime Music at the Plaza!	1	
105	2012-05-17 08:35:33.245197-04	1	18	68	Lunchtime Music at the Plaza!	1	
106	2012-05-17 08:37:59.929998-04	1	18	69	WYEP's 15th Annual Summer Music Festival at Schenley Plaza	1	
107	2012-05-17 08:49:34.018975-04	1	18	70	M Is For Museum	1	
108	2012-05-17 08:52:12.640645-04	1	18	71	The Thousand & One Nights	1	
109	2012-05-17 09:09:36.335498-04	1	18	72	Books In The Afternoon	1	
110	2012-05-17 09:13:16.810839-04	1	18	73	Saluting Service 	1	
111	2012-05-17 09:18:32.113693-04	1	13	284	4802 Fifth Ave	1	
112	2012-05-17 09:20:58.810124-04	1	14	413	WQED Studios (4802 Fifth Ave)	1	
113	2012-05-17 09:21:06.119569-04	1	18	74	Executive Women's Council Of Pittsburgh Annual Meeting	1	
114	2012-05-17 09:23:16.492708-04	1	18	75	Writers Live: Ron Tanner	1	
115	2012-05-17 09:24:47.088357-04	1	18	76	Writers Live: Michael Sims	1	
116	2012-05-17 09:26:17.725027-04	1	18	77	Soldiers & Sailors Memorial Day Celebration	1	
117	2012-05-17 09:41:03.66208-04	1	18	78	Pittsburgh Take Steps For Crohn’s & Colitis Walk	1	
118	2012-05-17 09:44:03.178018-04	1	13	282	Forbes Avenue and Bouquet Street	2	Changed address.
119	2012-05-18 11:04:23.652568-04	1	29	21	Children’s Festival Has Schenley Plaza Buzzing With Activity	1	
120	2012-05-21 21:12:54.091487-04	1	29	22	Best French Fries In Pittsburgh	1	
121	2012-05-21 21:15:37.536261-04	1	13	285	3901 Forbes Avenue	1	
122	2012-05-21 21:21:59.595113-04	1	14	414	The Original Hot Dog Shop (3901 Forbes Avenue)	1	
123	2012-05-21 21:24:19.678266-04	1	29	22	Best French Fries In Pittsburgh	2	Changed related_places.
124	2012-05-22 08:15:34.783923-04	1	29	23	Pittsburgh anticipating $3 million from nonprofits	1	
125	2012-05-22 10:05:43.876308-04	1	28	1056	nate@parkviewavenue.com	1	
126	2012-05-22 13:02:05.993231-04	1	28	1057	kirstenitaliko@gmail.com	1	
127	2012-05-22 13:02:21.031639-04	1	28	1058	mcw2@pitt.edu	1	
128	2012-05-22 13:02:48.31211-04	1	28	1059	bsatt37@directv.net	1	
129	2012-05-22 13:03:18.69802-04	1	28	1060	vkrishnamurthy@ptilabs.com	1	
130	2012-05-22 13:03:31.672488-04	1	28	1061	km3701@yahoo.com	1	
131	2012-05-22 13:03:54.196957-04	1	28	1062	murphyjw@westinghouse.com	1	
132	2012-05-22 13:04:10.44657-04	1	28	1063	zach.wicks@rhea.us	1	
133	2012-05-22 13:04:35.31633-04	1	28	1064	jrowe@centralcatholichs.com	1	
134	2012-05-22 13:04:47.611491-04	1	28	1065	rdillie@gmail.com	1	
135	2012-05-22 13:04:57.999775-04	1	28	1066	ebt256@gmail.com	1	
136	2012-05-22 13:05:12.707463-04	1	28	1067	mabney2008@gmail.com	1	
137	2012-05-22 13:05:31.533199-04	1	28	1068	mwschultz@gmail.com	1	
138	2012-05-22 13:31:45.611443-04	1	18	83	Clean Energy Matters	1	
139	2012-05-22 13:37:18.483112-04	1	28	1057	kirstenhaliko@gmail.com	2	Changed email.
140	2012-05-22 13:38:43.029024-04	1	28	1058	mcw23@pitt.edu	2	Changed email.
141	2012-05-23 07:09:16.861297-04	1	29	24	Pittsburgh-based Innovation Works living up to its name	1	
142	2012-05-23 21:02:02.745257-04	1	29	25	Phipps' Center for Sustainable Landscapes opens today, to be greenest building	1	
143	2012-05-25 13:27:22.607206-04	1	7	1	www.scenable.com	2	Changed domain and name.
144	2012-05-29 13:53:12.742815-04	1	29	26	Small fire extinguished at Pitt's Salk Hall	1	
145	2012-05-29 15:41:09.877257-04	1	28	1069	bperry@opdc.org	1	
146	2012-05-30 16:12:28.626172-04	1	18	26	Meet the VA: AmVets Post 103	2	Changed listed.
147	2012-05-30 16:12:42.010528-04	1	18	25	Veterans Employment Outreach Day	2	Changed description and listed.
148	2012-05-30 16:13:11.822223-04	1	18	24	Wounded Warrior Amputee Softball game	2	Changed description and listed.
149	2012-06-01 15:16:01.451621-04	1	28	1070	hilary@muffinmanstudios.com	1	
150	2012-06-04 09:47:34.6798-04	1	29	27	Reunion joins families helped by Magee neonatal unit 	1	
151	2012-06-04 17:44:21.609779-04	1	18	84	12th Annual Summer Reading Extravaganza	1	
152	2012-06-05 16:41:02.114386-04	1	28	1071	painholic@gmail.com	1	
153	2012-06-05 16:43:13.481671-04	1	28	1072	zachery.ambrose@alleghenycounty.us	1	
154	2012-06-05 17:16:33.317257-04	1	28	1073	kkunak@gmail.com	1	
155	2012-06-12 11:04:36.423151-04	1	28	1074	candice.gonzalez@pittsburghpa.gov	1	
156	2012-06-12 12:42:49.672831-04	1	29	28	 300-plus University of Pittsburgh employees opt for early retirement  Read more	1	
157	2012-06-12 12:44:39.880382-04	1	29	29	Probe into Pitt bomb threats continues, FBI says 	1	
158	2012-06-13 20:50:24.82027-04	1	13	286	122 Meyran Ave	1	
159	2012-06-13 20:52:24.510207-04	1	12	212	technology	1	
160	2012-06-13 20:53:04.414827-04	1	14	415	Revv Oakland (122 Meyran Ave)	1	
161	2012-06-13 20:53:54.28728-04	1	18	85	Tech Networking Happy Hour!	1	
162	2012-06-14 19:05:39.304646-04	1	28	1075	customerservice@pittsburghpretzel.com	1	
163	2012-06-15 09:56:31.799612-04	1	28	1076	ablavin@gmail.com	1	
164	2012-06-15 09:57:00.327117-04	1	28	1077	smileandlaughoften@gmail.com	1	
165	2012-06-18 12:46:16.287832-04	1	28	1078	demarco@hilton.com	1	
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_content_type (id, name, app_label, model) FROM stdin;
1	permission	auth	permission
2	group	auth	group
3	user	auth	user
5	content type	contenttypes	contenttype
6	session	sessions	session
7	site	sites	site
8	log entry	admin	logentry
9	migration history	south	migrationhistory
10	kv store	thumbnail	kvstore
11	user profile	accounts	userprofile
12	tag	tags	tag
13	location	places	location
14	place	places	place
15	place meta	places	placemeta
16	favorite	places	favorite
17	organization	organizations	organization
18	event	events	event
19	event meta	events	eventmeta
20	role	events	role
21	attendee	events	attendee
22	i calendar feed	events	icalendarfeed
23	special	specials	special
24	special meta	specials	specialmeta
25	coupon	specials	coupon
26	api access	tastypie	apiaccess
27	api key	tastypie	apikey
28	beta member	accounts	betamember
29	article	news	article
30	post	chatter	post
31	generic feedback comment	feedback	genericfeedbackcomment
32	organization	accounts	organization
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_session (session_key, session_data, expire_date) FROM stdin;
7bf9db30c4f8a29833fce7f57b899d01	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 13:53:35.660878-04
2f6d1ec3f61ac61464bb9fc751de1796	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-19 19:47:47.001358-04
ba1ea8ef118719e8b1d93533fb95f2d1	OWU0YTc5YjUwNGJiMzM0M2EyMzcxOWMyMWNlMDE4NjA0N2MzNjM1ZTqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-04-28 22:21:44.236686-04
b93a003002293598b874774292bed5c5	Mjc0MDNjMDIzMTZiZGEwNjg1NmJmOTFkMTgwZDI1OGEzMTM4NDcxZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAVULY3VycmVudF9vcmdxBWNkamFuZ28uZGIubW9kZWxzLmJhc2UK\nbW9kZWxfdW5waWNrbGUKcQZjb25seWlucGdoLm9yZ2FuaXphdGlvbnMubW9kZWxzCk9yZ2FuaXph\ndGlvbgpxB11jZGphbmdvLmRiLm1vZGVscy5iYXNlCnNpbXBsZV9jbGFzc19mYWN0b3J5CnEIh1Jx\nCX1xCihVCWR0Y3JlYXRlZHELY2RhdGV0aW1lCmRhdGV0aW1lCnEMVQoH3AQNCCkCAUOchVJxDVUE\nbmFtZXEOWCUAAABPYWtsYW5kIEJ1c2luZXNzIEltcHJvdmVtZW50IERpc3RyaWN0VQN1cmxxD1gA\nAAAAVQVpbWFnZXEQWAAAAABVBl9zdGF0ZXERY2RqYW5nby5kYi5tb2RlbHMuYmFzZQpNb2RlbFN0\nYXRlCnESKYFxE31xFChVBmFkZGluZ3EViVUCZGJxFlUHZGVmYXVsdHEXdWJVBWZiX2lkcRhYAAAA\nAFUQdHdpdHRlcl91c2VybmFtZXEZWAAAAABVAmlkcRpLAXVidS4=\n	2012-04-30 14:58:21.024657-04
69731687a6c38e4626be31f258901eb5	M2VlZWE3YjQ5MjQ4NTJmMTRmMWE3ZmMyYTJlNmRhMTVjYTc2YzIzNDqAAn1xAS4=\n	2012-04-30 15:02:16.357078-04
c8604664080321a454c0ed5c963b9515	M2VlZWE3YjQ5MjQ4NTJmMTRmMWE3ZmMyYTJlNmRhMTVjYTc2YzIzNDqAAn1xAS4=\n	2012-05-02 18:45:06.686101-04
c761a04d0149c1462a35d4c2e19ddb30	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-23 19:15:11.853056-04
ec26ca2201bad3a9c1b90ddd52a0f747	Mjc0MDNjMDIzMTZiZGEwNjg1NmJmOTFkMTgwZDI1OGEzMTM4NDcxZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAVULY3VycmVudF9vcmdxBWNkamFuZ28uZGIubW9kZWxzLmJhc2UK\nbW9kZWxfdW5waWNrbGUKcQZjb25seWlucGdoLm9yZ2FuaXphdGlvbnMubW9kZWxzCk9yZ2FuaXph\ndGlvbgpxB11jZGphbmdvLmRiLm1vZGVscy5iYXNlCnNpbXBsZV9jbGFzc19mYWN0b3J5CnEIh1Jx\nCX1xCihVCWR0Y3JlYXRlZHELY2RhdGV0aW1lCmRhdGV0aW1lCnEMVQoH3AQNCCkCAUOchVJxDVUE\nbmFtZXEOWCUAAABPYWtsYW5kIEJ1c2luZXNzIEltcHJvdmVtZW50IERpc3RyaWN0VQN1cmxxD1gA\nAAAAVQVpbWFnZXEQWAAAAABVBl9zdGF0ZXERY2RqYW5nby5kYi5tb2RlbHMuYmFzZQpNb2RlbFN0\nYXRlCnESKYFxE31xFChVBmFkZGluZ3EViVUCZGJxFlUHZGVmYXVsdHEXdWJVBWZiX2lkcRhYAAAA\nAFUQdHdpdHRlcl91c2VybmFtZXEZWAAAAABVAmlkcRpLAXVidS4=\n	2012-04-30 15:57:52.317227-04
e4ce403eb10e899030e201945ec509a4	YTdjY2EyMTYzN2UxMTBmYjBmNWM4MDEyNzllMGE2OGYyNDA1MzhjNzqAAn1xAShVDV9hdXRoX3Vz\nZXJfaWRLAlUSX2F1dGhfdXNlcl9iYWNrZW5kVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRz\nLk1vZGVsQmFja2VuZFULY3VycmVudF9vcmdjZGphbmdvLmRiLm1vZGVscy5iYXNlCm1vZGVsX3Vu\ncGlja2xlCnECY29ubHlpbnBnaC5vcmdhbml6YXRpb25zLm1vZGVscwpPcmdhbml6YXRpb24KcQNd\nY2RqYW5nby5kYi5tb2RlbHMuYmFzZQpzaW1wbGVfY2xhc3NfZmFjdG9yeQpxBIdScQV9cQYoVQlk\ndGNyZWF0ZWRxB2NkYXRldGltZQpkYXRldGltZQpxCFUKB9wEDQgpAgFDnIVScQlVBG5hbWVxClgl\nAAAAT2FrbGFuZCBCdXNpbmVzcyBJbXByb3ZlbWVudCBEaXN0cmljdFUDdXJscQtVAFUFaW1hZ2Vx\nDGNkamFuZ28uZGIubW9kZWxzLmZpZWxkcy5maWxlcwpJbWFnZUZpZWxkRmlsZQpxDSmBcQ59cQ8o\nVQpfY29tbWl0dGVkcRCIVQVfZmlsZXERTmgKTlUGY2xvc2VkcRKJdWJVBl9zdGF0ZXETY2RqYW5n\nby5kYi5tb2RlbHMuYmFzZQpNb2RlbFN0YXRlCnEUKYFxFX1xFihVBmFkZGluZ3EXiVUCZGJxGFUH\nZGVmYXVsdHViVQVmYl9pZHEZVQBVEHR3aXR0ZXJfdXNlcm5hbWVxGlUAVQJpZHEbigEBdWJ1Lg==\n	2012-04-27 08:41:02.162424-04
7ab03b7fa3d84a5f8359765d40bad40c	OWU0YTc5YjUwNGJiMzM0M2EyMzcxOWMyMWNlMDE4NjA0N2MzNjM1ZTqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-04-27 10:00:56.162091-04
f93d1de1467dde75ee65caa35ce9ba9b	NDg3YTVkZGI4OWRhZTU5MmEyOTU1MDYwNWUzODU1ZWJiMGZiN2QyYjqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-04-30 22:36:55.021219-04
31b87262cb54afd79609c0155047c52b	M2VlZWE3YjQ5MjQ4NTJmMTRmMWE3ZmMyYTJlNmRhMTVjYTc2YzIzNDqAAn1xAS4=\n	2012-05-01 10:13:34.252383-04
dd7cc4ffc0c572e382928eeadecbb7a0	OWU0YTc5YjUwNGJiMzM0M2EyMzcxOWMyMWNlMDE4NjA0N2MzNjM1ZTqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-03 16:43:05.364704-04
51241fdcd1a4a928dadc61fdba9fe148	NDg3YTVkZGI4OWRhZTU5MmEyOTU1MDYwNWUzODU1ZWJiMGZiN2QyYjqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-04 13:47:13.572662-04
d7fd7792ee764a97b80636042edd9164	OWU0YTc5YjUwNGJiMzM0M2EyMzcxOWMyMWNlMDE4NjA0N2MzNjM1ZTqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-04 13:55:25.865584-04
da8f01367d5bba2a9f5b999f79c0e9b0	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-16 22:16:51.540012-04
fc46045e7cc9e52510be2107202c4783	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-10 15:26:16.754341-04
597c856be3c56d2b5cb38f2c9bfd9c47	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-16 22:58:14.178812-04
3d0c92fb2d2b81575c59660c27726fbb	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-16 23:00:36.493242-04
beb04016957e267588ce00602afaa1c6	Mzc1ZWU2NTZkNTBhYTRjZThjZmM3OWY2MTI2M2FhMzcyNDZjZDAxYjqAAn1xAShVDV9hdXRoX3Vz\nZXJfaWRLB1USX2F1dGhfdXNlcl9iYWNrZW5kVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRz\nLk1vZGVsQmFja2VuZFULY3VycmVudF9vcmdjZGphbmdvLmRiLm1vZGVscy5iYXNlCm1vZGVsX3Vu\ncGlja2xlCnECY29ubHlpbnBnaC5vcmdhbml6YXRpb25zLm1vZGVscwpPcmdhbml6YXRpb24KcQNd\nY2RqYW5nby5kYi5tb2RlbHMuYmFzZQpzaW1wbGVfY2xhc3NfZmFjdG9yeQpxBIdScQV9cQYoVQlk\ndGNyZWF0ZWRxB2NkYXRldGltZQpkYXRldGltZQpxCFUKB9wEEQ86HARcg4VScQlVBG5hbWVxClgS\nAAAATWFnZ2llICYgU3RlbGxhJ3MgVQN1cmxxC1UAVQVpbWFnZXEMY2RqYW5nby5kYi5tb2RlbHMu\nZmllbGRzLmZpbGVzCkltYWdlRmllbGRGaWxlCnENKYFxDn1xDyhVCl9jb21taXR0ZWRxEIhVBV9m\naWxlcRFOaApOVQZjbG9zZWRxEol1YlUGX3N0YXRlcRNjZGphbmdvLmRiLm1vZGVscy5iYXNlCk1v\nZGVsU3RhdGUKcRQpgXEVfXEWKFUGYWRkaW5ncReJVQJkYnEYVQdkZWZhdWx0dWJVBWZiX2lkcRlV\nAFUQdHdpdHRlcl91c2VybmFtZXEaVQBVAmlkcRuKAQZ1YnUu\n	2012-05-01 15:58:28.411045-04
16b0aefbd89bf71b0a03f476f5c92a88	Y2VmOWQ0NzM2OWQ1ZWZiZGMyMGU2Y2NjMWM0ZmFjOTE5MmU0ZjNhNjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLBVULY3VycmVudF9vcmdxBWNkamFuZ28uZGIubW9kZWxzLmJhc2UK\nbW9kZWxfdW5waWNrbGUKcQZjb25seWlucGdoLm9yZ2FuaXphdGlvbnMubW9kZWxzCk9yZ2FuaXph\ndGlvbgpxB11jZGphbmdvLmRiLm1vZGVscy5iYXNlCnNpbXBsZV9jbGFzc19mYWN0b3J5CnEIh1Jx\nCX1xCihVCWR0Y3JlYXRlZHELY2RhdGV0aW1lCmRhdGV0aW1lCnEMVQoH3AQNCjk5DGXwhVJxDVUE\nbmFtZXEOWBEAAABSaWNrIEdvdHRsaWViIERNRFUDdXJscQ9YAAAAAFUFaW1hZ2VxEFgAAAAAVQZf\nc3RhdGVxEWNkamFuZ28uZGIubW9kZWxzLmJhc2UKTW9kZWxTdGF0ZQpxEimBcRN9cRQoVQZhZGRp\nbmdxFYlVAmRicRZVB2RlZmF1bHRxF3ViVQVmYl9pZHEYWAAAAABVEHR3aXR0ZXJfdXNlcm5hbWVx\nGVgAAAAAVQJpZHEaSwN1YnUu\n	2012-05-01 16:53:50.329461-04
9e45d9f18ae76f1ee5869c358a534d7f	Y2VmOWQ0NzM2OWQ1ZWZiZGMyMGU2Y2NjMWM0ZmFjOTE5MmU0ZjNhNjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLBVULY3VycmVudF9vcmdxBWNkamFuZ28uZGIubW9kZWxzLmJhc2UK\nbW9kZWxfdW5waWNrbGUKcQZjb25seWlucGdoLm9yZ2FuaXphdGlvbnMubW9kZWxzCk9yZ2FuaXph\ndGlvbgpxB11jZGphbmdvLmRiLm1vZGVscy5iYXNlCnNpbXBsZV9jbGFzc19mYWN0b3J5CnEIh1Jx\nCX1xCihVCWR0Y3JlYXRlZHELY2RhdGV0aW1lCmRhdGV0aW1lCnEMVQoH3AQNCjk5DGXwhVJxDVUE\nbmFtZXEOWBEAAABSaWNrIEdvdHRsaWViIERNRFUDdXJscQ9YAAAAAFUFaW1hZ2VxEFgAAAAAVQZf\nc3RhdGVxEWNkamFuZ28uZGIubW9kZWxzLmJhc2UKTW9kZWxTdGF0ZQpxEimBcRN9cRQoVQZhZGRp\nbmdxFYlVAmRicRZVB2RlZmF1bHRxF3ViVQVmYl9pZHEYWAAAAABVEHR3aXR0ZXJfdXNlcm5hbWVx\nGVgAAAAAVQJpZHEaSwN1YnUu\n	2012-05-01 17:18:29.664811-04
3738d65c67f7b891a7e47838ef8e270c	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 14:10:26.799568-04
1a8a19b41acf42a466d6b4a8a386ce8d	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 14:22:02.047117-04
1a9d99e9a709b5f954ba59b92ae85c96	Mjc0MDNjMDIzMTZiZGEwNjg1NmJmOTFkMTgwZDI1OGEzMTM4NDcxZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAVULY3VycmVudF9vcmdxBWNkamFuZ28uZGIubW9kZWxzLmJhc2UK\nbW9kZWxfdW5waWNrbGUKcQZjb25seWlucGdoLm9yZ2FuaXphdGlvbnMubW9kZWxzCk9yZ2FuaXph\ndGlvbgpxB11jZGphbmdvLmRiLm1vZGVscy5iYXNlCnNpbXBsZV9jbGFzc19mYWN0b3J5CnEIh1Jx\nCX1xCihVCWR0Y3JlYXRlZHELY2RhdGV0aW1lCmRhdGV0aW1lCnEMVQoH3AQNCCkCAUOchVJxDVUE\nbmFtZXEOWCUAAABPYWtsYW5kIEJ1c2luZXNzIEltcHJvdmVtZW50IERpc3RyaWN0VQN1cmxxD1gA\nAAAAVQVpbWFnZXEQWAAAAABVBl9zdGF0ZXERY2RqYW5nby5kYi5tb2RlbHMuYmFzZQpNb2RlbFN0\nYXRlCnESKYFxE31xFChVBmFkZGluZ3EViVUCZGJxFlUHZGVmYXVsdHEXdWJVBWZiX2lkcRhYAAAA\nAFUQdHdpdHRlcl91c2VybmFtZXEZWAAAAABVAmlkcRpLAXVidS4=\n	2012-05-02 11:34:03.496463-04
0d3381a0256f033947d99527f61fb4cb	Mjc0MDNjMDIzMTZiZGEwNjg1NmJmOTFkMTgwZDI1OGEzMTM4NDcxZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAVULY3VycmVudF9vcmdxBWNkamFuZ28uZGIubW9kZWxzLmJhc2UK\nbW9kZWxfdW5waWNrbGUKcQZjb25seWlucGdoLm9yZ2FuaXphdGlvbnMubW9kZWxzCk9yZ2FuaXph\ndGlvbgpxB11jZGphbmdvLmRiLm1vZGVscy5iYXNlCnNpbXBsZV9jbGFzc19mYWN0b3J5CnEIh1Jx\nCX1xCihVCWR0Y3JlYXRlZHELY2RhdGV0aW1lCmRhdGV0aW1lCnEMVQoH3AQNCCkCAUOchVJxDVUE\nbmFtZXEOWCUAAABPYWtsYW5kIEJ1c2luZXNzIEltcHJvdmVtZW50IERpc3RyaWN0VQN1cmxxD1gA\nAAAAVQVpbWFnZXEQWAAAAABVBl9zdGF0ZXERY2RqYW5nby5kYi5tb2RlbHMuYmFzZQpNb2RlbFN0\nYXRlCnESKYFxE31xFChVBmFkZGluZ3EViVUCZGJxFlUHZGVmYXVsdHEXdWJVBWZiX2lkcRhYAAAA\nAFUQdHdpdHRlcl91c2VybmFtZXEZWAAAAABVAmlkcRpLAXVidS4=\n	2012-05-02 11:35:02.917858-04
f47e550e2328d099942e3d81a3d89d70	OWU0YTc5YjUwNGJiMzM0M2EyMzcxOWMyMWNlMDE4NjA0N2MzNjM1ZTqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-04-27 10:44:47.110485-04
f62de1b9bd6a7533fab64ae3cb67142d	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-13 15:21:22.243743-04
d6f974f4a83e8483a8817739543fa515	M2VlZWE3YjQ5MjQ4NTJmMTRmMWE3ZmMyYTJlNmRhMTVjYTc2YzIzNDqAAn1xAS4=\n	2012-05-02 18:25:11.968544-04
0de3b711c827bb4d3f79f268d50736c9	NDg3YTVkZGI4OWRhZTU5MmEyOTU1MDYwNWUzODU1ZWJiMGZiN2QyYjqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-04-30 15:02:45.78551-04
65a9ae3c53bdd03f292638178edd8ac8	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-10 15:27:40.321649-04
3b1f4e5b5a1cb62bfc82e799ff6c08cf	Mjc0MDNjMDIzMTZiZGEwNjg1NmJmOTFkMTgwZDI1OGEzMTM4NDcxZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAVULY3VycmVudF9vcmdxBWNkamFuZ28uZGIubW9kZWxzLmJhc2UK\nbW9kZWxfdW5waWNrbGUKcQZjb25seWlucGdoLm9yZ2FuaXphdGlvbnMubW9kZWxzCk9yZ2FuaXph\ndGlvbgpxB11jZGphbmdvLmRiLm1vZGVscy5iYXNlCnNpbXBsZV9jbGFzc19mYWN0b3J5CnEIh1Jx\nCX1xCihVCWR0Y3JlYXRlZHELY2RhdGV0aW1lCmRhdGV0aW1lCnEMVQoH3AQNCCkCAUOchVJxDVUE\nbmFtZXEOWCUAAABPYWtsYW5kIEJ1c2luZXNzIEltcHJvdmVtZW50IERpc3RyaWN0VQN1cmxxD1gA\nAAAAVQVpbWFnZXEQWAAAAABVBl9zdGF0ZXERY2RqYW5nby5kYi5tb2RlbHMuYmFzZQpNb2RlbFN0\nYXRlCnESKYFxE31xFChVBmFkZGluZ3EViVUCZGJxFlUHZGVmYXVsdHEXdWJVBWZiX2lkcRhYAAAA\nAFUQdHdpdHRlcl91c2VybmFtZXEZWAAAAABVAmlkcRpLAXVidS4=\n	2012-04-30 16:01:34.411932-04
e9fcdfe1d7e512e83d0f92736e7eb339	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-10 16:39:05.835903-04
7a3d1bbfd0519af1910056173f9607bd	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-12 13:58:32.732697-04
f659ea54e1b33339fc743b50e7679221	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-12 13:59:30.159393-04
33b35f4913b058a3d224b1d13c65f23c	Mjc0MDNjMDIzMTZiZGEwNjg1NmJmOTFkMTgwZDI1OGEzMTM4NDcxZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAVULY3VycmVudF9vcmdxBWNkamFuZ28uZGIubW9kZWxzLmJhc2UK\nbW9kZWxfdW5waWNrbGUKcQZjb25seWlucGdoLm9yZ2FuaXphdGlvbnMubW9kZWxzCk9yZ2FuaXph\ndGlvbgpxB11jZGphbmdvLmRiLm1vZGVscy5iYXNlCnNpbXBsZV9jbGFzc19mYWN0b3J5CnEIh1Jx\nCX1xCihVCWR0Y3JlYXRlZHELY2RhdGV0aW1lCmRhdGV0aW1lCnEMVQoH3AQNCCkCAUOchVJxDVUE\nbmFtZXEOWCUAAABPYWtsYW5kIEJ1c2luZXNzIEltcHJvdmVtZW50IERpc3RyaWN0VQN1cmxxD1gA\nAAAAVQVpbWFnZXEQWAAAAABVBl9zdGF0ZXERY2RqYW5nby5kYi5tb2RlbHMuYmFzZQpNb2RlbFN0\nYXRlCnESKYFxE31xFChVBmFkZGluZ3EViVUCZGJxFlUHZGVmYXVsdHEXdWJVBWZiX2lkcRhYAAAA\nAFUQdHdpdHRlcl91c2VybmFtZXEZWAAAAABVAmlkcRpLAXVidS4=\n	2012-04-30 18:47:24.882521-04
3422970bfb935f7fac43d763daf3e4ea	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-12 14:01:07.788223-04
24f70d4a7a8ea89585a5674f0127e39d	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 02:36:26.588264-04
45cb1f4bef8bcc29c89857d937b68f0d	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-12 14:01:19.301919-04
0b20be218ccdaa5984bab9ae21a460ec	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-14 15:21:33.725271-04
167db7d981b5fb970a5910281608d49b	YWUzNTk2OTdjNWFjODA4N2IyZWMyOGZiNjE3MjNhMDBmZDA5MTFlYTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLA1ULY3VycmVudF9vcmdxBWNkamFuZ28uZGIubW9kZWxzLmJhc2UK\nbW9kZWxfdW5waWNrbGUKcQZjb25seWlucGdoLm9yZ2FuaXphdGlvbnMubW9kZWxzCk9yZ2FuaXph\ndGlvbgpxB11jZGphbmdvLmRiLm1vZGVscy5iYXNlCnNpbXBsZV9jbGFzc19mYWN0b3J5CnEIh1Jx\nCX1xCihVCWR0Y3JlYXRlZHELY2RhdGV0aW1lCmRhdGV0aW1lCnEMVQoH3AQNChoOBFA4hVJxDVUE\nbmFtZXEOWCYAAABUb3VjaCBvZiBHb2xkIGFuZCBTaWx2ZXIgSmV3ZWxyeSBTdG9yZVUDdXJscQ9Y\nAAAAAFUFaW1hZ2VxEFgAAAAAVQZfc3RhdGVxEWNkamFuZ28uZGIubW9kZWxzLmJhc2UKTW9kZWxT\ndGF0ZQpxEimBcRN9cRQoVQZhZGRpbmdxFYlVAmRicRZVB2RlZmF1bHRxF3ViVQVmYl9pZHEYWAAA\nAABVEHR3aXR0ZXJfdXNlcm5hbWVxGVgAAAAAVQJpZHEaSwJ1YnUu\n	2012-05-01 14:59:17.939436-04
c1c9c32cb58e626c8552050048d75d63	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-14 17:18:00.450704-04
64d304f63e025095d13cce7859d09a11	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-14 17:24:03.319623-04
cbde8ab1f42a49d7512e5ac7f2442b86	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-15 16:45:00.975659-04
c7246de88729ca1fabb9b14c49d8a7b5	YjM4NTI5Mjg3ZGUwODc0ZTRiMDA3YzU2M2UwNmQ5Y2UwOTFmZWQ4YzqAAn1xAShVDV9hdXRoX3Vz\nZXJfaWRLBlUSX2F1dGhfdXNlcl9iYWNrZW5kVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRz\nLk1vZGVsQmFja2VuZFULY3VycmVudF9vcmdjZGphbmdvLmRiLm1vZGVscy5iYXNlCm1vZGVsX3Vu\ncGlja2xlCnECY29ubHlpbnBnaC5vcmdhbml6YXRpb25zLm1vZGVscwpPcmdhbml6YXRpb24KcQNd\nY2RqYW5nby5kYi5tb2RlbHMuYmFzZQpzaW1wbGVfY2xhc3NfZmFjdG9yeQpxBIdScQV9cQYoVQlk\ndGNyZWF0ZWRxB2NkYXRldGltZQpkYXRldGltZQpxCFUKB9wEDQsGEgJzwoVScQlVBG5hbWVxClgI\nAAAAU2NlbmFibGVVA3VybHELVQBVBWltYWdlcQxjZGphbmdvLmRiLm1vZGVscy5maWVsZHMuZmls\nZXMKSW1hZ2VGaWVsZEZpbGUKcQ0pgXEOfXEPKFUKX2NvbW1pdHRlZHEQiFUFX2ZpbGVxEU5oCk5V\nBmNsb3NlZHESiXViVQZfc3RhdGVxE2NkamFuZ28uZGIubW9kZWxzLmJhc2UKTW9kZWxTdGF0ZQpx\nFCmBcRV9cRYoVQZhZGRpbmdxF4lVAmRicRhVB2RlZmF1bHR1YlUFZmJfaWRxGVUAVRB0d2l0dGVy\nX3VzZXJuYW1lcRpVAFUCaWRxG4oBBXVidS4=\n	2012-04-27 11:06:18.214842-04
e44acb21ca548fe3623f9b037778c9fa	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-15 16:55:07.964687-04
cfb299ea2e6b8f41503a24dfd9c913da	NDg3YTVkZGI4OWRhZTU5MmEyOTU1MDYwNWUzODU1ZWJiMGZiN2QyYjqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-04-27 13:27:11.397926-04
64bb36d04d4e61deaeafdce7cc42ce64	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 00:03:25.039958-04
c2108f565b855d89948950b8ef36b42f	Y2VmOWQ0NzM2OWQ1ZWZiZGMyMGU2Y2NjMWM0ZmFjOTE5MmU0ZjNhNjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLBVULY3VycmVudF9vcmdxBWNkamFuZ28uZGIubW9kZWxzLmJhc2UK\nbW9kZWxfdW5waWNrbGUKcQZjb25seWlucGdoLm9yZ2FuaXphdGlvbnMubW9kZWxzCk9yZ2FuaXph\ndGlvbgpxB11jZGphbmdvLmRiLm1vZGVscy5iYXNlCnNpbXBsZV9jbGFzc19mYWN0b3J5CnEIh1Jx\nCX1xCihVCWR0Y3JlYXRlZHELY2RhdGV0aW1lCmRhdGV0aW1lCnEMVQoH3AQNCjk5DGXwhVJxDVUE\nbmFtZXEOWBEAAABSaWNrIEdvdHRsaWViIERNRFUDdXJscQ9YAAAAAFUFaW1hZ2VxEFgAAAAAVQZf\nc3RhdGVxEWNkamFuZ28uZGIubW9kZWxzLmJhc2UKTW9kZWxTdGF0ZQpxEimBcRN9cRQoVQZhZGRp\nbmdxFYlVAmRicRZVB2RlZmF1bHRxF3ViVQVmYl9pZHEYWAAAAABVEHR3aXR0ZXJfdXNlcm5hbWVx\nGVgAAAAAVQJpZHEaSwN1YnUu\n	2012-05-01 17:20:29.826117-04
fcaaca797d4a55d905128b819344b234	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 21:50:16.039031-04
90263118f8219b857e66414808157b1d	YTI3N2Y0MDAzN2QxNGQyMzRkMTRhYTFlZmE0NWI2NTU1NTRjNDFlMzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLClULY3VycmVudF9vcmdxBWNkamFuZ28uZGIubW9kZWxzLmJhc2UK\nbW9kZWxfdW5waWNrbGUKcQZjb25seWlucGdoLm9yZ2FuaXphdGlvbnMubW9kZWxzCk9yZ2FuaXph\ndGlvbgpxB11jZGphbmdvLmRiLm1vZGVscy5iYXNlCnNpbXBsZV9jbGFzc19mYWN0b3J5CnEIh1Jx\nCX1xCihVCWR0Y3JlYXRlZHELY2RhdGV0aW1lCmRhdGV0aW1lCnEMVQoH3AQcDTsYCqLLhVJxDVUE\nbmFtZXEOWB4AAABDYXJuZWdpZSBMaWJyYXJ5IG9mIFBpdHRzYnVyZ2hVA3VybHEPWAAAAABVBWlt\nYWdlcRBYAAAAAFUGX3N0YXRlcRFjZGphbmdvLmRiLm1vZGVscy5iYXNlCk1vZGVsU3RhdGUKcRIp\ngXETfXEUKFUGYWRkaW5ncRWJVQJkYnEWVQdkZWZhdWx0cRd1YlUFZmJfaWRxGFgAAAAAVRB0d2l0\ndGVyX3VzZXJuYW1lcRlYAAAAAFUCaWRxGksJdWJ1Lg==\n	2012-05-13 15:16:21.42383-04
8e75708c3e72cc991259205fc647e060	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 01:55:37.943858-04
22b9e41f50ca49d8f77d2dcedf26388f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-14 17:18:14.095884-04
c746675e56d175b3925d537963f07bf2	OWU0YTc5YjUwNGJiMzM0M2EyMzcxOWMyMWNlMDE4NjA0N2MzNjM1ZTqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-02 17:50:05.49055-04
b00dd746ac1b57b4592c08136d1fe2d5	M2VlZWE3YjQ5MjQ4NTJmMTRmMWE3ZmMyYTJlNmRhMTVjYTc2YzIzNDqAAn1xAS4=\n	2012-05-02 17:51:19.946468-04
bc2267f9ad9a4c4d67e1c6337b7650c7	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 05:13:45.308573-04
05e00df4f624035b52c13c44d9918386	M2IzM2FlZmFiNTAyMDAxZTFlNGUwNTc2MzU3ODdhM2QxN2NlNjI1ZDqAAn1xAShVDV9hdXRoX3Vz\nZXJfaWRLC1USX2F1dGhfdXNlcl9iYWNrZW5kVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRz\nLk1vZGVsQmFja2VuZFULY3VycmVudF9vcmdjZGphbmdvLmRiLm1vZGVscy5iYXNlCm1vZGVsX3Vu\ncGlja2xlCnECY29ubHlpbnBnaC5vcmdhbml6YXRpb25zLm1vZGVscwpPcmdhbml6YXRpb24KcQNd\nY2RqYW5nby5kYi5tb2RlbHMuYmFzZQpzaW1wbGVfY2xhc3NfZmFjdG9yeQpxBIdScQV9cQYoVQlk\ndGNyZWF0ZWRxB2NkYXRldGltZQpkYXRldGltZQpxCFUKB9wFARA3NAIEroVScQlVBG5hbWVxClgU\nAAAAVW5kZXJncm91bmQgUHJpbnRpbmdVA3VybHELVQBVBWltYWdlcQxjZGphbmdvLmRiLm1vZGVs\ncy5maWVsZHMuZmlsZXMKSW1hZ2VGaWVsZEZpbGUKcQ0pgXEOfXEPKFUKX2NvbW1pdHRlZHEQiFUF\nX2ZpbGVxEU5oCk5VBmNsb3NlZHESiXViVQZfc3RhdGVxE2NkamFuZ28uZGIubW9kZWxzLmJhc2UK\nTW9kZWxTdGF0ZQpxFCmBcRV9cRYoVQZhZGRpbmdxF4lVAmRicRhVB2RlZmF1bHR1YlUFZmJfaWRx\nGVUAVRB0d2l0dGVyX3VzZXJuYW1lcRpVAFUCaWRxG0sKdWJ1Lg==\n	2012-05-15 16:55:52.392667-04
0992b60f70394ab4945624a769ad2d24	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-16 09:05:27.240891-04
7fbe5353d4c7f235dc7dbe92d1207725	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-10 16:39:05.511402-04
267e5f98017eb28d1b715fd62b2bf6c1	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-10 16:39:06.26084-04
791be4490b78022ec6c7eb24c5d0caa2	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-11 07:56:39.488348-04
3ff9515cc85908dda951b333d63ffac4	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-11 16:20:53.327707-04
cd910b3a583ef1c89979ac5e0726ffee	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-16 22:01:37.748303-04
edb52c18f3fc63f9215af76a1a969e26	N2VkZjRkNzAzOTA3NWY4YjcwNzkzMTg2MmFjNmQ2MzhmMTJhNjZiNzqAAn1xAShVDV9hdXRoX3Vz\nZXJfaWRLDVUSX2F1dGhfdXNlcl9iYWNrZW5kVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRz\nLk1vZGVsQmFja2VuZFULY3VycmVudF9vcmdjZGphbmdvLmRiLm1vZGVscy5iYXNlCm1vZGVsX3Vu\ncGlja2xlCnECY29ubHlpbnBnaC5vcmdhbml6YXRpb25zLm1vZGVscwpPcmdhbml6YXRpb24KcQNd\nY2RqYW5nby5kYi5tb2RlbHMuYmFzZQpzaW1wbGVfY2xhc3NfZmFjdG9yeQpxBIdScQV9cQYoVQlk\ndGNyZWF0ZWRxB2NkYXRldGltZQpkYXRldGltZQpxCFUKB9wFAgkuMA7LYIVScQlVBG5hbWVxClgp\nAAAAUGVubnN5bHZhbmlhIENvbW1lcmNpYWwgUmVhbCBFc3RhdGUsIEluYy5VA3VybHELVQBVBWlt\nYWdlcQxjZGphbmdvLmRiLm1vZGVscy5maWVsZHMuZmlsZXMKSW1hZ2VGaWVsZEZpbGUKcQ0pgXEO\nfXEPKFUKX2NvbW1pdHRlZHEQiFUFX2ZpbGVxEU5oCk5VBmNsb3NlZHESiXViVQZfc3RhdGVxE2Nk\namFuZ28uZGIubW9kZWxzLmJhc2UKTW9kZWxTdGF0ZQpxFCmBcRV9cRYoVQZhZGRpbmdxF4lVAmRi\ncRhVB2RlZmF1bHR1YlUFZmJfaWRxGVUAVRB0d2l0dGVyX3VzZXJuYW1lcRpVAFUCaWRxG0sMdWJ1\nLg==\n	2012-05-16 09:46:49.178475-04
2343885e593de662a76df206f9fa51c1	MTkxN2RjMDE1NzkzY2QzZmRmNjRjNWQ4OWQwMmE2NDNjNjI5MjVmNzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLA1ULY3VycmVudF9vcmdxBWNkamFuZ28uZGIubW9kZWxzLmJhc2UK\nbW9kZWxfdW5waWNrbGUKcQZjb25seWlucGdoLm9yZ2FuaXphdGlvbnMubW9kZWxzCk9yZ2FuaXph\ndGlvbgpxB11jZGphbmdvLmRiLm1vZGVscy5iYXNlCnNpbXBsZV9jbGFzc19mYWN0b3J5CnEIh1Jx\nCX1xCihVCWR0Y3JlYXRlZHELY2RhdGV0aW1lCmRhdGV0aW1lCnEMVQoH3AQNChoOBFA4hVJxDVUE\nbmFtZXEOWCYAAABUb3VjaCBvZiBHb2xkIGFuZCBTaWx2ZXIgSmV3ZWxyeSBTdG9yZVUDdXJscQ9Y\nAAAAAFUFaW1hZ2VxEFgAAAAAVQZfc3RhdGVxEWNkamFuZ28uZGIubW9kZWxzLmJhc2UKTW9kZWxT\ndGF0ZQpxEimBcRN9cRQoVQZhZGRpbmdxFYlVAmRicRZVB2RlZmF1bHRxF3ViVQVmYl9pZHEYWAAA\nAABVEHR3aXR0ZXJfdXNlcm5hbWVxGVgAAAAAVQJpZHEaSwJ1YnUu\n	2012-05-16 10:10:14.001355-04
626d4cb83b86bdf4c003e292234cea6a	OGRiMTU1MjkxMmM1OWE5OTliOGVmMTJiMTQyODcwMzZiNzNlYzdhNjqAAn1xAShVDV9hdXRoX3Vz\nZXJfaWRLClUSX2F1dGhfdXNlcl9iYWNrZW5kVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRz\nLk1vZGVsQmFja2VuZFULY3VycmVudF9vcmdjZGphbmdvLmRiLm1vZGVscy5iYXNlCm1vZGVsX3Vu\ncGlja2xlCnECY29ubHlpbnBnaC5vcmdhbml6YXRpb25zLm1vZGVscwpPcmdhbml6YXRpb24KcQNd\nY2RqYW5nby5kYi5tb2RlbHMuYmFzZQpzaW1wbGVfY2xhc3NfZmFjdG9yeQpxBIdScQV9cQYoVQlk\ndGNyZWF0ZWRxB2NkYXRldGltZQpkYXRldGltZQpxCFUKB9wEHA07GAqiy4VScQlVBG5hbWVxClge\nAAAAQ2FybmVnaWUgTGlicmFyeSBvZiBQaXR0c2J1cmdoVQN1cmxxC1UAVQVpbWFnZXEMY2RqYW5n\nby5kYi5tb2RlbHMuZmllbGRzLmZpbGVzCkltYWdlRmllbGRGaWxlCnENKYFxDn1xDyhVCl9jb21t\naXR0ZWRxEIhVBV9maWxlcRFOaApOVQZjbG9zZWRxEol1YlUGX3N0YXRlcRNjZGphbmdvLmRiLm1v\nZGVscy5iYXNlCk1vZGVsU3RhdGUKcRQpgXEVfXEWKFUGYWRkaW5ncReJVQJkYnEYVQdkZWZhdWx0\ndWJVBWZiX2lkcRlVAFUQdHdpdHRlcl91c2VybmFtZXEaVQBVAmlkcRtLCXVidS4=\n	2012-05-12 13:59:25.045546-04
255dbf2a694f0ff1922a6f4e08e8434b	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-12 13:59:45.753612-04
05c2beb2477763dfc42a398386969e8a	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-12 14:01:12.868929-04
27d1ff143337b9367a293d84fccfd5e1	ODI1MmI3MzNiMGQ0M2NhYmFhMDQ1OWE5MzI4NmY0MGY0NTY3MzExZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAXUu\n	2012-05-16 19:14:40.114176-04
7de0cc5c9818b1ba18b2cacec91dbc0b	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 14:05:55.377308-04
538fcf1593e9ba4f022bd82bf9e8b2a2	NWIyMDZmZTdjMmM4MmJjMjEyNTQ5YzUzMDdlNzQ1YTcyZmZlMzY3NTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLKnUu\n	2012-05-17 09:59:44.025132-04
b14aff5442eb6cad3bf12c96890903b2	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-19 19:54:16.630216-04
ccb00420c83ef5207b500ed4845f80f5	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-19 21:12:24.303899-04
47e7d3005390a8e40daf07db720e8098	YTlmNzEyMzY3NjU3Yzc0Y2E4MzBkZTY3MGQ2NmU4MDhhNjRhMWU2ZTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLLHUu\n	2012-05-17 10:22:45.751794-04
b3eb66100867856a1cae9e79609e8d01	ODI1MmI3MzNiMGQ0M2NhYmFhMDQ1OWE5MzI4NmY0MGY0NTY3MzExZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAXUu\n	2012-05-16 21:02:22.36338-04
c1e5fcaae75ec6522e61436ae1984738	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-16 22:11:58.997138-04
ed793e0485008f9fba623e0b79f37df6	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-16 22:58:14.422013-04
530657a5aa7a461de7c7a799921f2bc8	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-16 23:01:37.139351-04
1a7a9939a0d1f028d60f790a27382694	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-16 23:01:57.888816-04
f5f3fcc508795877652456b9861d9419	ZWIxMDA1MWY4ZTA3OTZjMjk2ZjdiZGM3OWVmNDc4MTRkZGRkYjJhMDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLEXUu\n	2012-05-16 23:02:41.261845-04
70117f4fc454ebe8a9b084af7ed38aa7	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-16 23:03:32.960344-04
6582030e300ac78efc34c9149382fdcf	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-16 23:04:08.620224-04
480ad5546fd8421d095263da65ab558b	MTE4YTA0ZDdjZjljNDc0NWUwMGVjOGU2MDc1MWRmYWE0ODlmMTBjMjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLEnUu\n	2012-05-16 23:04:39.644147-04
920bdbcc801828868782dcab69310a10	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-16 23:05:02.227603-04
c4a5bbc622bf06173e296935af132096	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-16 23:06:04.39671-04
21cd64a2f1bf112e7b8f1db132a990b1	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-16 23:06:22.238516-04
79c1f9cf9b70446c4daf5fe030f98aa3	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-16 23:07:29.092485-04
411c413ad38d6d0af10cd218fb941145	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-16 23:07:39.875395-04
e8ddd38949e387942ff8d420522c6c96	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-16 23:11:50.739173-04
68cbe7f32948bbbbc8124ee32340ba52	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-16 23:12:28.201986-04
190a9f9278ad055e9f8d3ac4385cdd44	YTlhYWNkZjNhODZhYTY3NzMyYTY0ODZjZjQ3YjEyOTE4OTg5ZmE0OTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLE3Uu\n	2012-05-16 23:14:14.217066-04
492fa97cdf9a8eb7651256998ff5d46c	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-16 23:14:33.37089-04
90b973f1adff5adb8cc9f01cf9d97998	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-16 23:18:00.514265-04
52f0b4bb47e93fa3ce341886c824756d	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-16 23:18:20.380352-04
60f052b0ea61672ba2bd3a9dc28a841a	MTM0NmQ4NzQ3Y2NjMWVmM2Y4M2VjMWNjMTk4MThiN2VkYzdjMzAzYzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLFHUu\n	2012-05-16 23:19:02.82787-04
38ef32784a069123889b2d32ec5124c1	MmIyMjRkNGVmZDdiNjczMjVlMDJkMjFmNWZkMzRlOWQzYWEyYmYxMDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLFXUu\n	2012-05-16 23:20:50.158561-04
a6ae81d7bf9d36d5f9672d2bb35013ba	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-16 23:21:13.828108-04
ff005735cea5a55aabe2ddbf02f304e3	MDViOTg3M2Q4NWY2NWY0MGRhY2VhMDcxNDg3YTkxYmIxNGQwNzcyMjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLFnUu\n	2012-05-16 23:21:16.976083-04
6b2737301f74e232f7abf3ae67bbdba9	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-16 23:25:57.633818-04
2468eb760cf3b5bedacab129fc973ba4	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-16 23:28:41.753147-04
cb89b7cfd12d3b4823a4fff3b667ecc4	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-16 23:29:13.846664-04
0a9c45f663259ddb1672850e9f362f5a	ZTc3ZGZhZjAwNmE2Mzk0MzhjMWE1NDFiMDg3YzViNjVmNTQ4NTU2MjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLF3Uu\n	2012-05-16 23:34:40.781112-04
c9cbb6edf3f3f3e0166ac2fcd727561f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-16 23:48:14.281329-04
cbbc06abc8da622cd849c15ddbb97048	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-16 23:51:35.362676-04
39cb971562e46ea4175e6db007e02f75	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-16 23:57:09.343711-04
38e51a466c4df2ecb8ed25f4c319aed6	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 00:00:26.592369-04
9f3ebec8656fc8b168c0ecd7636f0440	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 02:00:11.943309-04
9408fc259b4be53b5c0702e4bf68ca6a	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 21:50:16.150166-04
1af3912da28e487596cbe2b77a3462b5	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 00:02:31.139455-04
eda943f0382caf8821b3e2215613aea7	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 14:02:22.619131-04
3449878c6f90a7756697dc1f4d6a1f2a	Y2FkOTFjMmRmZmQ1MTBhMjJiMWE1MmZmMzJlYzhjMjZlYjM5OGE2YjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLGHUu\n	2012-05-17 00:03:13.994491-04
f988ca5ea9da34c74a20a37cad4a8be7	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 00:03:27.346809-04
7d952dbda756b28562a4e29b0b7e5272	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 04:07:12.194097-04
f4815e817188ccae1fb353468511e828	OTI2ZTBjYjM0Y2I1OTQyMWQ4M2YxYTllYTQzYjAwYjUyNjcxYjI5NjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLGXUu\n	2012-05-17 00:03:55.858244-04
c52d968e0ca41accc1358bbfe39a7020	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 05:00:55.114369-04
12ec51401199eb501debc6ef78f91a91	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 06:38:21.298471-04
d7e7c20480bb7b5f58b80c0263f352fc	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 06:48:48.29541-04
7e7cf24f9a5c2579c561636e83017dec	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 00:07:15.74684-04
cd14084872e42732ebd74e1bfdcd2a71	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 06:58:48.183478-04
fd8cd641dfa115a9322ba1a566b905f3	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 07:09:31.806208-04
342c3481ce25c6d2ede21fae11d1dbac	YzQ5ZDY4MDYzZDE2ZTUzOGVhZDc4M2I0YTc4ZmVkZjU5ZjliMzlhMDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLHHUu\n	2012-05-17 07:09:34.778252-04
d5e98657b2e6623382f6a356d3d68f27	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 07:09:43.976416-04
9491fd94e4bd81ec62d917a5e67ac50e	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 07:09:50.102491-04
be16e1d72c9703e1e947e8651c7fc33e	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 07:14:18.175724-04
aa09f5381bebd0b5633e222c4f5d2e39	ODk0OGE0OTgyZGRiNWM4YmFiZDFiZGUyNTZkYjIyZmZjMjBkM2IzNDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAnUu\n	2012-05-17 07:23:40.119852-04
53e30d2c9c33b28be39e491f14bd3891	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 07:28:06.439425-04
ae754c79175e6b0306c44bd118ff9064	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 07:29:15.907795-04
d82ffb47a08ff7b4d848844850993821	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 07:41:29.980706-04
c5459d03f06dee65273b77fadfad21da	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 00:13:08.023783-04
e39071943f58c5808e4861438eda1fb5	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 07:41:30.727002-04
18d9efdaf4b0a950a5f380d22ef9a902	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 07:41:46.301279-04
b89035a7e4ac8913a9b812b4ada5e8aa	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 00:13:18.180281-04
a58efecad27d22f9486955b667268a45	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 00:13:25.132335-04
ed3eeb44e79e2db5354411fce9989c0b	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 00:14:28.47727-04
7070c65fa004fa46df39dae611fad83c	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 00:25:58.509044-04
e95c99649d5c0ae8e27c5e40d4bef424	NGNjZjQ4Y2U4ZTEzNGZhNWQwMmI2NzBlMDhjYTM3NTUwMjhhZGM3OTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLHXUu\n	2012-05-17 07:42:42.530302-04
07fac6b7f4a37695dc72cf98505a470a	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 07:42:42.956509-04
e930231544536c5af485b9302d145e8a	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 07:42:43.331052-04
2590f972928852888dc3a1b0d04b8c15	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 07:43:35.315156-04
996e2fd246483d6c5f7c62ef09be38b7	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 07:43:43.560902-04
d90b81be77ccbef2533608e1902a5616	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 07:45:47.540546-04
793cf910375c78186f21cb59754e5e98	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 07:45:50.878083-04
550eb31f87845be6b914e24c9491a5b4	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 07:45:59.968135-04
624454d03717c51a91ddba133fbf14fa	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 08:42:55.590936-04
c3ee577ce8dbb3691a60b981755579fa	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 01:03:57.617857-04
2949696437323228082731631e6e0da9	NzVhMWQ4M2Y0OGRmNjU3NzcxZDI1MzMzNTA2YzZhMzFiN2I1MzU2NTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLGnUu\n	2012-05-17 01:08:20.694678-04
6643728d34f17356b5f119118b98d2b1	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 01:24:05.863458-04
f6e23980f33a8dc525b82e0b6a2af6db	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 07:46:16.926347-04
23614171e39d0d24eba7437332987b5d	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 07:46:22.324656-04
fa6ccaf2013a264b5d81fb44ea78c641	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 07:46:25.722506-04
6b347a37f996f8a2ab366b6f37891e00	NDJiNzA3NmFmMGZhYTc4MTg0ZjYzMzU4N2U4NzAxMDM5MTBhMzdiNDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLKXUu\n	2012-05-17 09:44:02.983459-04
3dafbb94926c533b1d384e76fe2798c9	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-19 21:35:44.465126-04
f61ac03d160fc847564cdbf4d5e42c6b	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-19 21:49:14.334624-04
8b6ef0779cf36e50f94e2513e387f8cb	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 07:49:54.027538-04
9090b6e0be520a4d17bceb9094285ff6	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 14:38:24.90563-04
3d01300f01aaf60d0179c8e9e2af97af	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 15:37:18.900768-04
6e5b90ea278eddf3e48ca302ce38be09	NTEyOWM2OThjOWUxYjdmMmM5OWMxYjgzMjBlNDBlNTg2MmQ3NzM0ZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLHnUu\n	2012-05-17 07:54:13.961454-04
859b83e15a0876d28b8fa3dd5adfd45f	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 07:56:01.77035-04
4e18d36ed2a54fbd4b4438041873d868	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 07:56:53.528536-04
d252e51f928ec2f2fd7f80c8ac9a4b19	NTg2N2Y0Y2YwYTcyMjc0YTkyNjUwZjQ1NjEzNzQ2MjUzMTdiYjBlMTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLH3Uu\n	2012-05-17 08:00:45.044512-04
61869b11f7dbbbe6222b8ea44259805c	NTY3OGUyNjgwYTE0ZDhjYmI4NjVmYjMwMWU3ZGQ3NWE0MTZlZTM4YjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLIHUu\n	2012-05-17 08:10:10.15529-04
4111a38c43eeedae99693d5e91b4bfe8	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 08:12:37.076056-04
6553006250b2ea1ec9e77ea401d16204	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 08:21:57.190249-04
976ea6649fb6923ef4c3c12859b9204e	NTczYWExOTc5YjM0YjIxZGI2ZDZjZGFjMTVmYTAyNzlkNTk2ZWI3YzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLInUu\n	2012-05-17 08:23:10.704736-04
d91ee7b230a5524e41b8a1c6b44fb230	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 08:25:03.023521-04
275f7c582911720085617674917ccea7	NzM0NmYxYjUwZDQyYWU4OTljOWEwYjJmN2Q1NmM3Mjc4NzAwYWU1NjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLI3Uu\n	2012-05-17 08:32:22.022902-04
209d0d19da1c894675c0a74b5533303e	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 08:35:07.392635-04
67316afac65f6089bac19f64723e864e	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 08:38:03.964689-04
6cf99292ba813933bf0c21c3d16525ed	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 08:40:11.744436-04
cbf278396c389d2593f44b56e9192065	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 08:42:52.966521-04
eb9aa86f177330fba772766bd3573ac2	MGNmZGQxOTc4MzI3ZjI5Nzc5MzFhNDlkNzc3OTU0MzA1NWFhMGMyZTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLJHUu\n	2012-05-17 08:44:02.489756-04
25daef0ecc2d8afc494e4cb6c52208e2	ZjQ4Y2Q3NjRlZjYxNmNlZDI1YWY0ZGQ4YzQ2ZGJkM2VmNDYxY2JhYjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLJXUu\n	2012-05-17 08:49:39.929185-04
e25cfca107b679298dc9b6ad86ecd380	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 08:52:22.053967-04
1e5a47b8651155ea5e5a7d3fc982037a	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 08:52:25.204136-04
87318a4e16fc0ec4e6943653f29f1b7c	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 08:55:16.46671-04
53eb0f24859445d36df1812bf195d726	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 08:55:20.768089-04
7bf21898ef2e5b54a368789bb79fbb15	ZDNlM2Q1ZDhlZWZhNDdkMGNmMDJhNTNhMzQ3YWFlNzQxYjdlOThjZDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLJnUu\n	2012-05-17 08:56:26.140891-04
dd43709afeb1fdefaad6e05bb3557b49	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 09:02:03.760101-04
d532c24af635a3f3de8471ac8dc56daf	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 09:14:42.740038-04
cd4447d248da14ed309d2730bffa2253	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 09:14:44.153837-04
2b8722a408a3e5ab531c539a3fd29687	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 09:15:10.93119-04
4f49855c1c322e6983f029f7e0b51c1e	OGVmODRkMmE3ZjM2MjdkZTEyNGI2OWZmN2I3MTkxNTAwYTE5MGZiOTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLJ3Uu\n	2012-05-17 09:15:22.02234-04
b847fa2b14b1fcac14e2d985ec40f066	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 09:16:33.881225-04
f5e82172a8e1cc5c09281d591ee222e3	YWYyNWY3ZDkyZTM2OGY2MDFmYmI2ZDVkMTU3ZGYzNDg2ODhmOTVkMzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLKHUu\n	2012-05-17 09:20:56.03097-04
1c3791d1ffce45172dbfc718605047bf	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 09:26:01.669258-04
fcab44159d29fbb956f00cf5510394f8	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 09:29:17.617392-04
f5244281261421bcacbdec5ae118944e	OGY2ZWRmMjZlY2VkNGMyOTY2NGJlYWU1NmUzNmZhZGIyYzc1NmFhMzqAAn1xAShVDV9hdXRoX3Vz\nZXJfaWRLNlUSX2F1dGhfdXNlcl9iYWNrZW5kVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRz\nLk1vZGVsQmFja2VuZHUu\n	2012-05-17 14:10:36.569959-04
188b8349bb0e1a1557a564fdf5bdd9f2	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-19 22:58:40.080283-04
e7cb173de66d60dfb123ecf723738321	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 16:20:36.333131-04
bc198d461a04834c5640a0357a7d07fd	MmEwYmExM2VjODMyMGIzZDNiMzJmZDZkNWMwZGEzYzViMjg1ODUwZDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLK3Uu\n	2012-05-17 10:00:02.696084-04
26c12400990014a045f11f7fa3438afd	N2UyNDA4MDJkNjk2ODgyOGEwOGM2NThiNWEwNDZlOWIxNGNjNDlkNjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAlULY3VycmVudF9vcmdxBWNkamFuZ28uZGIubW9kZWxzLmJhc2UK\nbW9kZWxfdW5waWNrbGUKcQZjb25seWlucGdoLm9yZ2FuaXphdGlvbnMubW9kZWxzCk9yZ2FuaXph\ndGlvbgpxB11jZGphbmdvLmRiLm1vZGVscy5iYXNlCnNpbXBsZV9jbGFzc19mYWN0b3J5CnEIh1Jx\nCX1xCihVCWR0Y3JlYXRlZHELY2RhdGV0aW1lCmRhdGV0aW1lCnEMVQoH3AQNDCkCAUOcY3B5dHoK\nX1VUQwpxDSlScQ6GUnEPVQRuYW1lcRBYJQAAAE9ha2xhbmQgQnVzaW5lc3MgSW1wcm92ZW1lbnQg\nRGlzdHJpY3RVA3VybHERWAAAAABVBWltYWdlcRJYAAAAAFUGX3N0YXRlcRNjZGphbmdvLmRiLm1v\nZGVscy5iYXNlCk1vZGVsU3RhdGUKcRQpgXEVfXEWKFUGYWRkaW5ncReJVQJkYnEYVQdkZWZhdWx0\ncRl1YlUFZmJfaWRxGlgAAAAAVRB0d2l0dGVyX3VzZXJuYW1lcRtYAAAAAFUCaWRxHEsBdWJ1Lg==\n	2012-05-17 10:04:39.717144-04
577bd4f1b76079c16fd529b88b63fcc7	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 10:28:32.541144-04
6768466fbdb3440b3ef295d850ceeb3a	NGMyMmRhMTk1NTU0ZjlhYjNlNTczYTY4YmI4NGMxOGM1NDQ1ZjZlYzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLLXUu\n	2012-05-17 10:30:29.814581-04
c68b1ed11b5538abba39e946146de917	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 10:34:23.799889-04
407fe5d2b3f31ddb51d42f6eb3d519c6	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 10:38:11.320331-04
d6c44d41c9fe4d7ab915286d85894ba1	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 10:44:16.595604-04
156c60daae67f3c4bd2e988fb8610750	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 10:44:46.537113-04
1fa69c74d643ba73f73034aa46658467	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 10:48:05.983273-04
6301e23e99abe1d74901f0b98515a8f0	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 10:52:37.013843-04
e62592738a388713418d69b26c0c88db	ZjQ2NzE5MjFhOWRkMTk4NmE4Y2NmNWZhZWJkZTZmMTRjNGQyNDg2YjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLLnUu\n	2012-05-17 10:57:25.972821-04
49925e3ec92d51c37cf44d8b2026f8fb	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 11:15:23.258242-04
04090e770e0fa5dad942c333610916e8	ZWNmNjBhMTIwYWRlN2E2ZTQ3NmZhMGFiZTc4NTMzOTNmZGIyY2ZhMTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLL3Uu\n	2012-05-17 11:15:34.122655-04
399da9e3beaaa675774c40a9a72f224e	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 11:15:36.851862-04
d0ce43574dca0157bb423adc387d3188	ZTc3ZGZhZjAwNmE2Mzk0MzhjMWE1NDFiMDg3YzViNjVmNTQ4NTU2MjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLF3Uu\n	2012-05-17 11:21:28.988099-04
45622c1f0774953db0d6958d74561c2d	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 11:23:45.023282-04
4bd70759108579b9ce853d737630b6e6	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 11:24:08.585225-04
004725157b30a7c5e4e0c60c63e64b74	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 11:35:32.264647-04
66b210819da74639ef84b8ab5f43a6fb	NGFhMmYwNTYxNWNlZjMxMzFhN2Q0N2UzZTk2MGM0NzU2MDU2Y2RmYjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLMHUu\n	2012-05-17 11:46:51.595525-04
157491bdec98fd99b175da608bac14d2	MjZmYzc2ODNkZmI5ZmJjODcwMjdjODVkYTdjYjU5ZTRmODc4MGNmMzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLMXUu\n	2012-05-17 11:48:58.089105-04
36e0fb23dd415eb3b263b663acb437af	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 11:50:06.103392-04
3b3b658f571b5dee40e36034cdd4d1a5	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 12:13:34.341966-04
d54aa5042071d1b19f6563fad043f7df	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 12:15:24.142207-04
ba24fc2954c81c0072dd5518a79b8e54	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 12:15:24.176017-04
ddf25c89da5ceef5ec0e35a4d8be691b	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 12:25:34.995384-04
f03af5f9c2494b7157095190d6f1b3fb	Y2ViMjkxMmI2ZDY3MmZkYzJmMTY4OGUxYjM0YWExZTc3ODVjODVkZDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLEHUu\n	2012-05-17 12:51:07.62556-04
273b12ca69d3b258091066c143787f49	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 12:52:00.444504-04
9a1c9fbcc567d932a691a458374ebc9a	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 12:52:17.796259-04
47ede2037e9ce222fa72901b35a8f574	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 12:52:18.358447-04
d3329e4812f23adbfc2c91ff5eac18dd	Y2Q3YWY4YzI1N2JhNWQ5OTZjZjQ2ZmRhZGExZDlkOWU0NDliOTY0YjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLM3Uu\n	2012-05-17 12:52:22.203076-04
0e6bb562ea69d340d9fe1917281216b8	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 12:53:26.946609-04
33f91a8d7c0f2b9700c2114d345b5cd8	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 12:55:41.011335-04
16eb4b3933999ea81a80695083c822f8	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 14:12:40.469959-04
23b7ddf85cc5482e1291eaf74e14ff87	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 14:20:46.944679-04
c86c0b0c688eb90b5614120306fef299	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-20 00:05:12.458154-04
4c31e583cc2e1c26523ffbe4b5c2c8df	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-20 01:04:29.910317-04
e6b9789478b2d1ee91f87505eacd9a45	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-20 04:04:40.523-04
b7174552c686d4859d6242795502a3f8	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-20 04:31:06.081361-04
ab41b6bc1bd23690cdffb4d04b1d049c	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-04 16:11:08.873942-04
6eafc23ceb5edd3cacad454ed6f459e6	ZjNiNGUxNTUyOGEwM2NjNDQzMjZlODViMTZkNDdjZDMwZjVjYTEzYjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLBnUu\n	2012-05-23 19:14:55.136622-04
239a185d838058fc29429479bcfc32d8	MTE3YjdkYWI3ZmE1MzlmODM1N2Q5OGQ1NTU0ZGUxZDA5YThhNDY3YzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLNHUu\n	2012-05-17 12:58:35.344598-04
fc12989662e94588a65c6c27929b9cf9	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 14:38:31.745387-04
85ca43d0fdecfee92b1f5b54f31c991f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-23 19:15:37.148805-04
91f575c73881fddb66a5875aeb435de5	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 15:34:38.828367-04
a80db04ea668350e44372bb0f5ea0ef8	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 16:24:42.163768-04
4868c51571ebbcc0dd548c0742eca4ed	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-23 19:16:15.976698-04
3dee87b826c6ec2ab1be29a07249d85c	OGYwZWI0MGUyYWM0ZjkwZDY0ZGQyODZmOWE2MTA0ZmY0YzE2MzRhZDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLOXUu\n	2012-05-17 22:15:54.106651-04
ebd8437971dc509f426a83f5f2b9ed9a	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 22:33:31.829728-04
aeee57afe7c8ec23e57fca59f6896ba3	NmQ2ZTcxY2ZkYmVlZTA0YzgwOTQ1OTI4ZWEzYmE5YTkzNGI5NTc0YjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLD3Uu\n	2012-05-17 13:02:02.668783-04
f4ecd4e7601c83821a81c7df1248b668	NmI0NzE2NTYwMWZjNzU1NGNjMTQ3OGRkYzQxMTAxNTNhNjVjMjQ3ZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLOnUu\n	2012-05-17 22:55:10.848916-04
431674ff5a17c0c08580f7e5bb5f9b00	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 23:32:23.289206-04
39da6dd4523ac38cf6f39a8c2eec9216	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 13:27:08.631961-04
690bc135e5f41885995d5f32852522a7	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-17 23:32:40.701303-04
52d6930e1545ac07c36aa990ec24b062	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 16:45:39.044836-04
8f57970188847b55cf7c9dd2c7673bb3	NDNmODIwN2Y5YzRlNTY1ZGUyNTAxMzYwNTJhNWMwZWY2M2M3Njc0NDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLO3Uu\n	2012-05-18 00:22:31.823288-04
465409ed2afc1ea6b4a81551fc71db09	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 01:39:56.120229-04
37d9baaba75a3bcaabfd54318d07f7fd	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 04:58:50.663375-04
7a9730fd9a8c8f3dd8647441b2c4a0b6	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 06:26:30.41491-04
2b7f3a5bf9211b734042923c9d5eab14	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 08:54:59.989933-04
583df718d4606e5425c43cf467858c8f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 09:20:21.510503-04
9b6f90c763bcf0d5fe00efe1e1a7a708	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 09:26:13.128893-04
f7e325f1612d2cab93a4d247a07b48cc	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 09:44:36.707207-04
8ec4bfb56bf6c3deb969468618408fc3	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 17:03:49.427676-04
bba8e00171493a6c964e8d1566c59243	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-18 10:58:47.724984-04
8efd283d2290e85e8391fc78b7670a5e	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 11:35:11.019809-04
c53a3e47238d9745aeddb3b880e7d3ec	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 11:37:08.864258-04
f6ab90427823fd033715590a898e5749	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-18 11:51:05.104952-04
3de79c56ce5d0550ea12bc7671cbd62e	Y2Q3YWY4YzI1N2JhNWQ5OTZjZjQ2ZmRhZGExZDlkOWU0NDliOTY0YjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLM3Uu\n	2012-05-17 18:28:29.693312-04
14aca327f46be4e1ac3ef105c194ba1e	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-17 18:31:39.109962-04
caffa8d11668a57ff7b5239bc0d2919d	Y2ViMjkxMmI2ZDY3MmZkYzJmMTY4OGUxYjM0YWExZTc3ODVjODVkZDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLEHUu\n	2012-05-17 18:35:45.228821-04
b6aa62cce1a37445444c53ab0ba2b9c7	NDQ0NmJjMDQzMDc1N2UxM2ZmZTc1NTJkYjlkNDE2NGZjYjczZWNhNzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLN3Uu\n	2012-05-17 19:13:14.572422-04
c219cc468587ab8c62967ed1a69488c2	YmZjOTc1MzljYTdhZDc1ZGJkMTAyN2YyY2E3ZjY5NWM3NjZmMDk4YjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLOHUu\n	2012-05-17 21:29:28.667037-04
199c291b51e90719bdd305bfb5c511fb	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-20 04:07:50.434612-04
1a3732fae1c070b6ae66334675d6f0d6	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-18 12:00:30.624674-04
2fad8f4f5f1358591340f0bb953e5182	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 12:24:46.567363-04
7f0d15990e87c8b4b92ec9b7cec41918	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 12:55:45.419742-04
2691bd52b57f49dd495ccdf6c1654442	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 13:33:17.551216-04
d2ffc395ee6256abded441fcc1b78dbb	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 13:43:27.352841-04
6308b28f72243fe74cef9462559ac8a4	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 13:57:01.977286-04
f2daff1b8333d4d792a0a71ac73f0b19	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 14:03:14.4752-04
5fb27e1e4c4fa6d4865e4ecd2bbdc77c	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-20 10:34:11.71549-04
c46b92023dc30b5ae5862c5de5d8c5bb	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-20 12:22:33.431359-04
1e90fc82880c10e6ae5eba3b7bce9f9c	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 14:06:49.173761-04
32389d3c872a430bcdf13f4b447fbac6	ZTc3ZGZhZjAwNmE2Mzk0MzhjMWE1NDFiMDg3YzViNjVmNTQ4NTU2MjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLF3Uu\n	2012-05-18 14:07:08.869619-04
8f5b3c7f11a5ddd4337f41cefddb82a2	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 14:12:47.034035-04
7ecdd20a0aa233e667723f0c9c4010fc	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 14:23:57.421949-04
668849963f3efbf0b5de7c55b27b37c9	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 14:47:32.895049-04
7960a7702fcc64060d00a5e44a24ad27	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 14:47:34.876008-04
d9612be3588575944ed0e3a2204ba256	ODI1MmI3MzNiMGQ0M2NhYmFhMDQ1OWE5MzI4NmY0MGY0NTY3MzExZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAXUu\n	2012-05-18 14:57:04.048065-04
d17ebcd1618b5dcac04ebe7e265aaa6c	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 15:29:45.758043-04
ed7b5886fd8c1acceb867c70300003de	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 15:41:46.143171-04
d05940f8c5a30147ca5d1e8a8aa1549d	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 15:43:38.753084-04
67486df4f25cdc09d5f2557d1084a9c2	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-18 16:16:46.858302-04
139f95e402f4af309d589f9cfe0ff652	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-18 16:23:26.848303-04
d0fe33cb453ae0bcd19b404e9359b71b	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 16:24:53.950918-04
4fd48ac506bd5a4ab926b069597f453e	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 16:37:36.525053-04
bfa892e265e6aab6aba81b0e54c2feed	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-18 17:27:33.98864-04
7507ea13be9c84fbbd2b3cce6156ac99	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 19:21:52.720648-04
c5a605acf4e26c61c764ee42a108e432	MTMyNjg1ODJlNGJkYWE1ODBjNDYzMjg5NjhiMzI2YzNhNDg2OWYwMTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLPXUu\n	2012-05-18 19:34:16.055933-04
312f4ccd3805966fdd4de54b7cdb07b5	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-18 22:50:01.155939-04
15b4a68aeb3f5d88f0aa22444ab02317	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-18 23:38:52.405047-04
8c6ab6abd0b8294a8f9d8fe221e480aa	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-19 05:02:06.335445-04
b28e3b0b52370df11a234219e1d76d0b	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-19 06:51:34.733791-04
5451c3f01e37999c8a284f9a51387d80	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-19 09:56:20.228242-04
25dee44cd97a49f09808bc16f3ac1236	ZDExYjUwZThiOWQ4MzJhYWNhMDZmYmE2YmI4MzYwZGE2OWUwMDJiYzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLPnUu\n	2012-05-19 10:00:52.940595-04
30f9cd38d82b697068c11af3ddff6301	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-19 10:31:01.432371-04
7851d6daaeea818f4a569e1090a8cbe7	MDU0ZjQ4MjZlYmRmNjZlMGNkYWUwOWU3MzUyOWM5YjMwZTJlOTc2YzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLP3Uu\n	2012-05-19 12:13:11.71324-04
f658956ce4c6a90ab699cbe8740598bb	MDU0ZjQ4MjZlYmRmNjZlMGNkYWUwOWU3MzUyOWM5YjMwZTJlOTc2YzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLP3Uu\n	2012-05-19 12:15:28.569343-04
38e5bb72fb6e38e582d4a17d056869c8	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-19 14:35:37.44368-04
e0f654e91983529a40c57e207d0968d4	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-19 16:17:47.588431-04
44a3434518f13c517eb8079da7c3282d	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-19 16:19:55.854947-04
593e9b1e0e1e7dc55fa8755b236d48f3	NDMwY2Q2NjhkZDU3MDg2MDViNTZlNmRmMzM0MGEyNjY5NjU1ZGY1MjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLQHUu\n	2012-05-19 16:49:06.461496-04
6ac1a3c4b8e7ca59c4545390559aa1de	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-19 17:13:19.428357-04
21b92e354af962b6c09619e55ee67181	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-19 17:26:27.719747-04
9e014f9d8f60e5d0e0472eb8e29ae72b	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-20 13:48:39.419854-04
64485be7d4ead1ad4a4d242814f0795c	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-20 14:32:30.271692-04
365536fb217f8e952b5235ac8dcd7131	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-20 17:06:43.855704-04
e31bf8263904681469a5747109d0739e	NzVlNjc0YjQ3NWQwNmM4YjM4ZDcwZTJjMmFmMDFmMzQyZGJkNjk1MzqAAn1xAS4=\n	2012-05-23 19:14:55.636217-04
536794eb6550e1267c75cb02ea8c8a6b	ZjQ2NzE5MjFhOWRkMTk4NmE4Y2NmNWZhZWJkZTZmMTRjNGQyNDg2YjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLLnUu\n	2012-05-25 14:05:06.46726-04
8cd9a46fdd84090086aada60bad573ef	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-20 18:42:51.135863-04
343df8b2657e22cfecac7eb086e41573	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-20 18:57:24.441644-04
fa52f9c70a92ec84bffe1f2db9740e78	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-20 19:19:10.226789-04
9bd7cf041d7913475ab699d171e96f01	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-21 01:35:29.979636-04
2a12a30a465e0e4ab05f2a9d5232bc72	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-21 03:58:15.687873-04
9a623646c8862fa3689fe4c7d3f9bdcb	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-21 08:48:34.663001-04
72a89478fef19e18f817a9ca976efd49	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 15:26:28.902222-04
b5eb6f02914e9a3629c99b5f93c7c9ae	NTJmZTkzN2Y3ZjFlNjkzNDdmNmY4ZTlhOWJjOGQ2YTM4YWM3ZDExYzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLQXUu\n	2012-05-21 09:52:53.788957-04
85272adc9ea015e69e562afea8813b5f	NGJiMmYxMzQ0ODIwYjY5YjY2NWVkYTc5NDQ1YTkxYTRmODQ1ZGQ0NjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLQnUu\n	2012-05-21 11:24:26.475061-04
7d1e0d4dc56153497b936e24939b2e33	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-21 11:26:56.582487-04
2b63d4c165af44aab54a339d29be3353	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-21 12:30:41.843581-04
9a388bb276f68e0d03214f9ea86b1c49	ZjNiNGUxNTUyOGEwM2NjNDQzMjZlODViMTZkNDdjZDMwZjVjYTEzYjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLBnUu\n	2012-05-21 13:10:10.287056-04
2fd0e2ee2784ef889d8d78d0db633ceb	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-21 14:09:03.554758-04
7491716b3dd94d958f1e62b90028eb24	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-21 14:23:22.782341-04
66dc4d29b2f5612060d3c3d361cf6ef6	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-21 15:24:20.054373-04
d3435ec9042517ae249c851d58819c60	NmQ2ZTcxY2ZkYmVlZTA0YzgwOTQ1OTI4ZWEzYmE5YTkzNGI5NTc0YjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLD3Uu\n	2012-05-21 15:43:43.16827-04
46c3f5285b74ef8d62d6420a3a3bd158	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-21 16:20:14.516727-04
a52279405bab4de2876e0af79dc61e3d	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-21 18:18:36.900812-04
7fddf3b51a1e39f3d85e9420781c27d4	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-21 19:22:26.056556-04
8c27667cdc785b4a7d2fac7dc05c976c	NmQ2ZTcxY2ZkYmVlZTA0YzgwOTQ1OTI4ZWEzYmE5YTkzNGI5NTc0YjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLD3Uu\n	2012-05-21 20:17:24.450941-04
498ee2895f20f84c1a0323ea28e8fe25	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-21 20:39:22.74754-04
eae853728ba74d678a35793a5d6220f0	NmQ2ZTcxY2ZkYmVlZTA0YzgwOTQ1OTI4ZWEzYmE5YTkzNGI5NTc0YjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLD3Uu\n	2012-05-21 21:10:32.040374-04
3bfdddafd0c358288ce2a98ee6d3b4e2	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-21 23:42:38.5816-04
553a5b12fa0bc8ea4922db7c9d080ad5	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-22 00:22:41.336663-04
183dc4ced07f3c2a88a2d16c89d2448a	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-22 00:51:22.930531-04
4aaead450582eeefb8e06ca205a74b76	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-22 01:20:13.934697-04
d1694c1ad459b3f630690468af82fd85	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-22 01:54:15.917819-04
c823894caf7a79a5ec76c96f0dbc8aa6	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-22 03:43:56.233603-04
8cac1363993fe2827e835e474c8b1600	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-22 03:44:20.550411-04
3903344d62f46ca949427593ba9553dd	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-22 04:02:34.440131-04
db00e76a8e9c93758d9a8b83f404cdbe	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-22 04:12:01.07085-04
a5797cf4e46d9071e71c049df29a9ca4	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-22 04:13:50.249806-04
80fc92293d1ecf701522a770b0a25ea8	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-22 04:14:12.210505-04
d43b9452fe9a3f2c770794e70ff9bf8a	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-22 04:23:18.985141-04
53a811fe540741e2494b8eee6693a6b8	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-22 04:26:40.206335-04
052dcf331da1e5001774a001595a0600	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-22 07:40:01.828572-04
2bbbcc56447f742f816501ecb84c8df3	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-22 11:03:19.169721-04
f63fd2349f0f8ffaea5e3e18e0e9ac1f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-22 13:16:40.566721-04
43e789d871ff3a2f7517670ade676af3	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-23 19:14:56.22253-04
790bca57065bd39bba60a50c7d514d13	NTJmZTkzN2Y3ZjFlNjkzNDdmNmY4ZTlhOWJjOGQ2YTM4YWM3ZDExYzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLQXUu\n	2012-05-22 13:41:14.200965-04
c3b298edc84d6063ae5184a1f86b2a4e	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-22 17:37:22.587715-04
bbf7e28b33a1f60ad79038cc91b5f460	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-22 17:42:00.720194-04
bdb64804aa3a4ff517119f52cb431ba5	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-22 19:01:01.961112-04
25c21fbc1d542d3013d62fc909f88f5d	YjViM2E2ZDA2OWQzNTJiNDUxZDhkNjY4YzgwNGNhNTFlY2RiZWQ1NTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLKlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-25 14:03:32.597934-04
2ce24b64d6131ec26a5cc873cbc5781b	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-23 19:15:53.207593-04
6a62af0e53b0642ce714ef60af8de608	YzJkOTY1MGY1MDIwMzhlZjZmZDA5NDk1NjQ2ZWM4OWIwM2UyODBhODqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLQ3Uu\n	2012-05-22 21:36:04.839525-04
5646ae70be5f270a1782dfb149f9b300	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-22 23:03:35.174667-04
5cad3f26d87eabbd9242756dc123b544	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-23 01:05:28.169728-04
1f006350118d6af7ca3a5e88e4018585	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-23 04:25:49.791465-04
1c5fe5ef37462e20663217b57509af2a	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-23 19:16:33.648701-04
e09554b0758093ba7b5ba5b7fa02dee7	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-23 19:16:45.453404-04
e03c6e85dbc1dd82c16b681cf086004b	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-23 08:32:04.189775-04
8be85a921b41b3c11c80910c52e4b063	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-23 08:33:47.209381-04
146568254d87df11016d02af44db3307	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-23 08:35:55.15809-04
6baa941c941b2b50e21ba58b31afc0d3	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-23 08:39:01.347999-04
883567aa1ac98bbf8598b421e9d38d1a	ODI1MmI3MzNiMGQ0M2NhYmFhMDQ1OWE5MzI4NmY0MGY0NTY3MzExZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAXUu\n	2012-05-23 19:17:56.405562-04
d81c89ca1ce6443d38a238fd479a79cd	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-23 09:20:14.228735-04
d95714d566740838d789185706f7f0f3	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-23 19:59:37.075155-04
7edcf3ed3c35de1e68b6e6c3edbf429b	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-24 02:37:52.30416-04
b4045b7fcbc0592771b45a24da7a629f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-24 04:14:48.363072-04
57b67c9756654f006792b792a1c6efa6	ZWNmNjBhMTIwYWRlN2E2ZTQ3NmZhMGFiZTc4NTMzOTNmZGIyY2ZhMTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLL3Uu\n	2012-05-23 10:49:12.895461-04
772492c0b0cffc17fd5ca9dcd08329c7	MWEyN2QwNmQ1NzJhMWI2Y2Y1YjMxNjdhODE4M2M1ZmZlYmE1MzJiNDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLRHUu\n	2012-05-23 10:51:20.069314-04
d38448fcd4d94c9ea59e3ceef0586c75	ZTc3ZGZhZjAwNmE2Mzk0MzhjMWE1NDFiMDg3YzViNjVmNTQ4NTU2MjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLF3Uu\n	2012-05-24 07:01:47.275825-04
811bda121869f6dc0dbc56c09d916a23	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-24 09:12:35.010751-04
9636ce4af35f976575d348ab6eb8c3de	YjM2ZmNkM2FkZTNiZDYyOTk3OGRmNzVmMzk0Zjc4OTViYWYwMDU1ZTqAAn1xAShVDV9hdXRoX3Vz\nZXJfaWRLRVUSX2F1dGhfdXNlcl9iYWNrZW5kVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRz\nLk1vZGVsQmFja2VuZHUu\n	2012-05-23 11:06:03.9137-04
a04f60ed745a7d4a48d5ade1e681d97b	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-24 09:12:35.016167-04
c0c55e7ae02d890f13d17f292c6edff5	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-24 09:12:35.016548-04
3bddf79b5ad280f5c2c6d66e2483bf5c	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-24 09:12:35.1125-04
218eb7f8f3776d668662933232af563f	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-24 09:12:35.12968-04
b6ff025155fa39c9827ee2c38c656628	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-24 10:10:57.113178-04
7973c52bdcf89141ad3c7ddb944bc78f	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-24 10:15:54.646574-04
5a316cf77aae1f92e62942e78427ad90	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-24 11:55:23.203176-04
ee6ea7079df1ac5aa2412c8ce9ed9e87	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-23 15:23:13.341817-04
d95901875b16eeb6b762edbfe621c16e	NmQ2ZTcxY2ZkYmVlZTA0YzgwOTQ1OTI4ZWEzYmE5YTkzNGI5NTc0YjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLD3Uu\n	2012-05-23 15:34:31.208055-04
34f564fceb0dabaca46ab278763df1f1	NGI0ZTVjZDQzNDAyNGM2MTljZGEzNmFkMzNhNjUxMmU5NGE1N2U0NjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLSHUu\n	2012-05-23 16:08:02.969204-04
75c26db9f75b53e676e5e7709efaabf0	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-23 17:19:58.575155-04
d581c1fde4a19ce8a3e51de4b778d8d4	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-23 17:22:48.180766-04
99c48f5944c976eab845421724610fe9	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-30 17:56:39.80442-04
c29b3c1b0f8a4013c450eeb2103d6ca9	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-04 16:51:28.595142-04
51d9f098ae04356d8561e2d9d3dcaa0a	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-25 14:18:24.459606-04
750bc3d31cc271c1e82e502ecebfa1a0	Y2JhMzAyMTRjZTE2MTQ2NjBlZWQyMDRkMzg1MWYzYTdiNDNiZjQyNzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLSXUu\n	2012-05-24 14:20:31.17405-04
b771da024fb0f3305a58428951be347b	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-24 14:24:57.40359-04
94d9bfe675b4a13764bb107e9b9bb625	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-24 14:28:13.896701-04
d3870f7901043a0fa6625f2943fae798	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-24 14:36:26.547407-04
5be893ea9f2d93d26a39be4f0b1ccedf	ZGI5ODk5MzU4ODk4OTU3Yzg5Y2RjMmFhMmIyNTU4ZGI0NmIxMGNiOTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLSnUu\n	2012-05-24 14:54:15.446169-04
aa1954e3f2fb5081c23863d5f83205c3	MzM2YjJlNDA1ZTZmYzU5ODE5M2NlOWQ1ZjJjZmYzNTk1YmU0OGFhMTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLHlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-04 22:17:27.984602-04
472926c21179df957ae22800ffcaa16d	YzJiMmVhMWI3OWZkZWNhNmQwNzMxOWE4ZjZhMTkyZjY1NmRmZmJkOTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLS3Uu\n	2012-05-24 15:08:24.211453-04
caffe8d5ed1d0a904f59be65a32d8699	ODI1MmI3MzNiMGQ0M2NhYmFhMDQ1OWE5MzI4NmY0MGY0NTY3MzExZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAXUu\n	2012-06-05 10:04:51.88005-04
1c17aa5affb5cc8d96c9a2ad749fccf5	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-24 15:10:00.067663-04
acf52102d46f90d0a0e267d35e63e929	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-24 15:35:04.818367-04
0b1d1dd26c089e5ffa02407a3c520558	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-24 15:41:31.931301-04
0def7d3f8d20d35d091b51eecd66f94e	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-24 17:01:56.029574-04
5299368c812db1878a4f6ad1a7dfb708	Y2ViMjkxMmI2ZDY3MmZkYzJmMTY4OGUxYjM0YWExZTc3ODVjODVkZDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLEHUu\n	2012-05-24 17:01:59.544789-04
accae8a522cebb432c7f9b6b7e07e79d	ZDYyNTQ4Njg3YjlkNmRhNzZhZmJkNWRhMzY5MTExMDQzYmFhMzk0ZTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLEFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-24 17:13:10.429927-04
a3042cd633b782671e38063750f5ba6a	ZDYyNTQ4Njg3YjlkNmRhNzZhZmJkNWRhMzY5MTExMDQzYmFhMzk0ZTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLEFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-24 17:20:51.953895-04
cf53b882d8c920865788788a9f2ffee3	ZDYyNTQ4Njg3YjlkNmRhNzZhZmJkNWRhMzY5MTExMDQzYmFhMzk0ZTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLEFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-24 17:25:20.509539-04
de6223f7b6681d109bb4de914129aaa7	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-24 17:43:07.081483-04
3fdaa191d24d45324efada7349e16ed3	MTg3OTM4MTUyMjIyNjA5NjRlNzQ5ODc0NDNkZjJmMjJhZDgyZjMyYzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLD1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-24 22:50:05.387321-04
9835ea0526c4bb4afc74802643822abc	MjIyN2RhMjVkNjcwY2IyZTM5YTBhZTM4MDQ1YzhhYjA1ZjI0Zjg3NDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLTFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-25 00:53:46.254277-04
0b8a6c85215e6e9b90a696600fafd713	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 04:09:00.653648-04
948852c7ce93b02d1d03ea5e9e664c7c	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 11:55:34.548561-04
4baf2f53092d7692e19a7f61d749a639	MTg3OTM4MTUyMjIyNjA5NjRlNzQ5ODc0NDNkZjJmMjJhZDgyZjMyYzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLD1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-25 12:07:14.832326-04
e5e17149f66c8299de5dd6003b07b068	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 13:00:41.062541-04
82ed7ed29c40842d235f11af35c04a55	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 13:02:53.544494-04
5ab1228e4194fe008774f4f1a6185375	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 13:02:53.924946-04
d555efebe9ae3e6779cbc590c237a14b	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 13:02:54.84427-04
dcb1ea7ca12cc445b0676c984836b634	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-25 13:05:31.230093-04
007f2ee3c2b6dd682ef0cd1f02858745	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 13:06:38.85138-04
39b83ed162f41c8779a8c8286016bbd0	ZjMzZDBiZTIxMWM0YTAxNWJjMTAxNzg3YzUyODMxOThhY2Y2NTdiMzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLTVUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-25 13:07:42.266886-04
b9c2f7523e171c2218123460d476280f	MmNkMzdmZThlNmZjZGU4OTllNWMwNzgzNTIyOTAyMTRiMmYzNjNiZDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLTnUu\n	2012-05-25 13:09:03.19206-04
8c9eae06226aba6d652706495b3028b0	YTIwODRkNjhiMGRmNzQyMzU3NzdkNGQzZjBmOGYyM2Q0ZjNkN2JhYjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLT3Uu\n	2012-05-25 13:09:28.402596-04
46e611cb4df7dfa5d5ca1d943532c62b	NmE1MmU2MmI1ZWJkNjJhNmZlN2JiYTgxNmY3Y2ZjODc5N2QxMjNlZTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLUHUu\n	2012-05-25 13:15:44.28922-04
d132fbb9f5037ea393b2df00998c0eb0	MTA4YWZkOTUwZjIzOGVkMmI1ZTRlYTQxNGRiNmY0YWZhMjQxOTFkNzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLUXUu\n	2012-05-25 13:17:49.39335-04
65f0b15610e35122ef19e0f47000f6a6	NzRlMGU5ZjczOTc0MTdmNzcyMzA4ODI0Yjk0MWZhZDJmODY4YTU1YTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLKVUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-25 14:07:50.17331-04
2563f91f8f52c09cd4910105dfc44108	NjgyN2EyYjE1MTNkYWE5NTEzMjY2MjUxZDU1OWY2M2E0MWQ3MjNjZDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLFFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-30 22:15:35.250965-04
509411736d6458b199589c2df35776e6	ZGVkMTA4M2I1MTcwMTA0NGMyZTgwOTFhOWU5ZjVmYWRiYTViZjRiNTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLUlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-25 13:30:29.723562-04
0d0348caec034ce9fdf8672adbd8e3de	OGQ1MmJkY2ZjYjFiZWRkY2QxY2UzYjhlYzE0NDg1YWE3ODk0OGM1ZTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLU3Uu\n	2012-05-25 14:28:13.076552-04
e2df089f055d6b467cec1f773870700c	MmQ0NDE1OTc5Mjg5NmEzNWQ0MGNhOGNlNWI0YzE0NGE0MDZkNzNiYTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLMlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-31 03:26:45.579929-04
4c4949096f67f45c5651fe518155ebd3	MGQyMzg4NDFiMTZmYzk5MTJlOTZkM2EzYjNiY2RjZDFlODhmNzZiNDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLLVUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-25 13:32:51.684002-04
3c89701e3d65bcd2135bc12c948e33f4	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 13:33:47.288461-04
a83001d13e6b03cba8444f76fc370870	YzdhNGQ2MGExOGZkMWYxZWVlODVlYjA4YWZiYzgwMWQyMWIwZDgxYzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLVFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-25 14:47:03.405765-04
7b1f8256a151b791812af00c19b0a430	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-31 04:44:33.5472-04
44114ebee7ac5d90e2baf47e128ff3de	NjgyN2EyYjE1MTNkYWE5NTEzMjY2MjUxZDU1OWY2M2E0MWQ3MjNjZDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLFFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-25 14:49:12.325978-04
d00aab317c5b6f218e9cf498ff25c21a	MTMyNjg1ODJlNGJkYWE1ODBjNDYzMjg5NjhiMzI2YzNhNDg2OWYwMTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLPXUu\n	2012-05-25 13:44:26.650332-04
d029b48f0827c33ab6a29deafd8d613f	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-25 13:44:41.025692-04
749ac991eae2ab2986a77eb0bc0748ec	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-25 15:35:00.82317-04
31de7929d7d5801a47d0ba2200a0a3d6	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 15:35:13.186091-04
e202c3508b89539010fb9bcf262fa131	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-25 13:54:58.936901-04
0023e43012c026392a6be729bc47cc42	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 15:36:29.167589-04
689842af1a253ca6b09f8fdd9732deec	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 15:38:33.729971-04
6d0118e3cbdef2aeaca7a16727ad134f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 15:50:55.068407-04
b0164e76074c8fded4bffdaa6bb1f904	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-25 15:51:53.056176-04
f0a08ad985dbb730f72dce67b93ae3df	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 15:52:22.468531-04
f343af4a2391b8fd8bd9ac546380fb8a	OTIyZTUxZmZkYjQ5OTliNmFlZGMyYzgwNmRjNDJiNjEzMjBlMzk3ZTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLGlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-25 16:54:56.192165-04
748227a62925e62e6277e20862440dc1	MmE3NTQ1NGVkYzc5ODMxMWQ2NzhhYzY1NDA5OGQ5OGE2MWE3ZWNiZTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-25 17:32:21.198691-04
65ab8a32c7f177276668a0bc36bad9c5	NjM1MzYyOTJjMDBkZDhjMjA4NTBhNTk2OWI3ZDEyZTQ2NGU5MDFlMTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLVnUu\n	2012-05-25 18:00:32.730744-04
a12876eddb497661294784ba9f0f63a6	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 18:49:07.312458-04
231252b6908b43ca08349762e022ac6e	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 18:57:23.490014-04
75a6ffa0952b26585be723d39c3a0815	Y2ViMjkxMmI2ZDY3MmZkYzJmMTY4OGUxYjM0YWExZTc3ODVjODVkZDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLEHUu\n	2012-05-25 19:04:47.117618-04
0cbcdd5ebfd563df7b5d065068299ad2	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 20:12:26.526242-04
8148132d50292e10fc3f6c41946773a7	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 22:04:01.05218-04
f7d38b5bc7adb83830ad4f995d8d8bbb	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 22:23:37.938803-04
385bb413e23b637e124699533440e7e9	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 22:26:44.486452-04
34cac9ae92051a55726144214bb70f57	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 22:28:21.425476-04
02ed751ffdd653d1aa206a3b46d94287	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 22:30:14.123259-04
e97bda012f160c3da3f9b46e62103c65	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 22:31:13.932714-04
a8f59357fd39d88e7d0f11dc0eb0a148	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-26 18:24:20.273902-04
09233ea62d038c219a845e5f6a321c69	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 22:31:14.541768-04
8866a843963bacdabb5c976bd9733a87	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 22:31:15.84686-04
8641c6b57fbf14f7250717d04deff0ce	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-25 22:45:50.440925-04
556f8a583b8ff5b044195a2e487b696d	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-26 01:17:53.345187-04
14853d9f174757ab7df8ef0fae3f4e91	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-26 04:16:33.295149-04
3bfacd4fda6b3fc2460e4249234612a8	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-26 08:13:54.550643-04
53296438dbeca236e3dc37171c007070	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-26 08:42:36.278338-04
75f1d5797dd828c145911a7ae16f673f	NmE4YTA2NDgxNzBkODM0MTc3NTM5NWM5OThjOTU3ZjY5NDI0NzIxYjqAAn1xAShVDV9hdXRoX3Vz\nZXJfaWRLV1USX2F1dGhfdXNlcl9iYWNrZW5kVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRz\nLk1vZGVsQmFja2VuZHUu\n	2012-05-26 10:17:46.692896-04
ee2a27791cc202d4a6322479ac2b5805	N2I3MjExYjEzYmNlYWFlY2I2OWYwNDA5OGQ2NmM0NGQzMmU1ODFhOTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLJlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-26 10:21:08.302339-04
7f3a5b9fbfd29fb1f8044449c40eb925	MjIyN2RhMjVkNjcwY2IyZTM5YTBhZTM4MDQ1YzhhYjA1ZjI0Zjg3NDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLTFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-26 11:39:04.979676-04
dff3ba7f35b99af7ce15eb1a2590ae04	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-26 11:51:13.593013-04
45cac9e40006094d9a8742db96c454f1	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-26 14:11:19.664351-04
683784f6af97d52c37a497748287732e	ZTc3ZGZhZjAwNmE2Mzk0MzhjMWE1NDFiMDg3YzViNjVmNTQ4NTU2MjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLF3Uu\n	2012-05-26 16:53:59.038564-04
162c5d3c20b0aec0ba973e80a2c3ade3	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-26 19:09:04.038357-04
f39524e145925e8dcb9e0629a3b68fce	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-26 20:16:18.02662-04
0bdef12efadba67ffdc2e83d5438eef8	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-26 22:13:33.838138-04
bb7aa8d125b54744e9b5deb57caa6589	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-27 00:54:16.046623-04
cbbe2489fc32b83e1a3cf8b321bcbd74	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-27 01:37:54.557406-04
a34b10fff423be4e968643059db42cd1	Y2JmYjFiMzZjZmZkODgwYjdiYWZjZGJjYzM5NTViZTBiM2E5M2UyZTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLWHUu\n	2012-05-27 02:01:54.474747-04
7827976231cc1e93eca6277ae878f625	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-27 11:19:12.800824-04
91ab3859fe1cc20c8cf07cb6323a2606	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-27 11:40:52.581732-04
fcab6e59b61b5a5de3edf33b37ecdd76	YWFjYTYyOWFlNDI5NzZlM2Y1YzVjYjliOGVlN2I5YjRlMjk5MGU3YjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLWXUu\n	2012-05-27 12:48:08.784172-04
e054c2058dafc4506b232ae3c1605eea	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-27 12:53:22.233021-04
cbb723449bce5329a37dae3889e3c83a	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-27 17:22:03.438516-04
1b833dab5e3e18b300c75f73511c1f5c	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-27 18:21:49.819226-04
5597163f18745ed657d45d11cec9c511	MmFjMTY5Y2MwZWI2NDI4YTkxYmVmYWYwOGFiMzg0ZTBlNTQ5YzE2YjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLWnUu\n	2012-05-27 18:22:14.85005-04
5f4092d414c09ee6d18123e9ec498995	NTczYWExOTc5YjM0YjIxZGI2ZDZjZGFjMTVmYTAyNzlkNTk2ZWI3YzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLInUu\n	2012-05-27 19:52:38.780019-04
3a1b94f30a458bb32912aaa89924b1eb	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-27 20:24:03.720781-04
30674ae01b5dc4013e94ece0aaef179d	MGMzYTBmNGE1MjNlN2YzZWNjZmJhMWMxZjY2YjFhMTI5OGQzY2VhYTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLW3Uu\n	2012-05-27 21:55:55.891639-04
31a5eefc2e0c763976382c666066807e	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-27 21:56:35.749904-04
0c0048e5b9ab72ed965645bbb4d1c20e	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-27 23:51:10.157556-04
2d38e4caaacb0069c6efef69c8806e63	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-28 00:10:26.01269-04
5ed6d4bd16dfcb11b41b0e80e199271a	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-28 06:08:42.883589-04
a6d6357ff922b6f3ddd5db5ad4a57e5a	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-28 06:14:05.382565-04
8ddd62029e3bf2506070df1c065d072f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-28 07:04:22.491333-04
21f40ab117097ece191687c14e61e3d3	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-28 07:44:29.666233-04
1c0e6750378fbca3fd4df62463a4df14	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-28 07:44:31.285867-04
38530cf48bd88dde8b37d68ab20ddaf6	YzI1ODQ5YmJjMGFmM2NjZjBlOTQ1ZWZhMjgwZTE2YzBkMmU3OGY5OTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLXFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-28 09:27:33.880647-04
d4b543b618afd5c2c225a7dc98603abb	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-28 11:20:32.308794-04
852851598efd3136021b0444c7b2bb79	YzdhNGQ2MGExOGZkMWYxZWVlODVlYjA4YWZiYzgwMWQyMWIwZDgxYzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLVFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-30 18:46:22.028453-04
edaa6737a66493d90b6e313a9e42f099	ZDYyNTQ4Njg3YjlkNmRhNzZhZmJkNWRhMzY5MTExMDQzYmFhMzk0ZTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLEFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-30 19:58:11.572656-04
21f043e8e9318f9a37fde92b0cf98a1a	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-31 06:09:32.517482-04
0ac438cef469ec0724bd00c79bc6b6bb	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-28 12:06:45.909739-04
18ce565587855e3f14186c39f9b9d076	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-31 06:54:06.582599-04
3bbbf73897eb20de383677c0ca64a0f2	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-28 12:40:07.9878-04
9482e3304ab270e1da1f807772e927c6	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-31 07:47:41.714921-04
5412832bac21015353e5d02ffcd13ff1	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-28 13:45:43.906154-04
05592a741ee65a3de684d2d109e58c6f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-28 13:46:07.219453-04
5f7102039538ab23c194ccf40e08d9a3	N2Y0ZDQxYzk4ZTg2OTNiNTQwN2UzZDRmZTY0ZGQ4ZmZhYzk5MDRjMjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLKFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-31 09:04:41.912972-04
238541db2c5ad45b8cf50d2105b35a3a	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-31 10:04:17.374693-04
8a4fa31f117c09a1d52c3ff0e30cd659	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-28 13:46:54.174913-04
15e564d21b95447af6e53cca3fc5f774	NWIzZTBjYmI4OThmNTU2NmRhNDQ0YjQ4NGEyNjU2MTIyYTYzNDAzNzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLXVUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-28 14:55:04.511138-04
557232b3aa8b458f109451b1b0458720	MDViMDhhOTZlYTQzYzE0NTQ3ZmI2MzEyMWVlMzExYTQ5MDA5ZGUxMzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLXnUu\n	2012-05-28 16:07:44.473798-04
73d859138f1e52f3696f200d7a2a2ec2	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-28 16:40:42.295945-04
39fa844b8072c35e69f9adec83e0d629	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-28 16:48:58.507945-04
048c7e094f85b5318957c85ae93d16da	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-31 10:27:22.276024-04
39aa91e11de559c74844bf8ab19b48ed	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-31 10:35:10.53348-04
fa7df55e40ddcf62ee3aef50afca7410	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-29 02:45:10.124533-04
a00adf03ee210ef18228c80f828dbba6	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 08:24:50.40203-04
9b13ddc4394d82b5f336072ed5afe766	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-31 10:40:59.931054-04
6c0842caded13f79649cd52699070319	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-29 10:48:16.421981-04
6512b3c7584e0851e3702e69319cbbbc	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 13:42:21.365955-04
ea741f4f087e06b961d6fa7349923a2d	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 13:42:22.051919-04
0927d143a98186cbb4083c1a42edd4ff	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 13:42:34.267543-04
72628f9f0db399cd6f152a47094f1f76	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 13:42:34.764792-04
3254fea6057b38603e9d3711ee25db64	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 13:42:35.344549-04
f34b81775c4e3adb6440f3ef24209ba1	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 13:42:37.858669-04
9f42262e0a289964be4c6a933fe6877b	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 13:43:20.95506-04
9fbac9eb39af36dcb7702fc651ff46e7	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 13:43:21.521838-04
c8110b2bd69fc3ad9f0b760e3987d482	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 13:43:44.561594-04
cd2a889130523d643d5477ca1611cf51	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 13:44:09.53886-04
a6c56c2faeb07597b4feb2bcd5e065d0	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-31 11:10:38.268411-04
ac03b3a4041a81ad247058b5481b7015	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-31 11:11:56.424292-04
4570b5439a50f0d41a21240f539e9b50	M2Q0MzIzMzIwZDBlODllZDNiNDY0MjQyMTUyMDU4YjgxNGNlYWRmOTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLYVUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-31 11:14:18.841402-04
33b7b8cd70e7e5e5ed4448d29eafbcea	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-31 11:49:33.428572-04
91f47857f40503732483c8ef1a4d3ca9	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-31 11:52:00.059396-04
6eab7d88425615c9d5b35908774993b9	MWViOThlOWU2YTU5OGQ3NWEwZjIyZjhjZDY5ZjZhOGNkNmM4N2VmZTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLYlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-31 13:01:07.96765-04
18da7b858e1f6aa28c124ecc2e78fc56	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-31 13:22:29.783734-04
8124a8888b887e648da663b4bbefd909	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-31 13:27:12.468972-04
6fb4428972844598e31e789f131593c1	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-31 14:31:50.765259-04
17b99238aee7d5d4bdbea780349352b6	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 13:47:47.692022-04
c4c26c034ec3282f29a2c303be6f6e72	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 14:10:17.879119-04
e78f41501895e3566dfefa5c2cc08394	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 17:00:36.918564-04
23f8420570e2fd33e66637e7f0b12740	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 17:43:41.673739-04
6170fb4dcca0afc55e3a7c9f764befdb	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 18:18:15.399496-04
9164d9d31d9566e2d915342c20055754	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 18:25:23.443466-04
68c7a94243b65443d510bfbc3be37e89	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 20:22:15.591187-04
9470311e88810c514938281ff86c8852	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 20:28:23.451968-04
fc28c505158db9ed47015ac3331bf694	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 21:21:02.869196-04
4841b7a1c0b3a124e5506c773a50894d	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 21:51:46.461575-04
0258eaac8715a8409752d57720875984	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-29 22:50:15.84575-04
87b2869856a8e71136c5ba9627b9b4f6	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-30 01:04:02.777811-04
fac6d863ab2525db31e9183403555e9f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-30 01:37:36.324505-04
dc79ac6e07890c2961414f18277c146f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-30 06:25:11.74526-04
5869e500fbaec0136e68e5ba4ff1c018	ODI1MmI3MzNiMGQ0M2NhYmFhMDQ1OWE5MzI4NmY0MGY0NTY3MzExZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAXUu\n	2012-06-04 16:29:13.734585-04
afcbc4d59c4cb8a769817474d5ffc857	NmQ2ZTcxY2ZkYmVlZTA0YzgwOTQ1OTI4ZWEzYmE5YTkzNGI5NTc0YjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLD3Uu\n	2012-05-30 10:41:28.181531-04
5f5dd8d7cee0d8d693f7772579b1b7b6	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-30 11:13:10.551535-04
6a1a65551bfffecd40444d97abfabdc2	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-30 12:24:25.696026-04
b9bbfdc36b44cc6b451c9d4bcfe70cde	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-30 19:20:55.426356-04
c66016bbc12d513750b620b7bd34b2a5	MTg3OTM4MTUyMjIyNjA5NjRlNzQ5ODc0NDNkZjJmMjJhZDgyZjMyYzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLD1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-30 12:42:12.323665-04
b84d3f9e58b84590363d27d199379946	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-30 14:50:00.429483-04
ede9593abd2968bc4b075f75de45c8b9	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-30 15:42:02.557839-04
f781f45bc65cb4038d1c2a9533c85161	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-30 15:42:05.680426-04
eb67b82ab54a9189673c504d99427e3c	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-30 15:42:11.547441-04
6260c2ff258aa833d243aae6be7a5858	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-30 15:42:13.634475-04
50a59fc5a195ebe122a3a2cac05f0de4	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-30 15:42:15.700816-04
bf5d2d44025dde90f7526bee7d95c1b7	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-30 15:42:17.768963-04
6cbaabdf21f519dc7f254ee5f216d711	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-30 15:42:19.836448-04
ad1a4d6e0e01f2fbf5b776f9e625e37a	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-30 15:42:21.903834-04
0a6df4f33419d463af7319775e5bfc9d	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-30 15:42:22.973826-04
716fddbeb64c78dd7a2aed9c77ac3e93	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-30 15:42:24.090213-04
37f923521771f14bda348aa5adc41683	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-30 17:06:18.937164-04
5c9844bacd82fa95899e0f7d0199e0fe	ZDY4NjFlZTUwNTA5ZWRkYzgyYTg4ZGNiYmE4N2EwYWY4MTdmNDZkYzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLX1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-30 19:46:56.308704-04
742d96fda49686b4fd13b63ca52ea3ac	MGU0YTE4ZDJmZjRjNTA4Y2VjZjIyOWQ1OTk0MjNiY2E1YmVhNGYxMjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLC1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-30 17:07:23.62248-04
a2adbee4f18324bcb38964d3e5713b92	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-30 17:21:49.556133-04
b1fdd99d6f5ce0efa29dbd5b1093bc77	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-30 17:30:36.623815-04
c666218e92be2ba6bf466adc29ecf329	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-05-30 20:38:35.70311-04
7a6c4758dcaa99dd48c8e83ce4d3805c	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-30 20:46:04.385844-04
cfa06f4e9be855f70db6d8c11ea9059a	MmFkOGRiZjU1ZTYyMGY0MzNhMmNiM2JmMDIwZjIxN2EwZDFiZWUxMDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLYHUu\n	2012-05-30 23:12:20.544349-04
19166e6ef8161fcde6ed3ad2dc7c5961	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-30 23:58:53.034973-04
2358ff015c8c47daf6d2d715fd6150fb	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-31 00:16:26.847638-04
f4baf9b9ed6e8da2be2c30499bb9d02b	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-31 00:23:12.903072-04
2551a12af594a85649bd9d1eab852b1c	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-31 04:10:25.467036-04
3d474abdd772f27f670da8164b7124a7	NDJjZTg1YWU5MDgzMThkY2YyNGQ1ZGE4MjBhM2EyM2I3YzU1ZDVkMjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLC3Uu\n	2012-05-31 16:44:14.047729-04
642fe43848ad92f2fb0c60f33f9f3db0	ZjExNzU3NGM1OTQ4NTZjMWUxZTEwNjIzNjA0NDQzY2NhYzIyOTljNzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLA1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-31 17:19:36.993561-04
78e1518e65bf790f2720a542753ec480	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-05-31 17:52:50.796694-04
610ece2d593166ce7526e99661934b62	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-04 17:28:56.687309-04
472c5b13d17b62aef7a149f0e11a47ca	MzM2YjJlNDA1ZTZmYzU5ODE5M2NlOWQ1ZjJjZmYzNTk1YmU0OGFhMTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLHlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-05-31 21:34:37.978897-04
a5923157ff706d69c18c92ddd7908abe	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-05 11:01:50.954767-04
b68f543d6301c70d52483d2c95bb6070	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-01 00:29:38.764303-04
fd99620c0a805b2feba8cf2c90e97226	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-01 01:02:48.723277-04
0c1b180e742a0b4b4845b66342316c5c	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-01 02:23:26.364959-04
460b7cf8a9e108c2e5736747c58a858b	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-01 09:14:34.784461-04
56c2b530cbd252d40e8c220a292884c5	NWY1NDQ1MmIzOGIzMjE1ZjZkNzU2NjU1YTY0YmU1NDM1MTViZmI3MTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLNlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-01 09:29:22.571681-04
f17379bc087e50d95dd626d8ea3ca343	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-01 10:18:34.43696-04
6c9bc06579c5bd1dcfc95fe1eb9a5437	NjE3ZmJlYWVkMTEzMjQxOWQ5MGJkM2FhZjU2ZDQ1MjRmNzFhZjgyNjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLB1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-01 10:25:31.576266-04
6874587552a5f5fc9f0afb288a77fe01	YjViM2E2ZDA2OWQzNTJiNDUxZDhkNjY4YzgwNGNhNTFlY2RiZWQ1NTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLKlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-01 10:31:51.703997-04
5fa24549d1a0ac9a4138148d0e251fa8	NWIzZTBjYmI4OThmNTU2NmRhNDQ0YjQ4NGEyNjU2MTIyYTYzNDAzNzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLXVUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-01 10:53:59.787899-04
1f6c6f52a22708b2c33d345d9fcd65f1	NWY1NDQ1MmIzOGIzMjE1ZjZkNzU2NjU1YTY0YmU1NDM1MTViZmI3MTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLNlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-01 10:54:40.69337-04
a86a07200347c82cc94e20f49a858075	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-01 10:57:41.239939-04
334ed7aa3f009b5521a6760a4d8a23d6	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-01 11:04:37.525989-04
1f782812d24a32579ea6dc9163b52257	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-01 11:04:43.272243-04
4c4ec769cf790af43837485cae4d3b5b	MzkwNWRmMjlhZThlZDJlODkyMGFiNTEwYmFiNmMxODBiZmE4ZDhmMTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAVUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-01 11:11:52.752694-04
7641f442e494338597cf396bd9da6c2e	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-01 11:22:21.074556-04
92c7fdcbf1f084f82f6d380502875361	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-01 12:39:48.176588-04
aa09962f62437b1eb0f70199a4b5937c	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-01 16:08:38.404289-04
146d683ce51b1b634f3d67e8661e53af	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-01 17:26:56.961821-04
e32225e7a5df70644aba96480e84d318	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-01 17:38:00.153536-04
2ee1f41091aa6a6782f9a2a35a4fe1f2	Y2Q3YWY4YzI1N2JhNWQ5OTZjZjQ2ZmRhZGExZDlkOWU0NDliOTY0YjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLM3Uu\n	2012-06-01 18:59:18.707325-04
732e579ce9bd8ebc5f0233fd5a8da56f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-01 20:00:54.583967-04
920661990d389726b7d3bf978efa3da5	MTdiNTUxNjViYmUwY2Q4N2YwYTEyNTdmYjFlZmI3YjA4YTQ4MmY0ZDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLSlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-01 22:29:57.902426-04
40e23a7c0526705c115a3c10aee5e6d8	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-01 23:55:12.261961-04
9f4b4ba05376368fcbb05afc0c4ef589	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-01 23:55:16.073668-04
ec05cfd898edb895cede53e692d39b84	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-01 23:55:55.218896-04
5fe3a49d68ddd4df9eaebabb633d1928	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-02 00:03:35.482172-04
02424d82266177afd4ba71aad9147ee9	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-02 03:45:36.288627-04
4f900e889085c0d9f80a5bb722906188	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-02 07:28:37.046139-04
50484d3513e754d0ad8a265baf58d35c	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-02 07:40:26.043396-04
ce4147546f20800c2b46666f28226c7a	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-02 10:17:58.71094-04
5f20125fcbbf41406a6b80a8d9adcc74	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-02 12:38:18.891737-04
84226bafd47597d88f646b6ce63b5772	N2MxNzZlOWY2ZTI3YjliMDdkMjNlYTdiMmNjYTZlM2NkMmVlMDc3MzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLBlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-04 16:53:29.863384-04
6713cfb684d98f6e0c342eae90afa890	ZTIxNDhiZThhZDE2YzZmMzMwNjE0MThhYWNhYzY5ZGQ4MzFlN2NhMDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLY1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-02 13:01:51.79864-04
ce650b0ca197544e4b6871a032591613	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-02 13:05:50.31436-04
415ded490f49d326d3399befd2e03785	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-02 13:58:18.269801-04
918ca9b378eaae5cc322dbe2e4d257e5	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-02 14:06:17.830176-04
5d0d76078b31d0740a7fec749242c0b7	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-02 14:11:59.886314-04
94c182b503189b86178677e51437dbcc	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-02 14:15:44.738264-04
25ee70955d29b6695318b04aaf0b88f9	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-02 14:19:29.751539-04
1585ca34d31c3fe357e63f0f79c225b7	MTg3OTM4MTUyMjIyNjA5NjRlNzQ5ODc0NDNkZjJmMjJhZDgyZjMyYzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLD1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-02 14:19:48.177536-04
b5181931a679967de49f0c6d4fbde92e	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-02 14:23:14.410803-04
26f250db575e93c7f2944db7f991baaa	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-02 15:23:04.188522-04
29e7c02b2a66e2c8d14a19c334391e8e	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-02 15:57:41.297997-04
b9be00197afc689cc8e090bd07f1fefd	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-04 17:34:48.487847-04
45980738c46e015dfd0c213f290d7a34	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-04 18:49:05.551031-04
08dfeca8d73ba08f8705e0aaa0403850	MTg3OTM4MTUyMjIyNjA5NjRlNzQ5ODc0NDNkZjJmMjJhZDgyZjMyYzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLD1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-02 18:22:11.515993-04
56e6654edbad00d663269d154155a8e2	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-02 22:41:18.716894-04
92d4a860f2a1649fd19311a163ea26b1	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-02 22:43:40.090509-04
b5a54388453c395f85600bb39a8bd9bb	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-03 01:57:51.499209-04
ec8b909cd6f56a8fd3481f21d4bf0b69	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-03 02:24:14.02001-04
457b998c2718b5b8c2eb0367e20edf80	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-04 22:35:34.603644-04
335f27c1bb4fae259ed3896555ad9d31	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-05 03:45:11.945088-04
d116bb3271dd2d45d170305fdbd55847	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-05 08:03:36.608342-04
2c2d0dd84774d3733290dccae6f1d844	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-03 10:21:57.499483-04
d9a1509dc8cfd88f12eb2db9f98927b3	N2U1NzE5ZjlkMzAwNTgyMWUzYjExOTk1MWYwNWY5YmE1MmUyZjM4MTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLZFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-05 10:14:53.04746-04
5bd2c1e4f68dc38815dc682f27d88c38	NjU5MmNlYWY1ZmYwYzdhYWMzYzc5OTI0OTQ2MmM0ZDg2ZmMwNGYzYjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLZVUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-05 13:39:48.09417-04
8e200c5f03ba67e72625d83a8901e902	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-03 19:18:38.654121-04
f27d508301ac969dc8fae3b1261bb674	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-03 21:13:19.274063-04
a03f374d72ca0a40131a297dbfa96447	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-04 06:59:04.169656-04
03019fc49edfb33ec19b34312a884d37	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-04 09:15:22.675999-04
7b8c48a020ab85deab8a690805973c14	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-04 09:25:05.654857-04
aac5b413ccfc3b26fe27d8b2eb0deb15	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-04 09:44:49.182953-04
2cc1f997db9beb61d97894b766105a04	MTg3OTM4MTUyMjIyNjA5NjRlNzQ5ODc0NDNkZjJmMjJhZDgyZjMyYzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLD1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-28 15:01:12.775591-04
5ee2ca8c85e0530d394524725f7dd1d6	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-05 13:52:05.919525-04
33d34999970fa267d47dbbbb1e678fa9	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-05 14:47:25.551994-04
89e34aa912e37c5c0e653439ceab0c94	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-05 15:15:48.034169-04
0c4eceec4bc7ab5547807d0e8fd5ec58	YzQyZjExN2FhMmNlNWFmNzY3MjBlNTg4ZWQxY2FjOTc5NDA4ZGVkZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLCFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-04 11:14:44.147987-04
c92258242a25362d6971825339ad9c6f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-04 13:10:46.155777-04
0a901d38fbf4dafe6d540bea305ec5e9	OTgzMTYyZDA1M2E5N2NkZGM2MTdkNDdlZTQ2N2YzNTc4MmQ0N2NmODqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLZnUu\n	2012-06-05 15:30:08.672336-04
e06a56f00f2f5f3c050419ee61c8118e	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-05 20:06:13.562679-04
f684ba7d2dab8432456003dd8774a3e7	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-05 20:46:02.484029-04
8d41989eb287cc13758a8afd7fbfe048	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-05 21:12:41.362146-04
c91431210208c29036e3aff5ce4939f6	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-06 06:04:49.660882-04
3fa4ea3e27a96d112ea620d07812f472	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-06 06:17:18.272074-04
255026495fa1d7f4cc5ab1be0f63b00d	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-06 06:20:52.391114-04
24c66722f8fb4e288019fb4cddca4e63	MTg3OTM4MTUyMjIyNjA5NjRlNzQ5ODc0NDNkZjJmMjJhZDgyZjMyYzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLD1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-06 09:19:41.902479-04
cda6759bfde2f06f3c0ccfa2b973f9a6	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 18:26:38.688875-04
1b953e8b1e7c82411f4dcc1e7785bbe9	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-06 10:28:57.054725-04
6e1f217074f99176ff1ec3c2ff615f58	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-06 11:01:45.703644-04
8e226a211ab3e1ef5e1b426e973a0eab	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-06 11:05:31.424623-04
c885cfe46dda3c59ae011adeb4c2547b	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-06 11:19:07.670479-04
2c20b85bcbcac8da16a552877b9195e7	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-06 11:33:27.271732-04
51e90ccf14e791d35271ce8dab68aa42	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-06 11:48:31.686398-04
ed10074f0e63d106fba7a320c71c2a0d	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-06 12:31:20.259028-04
b515779e31751a2ba18dd550fae3a2c8	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-06 14:44:57.43613-04
f00505639217224318745a3b120a9fd9	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-06 14:59:55.967206-04
7d89f5925d40c6beb211e28e6c8065c9	ZTAwZTYyMTVkOWNhZTQyNjI5NmM1NzcxNjA5MDgyZWViZGEwNzIxOTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLaHUu\n	2012-06-06 18:28:16.155184-04
0fe230265a6beaaebb1a80c3f15e58ce	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-06 21:59:17.52956-04
0c6a48ccc4dfb704b549adc84b0b5711	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-07 03:54:50.464486-04
ab511143a07c81dd88eb5d98aabee224	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-07 05:42:15.299098-04
6903c1a84bd1752904f6a42d6e6faa41	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-07 07:47:22.521326-04
e460f6a0e35183e9be98a5c5bd79047e	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-07 09:00:41.292774-04
ef5d8fdfa7ba0017e16acd6d491911f3	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-07 10:21:23.830487-04
eece13893f8f626a4c095cda049ad6ec	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-07 11:42:00.751578-04
15ee223ae9969a9856556de0653cd494	MmE3NTQ1NGVkYzc5ODMxMWQ2NzhhYzY1NDA5OGQ5OGE2MWE3ZWNiZTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-07 13:12:27.056185-04
c5ba192e942997b690483781368fe607	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-07 14:51:32.514258-04
2bac3f4a40ca0178e1f787bdfc12d0f2	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-07 20:32:43.563783-04
581d883c2c8af6e126792c6eadbc567f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-07 23:37:37.073024-04
744ac4c48cdaa223cb8255aae0ab03b5	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-08 03:27:26.454674-04
b82630df0184eb533a7ea743a174f34f	MGEyMmI5MzQ2NmFlM2U0YmU4NDIzZTM3NTBmOGVlMzdmMTgyYWRhODqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLSFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-08 08:22:53.06091-04
f660b83a0300a453cc5e59006103f10d	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-08 11:16:37.77527-04
81cc73500857e6478c34f7ad7d354d96	YzQyZjExN2FhMmNlNWFmNzY3MjBlNTg4ZWQxY2FjOTc5NDA4ZGVkZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLCFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-08 11:22:30.918172-04
70a4341fe2b9b9874bcdf2cb911381ce	NTQzNjQ1MjBmNTBhM2QxYWRmYmM5NzM5OWU0YmVjMDczMjA1OTk1NDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLGFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-08 13:04:50.738013-04
02e12107cd38c1a1cba38d9b8d0a44f0	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-08 13:24:17.682347-04
9323c30bdeea4213c1465007ca02a036	ODEwMDE3MGIyYjBkMWE0MGFjYWNjMGMyNzE0NTEyNTNhNzBjNTcyOTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLLFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-08 13:46:52.636416-04
c42a0ba5e71ecf3b02f60bec2786276b	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-08 14:08:01.822152-04
9e56b2f6c6b1e9852d82758baf80324f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-08 14:08:08.95536-04
88a08b8e63505b9a520735bcf17e8bf2	M2ZjZGM0NDk5OGVjMWYyOTFjOThlMDU3NmU4ODc5YTAyNGVjNzNkZDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLQFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-08 15:16:56.023775-04
cd9d69f0b2a51e0f25c126cc31b6e7f1	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-08 16:44:45.201998-04
913e58de3f33a9e937df8a6d3824c5e2	MTg3OTM4MTUyMjIyNjA5NjRlNzQ5ODc0NDNkZjJmMjJhZDgyZjMyYzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLD1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-08 21:16:15.760268-04
844460b4344701de36534ee16580dc33	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-08 22:13:09.589368-04
a168a194026cec9577c95339ab8584b5	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-09 01:57:35.189482-04
69839d1cad1545fb8dbcdbc18f017dae	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-09 06:27:37.252917-04
ab5f36fc2f883e289ff2d3a08cd34571	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-09 09:44:40.094291-04
bb1bfb16698126ad9e477eadcf774a81	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-09 11:23:18.689921-04
e29e9288810be1ff11c2d5d1b66b6f76	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-09 19:55:12.544909-04
fb5137e22f2033640967ee6bef5cf583	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-09 20:20:21.089083-04
4da3eee943d7b5b6a2b0111aea10fc1e	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-09 22:12:30.052533-04
64472182bb8a81eb28741cbc77b80999	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-10 01:45:25.383229-04
f5494b45ceedde17bc13447447593fb2	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-10 04:22:30.188932-04
2bb60293409e6feb1282179e0132bf4f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-10 05:59:10.35125-04
d7d5cae24ef9636d87ecff11c17718b7	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-10 16:11:21.709221-04
6eab83ae77e2579a199183d49194f2dc	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-10 16:18:00.047599-04
9efe35065c71ec0e0ceeda62ccef6b0c	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-10 17:56:48.654354-04
cbd19ac9393de0a88e9d4756550be87d	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-10 23:37:39.13578-04
02dbd064c85d38991e349949c08a6e7f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-11 00:55:10.91622-04
1e83dab0adf919951ff52ed75803f11b	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-11 02:50:33.094956-04
710130a062d93e7ff3c1e03ba2a25ac8	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-11 10:26:21.884244-04
e9f5a973c2caa6113e027972731371fd	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-11 12:41:35.96019-04
5cf0d9df13763787a2ef6f1d49d8bbe1	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-11 15:16:55.815685-04
44c983a7cd653b3d978dcf84a2ac6db4	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-12 04:20:54.827888-04
b6da79ae8afaf81b1f69c24853b66650	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-12 04:21:12.295532-04
2061027ee74e0af49e69aa9ec4ed6b0d	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-12 05:30:14.368267-04
89a00a0c8bd891a838b55d4a93c7f05f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-12 09:38:15.631228-04
aa1ff908f0af8467511d3de0c7e12525	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-12 12:39:05.625168-04
ceff6673936344a3a50ba3a8f7ad1b8f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-12 14:08:28.595856-04
c76a007ea522a2f6e472012a3d140e43	ODYwNzk2N2FjNWExZDliYzgyZGY5M2ZlOTQ0NmFiZGEyM2IyMWNhZDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLaXUu\n	2012-06-12 15:44:12.25913-04
764821e141554c83583a5f5634ab9f42	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-12 23:03:25.198425-04
7357a3895479db74a51f002cac4da3b6	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-13 00:47:08.690551-04
84e240312b6373efe335266e44bb3d11	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-14 15:54:40.327029-04
3534c8deb9a7225ec0dd2be33c6e5177	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-13 07:48:55.527075-04
3878206292150a5ab18af90e06290f26	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-13 11:03:20.577824-04
b13018525bc40c7d21253db2a5cc5b0c	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-13 11:11:51.8095-04
602083af3431ec1123d0f8ab2b5654fd	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-13 11:31:56.281782-04
36408a0e0f63002ba00ff15f32233bfa	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-13 12:38:25.682468-04
5574301167ea5e6dcc346a5d1fb2820e	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-13 13:09:57.663832-04
9a51e9d51ef3c30a4fb430e693fa48f2	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-13 13:11:35.579419-04
93b4b37ee8260250513d6606966461a1	MmE3NTQ1NGVkYzc5ODMxMWQ2NzhhYzY1NDA5OGQ5OGE2MWE3ZWNiZTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-28 17:00:09.248587-04
3c49fd8820c8fdbe99cf3ffb616818ad	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-13 22:15:01.41951-04
a9c49ad43b30b096d5ad46142a66c83c	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-13 22:15:40.03355-04
ecfc09c84433c8d7293e700f4cd1ad45	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-13 22:30:02.351777-04
ecb270cb59bac1fca954e4ea9a68a360	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-13 22:40:14.679355-04
b794d470f4cb89a01198fcafbee69362	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-13 22:50:58.416472-04
508768bd3b60d3efad49fe83607cb7b5	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-13 23:37:41.191606-04
d4267c3ca3b748b6513a8c49b4224b38	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-14 03:20:27.195038-04
37f019f112e2561d705e8e0d77d6a013	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-14 06:19:58.694892-04
c28762a9a76bd343ca4710e295b33b03	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-14 07:13:18.03695-04
fb6cb7fcb0b9e18c4cb4b3ef86a78a54	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-14 14:14:25.529112-04
e33a835f671223c81313e6672f5c012f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-14 15:05:02.672108-04
d44a6896688f31893155b2678ec48fa0	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-14 15:05:02.78549-04
6b5337fcedb57c5bff2689c46a6004b8	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-14 15:05:02.837523-04
551cce0f600533a7090afa6cac820d50	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-14 15:05:02.896293-04
e2e31ce6bd98bbd13a90defcb7b5cdf6	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-14 15:05:03.043633-04
69cb6a1b84ce738b9dbe1cab04637e41	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-14 23:16:36.514282-04
992aed6d5ec1a6cf75cba3a626786cef	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-15 05:57:53.235875-04
432c5f1cf02bbe87ee63c2313dfc1df0	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-15 12:25:25.524895-04
7a8be20edf7b69027faf85d3ac1b61e9	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-15 15:31:25.677589-04
d178c808caa9b05dd5d553c197ab2255	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-16 09:56:12.975209-04
62c42e87e04cf1ef7ce24b3d2ce2dd86	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-16 11:55:05.370511-04
c7d90968ba53752b13570c0a3eee2328	Y2ViMjkxMmI2ZDY3MmZkYzJmMTY4OGUxYjM0YWExZTc3ODVjODVkZDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLEHUu\n	2012-06-16 12:46:38.551582-04
6467f7f40f5d3393b814f6cf47fcf024	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-16 18:21:55.508684-04
b2b1093fac11b8fdabaa9ccfd8f1e4db	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-16 23:54:20.575415-04
710d75ff99aa6cee28e67d4f8725ddf0	YzM2NWQwYTlmZDkyNWJhZWZlN2ZkOTAyNzM0MzJhOGZlMDM1OTg0YjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLalUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-18 09:09:26.352081-04
60153188bc8b81433eba0653f32c1170	NmQ2ZTcxY2ZkYmVlZTA0YzgwOTQ1OTI4ZWEzYmE5YTkzNGI5NTc0YjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLD3Uu\n	2012-06-18 09:41:04.813107-04
a338d614e190524943e7a40106ed19fa	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-18 10:08:56.394046-04
1a46ef929766189abf26ce6515948984	NzVlNjc0YjQ3NWQwNmM4YjM4ZDcwZTJjMmFmMDFmMzQyZGJkNjk1MzqAAn1xAS4=\n	2012-06-18 10:47:12.016085-04
6f3ed8bdcfec6567a6b5d475077f40f6	ZTc3ZGZhZjAwNmE2Mzk0MzhjMWE1NDFiMDg3YzViNjVmNTQ4NTU2MjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLF3Uu\n	2012-06-18 11:02:35.299612-04
99cf52349370f9a4519d71216ac010fb	MzkwNWRmMjlhZThlZDJlODkyMGFiNTEwYmFiNmMxODBiZmE4ZDhmMTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAVUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-18 17:40:53.385556-04
b0a81d41a0aa07456a111265ce7bab25	N2MxNzZlOWY2ZTI3YjliMDdkMjNlYTdiMmNjYTZlM2NkMmVlMDc3MzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLBlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-18 18:32:48.438565-04
8c09dc8536dae136650d3908f30ef565	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-19 14:21:15.311795-04
693eae682d346ca6e6822fa9b32acae8	ODI1MmI3MzNiMGQ0M2NhYmFhMDQ1OWE5MzI4NmY0MGY0NTY3MzExZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAXUu\n	2012-06-19 16:40:37.059629-04
4cafd7cb4af2da7099b80e6671202041	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-19 17:12:50.642762-04
7e0715271b7ce72f208ca94c88c70219	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-20 06:34:40.887315-04
4f499b5c6aecc6015a641713b875925f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-20 07:05:39.667517-04
be62fb7c508190ab87642ff722e7041f	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-20 09:07:52.891301-04
9b46dd3be681f0e06dfa8f0a35310f6c	NTdkM2Q1ZDUzOWMzZGM0OTU0ODY5MzA4MzU4ZTk4ZGUyZjBiZWE0ZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLWlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-28 15:04:00.381126-04
57ea2929a444195de585fb50f7a6f7fc	NmQ2ZTcxY2ZkYmVlZTA0YzgwOTQ1OTI4ZWEzYmE5YTkzNGI5NTc0YjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLD3Uu\n	2012-06-20 17:23:56.630632-04
1e04e4837287199e4c9bde7d1d485ba7	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-20 18:18:03.308068-04
598dc0a40e575add2a7c270302aa429d	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-20 18:30:27.698684-04
a8fcca2b20c49546c8e5fdf8574f8bf2	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-21 00:24:59.724758-04
0967022cfe76edde7d0c2ae3f8c554de	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-21 03:22:05.68033-04
46111ad944aad2957c301811e3f31bde	NWZlYjIyNmUxNDNhMmUxZTExOWQ3MjBmNjE3ZmFlZDc4YzcxMWQyMzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLa1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-21 08:45:22.064729-04
a3adb6bb84ef9c06c7d0a0300238f32d	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-21 16:22:44.292376-04
2792868f1a96cfa24879118185496e03	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-22 03:25:18.111243-04
16862a355901be21cb4f557f34a62015	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-22 09:30:15.162634-04
c02ee9e8bb5ca851a5528a58e72ea223	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-23 09:08:34.01536-04
d2514f7db097cacd38f36aaa608148e8	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-23 10:55:18.040394-04
436a48e460e677584fda1f4fe15d909b	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-23 14:01:02.268765-04
a09bb67ed498ceef682e8a74f33fe471	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-24 07:55:17.862028-04
c84c478a7b7dcd5a556a3dc68fc464cd	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-25 00:15:13.315241-04
aaeaa5acc905bef28c4920aaf1416cec	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-25 03:33:26.88995-04
ad6e2150b8756069f5b88ebf29fcf204	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-29 14:42:56.827406-04
205f2d539b9f6c153039e08cd1302628	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-29 15:25:21.723055-04
f25d7a1b948d34580c8725d6f8b9d63a	MTg3OTM4MTUyMjIyNjA5NjRlNzQ5ODc0NDNkZjJmMjJhZDgyZjMyYzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLD1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-25 12:26:16.351241-04
77d463673d55b23007b5eb56f4c43595	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-25 13:36:06.928217-04
79bde1e4ab446abe008259fbdcbd6908	N2MxNzZlOWY2ZTI3YjliMDdkMjNlYTdiMmNjYTZlM2NkMmVlMDc3MzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLBlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-25 15:29:53.330958-04
736c35ab002f88dfbc1b9aa0832b6124	N2MxNzZlOWY2ZTI3YjliMDdkMjNlYTdiMmNjYTZlM2NkMmVlMDc3MzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLBlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-26 12:40:47.409814-04
baab7cae0aec3dd3f621c1365cea6335	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-26 16:52:24.659489-04
5a9fde4f64bd29bf52c6d6b7065c6c23	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-26 17:39:07.157585-04
0fa698e09d78943a70536fc82957c717	MTg3OTM4MTUyMjIyNjA5NjRlNzQ5ODc0NDNkZjJmMjJhZDgyZjMyYzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLD1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-27 10:36:38.950613-04
bca4aac2a7cb80c3941061e9b1a6a714	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-27 11:59:27.144656-04
0bde42acf1e03f9b4478dfaf9372fc90	MmE3NTQ1NGVkYzc5ODMxMWQ2NzhhYzY1NDA5OGQ5OGE2MWE3ZWNiZTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-27 13:27:40.147114-04
b9be176f650e318cf006328feca714df	MmE3NTQ1NGVkYzc5ODMxMWQ2NzhhYzY1NDA5OGQ5OGE2MWE3ZWNiZTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLAlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-27 13:28:48.816887-04
7b96669367a87d47f3b0d8126b6b2e61	ZDYyNTQ4Njg3YjlkNmRhNzZhZmJkNWRhMzY5MTExMDQzYmFhMzk0ZTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLEFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-27 15:37:17.521156-04
b6cdc0a0b3fa0899e2a8091dd0da8ebf	MTg3OTM4MTUyMjIyNjA5NjRlNzQ5ODc0NDNkZjJmMjJhZDgyZjMyYzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLD1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-27 17:49:19.539251-04
da53de329542892a1e8f244e9b52fb45	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 08:28:39.2917-04
4dc983fa00a2f7f9fade63b90483f197	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 09:46:54.322882-04
97de444b6182f51de1e1c3e15b12639a	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 12:05:15.401372-04
af8e4374794b42a22ecfa470c4b3ec89	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 15:15:08.573376-04
de0afe25c46b0e1f09c9ac08a675653b	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 16:48:13.698207-04
cff92508d65fed0db86ee181be54f333	Y2ViMjkxMmI2ZDY3MmZkYzJmMTY4OGUxYjM0YWExZTc3ODVjODVkZDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLEHUu\n	2012-06-28 17:07:48.974248-04
21fd089239842ddc36ba4e73a8c9c602	NzM0NmYxYjUwZDQyYWU4OTljOWEwYjJmN2Q1NmM3Mjc4NzAwYWU1NjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLI3Uu\n	2012-06-28 12:50:34.747436-04
2e2b5e77b4e28757b3f6a40ba0b298ea	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 12:51:55.97161-04
ffe8e6d0545569623e8590eae81ca339	YjViM2E2ZDA2OWQzNTJiNDUxZDhkNjY4YzgwNGNhNTFlY2RiZWQ1NTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLKlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-28 17:26:14.175711-04
b325bb41f6e7f9186ec84d4901e7cba7	NjgyN2EyYjE1MTNkYWE5NTEzMjY2MjUxZDU1OWY2M2E0MWQ3MjNjZDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLFFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-28 17:57:22.855481-04
9a1cd1b21d6a87bd613be664fa6bb4f4	N2Y0ZDQxYzk4ZTg2OTNiNTQwN2UzZDRmZTY0ZGQ4ZmZhYzk5MDRjMjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLKFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-28 12:52:45.912325-04
e21e68643b1e72e7813ede1559411a07	MWZjNmM2OTgxODBkNTU3MGUxMWMxMzdlNzc1MzBkNTcwMDM3ODdkNDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLQVUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-28 12:53:01.581537-04
1ac64a7476508882e16d5ba0d713cdc8	N2MxNzZlOWY2ZTI3YjliMDdkMjNlYTdiMmNjYTZlM2NkMmVlMDc3MzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLBlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-28 19:08:15.789045-04
4a6d6c197f57cdb0787cc59ecb0cc046	MGEyMmI5MzQ2NmFlM2U0YmU4NDIzZTM3NTBmOGVlMzdmMTgyYWRhODqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLSFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-28 12:54:58.424104-04
2bf2e2d9c477188abd54894b9df420ee	NWQzODJmMTI4YTFiZGY2ZjQ2MjYyZWU5NDdmYTA2ZmU1Y2Y4ZDU1NjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLO1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-28 12:55:19.12326-04
8356b0d13028f13b3bcaa6f629b1069f	YjA3OTk0ZjFjMWIxZmVkNjYzN2Q0ZmZlNTFiMmYxNGNmZDg4YzI3MjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLF1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-28 12:58:15.336477-04
80a8006aff2866169e6d24f644509581	ZDY0YWIxNGI2NWRiNTRlYTFjOTRkMWZkNThhYWM0ZWM4MTczOWY0YTqAAn1xAVUKdGVzdGNvb2tp\nZVUGd29ya2VkcQJzLg==\n	2012-06-28 13:01:43.906567-04
a9cf0a79e0ea77fbf430b96ac3d1dd87	YzQyZjExN2FhMmNlNWFmNzY3MjBlNTg4ZWQxY2FjOTc5NDA4ZGVkZjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLCFUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-28 13:04:41.698277-04
93d88a070e404d620e56df2fcc79bfee	MzYwNGE4OTY5ZDhiOWQyZDVmZTY0MGU5NDVkODNjZmVjNmQ3NjE3ZTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLLlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-28 13:05:04.846111-04
7578e10c4e1e1a606c660ec27f201022	NGJiMmYxMzQ0ODIwYjY5YjY2NWVkYTc5NDQ1YTkxYTRmODQ1ZGQ0NjqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLQnUu\n	2012-06-28 13:12:05.230587-04
1e7cb27b2e6c4a17420a513e1f72cf03	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 13:12:21.598052-04
2e23d1bedf91b50c0bd53755de6c7dfb	MTdiNTUxNjViYmUwY2Q4N2YwYTEyNTdmYjFlZmI3YjA4YTQ4MmY0ZDqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLSlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-28 13:18:51.343496-04
238b1f2d1bd4898a9edb474e9163ed9c	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 13:29:57.506328-04
fa9bcd9de8f92d3ec489ee09bc882e03	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 13:40:19.820508-04
d4cb1cbd9c4cd999159af3f9b83353ec	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 13:40:22.237207-04
cc24dd198551bf693e2a68be4ed1e360	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 13:40:25.781046-04
89226f3651dbc0f0298c021c8470378e	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 13:40:25.809752-04
94d95a3b3451a1cb1b0731eeaafca6c8	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 13:40:25.834579-04
b208a845e5e6f6a37faafa06b9dadc79	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 13:40:25.8485-04
669e8972f1dad5a558a6c40dc7653ae0	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 13:40:25.942021-04
534c97b7fe50557b45922c3be00b8fcd	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 13:40:30.769586-04
b00e8f03228db585d143174f78ff36f5	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 13:40:30.771332-04
079a19c0aaf8315d8680be8facabd2c1	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 13:40:32.573943-04
04af5459dbdef7f61142a6de8fb92bd5	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 13:40:36.689012-04
a0a189a0f669aa910b2275e8be43a063	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 13:40:37.596385-04
783538f1147ef63cfa893ab5b2307e49	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 13:40:38.893158-04
0473068d523a30c19198d343ac18caf4	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-28 14:22:16.324074-04
aad35c5279e59dbf6a91cea40710540c	ZDg1YTI3M2VhYjFmMzkwYzdjMmIxZjdkYWMwZjllZTgyOGU1ZWY4MTqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLS1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-28 14:53:10.891089-04
343677b03b13382e9f1a1a811e67025b	MTg3OTM4MTUyMjIyNjA5NjRlNzQ5ODc0NDNkZjJmMjJhZDgyZjMyYzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLD1UPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-06-29 15:51:30.470523-04
f0c1b67ca8d7cb1bbe67ac8d008a1d19	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-29 16:39:55.943953-04
d33279ed9339571cb5aca76b471967c2	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-06-29 21:11:49.179959-04
3a2279734186bb3ce448739af342e055	N2MxNzZlOWY2ZTI3YjliMDdkMjNlYTdiMmNjYTZlM2NkMmVlMDc3MzqAAn1xAShVEl9hdXRoX3Vz\nZXJfYmFja2VuZHECVSlkamFuZ28uY29udHJpYi5hdXRoLmJhY2tlbmRzLk1vZGVsQmFja2VuZHED\nVQ1fYXV0aF91c2VyX2lkcQRLBlUPX3Nlc3Npb25fZXhwaXJ5cQVLAHUu\n	2012-07-02 14:23:45.438718-04
951f1228dfe3cfa399b1924703677fbc	ZjI2YmMxODBlYWZkODQ5MmQwMzM4MzkyNGU5YWY1ZGE1NmNkNTY4ODqAAn1xAVUKdGVzdGNvb2tp\nZXECVQZ3b3JrZWRxA3Mu\n	2012-07-02 14:34:09.850714-04
\.


--
-- Data for Name: django_site; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY django_site (id, domain, name) FROM stdin;
1	www.scenable.com	Scenable
\.


--
-- Data for Name: events_attendee; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY events_attendee (id, user_id, event_id, dtcreated) FROM stdin;
1	6	33	2012-05-02 21:17:26.68892-04
4	6	49	2012-05-02 21:55:23.374354-04
5	16	48	2012-05-02 21:56:46.028587-04
8	16	46	2012-05-02 22:07:36.972672-04
9	15	49	2012-05-02 22:16:29.276821-04
10	15	53	2012-05-02 22:25:23.342512-04
11	1	33	2012-05-02 22:39:47.95097-04
12	1	40	2012-05-02 22:54:47.92073-04
13	15	50	2012-05-02 22:55:22.427128-04
14	19	53	2012-05-02 23:39:19.326234-04
15	2	46	2012-05-03 07:37:30.785533-04
16	2	33	2012-05-03 09:28:24.147426-04
17	2	32	2012-05-03 09:28:39.975055-04
18	45	33	2012-05-03 10:44:16.537202-04
19	45	52	2012-05-03 10:45:25.078742-04
20	1	10	2012-05-03 11:35:01.844757-04
21	15	10	2012-05-07 20:22:27.649559-04
22	20	56	2012-05-11 14:50:45.959589-04
23	15	64	2012-05-17 12:53:59.73684-04
24	74	81	2012-05-19 00:31:42.653756-04
25	99	81	2012-05-19 13:04:40.826976-04
26	99	69	2012-05-19 13:17:29.47943-04
27	93	68	2012-05-21 11:10:41.063402-04
28	65	69	2012-05-21 17:05:09.253805-04
29	65	81	2012-05-21 17:05:39.008525-04
30	65	77	2012-05-21 17:07:01.509089-04
31	15	69	2012-05-22 14:30:21.889524-04
34	107	69	2012-06-07 08:50:11.278542-04
35	1	85	2012-06-14 12:37:44.957684-04
\.


--
-- Data for Name: events_event; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY events_event (id, name, description, dtcreated, dtmodified, dtstart, dtend, allday, url, place_id, place_primitive, listed, image) FROM stdin;
40	Senior Art Exhibit Opening	CARNEGIE MELLON 2012 SENIOR ART EXHIBITION Organized by the CMU School of Art May 5-19, 2012 Opening reception May 4, Fri. 6-8pm	2012-05-02 17:46:31.740981-04	2012-05-02 18:19:45.477904-04	2012-05-04 18:00:00-04	2012-05-04 20:00:00-04	f	http://millergallery.cfa.cmu.edu/calendar.php	406		t	img/e/CMU_Logo_1.jpg
3	Cave Canem Poetry Reading	Carnegie Museum of Art collaborates with Brooklyn-based African American literary and poetry organization Cave Canem for an evening of poetry reading and conversation\nled by poets inspired by Teenie Harris, Photographer: An American Story.	2012-04-11 17:54:41.524204-04	2012-05-30 16:10:31.231915-04	2012-03-29 19:00:00-04	2012-03-29 21:00:00-04	f		196		t	img/e/HxiL7P.jpg
4	Wings of Hope Gifting Gala	6:30pm Cocktails, Dinner and dancing to follow.\nDress: Formal/Cocktail attire\nThere is a butterfly motif - so, think spring!	2012-04-11 17:54:48.261236-04	2012-05-30 16:10:31.337424-04	2012-04-14 18:30:00-04	2012-04-14 22:30:00-04	f		397		t	img/e/yjY6bm.jpg
5	The Bubbe Club!	Do you enjoy crocheting, and/or knitting, or would you like to learn? You are in luck! On Sunday, April 15, 2012, the Hillel JSU Arts and Culture committee is having The Bubbe Club meet to crochet, knit, drink tea, and just relax before the end of the semester. We will also be able to give beginner lessons.\n \nIf you are interested in attending, please e-mail Jamie at jak158@pitt.edu.	2012-04-11 17:54:58.143053-04	2012-05-30 16:10:31.436363-04	2012-04-15 14:00:00-04	2012-04-15 16:00:00-04	f		\N	Hillel JUC	t	img/e/dp6CsD.jpg
6	Passover Mid-Week Meal	Come to Hillel for a delicious mid-week kosher for Passover meal.\nIn order to make sure there's plenty of food, please RSVP to Jamie at jak158@pitt.edu by Friday, April 6th.	2012-04-11 17:54:59.384087-04	2012-05-30 16:10:31.546023-04	2012-04-11 18:00:00-04	2012-04-11 21:00:00-04	f		236		t	img/e/diyDHk.jpg
7	Chocolate Seder!	Indulge yourself before Passover! Join us for the annual Chocolate Seder at Hillel - enjoy candy and chocolate and meet other Jewish students. \n\nEmail Julie at jdc96@pitt.edu for more information	2012-04-11 17:55:00.640991-04	2012-05-30 16:10:31.668065-04	2012-04-04 19:30:00-04	2012-04-04 22:30:00-04	f		236		t	img/e/di__I2.jpg
8	Funniest Jew in NYC Performs at Hillel!	After Shabbat Dinner, Hillel welcomes Aaron Friedman - voted the Funniest Jew in NYC! This event is free for students - bring your friends!!	2012-04-11 17:55:01.522906-04	2012-05-30 16:10:31.797359-04	2012-03-30 21:00:00-04	2012-03-31 00:00:00-04	f		236		t	img/e/KaT3TN.jpg
9	Chocolate Lava Cakes & A Suitcase Full of Chocolate	The 19th Annual JFilm Festival is coming to the University of Pittsburgh!\n\nOn Thursday, March 29, come to Hillel at 6pm for yummy dessert, followed by a quick walk to the Frick Fine Arts building to see the film "A Suitcase Full of Chocolate"'\nCheck out the film: http://jfedpgh.org/suitcase.aspx\n\nRSVP to Jamie  (jak158@pitt.edu) or by commenting on this facebook group that you want to reserve a ticket! (we need to buy tickets in advance)	2012-04-11 17:55:02.173857-04	2012-05-30 16:10:31.936299-04	2012-03-29 18:00:00-04	2012-03-29 21:00:00-04	f		\N	Hillel and Frick Fine Arts Building 	t	img/e/p6fUWj.jpg
11	Avengers VS. X-Men Pre-Release party!	Issue #1 of the Avengers Vs. X-Men will be on sale at 8 PM this Tuesday. We will have some exclusive variants, posters, and some other fun stuff. There might even be cake!	2012-04-11 17:55:19.409684-04	2012-05-30 16:10:32.150452-04	2012-04-03 20:00:00-04	2012-04-03 21:30:00-04	f		241		t	img/e/dkOVh1.jpg
12	Western Pennsylvania Garden and Landscape Symposium	Join Phipps, Penn State Extension and Shady Side Academy for a day of discussion and presentations from special guests, as well as opportunities to shop for unique plants and accessories, at the Shady Side Academy in the Hillman Center for Performing Arts in Fox Chapel.\n\nRegister by contacting us at sbertovich@phipps.conservatory.org or 412/441-4442, ext. 3925. Tickets cost $99 per person before March 23, 2012 and $115 after; includes continental breakfast and lunch. A limited number of scholarships are also available. Call 412/441-4442, ext. 3925 for an application.  \n\nSCHEDULE\n\n(Full Audience)\n\nGarden Marketplace\nShady Side Ice Skating Rink\n8:30–9 a.m.\n\nRegistration/Continental Breakfast\nHillman Center for Performing Arts\n9 a.m.\n\nWelcome/Introductions\nHillman Center for Performing Arts\n9:15–10:30 a.m. \n\n(All Lectures Take Place at the Hillman Center for Performing Arts)\n\nForgotten Elements of Good Design: Texture, Movement and Fragrance\nDan Hinkley\n10:45 a.m.–1:30 p.m.\nFar from being static, sterile and frozen in time, a garden is a dynamic entity that ebbs and flows throughout the seasons and years.  Dan Hinkley will discuss how to take advantage of these changes while siting plants in the landscape. Using inspiration from nature, as well as imagery from his garden, he will show you how to employ and gain enjoyment from movement, texture and fragrance.\n\n(Choose a Track for the Following Portion of the Day’s Schedule)\n\nTrack A\n\nShrubs Through the Season\nRuth Rogers Clausen\n10:45–11:45 a.m.\nAs the seasons change, so should your garden, which often gains interest from shrubs selected for their color, textural foliage and, in many cases, their flowers, fruits and fall color. This talk examines some of the best specimens for growing in the Pittsburgh area, as well as more recent introductions to the marketplace. Combinations and potential companions will also be covered.\n\nGarden Marketplace and Ten Minute Tips\nVarious Local Experts\nNoon–12:45 p.m.\n\nLunch\n12:45–1:30 p.m.\n\nTrack B\n\nGarden Marketplace and Ten Minute Tips\nVarious Local Experts\n10:45–11:30 a.m.\n\nLunch\n11:30 a.m. – 12:15 p.m.\n\nWiser Living Through Gardening: Using Edibles in the Landscape\nBarbara Pleasant\n12:30–1:30 p.m.\nOrganic gardening is just the beginning for a new generation of gardeners. When growing food becomes a central element of your life, the pursuit of a truly sustainable garden becomes a primary goal. In this presentation, Barbara will explore what organic means in terms of soil care and selecting crops and varieties that thrive when grown in the Pittsburgh area.\n\n(Full Audience)\n\nSmall Garden Smarts\nKirk Brown\n1:45–2:45 p.m. \nSmall gardens are opportunities for big ideas. The fundamentals of elements and principles of design help sell the bigger concepts of quality of life, sustainable practices and resource management. This talk covers how to combine horticulture with hardscape, mixed borders with vegetable production, and seating with containers to create beautiful courtyards, pocket retreats, verandas, and more on a budget.\n\nPlant Marriages: Exceptional Combinations of Foliage and Flowers\nDan Hinkley\n2:50–4 p.m. \nUsing images from the gardens he has created—Heronswood and Windcliff—and drawing on his experiences working in natural and crafted landscapes around the world, Dan Hinkley will share the personal parameters he references when siting plants in the garden. He will also discuss how his attention to scale, height, differential, repetition, and communication between landscape components has resulted in a more satisfying garden through the seasons.\n\nConcluding Remarks\n4 p.m.\n\nThis conference qualifies for Landscape Architecture CEUs, four recertification credits for Pennsylvania Certified Horticulturist, and elective credits for Phipps’ Sustainable Horticulture and Landscape & Garden Design certificate programs.\n\nSPEAKERS\n\nKirk Brown is a graduate of Cornell University and a recipient of the Pennsylvania Nursery and Landscape Association Green Achiever Award for advancing horticulture in Pennsylvania. He serves as business manager of the award-winning Joanne Kostecky Garden Design, Inc., is the author of Landscape Contractor—which is distributed to high school guidance programs throughout the U.S. and Canada— and is the secretary and executive committee member for the Garden Writers Association. Kirk has also been chairman of the Penn State/PLNA winter education conference committee, part of the marketing committee for the American Nursery and Landscape Association, and a judge of major exhibits for the Philadelphia Flower Show.\n\nRuth Rogers Clausen’s Perennials for American Gardens received the 1990 Quill and Trowel Award from the Garden Writers Association. She has written for the American Garden guide series, which includes Perennial Gardening with the New York Botanical Garden, Annual Gardening with the Missouri Botanical Garden, and Trees with the Chicago Botanic Garden. A former horticulture editor for Country Living Gardener, she has also contributed to Country Gardens, Horticulture and Organic Gardening. Ruth was trained in horticulture at Studley College in England and received her M.S. in botany from Kent State University. Since 1976, she has free-lanced as a teacher, lecturer and author in the U.S. and Canada.\n\nDan Hinkley’s fascination with plants goes back to his childhood in Michigan, where he studied horticulture before moving west to Washington to earn his master’s degree. He writes for numerous horticultural publications and is in high demand as a speaker throughout North America, Europe, Australia, New Zealand, and Japan. Dan has received the Scott Medal, the Liberty Hyde Bailey Award and the Veitch Memorial Medal, among other awards. Founder of the original Heronswood Nursery, he now brings his expertise to Monrovia Growers, as well as to several design firms, including Gustafson Guthrie Nichol, Portico, and the Berger Partnership, where he serves as a horticultural consultant.\n\nBorn and raised in Mobile, Alabama, Barbara Pleasant is a four-time winner of Garden Globe awards from the Garden Writers Association and her 2010 article on organic pest control recently won a FOLIO Eddie award. She has written numerous books on a wide range of subjects from vegetables to weeds. Her newest book, Starter Vegetable Gardens, presents a compelling argument for growing a beautiful, productive garden filled with vegetables and herbs. Barbara is also a contributing editor for Mother Earth News, for which she has written the top-rated “Gardening Know-How” column for several years.	2012-04-11 17:55:21.993693-04	2012-05-30 16:10:32.186285-04	2012-04-14 08:00:00-04	2012-04-14 16:30:00-04	f		398		t	img/e/m92HLs.jpg
13	Lorraine Vullo- Studio Sale	After more than 30 years of making art, it's time for me to thin the herd by having a studio sale. I have many lovely images tucked away in boxes, closets and a large storage locker. They have been kept in the dark for far too many years. I would love for them to "see the light" and fill as many spaces as possible. Please stop by Pittsburgh Filmmakers starting Friday April 13th through Sunday April 15th. Pieces will be marked down significantly from earlier prices.\n\n\nHours:\nFriday, April 13th: 4 - 9pm\nSaturday, April 14th: 10am - 5pm\nSunday, April 15th: 12 - 5pm	2012-04-11 17:55:24.15096-04	2012-05-30 16:10:32.480697-04	2012-04-13 16:00:00-04	2012-04-15 17:00:00-04	f		214		t	img/e/y7Y8hP.jpg
14	Everything is Terrible Presents: DoggieWoggiez! PoochieWoochiez!	The artist collective known as “Everything is Terrible!” has made a career out of re-editing found VHS footage, then unleashing it on the Internet. Hip, hilarious, and out-there, the group's newest feature is not only made entirely from dog-related footage, it's been re-configured into a version of Jodorowsky's Holy Mountain, a cult film from 1973. Touring the US with a whacky performance component as well (guys in furry costumes) we guarantee this will be a one-of-a-kind experience. Tickets $10	2012-04-11 17:55:25.030839-04	2012-05-30 16:10:32.526181-04	2012-04-02 20:00:00-04	2012-04-02 23:00:00-04	f		\N	Melwood Screening Room	t	img/e/drZqAz.jpg
15	Starbucks Petites 2 for $2	Starbucks Petites are just the right amount of delicious.  From April 9 – 22 get 2 for $2 at participating stores. \n\nStarbucks Petites are just the right size for those moments when you need a little something sweet, delivering a whopping bite of satisfaction. The Brown Sugar Walnut Tart, Cherry Pie and Raspberry Truffle Cake Pop Petite – we have a treat for every sweet craving.	2012-04-11 17:55:37.841576-04	2012-05-30 16:10:32.592156-04	2012-04-09 05:00:00-04	2012-04-22 22:00:00-04	f		\N	Your Local Starbucks	t	img/e/0IALur.jpg
16	Global Month of Service 2012	By working together, we can create positive change in our own communities and around the world. Join us in reaching our goal of 1 million community service hours per year by 2015.  Every hour can make an enormous difference. Find a local project and sign up to volunteer with us today! http://community.starbucks.com	2012-04-11 17:55:38.519625-04	2012-05-30 16:10:32.672342-04	2012-04-01 00:00:00-04	2012-04-30 23:30:00-04	f		\N	Your neighborhood	t	img/e/glnlRE.jpg
17	SUBWAY® on The Pitch	How’s this for a pitch?  The series premiere isn’t until Sunday, April 30, but you can watch the SUBWAY® episode of The Pitch online right now!  Sneak a peek of top ad agencies battling it out in a delicious drama.\n\nGo to http://www.youtube.com/playlist?list=PL1B90C26310B64FFA&feature=plcp to watch.	2012-04-11 17:55:41.523473-04	2012-05-30 16:10:32.765985-04	2012-04-30 22:00:00-04	2012-04-30 23:00:00-04	f		\N	On AMC	t	img/e/ZGqqyH.jpg
18	SUBWAY® on The Pitch	How would you advertise SUBWAY®?  Tune in to watch two ad agencies compete to answer that question, and catch SUBWAY® in a special preview of the new series The Pitch on AMC, Sunday April 8th.  Why not get creative yourself and build your favorite SUBWAY® sub for the occasion?!	2012-04-11 17:55:42.186119-04	2012-05-30 16:10:32.871359-04	2012-04-08 23:00:00-04	2012-04-09 01:00:00-04	f		\N	On AMC	t	img/e/At_qMf.jpg
19	Buy One Get One FREE	Come in before 9AM and get a FREE 6” sandwich of your choice when you buy any 6” sandwich, this April only. From the toasty Steak, Egg & Cheese to the tender Turkey Breast. That’s right, buy one get one FREE. Hurry in by 9AM to score YOUR FREE sandwich.	2012-04-11 17:55:42.767719-04	2012-05-30 16:10:32.986269-04	2012-04-01 07:00:00-04	2012-04-30 09:00:00-04	f		\N	Participating U.S. SUBWAY® restaurants	t	img/e/wFLXl0.jpg
32	Secret Sale	Special sales announced every hour from 11-3.\r\nGift basket give away each hour during the event.\r\nGourmet food samples.\r\nRepresentatives from your favorite vendors available to help you find the perfect gift for Mother's Day.	2012-05-01 16:53:29.346213-04	2012-05-01 16:53:29.499745-04	2012-05-11 11:00:00-04	2012-05-11 15:00:00-04	f	http://www.facebook.com/maggieandstellas	7		t	
31	Carnegie Knits & Reads 	Whether you love to knit or want to learn, join us for informal knitting sessions. Knitters of all levels are welcome to come work on their own projects. Or bring your own yarn and needles and we’ll help you get started. We’ll learn from each other and learn why the Library is a great place to knit!	2012-04-30 15:19:41.212815-04	2012-04-30 15:19:41.77716-04	2012-05-02 16:30:00-04	2012-05-02 17:30:00-04	f		195		t	img/e/knit.jpg
65	Lunchtime Music at the Plaza!	Enjoy free live music under the tent from 12:00 to 2:00 p.m. on select weekdays April-October!\r\n\r\nThursday, May 17\r\nTuesday, May 22\r\nThursday, May 24\r\nTuesday, May 29\r\nThursday, May 31	2012-05-17 08:32:45.30083-04	2012-05-17 08:32:45.300863-04	2012-05-22 12:00:00-04	2012-05-22 14:00:00-04	f	http://www.pittsburghparks.org/plaza-music	412		t	img/e/Schenley_Plaza_1.JPG
33	Celebrating Scenable!	Get a Shamballa Bracelet for 50% Off!\r\nCelebrate something new with Scenable Oakland,\r\njust mention you saw the event.	2012-05-02 10:13:41.345534-04	2012-05-02 10:14:34.161218-04	2012-05-02 00:00:00-04	2012-05-04 00:00:00-04	f	http://touchofgoldandsilverjewelrystore.com/	404		t	img/e/Shamballa-bracelet.jpg
67	Lunchtime Music at the Plaza!	Enjoy free live music under the tent from 12:00 to 2:00 p.m. on select weekdays April-October!\r\n\r\nThursday, May 17\r\nTuesday, May 22\r\nThursday, May 24\r\nTuesday, May 29\r\nThursday, May 31	2012-05-17 08:34:46.063051-04	2012-05-17 08:34:46.063091-04	2012-05-29 12:00:00-04	2012-05-29 14:00:00-04	f	http://www.pittsburghparks.org/plaza-music	412		t	img/e/Schenley_Plaza_3.JPG
80	Taste of Oakland	Oaklands' annual, eat and shop event!\r\n$5.00 gets you loads of food.\r\nTouch of Gold and Silver will be featuring Dave and Andys ice cream. Enter to win a Shamballa bracelet of your choice!	2012-05-17 17:27:39.363079-04	2012-05-17 17:30:10.018551-04	2012-05-19 11:05:00-04	2012-05-19 15:30:00-04	f	http://www.touchofgoldandsilverjewelrystore.com/	404		t	img/e/LOGO_003.JPG
44	Prosaic disasters	Porter Hall Room 100\r\n\r\nThe Distinguished Lecture Series in Environmental Science, Technology, and Policy:\r\nHuman Dimensions of Technology\r\n\r\nDr. Charles Perrow is Professor Emeritus, Yale University\r\n\r\nReviewing a number of recent catastrophes discloses similar scripts of regulatory failures, unheeded warnings, bumbling responses, cover-ups, and little learning. Complexity and tight coupling set the stage for many failures, but production pressures and cost cutting creates the fuel, and prosaic, commonplace errors provide the spark. I will amble through the disaster landscape, which includes our economic meltdown, but Fukushima is the poster child of what should never have been built.\r\n\r\nCharles Perrow is a Research Scholar and Emeritus Professor of Sociology at Yale University, and Visiting Professor at Stanford. The author of several books and many articles on organizations, he is primarily concerned with the impact of large organizations on society (Organizing America: Wealth, Power, and the Origins of Corporate Capitalism, 2001), and their catastrophic potentials (Normal Accidents: Living with High-Risk Technologies 1999). His current interests are in the vulnerabilities of the country’s critical infrastructures to natural, industrial, and deliberate disasters, covered in The Next Catastrophe: Reducing Our Vulnerabilities to Natural, Industrial, and Terrorist Disasters. The 2007 edition is updated in a 2011 edition covering the 2008 economic meltdown, the 2010 Gulf oil spill, and the ongoing global warming.\r\n\r\nhttp://www.cmu.edu/uls/may/perrow.html	2012-05-02 17:46:35.273988-04	2012-05-02 18:14:01.876824-04	2012-05-03 16:30:00-04	2012-05-03 17:50:00-04	f	http://www.cmu.edu/uls/may/perrow.html	289		t	img/e/CMU_Logo.jpg
22	Graduation Central	It's "Grad Central" time again! Graduating students will be able to purchase academic regalia, general graduation announcements, class rings, and diploma frames and covers.\n\nGraduation Central is sponsored by the Pitt Alumni Association in conjunction with The Book Center and the Office of Special Events	2012-04-11 17:55:54.324262-04	2012-05-30 16:10:33.270909-04	2012-04-11 11:00:00-04	2012-04-11 19:00:00-04	f		400		t	img/e/ICLY4k.jpg
23	Consolidation Building Dedication	A mission advanced. A legacy honored. A promise kept.\n\nIntroducing the new standard in comprehensive, Veteran-focused care. Please join us on May 2 at 11 a.m. as we ceremoniously cut the ribbon for our Consolidation Building on our University Drive campus.\n\nCheck out our website for building details and a photo slideshow:\nwww.pittsburgh.va.gov/construction/UniversityDrive.asp\n\nWhen programming GPS for directions, use the following information:\nBrackenridge St. & Allequippa St., Pittsburgh, PA 15219	2012-04-11 17:55:56.134932-04	2012-05-30 16:10:33.432717-04	2012-05-02 11:00:00-04	2012-05-02 12:30:00-04	f		232		t	img/e/VikfI7.jpg
24	Wounded Warrior Amputee Softball game	Wounded Warrior Amputee Softball team vs. State Correctional Institution Greene Softball team.\r\n\r\nAdults - $20 | Children 12 and under - $5\r\nAll proceeds go directly to the team. To get tickets, go to www.woundedwarriorssoftball.com or call 412-835-7387.\r\n\r\nFood and beverages can be purchased at the concession stand. Limited bleacher seats are available. Bring your lawn chairs and blankets for field seating.\r\n\r\nFor more information about the team, visit www.woundedwarrioramputeesoftballteam.org.	2012-04-11 17:55:57.81392-04	2012-05-30 16:13:11.733748-04	2012-04-21 13:30:00-04	2012-04-21 16:00:00-04	f		401		f	img/e/32dRyd.jpg
26	Meet the VA: AmVets Post 103	Our Outreach team will be at the AmVets Post 103 to answer your VA health care and benefits questions. We'll be set up to help you enroll and get your photo ID plus we'll be doing blood pressure and blood sugar checks.	2012-04-11 17:55:59.74224-04	2012-05-30 16:12:28.555995-04	2012-04-14 10:00:00-04	2012-04-14 14:00:00-04	f		403		f	img/e/skYbFm.jpg
25	Veterans Employment Outreach Day	Veterans are invited to attend presentations and individual information sessions on civil service employment opportunities with the Commonwealth of Pennsylvania.\r\n\r\nMake sure to bring your resume, transcripts and DD214! There is free parking on 8-Perryville Bus Line.\r\n\r\nVA Pittsburgh's Outreach team will also be on hand to answer questions about VA benefits and health care services.\r\n\r\nQuestions? Call 412-565-7666 or visit the Commission's website at www.scsc.state.pa.us	2012-04-11 17:55:58.731221-04	2012-05-30 16:12:41.939738-04	2012-04-20 09:00:00-04	2012-04-20 14:30:00-04	f		402		f	img/e/2WpTpE.png
45	"Doing" Politics w/ Poetry 	Forum discussion w/ Emily Carlson, Josh Zelesnick, Vanessa German, & Sten Carlson. Part of the International Socialist Organization's First Thursday Forums. 	2012-05-02 19:19:52.81957-04	2012-05-02 19:19:52.8196-04	2012-05-03 19:30:00-04	2012-05-03 20:30:35-04	f	http://isopittsburgh.blogspot.com/	\N		t	
38	Exhibition Reception: The Antiquarian Avant-Garde	Class Exhibition\r\nOn view Apr 30th - May 7th\r\nwww.cmu.edu/theframe	2012-05-02 17:46:31.443818-04	2012-05-02 18:27:26.380878-04	2012-05-04 19:00:00-04	2012-05-04 22:00:00-04	f	http://www.cmu.edu/theframe/	407		t	img/e/CMU_Logo_2.jpg
37	Exhibition Reception: Re-Thinking Suburbia	On view May 7th - May 14th\r\nnew work by Sarah Keeling	2012-05-02 17:46:31.389894-04	2012-05-02 18:30:41.016379-04	2012-05-07 19:00:00-04	2012-05-14 22:00:00-04	f	http://www.cmu.edu/theframe/	407	The FRAME	t	img/e/CMU_Logo_3.jpg
46	Oakland Alive! Pittsburgh Marathon Party!	The runners start coming through Oakland around 8:00 and usually wrap up by 10:30 or so.  If you’re looking for a great cheering spot, we’ll be stationed at the corner of Forbes Avenue and McKee with hot coffee and pastries to help your cheering!  (There will also be free pom poms and tshirts!).	2012-05-02 20:03:59.921912-04	2012-05-02 20:04:43.517328-04	2012-05-06 08:00:00-04	2012-05-06 10:30:00-04	f		408		t	img/e/Oakland_Abbey_Road.jpg
48	Carnegie Mellon Philharmonic	Comprised of gifted students from Carnegie-Mellon University, this orchestra performs an evening of impressive classical music.\r\n\r\nThe program includes American composer Samuel Barber's "Concerto For Violin & Orchestra"; Swiss composer Arthur Honegger's "Pacific 231"; Swiss composer Frank Martin's "Concerto For 7 Winds, Strings & Percussion" and Czech composer Bohuslav Martinu's "Frescoes Of Piero della Francesca".\r\n\r\nGeneral admission is $5 and $4 for students and seniors with ID. For Tickets, call ShowClix at (888) 718-4253.\r\n\r\nRead more: http://old.post-gazette.com/events/default.asp?mode=4&id=58#ixzz1tlEToBkV\r\n	2012-05-02 20:12:32.949105-04	2012-05-02 20:12:32.949136-04	2012-05-03 20:00:00-04	2012-05-03 22:00:00-04	f		197		t	img/e/CMU_Logo_4.jpg
49	Entrepreneurship For Job Seekers & Career Change	James Merante, the owner of Padgett Business Services, will speak about entrepreneurship for job seekers and career changers.\r\n\r\nFor more information, call the library's Job & Career Education Center at (412) 622-3167.\r\n\r\nRead more: http://old.post-gazette.com/events/default.asp?mode=4&id=58#ixzz1tlF0OR35\r\n	2012-05-02 20:14:51.874543-04	2012-05-02 20:14:51.874579-04	2012-05-05 13:00:00-04	2012-05-05 14:00:00-04	f		195		t	img/e/157989_73877691965_505892_n.jpg
66	Lunchtime Music at the Plaza!	Enjoy free live music under the tent from 12:00 to 2:00 p.m. on select weekdays April-October!\r\n\r\nThursday, May 17\r\nTuesday, May 22\r\nThursday, May 24\r\nTuesday, May 29\r\nThursday, May 31	2012-05-17 08:33:39.456002-04	2012-05-17 08:33:39.456035-04	2012-05-24 12:00:00-04	2012-05-24 14:00:00-04	f	http://www.pittsburghparks.org/plaza-music	412		t	img/e/Schenley_Plaza_2.JPG
68	Lunchtime Music at the Plaza!	Enjoy free live music under the tent from 12:00 to 2:00 p.m. on select weekdays April-October!\r\n\r\nThursday, May 17\r\nTuesday, May 22\r\nThursday, May 24\r\nTuesday, May 29\r\nThursday, May 31	2012-05-17 08:35:33.024862-04	2012-05-17 08:35:33.024897-04	2012-05-31 12:00:00-04	2012-05-31 14:00:00-04	f	http://www.pittsburghparks.org/plaza-music	412		t	img/e/Schenley_Plaza_4.JPG
69	WYEP's 15th Annual Summer Music Festival at Schenley Plaza	Join us for the 15th Annual Summer Music Festival at Schenley Plaza, a night of free, live performances that’s open to everyone.\r\n\r\nPerforming this year are:\r\nDonora\r\nGreat Lake Swimmers\r\nSharon Van Etten\r\nDr. Dog\r\n\r\nGrab a blanket and enjoy live music on the lawn at Schenley Plaza as we kick off the summer of outdoor performances.\r\n\r\nThis year’s event features a kids' area and I Made It! Market.\r\n\r\nPerformances start at 6pm; Kids and Crafters Area starts at 4pm.\r\n\r\nMore info on our website: http://www.wyep.org/smf2012	2012-05-17 08:37:59.724514-04	2012-05-17 08:37:59.724556-04	2012-06-22 16:00:00-04	2012-06-22 23:00:00-04	f	https://www.facebook.com/events/267712579991560/	412		t	img/e/Schenley_Plaza_5.JPG
70	M Is For Museum	Designed for kids 5 to 13 years old ---but enjoyable for visitors of all ages --- this exhibition features multimedia and hands-on activities that help curious young audiences discover how museums protect, explore and explain the cultures of the world and nature in all its wonder.\r\n\r\nFor more information, call (412) 622-3131.\r\n\r\nRead more: http://old.post-gazette.com/events/default.asp?mode=3&id=34#ixzz1v89zfqsr\r\n	2012-05-17 08:49:33.969379-04	2012-05-17 08:49:33.969412-04	2011-10-15 10:00:00-04	2012-08-30 20:30:00-04	t	http://old.post-gazette.com/events/default.asp?mode=3&id=34	198		t	
79	Art Museum Day	FREE Admission on the evening of Thursday, May 17 for Art Museum Day! We're open until 8:00. \r\n\r\nCulture Club Happy Hour with Cash bar\r\n5:30 - Discussion on Glenn Ligon with Cave Canem poet Kelli Stevens Kane - CMA Galleries\r\n7:00 - Screening of new Art21 episode featuring Glenn Ligon	2012-05-17 12:49:00.653895-04	2012-05-17 12:53:24.947027-04	2012-05-17 15:30:00-04	2012-05-17 20:00:00-04	f	http://cmoa.org/	196		t	img/e/Degas_Dancers.JPG
81	Impressionism in a New Light	Impressionism in a New Light: From Monet to Stieglitz  presents a robust picture of what Impressionism means in art, displaying paintings, drawings, prints, and pastels by major artists alongside works by many of the most famous Pictorialist photographers of the late 19th and early 20th centuries. 	2012-05-18 10:40:05.889831-04	2012-05-18 10:40:06.342899-04	2012-05-12 10:00:00-04	2012-08-26 17:00:00-04	f	http://www.cmoa.org/	196		t	img/e/Degas_Dancers_1.JPG
50	Who Made Sherlock Holmes A Hit?	Robin Hoffman, a PhD candidate in the English department at the University Of Pittsburgh, discusses how English author Arthur Conan Doyle (1859-1930) and his fictional detective Sherlock Holmes became international sensations.\r\n\r\nPrinting presses worked overtime in late nineteenth-century England, providing both reading matter and suggestions for how to choose among the offerings. Hoffman will connect Doyle's first audience for his Sherlock Homes stories with British reviewers' many published responses. After they helped to spread the detective's fame, contemporary critics also worked to explain his popularity among the reading public of the late Victorian era.\r\n\r\nThis talk is presented in support of the Undershaw Preservation Trust, which is working to save Sir Arthur Conan Doyle's former home in Hindhead, Surrey, United Kingdom. For more information, call (412) 622-3114.\r\n\r\nRead more: http://old.post-gazette.com/events/default.asp?mode=4&id=58#ixzz1tlFUt4Jh\r\n	2012-05-02 20:16:03.469016-04	2012-05-02 20:16:03.469048-04	2012-05-05 15:00:00-04	2012-05-05 16:00:00-04	f		195		t	img/e/157989_73877691965_505892_n_1.jpg
51	Carnegie Science Awards	Join the Carnegie Science Center as they recognize outstanding science and technology achievements in western Pennsylvania.\r\n\r\nThis year's theme is "Science: Does the Media Get It Right?" The theme celebrates the courage of the human spirit thriving through adversity to reach the summits of our ambitions. It highlights the role science plays in challenging assumptions and overcoming obstacles to reach the unreachable, to attain the unattainable and to realize what was once thought impossible.\r\n\r\nSince 1997, the Carnegie Science Awards have celebrated the accomplishments of more than 300 individuals and organizations. For more information, call (412) 237-3400.\r\n\r\nRead more: http://old.post-gazette.com/events/default.asp#ixzz1tlFt6TBB\r\n	2012-05-02 20:20:17.924336-04	2012-05-02 20:20:17.92437-04	2012-05-11 18:30:00-04	2012-05-11 20:30:00-04	f		197		t	img/e/music_hall.jpg
52	"Doing" Politics w/ Poetry 	Forum discussion w/ Emily Carlson, Josh Zelesnick, Vanessa German, & Sten Carlson. Part of the International Socialist Organization's First Thursday Forums. 	2012-05-02 20:27:28.366365-04	2012-05-02 20:27:45.052366-04	2012-05-03 21:30:00-04	2012-05-03 22:30:00-04	f		409		t	img/e/HouseFront.png
53	Free Comic Book Day 	May 5th is the annual Free Comic Book Day nationwide. Here at Phantom we will have a bunch of extra free comics from our warehouse to give away in addition to the free books that are part of this years giveaway. We'll also be having some special sales and discounts, to be announced.\r\n\r\nSpecial guests include artist Dave Wachter, who will be here doing sketches and promoting his upcoming IDW comic, Night of 1000 Wolves.\r\n\r\nAlso appearing and signing autographs will be David Fielding, the actor who portrayed and voiced the original Zordon from the Mighty Morphin' Power Rangers!\r\n\r\nWe're open until 7, but the free books go pretty fast, and our guests won't hang out all day either, so get here early. There will probably be more to announce, so stay tuned.\r\n	2012-05-02 20:32:20.073641-04	2012-05-02 20:32:20.073675-04	2012-05-05 10:00:00-04	2012-05-05 19:00:00-04	f	https://www.facebook.com/events/218906918216068/	241		t	img/e/Comic_Book.jpg
55	Armadillos	This regional band performs fun, upbeat and danceable original folk/country that gives old time Americana a new, modern feel.\r\n\r\nAdmission is free. For more information, call (412) 622-3151.\r\n\r\nRead more: http://old.post-gazette.com/events/default.asp#ixzz1tljHN8BQ	2012-05-02 22:15:10.356005-04	2012-05-02 22:15:10.356038-04	2012-05-13 12:00:00-04	2012-05-13 03:00:00-04	f		195		t	
54	All Out Gaming	Teens are welcome to have fun playing a variety of board games and video games while making new friends.\r\n\r\nFor more information, call (412) 622-3121.\r\n\r\nRead more: http://old.post-gazette.com/events/default.asp?mode=4&id=58#ixzz1tli37oHk	2012-05-02 22:13:03.881738-04	2012-05-03 12:57:42.543231-04	2012-05-10 15:00:00-04	2012-05-10 17:00:00-04	f		195		t	img/e/images.jpg
62	Discovery Garden Day	Bring the whole family and join us in the Children's Discovery Garden to dig in the dirt and get planting as you learn about gardens and the critters who call them home. Activities include games, hands-on crafts, storytelling, and more.	2012-05-12 11:00:26.352996-04	2012-05-12 11:00:26.353028-04	2012-05-26 11:00:00-04	2012-05-26 16:00:00-04	f	http://phipps.conservatory.org/exhibits-and-events/events-calendar.aspx#tab1	230		t	img/e/Disc._Garden_Image.jpg
56	A Taste of Oakland presented by Hurley Associates, Hurley Insurance Brokers! Ticket Site 2!	A Taste of Oakland is a chance to spend a Saturday browsing the eclectic shops of Oakland while sampling our neighborhood’s delicious restaurant menus.  A Taste of Oakland is the signature event of the Oakland Business Improvement District.\r\n\r\nTickets?\r\nPick up your $5 Admission during the event at one of these locations during the event:\r\n\r\n- Parklet on the corner of Forbes Avenue and Bouquet Streets\r\n- Hilton Garden Inn University Place, 3454 Forbes Avenue\r\n\r\nOther Details:\r\n\r\nYour admission to A Taste of Oakland also grants you the following benefits:\r\n\r\n- Free Carousel Rides in Schenley Plaza\r\n- Free admission to the Carnegie Museums of Art and Natural History\r\n\r\nFor a list of all the restaurants participating check out http://atasteofoakland.wordpress.com/restaurants/	2012-05-03 11:38:44.693035-04	2012-05-03 11:40:26.164235-04	2012-05-19 11:30:00-04	2012-05-19 15:30:00-04	f	http://atasteofoakland.wordpress.com/	411		t	img/e/157904_414026435290572_113862470_n.jpg
57	St. Nicholas' Greek Food Festival (May 6-12)	Mark your calendars for our Annual Spring Greek Food Festival May 6-12, 2012 Join us for 7 fulls days of traditional Greek music and lively Greek dancing!\r\n\r\nFestival Hours:\r\nServing Hours TBD\r\nLive Bouzouki Music\r\nGreek Dancing Every Evening\r\nOutdoor Patio Grill\r\nFood Certificates Available\r\nConvenient ATM Machine on Premises\r\nCathedral Tours Daily	2012-05-03 19:35:33.158289-04	2012-05-07 09:33:45.832538-04	2012-05-06 11:00:00-04	2012-05-12 18:00:00-04	f	http://www.stnickspgh.org/GreekFood.html	192		t	
58	Light, Code, and Technology: Photography in the 21st Century   	Speaker: \tLori Hepner\r\nHost: \tCharles Glassmire\r\nDate: \tMay 06, 2012 1:15 PM - 3:15 PM\r\nURL: \thttp://www.digitalimagers.org/speakers/HepnerLori.htm\r\nLocation: \tRoom 1102, Scaife Hall, University of Pittsburgh\r\nDetail: \t\r\n\r\nDigital Imagers Speaker Series: Sunday May 6, 2012, 1:15 PM, room 1102 Scaife Hall on the Pitt campus.\r\n\r\nLori Hepner will speak on:\r\n\r\nLight, Code, and Technology: Photography in the 21st Century\r\nLori Hepner is an interdisciplinary artist working primarily in conceptually based fine art photography and photo installations. See the writeup about Lori's Twitter Portraits  in Time magazine: http://lightbox.time.com/2011/08/26/data-visualization-twitter-portraits-by-lori-hepner\r\n\r\nAbstract/Bio: http://www.digitalimagers.org/speakers/HepnerLori.htm\r\n\r\nFor more information about the Digital Imagers group, see http://www.digitalimagers.org/	2012-05-05 10:31:41.992805-04	2012-05-05 10:31:41.992842-04	2012-05-06 13:15:00-04	2012-05-06 15:15:00-04	f	http://halley.exp.sis.pitt.edu/comet/presentColloquium.do?col_id=3393	307		t	img/e/Pitt.jpg
59	The War on Cancer: The Next Forty Years   	Speaker: \tNancy E. Davidson\r\nHillman Chair in Oncology, School of Medicine\r\nSponsor: \tUniversity of Pittsburgh\r\nSeries: \tUniversity of Pittsburgh Inaugural Lectures\r\nDate: \tMay 10, 2012 4:00 PM - 5:00 PM\r\nURL: \thttp://www.universityannouncements.pitt.edu/davidson.pdf\r\nLocation: \tScaife Hall Lecture Room 6\r\nDetail: \t\r\n\r\nInaugural lecture of Nancy E. Davidson as Hillman Chair in Oncology\r\n\r\nNancy E. Davidson, MD, is internationally renowned for her research involving breast cancer. Prior to joining the University of Pittsburgh Cancer Institute and UPMC Cancer Centers, she served as director of the Johns Hopkins Kimmel Cancer Center’s Breast Cancer Program in Baltimore and as professor of oncology at Johns Hopkins School of Medicine. She also held the Breast Cancer Research Chair in Oncology, with a joint appointment in the Department of Biochemistry and Molecular Biology.\r\n\r\nDr. Davidson has published key findings on the role of hormones, particularly estrogen, on gene expression and cell growth in breast cancer. She has guided several important national clinical trials of potential new therapies, including chemoendocrine therapy for premenopausal breast cancer and antiangiogenesis therapy for advanced disease.\r\n\r\nDr. Davidson received her bachelor’s degree from Wellesley College and medical degree from Harvard Medical School. She completed a residency in internal medicine at Johns Hopkins Hospital and a fellowship at the National Cancer Institute. Dr. Davidson recently served as president of the American Society of Clinical Oncology and is a member of the scientific advisory board of numerous foundations. She has received many awards, including the Brinker International Award for Breast Cancer Research.	2012-05-06 19:07:54.755004-04	2012-05-06 19:07:54.755038-04	2012-05-10 16:00:00-04	2012-05-10 17:00:00-04	f	http://halley.exp.sis.pitt.edu/comet/presentColloquium.do?col_id=3396	307		t	img/e/Pitt_1.jpg
47	Maya Lin - Through May 13th!	This exhibition showcases the work of acclaimed artist Maya Lin, best known for designing the Vietnam Veterans Memorial in Washington DC.\r\n\r\nMaya Lin’s work embraces architecture, sculpture, nature and ecology, taking a truly original approach to landscape. The spare yet powerful works on view are imaginative re-creations of natural forms transformed into objects of contemplation. These sculptures and drawings are both beautiful in their own right and provide surprising glimpses into aspects of nature --- such as geographic forms, rivers and inland seas—that remain otherwise unseen. Ranging from room-sized installations evoking mountainous topography to delicate wall installations of silver pins tracing the flow of American rivers, Lin’s works evoke her own unique experience of the environment while encouraging visitors to consider the physicality of the world in which we live and our sympathetic existence with nature.\r\n\r\nFor more information, call (412) 622-3131.\r\n\r\nRead more: http://old.post-gazette.com/events/default.asp?mode=4&id=58#ixzz1tlDgsu6U\r\n	2012-05-02 20:10:36.327027-04	2012-05-07 09:33:16.359975-04	2012-05-02 12:00:00-04	2012-05-13 18:00:00-04	t		196		t	
60	30 years of lung cancer research: How far have we come?   	Speaker: \tJill M. Siegfried\r\nSchool of Medicine, University of Pittsburgh\r\nSponsor: \tUniversity of Pittsburgh\r\nSeries: \tUniversity of Pittsburgh Inaugural Lectures\r\nDate: \tMay 22, 2012 4:00 PM - 5:00 PM\r\nURL: \thttp://www.universityannouncements.pitt.edu/siegfried.pdf\r\nLocation: \tScaife Hall Lecture Room 6\r\nDetail: \t\r\n\r\nInaugural lecture of Jill M. Siegfried as UPMC Endowed Chair in Lung Cancer Research.\r\n\r\nDr. Siegfried investigates the role of growth factors and hormones in the development and growth of human lung cancer. The laboratory focuses on the effects of these cytokines on activation of cell signaling pathways and control of tumor growth, as well as their role in risk for cancer. Growth factors and their receptors currently under investigation include estrogen and its receptors and hepatocyte growth factor and its receptor, c-Met. Growth factors and hormones are also being investigated as possible therapeutic targets and diagnostic or prognostic indicators for lung cancer. Hepatocyte growth factor has been found to be a strong negative prognostic indicator for non-small cell lung cancer, and expression of the enzyme aromatase that mediates estrogen production has also been linked to poor outcome in women with lung cancer. Circulating growth factor levels may also correlate with active cancer. These studies are directed toward development of new methods to identify undetected lung cancer and new therapeutic strategies through increased knowledge of growth-regulatory processes in lung cancer cells.	2012-05-06 19:09:12.851169-04	2012-05-07 09:34:25.329657-04	2012-05-22 16:00:00-04	2012-05-22 17:00:00-04	f	http://halley.exp.sis.pitt.edu/comet/presentColloquium.do?col_id=3397	307		t	img/e/Pitt_2.jpg
61	May Market	On May 11 and 12, we will once again transform our historic and organically-managed front lawn into a bustling May Market, where our horticulturists, local garden clubs, nurseries and farms, and other vendors come together each year to offer a wide selection of plants and accessories. Happening just in time for Mother’s Day, the event also presents an opportunity for you to explore Summer Flower Show at half the price.\r\n\r\nAmong the treasures that you will discover at the 2012 May Market are organic herbs and vegetable seedlings; tropicals and succulents; low-maintenance perennials and shrubs on Phipps’ Top 10 Sustainable Plant Lists; native and rain garden plants; and many other seasonal favorites. Also available will be everything from organic soil and garden tool-sharpening services to botanical art and natural body care products. As always, our staff and Master Gardeners will be on hand to offer advice, and our ever-popular hand-dipped fondant strawberries will be back to tempt you, too. And, from 9:30 a.m. to 11:30 a.m. on both days, Pittsburgh Post-Gazette garden writer Doug Oster will be on hand to share tips.\r\n\r\nDuring May Market hours, you can also receive half off the regular price of Conservatory admission for a chance to experience Summer Flower Show: Fountains of Youth. Featuring healing botanicals, striking color combinations and rejuvenating water displays, Phipps’ invigorating new exhibit is the perfect complement to a day of shopping out in the open air. Café Phipps—our Green Restaurant Certified eatery offering fresh, local and organic foods—will be open for lunch both days as well.\r\n\r\nMay Market, which runs from 9:30 a.m. to 7 p.m. on May 11 and 9:30 a.m. to 5 p.m. on May 12, is free and open to the public.\r\n\r\n2012 Vendors\r\n\r\nAlways Summer Herbs\r\nBartsch Greenhouse and Nursery\r\nCafe Phipps\r\nChapel Hill Antiques and Gifts\r\nCharmed by Nature\r\nCoulson Slate Accents\r\nCynthia Grant\r\nDaffodil and Hosta Society\r\nFlorence Smith\r\nFriendship Farm\r\nGarden Dreams\r\nGoose Creek Farms\r\nGrow Pittsburgh\r\nGutter Helmet\r\nHess Landscaping\r\nIris and Daylily Society\r\nKridler Gardens\r\nLambs Ear Farm\r\nLinden Garden Club\r\nMen's Garden Club\r\nMosaic Mitzi\r\nMulberry Creek Farm\r\nNine Mile Run Watershed\r\nOrganic Mechanics\r\nPam Werner\r\nPaula Nettleship\r\nPenn Hills Lawn and Garden\r\nPhipps Tropicals, Perennials and Shrubs\r\nProspect Berry Farms\r\nPucker Brush Farms\r\nRenewal by Andersen\r\nRoad to the Lakehouse\r\nRockledge Garden Club\r\nSand Hill Berries\r\nSeeders and Weeders Garden Club\r\nStem Flower Jewelry\r\nStephanie Spingola \r\nSylvania Natives\r\nTastefully Simple\r\nUna Biologicals\r\nWhimsical Wonders\r\nWhitehall Green Thumbers\r\nWho Cooks for You Farm\r\nWindow Box Garden Club	2012-05-12 10:22:49.988326-04	2012-05-12 10:22:49.988359-04	2012-05-12 09:30:00-04	2012-05-13 17:00:00-04	f	http://phipps.conservatory.org/exhibits-and-events/featured-event.aspx?eventid=320	230		t	img/e/May_Market_Left-PS.jpg
63	Pittsburgh International Children's Festival	Pittsburgh International Children’s Festival opens the door for children to experience professional performing arts. Our vision is to present and promote professional programming for children which inspires, challenges, educates, and stimulate respect for and understanding of all cultures in an entertaining and enlightening way. The organization provides diverse programming which introduces young people to other ways of viewing the world around them. Vital to achieving our mission is making the season affordable and accessible for young families.\r\n\r\nPittsburgh International Children’s Festival is presented by Pittsburgh International Children’s Theater, a division of The Pittsburgh Cultural Trust.	2012-05-16 10:54:04.154104-04	2012-05-16 10:54:04.15414-04	2012-05-16 10:47:41-04	2012-05-20 18:00:00-04	f	http://www.pghkids.org/	412		t	img/e/Childrens_Festival.jpg
64	Lunchtime Music at the Plaza!	Enjoy free live music under the tent from 12:00 to 2:00 p.m. on select weekdays April-October!\r\n\r\nThursday, May 17\r\nTuesday, May 22\r\nThursday, May 24\r\nTuesday, May 29\r\nThursday, May 31	2012-05-17 08:31:36.036284-04	2012-05-17 08:31:36.036325-04	2012-05-17 12:00:00-04	2012-05-17 14:00:00-04	f	http://www.pittsburghparks.org/plaza-music	412		t	img/e/Schenley_Plaza.JPG
71	The Thousand & One Nights	On display is French artist Henri Matisse’s (1869-1954) famous "The Thousand & One Nights", a multi-panel, painted paper cut-out that was created when the artist was 81 and confined to his bed.\r\n\r\nUnable to sleep and kept alive by his drive to create, Matisse had much in common with Scheherazade, the legendary narrator of the Persian literary classic "Arabian Nights". Scheherazade saves her own life from a vengeful king by enthralling him with a story that she always interrupts at a moment of suspense just after dawn, ensuring her survival through 1,001 nights. Like her tales, "The Thousand & One Nights" is a work rich in fantastical imagery and symbolism created during many sleepless, difficult hours.\r\n\r\nFor more information, call (412) 622-3131\r\n\r\nRead more: http://old.post-gazette.com/events/default.asp?mode=3&id=33#ixzz1v8B669q3\r\n	2012-05-17 08:52:12.48507-04	2012-05-17 08:52:12.4851-04	2012-04-07 10:00:00-04	2012-07-15 20:00:00-04	f	http://old.post-gazette.com/events/default.asp?mode=3&id=33	196		t	img/e/188154_38014611787_6126162_n.jpg
72	Books In The Afternoon	Meet in the library's Large Print Room to discuss "Please Look After Mom" by Kyung-sook Shin.\r\n\r\n"Please Look After Mom" is the story of a missing mother and her family, told from the shifting points of view of each of the family members.\r\n\r\nFor more information, call (412) 622-3151\r\n\r\nRead more: http://old.post-gazette.com/events/default.asp?mode=3&id=13#ixzz1v8EyGQnB\r\n	2012-05-17 09:09:36.112296-04	2012-05-17 09:09:36.112326-04	2012-05-17 13:00:00-04	2012-05-17 14:00:00-04	f	http://old.post-gazette.com/events/default.asp?mode=3&id=13	195		t	img/e/157989_73877691965_505892_n_2.jpg
73	Saluting Service 	Twenty-three veterans making a difference through service in their Western Pennsylvania communities will be honored at this pre-Memorial Day celebration of all veterans of US military branches.\r\n\r\nOutdoor picnic and entertainment begins at 6:00 p.m. and the indoor program will be held at 7:00 p.m. The program features the Trinity Jazz Orchestra with Adam Brock, American Idol 2012 semi-finalist and Washington, PA, native. Lt. Col. (Ret.) Barry Bridger, who flew more than 70 combat missions over North Vietnam and survived a six-year imprisonment in the infamous "Hanoi Hilton" at the same time as Sen. John McCain, will share his inspirational story. WTAE sportscaster John Meyer, is guest emcee for the event. Soldiers & Sailors 6th Regiment United State Color Troops (USCT) Drum Corps Youth Re-enactors will perform outdoors and lead guests into the hall.\r\n\r\nAdmission is free. Presented by the Financial Planning Association Of Pittsburgh, a leadership and advocacy organization for those who provide, support and benefit from financial planning. For more information, call (412) 653-1054\r\n\r\nRead more: http://old.post-gazette.com/events/default.asp?mode=3&id=111#ixzz1v8Ft5p9Q\r\n	2012-05-17 09:13:16.61062-04	2012-05-17 09:13:16.610654-04	2012-05-22 18:00:00-04	2012-05-22 21:00:00-04	f	http://old.post-gazette.com/events/default.asp?mode=3&id=111	189		t	img/e/Soldiers_and_Sailors.jpg
74	Executive Women's Council Of Pittsburgh Annual Meeting	Join the Executive Women's Council as they honor Deborah Acklin, President of WQED Multimedia, with its first honorary membership at its annual meeting.\r\n\r\nEstablished in 1975, the Executive Women's Council (EWC) promotes the economic and political advancement of leading women in business and the professions within the Pittsburgh region.\r\n\r\nMs. Acklin has served in multiple executive roles in public broadcasting, the cable industry and commercial broadcasting. This honorary membership is given to an individual for her professional achievement, community leadership and commitment to the advancement of women.\r\n\r\nHors d'oeuvres and wine will be served. Tickets are $25 for members and $30 for guests. For more information, visit www.ewcpittsburgh.org\r\n\r\nRead more: http://old.post-gazette.com/events/default.asp?mode=3&id=426#ixzz1v8GqHoXR\r\n	2012-05-17 09:21:05.876692-04	2012-05-17 09:21:05.876724-04	2012-06-05 18:00:00-04	2012-06-05 20:00:00-04	f	http://old.post-gazette.com/events/default.asp?mode=3&id=426	413		t	img/e/WQED.jpg
75	Writers Live: Ron Tanner	Award winning author Ron Tanner shares his memoir "From Animal House To Our House: A Love Story" about his painstaking restoration of an 1897 Queen-Anne style row house in Baltimore.\r\n\r\nThe book recounts the story of buying the 4,500 sq. ft. brownstone with his girlfriend, Jill Eicher, embarking on a complex and demanding restoration, and falling more in love with the house and each other in the process.\r\n\r\nPresented by Pittsburgh Arts & Lectures. For more information, call (412) 622-8866\r\n\r\nRead more: http://old.post-gazette.com/events/default.asp?mode=3&id=13#ixzz1v8IvpoUN\r\n	2012-05-17 09:23:16.261936-04	2012-05-17 09:23:16.26197-04	2012-06-06 18:00:00-04	2012-06-06 20:00:00-04	f	http://old.post-gazette.com/events/default.asp?mode=3&id=13	195		t	img/e/157989_73877691965_505892_n_3.jpg
76	Writers Live: Michael Sims	Author Michael Sims shares his latest release, "The Story Of Charlotte's Web", which tells the story behind one of the best-loved books in America.\r\n\r\nFirst published in 1952, "Charlotte's Web" s a children's novel by American author E. B. White, about a pig named Wilbur who is saved from being slaughtered by an intelligent spider named Charlotte.\r\n\r\nStarting with the childhood influence of his family's farm in Mount Vernon, New York --- where the personalities of the beloved characters Charlotte, Wilbur and Fern were shaped --- Sims traces White's path from a writer for The New Yorker to the places in nature that inspired him to write the beloved American classic.\r\n\r\nPresented by Pittsburgh Arts & Lectures. For more information, call (412) 622-8866\r\n\r\nRead more: http://old.post-gazette.com/events/default.asp#ixzz1v8JMmQru\r\n	2012-05-17 09:24:46.962634-04	2012-05-17 09:24:46.962666-04	2012-06-21 18:00:00-04	2012-06-21 20:00:00-04	f	http://old.post-gazette.com/events/default.asp	195		t	img/e/157989_73877691965_505892_n_4.jpg
77	Soldiers & Sailors Memorial Day Celebration	Spend this special day remembering the men and women who proudly serve or have served in our country's armed forces.\r\n\r\nThere will be ceremonies, tours and other programming.\r\n\r\nAdmission is free. For more information, call (412) 621-4253\r\n\r\nRead more: http://old.post-gazette.com/events/default.asp?mode=3&id=111#ixzz1v8Jhk5Sn\r\n	2012-05-17 09:26:17.263175-04	2012-05-17 09:26:17.263205-04	2012-05-28 10:00:00-04	2012-05-28 18:00:00-04	f	http://old.post-gazette.com/events/default.asp?mode=3&id=111	189		t	img/e/Soldiers_and_Sailors_1.jpg
78	Pittsburgh Take Steps For Crohn’s & Colitis Walk	Lace up your best walking shoes to raise funds and awareness about Crohn's disease and colitis while enjoying the beauty of the university's campus.\r\n\r\nCrohn's Disease is an inflammatory disease that may affect any part of the gastrointestinal causing a wide variety of symptoms. Colitis refers to an inflammation of the colon and is often used to describe an inflammation of the large intestine.\r\n\r\nProceeds benefit the Crohn’s & Colitis Foundation Of America, whose mission is to cure Crohn’s disease and ulcerative colitis and to improve the quality of life of children and adults affected by these digestive diseases. For more information, call Jamie Rhoades at (412) 823-8272\r\n\r\nRead more: http://old.post-gazette.com/events/default.asp?mode=3&id=14#ixzz1v8NRJshi\r\n	2012-05-17 09:41:03.532985-04	2012-05-17 09:41:03.533022-04	2012-06-10 15:00:00-04	2012-06-10 18:00:00-04	f	http://old.post-gazette.com/events/default.asp?mode=3&id=14	217		t	img/e/CMU_Logo_5.jpg
82	Taste of Oakland	Maggie & Stella's is excited to be a host for a new restaurant coming to Oakland in June.  Please join us for food, fun and shopping!	2012-05-18 10:57:01.38901-04	2012-05-18 10:57:01.645799-04	2012-05-19 00:00:00-04	2012-05-19 00:00:00-04	f	http://atasteofoakland.wordpress.com/about/	7		t	img/e/taste.tif
83	Clean Energy Matters	Clean energy matters. Seriously. That's the title of our third hot event for a cool Pittsburgh. We'll be displaying the hottest new technology for renewable energy and hearing from the real live green energy entrepreneurs who will be discussing how the average yinzer can make all our futures brighter by buying and/or installing clean energy.\r\n\r\nOur featured speaker is Andrea Luecke. Ms. Luecke leads The Solar Foundation and is responsible for developing and implementing national educational initiatives and high-level research that promote the widespread adoption of solar energy.\r\n\r\n Additional speakers:\r\n\r\n    Andrea Luecke, Executive Director, The Solar Foundation\r\n    Richard Piacentini, Executive Director, Phipps Conservatory and Botanical Gardens\r\n    Heather Sage, Vice President, PennFuture\r\n    Patrick Sweeney, Vice President Business Development Manager, Pepco Energy Services, to discuss thermal storage and landfill methane recovery\r\n    Frank Bursic, Mid Atlantic Regional Director, Rentricity, to speak about hydrokinetic energy recovery\r\n    Dan Lagiovane, EverPower Wind, to talk about the importance of buying Pennsylvania wind through Choose PA Wind\r\n\r\nAs well as exhibits of all the technologies discussed and information about our local solar industry! \r\n\r\nRegister today!\r\nCost, which includes drinks and hors doeuvres, is $20 for the general public, $15 with student ID, and — you guessed it — free for PennFuture members.\r\n\r\nIf you'd like to attend this event you can purchase tickets online: http://my.pennfuture.org/site/Calendar?id=108981&view=Detail	2012-05-22 13:31:45.114669-04	2012-05-22 13:31:45.114703-04	2012-05-24 18:00:00-04	2012-05-24 21:00:00-04	f	http://my.pennfuture.org/site/Calendar?id=108981&view=Detail	230		t	img/e/Penn_Future.jpg
2	Backyard Coops:  Urban Chicken Farming	Interested in keeping backyard chickens?  Join representatives from the Uniontown Poultry Association and a few of their feathered friends to learn about the ins and outs of chicken coops, feed, local laws, and guidelines.\n\nTuesday, March 20 - 6 pm\nCLP - Brooklne\n\nFriday, March 23 - 1 pm\nCLP - Hill District\n\nSaturday, March 24 - 11 am\nCLP - West End\n\nSaturday, March 24 - 2 pm\nCLP - Knoxville\n\nTuesday, March 27 - 6 pm\nCLP - Lawrenceville\n\nSaturday, March 31 - 1 pm\nCLP - Woods Run\n\nWednesday, April 4 - 5 pm\nCLP - Homewood\n\nThursday, April 5 - 6 pm\nCLP - Squirrel Hill\n\nSaturday, April 7 - 1 pm\nCLP - East Liberty\n\nSaturday, April 14 - 10 am\nCLP - Carrick\n\nSaturday, April 21 - 12 noon\nCLP - Allegheny\n\nSunday, April 22 - 1 pm\nPittsburgh Public Market\n\nAll programs are free and open to the public!	2012-04-11 17:54:30.393749-04	2012-05-30 16:10:30.887172-04	2012-04-22 13:00:00-04	2012-04-22 16:00:00-04	f		\N	city-wide (see details)	t	img/e/G4W7aH.jpg
10	A Taste of Oakland presented by Hurley Associates, Hurley Insurance Brokers! Ticket Site 1!	A Taste of Oakland is a chance to spend a Saturday browsing the eclectic shops of Oakland while sampling our neighborhood’s delicious restaurant menus.  A Taste of Oakland is the signature event of the Oakland Business Improvement District.\r\n\r\nTickets?\r\nPick up your $5 Admission during the event at one of these locations during the event:\r\n\r\n- Parklet on the corner of Forbes Avenue and Bouquet Streets\r\n- Hilton Garden Inn University Place, 3454 Forbes Avenue\r\n\r\nOther Details:\r\n\r\nYour admission to A Taste of Oakland also grants you the following benefits:\r\n\r\n- Free Carousel Rides in Schenley Plaza\r\n- Free admission to the Carnegie Museums of Art and Natural History\r\n\r\nFor a list of all the restaurants participating check out http://atasteofoakland.wordpress.com/restaurants/	2012-04-11 17:55:13.085979-04	2012-05-30 16:10:31.976781-04	2012-05-19 11:30:00-04	2012-05-19 15:30:00-04	f	http://atasteofoakland.wordpress.com/	410		t	img/e/qmCBkZ.jpg
20	Fair an' Lucky, Chris Norman & David Greenberg	Final concert on the 2011-2012 season! Pittsburgh favorites Chris Norman & David Greenberg return with a constellation of Celtic and North American folk music as well as some Baroque tunes. Join us to listen to these stars of pipe and violin as they shine again on the stage of Synod Hall.\n\nDetailed program information and tickets: www.rbsp.org; 412-361-2048	2012-04-11 17:55:46.604525-04	2012-05-30 16:10:33.101921-04	2012-04-21 20:00:00-04	2012-04-21 21:30:00-04	f		\N	Synod Hall, 125 North Craig Street, 15213. Corner of Fifth Ave and N. Craig Streets in Oakland.	t	img/e/OymKIZ.jpg
21	Jam Session with Chris Norman & David Greenberg	EVERYONE IS WELCOME - NO EXPERIENCE NECESSARY\n    FREE, NO REGISTRATION NEEDED\n    COME TO PLAY OR COME TO LISTEN\n    FREE COFFEE BY THE CAFE N' CREAMERY \n    FREE PASTRY COUPONS FOR THE FIRST 50 PEOPLE   \n\nWHAT: play/hear Cape Breton, Scottish & Irish music with two masters of the art form\n\nWHO: instrumentalists, singers, dancers, listeners; anyone familiar with the music  or anyone who wants to give it a try\n\nWHERE: Fellowship Hall, Church of the Ascension\n              4729 Ellsworth Ave, 15213\n              (corner of Ellsworth and Neville St in Oakland)\n\nDETAILS:\n    Chris and David will bring music for those new to playing this music\n    Sponsored by Renaissance and Baroque\n    Coffee and pastries by The Café 'n' Creamery	2012-04-11 17:55:48.417706-04	2012-05-30 16:10:33.227578-04	2012-04-20 20:00:00-04	2012-04-20 22:00:00-04	f		399		t	img/e/wf9yLx.jpg
84	12th Annual Summer Reading Extravaganza	Sunday, June 10, 2012\r\n12 - 5 pm\r\nOn the lawn at CLP - Main, Oakland\r\n\r\nFollow your dreams, Pittsburgh! Imagination and fun await you at Carnegie Library of Pittsburgh's 12th Annual Summer Reading Extravaganza. The moon is up, the stars are out and summer reading is in. Celebrate summer reading with us, and let's dream big together! \r\n\r\nKick off your summer reading with free family fun, including entertainment, crafts and activities for kids and teens! Here's a sample of some of the fun things you'll be able to do at Extravaganza:\r\n\r\n    Watch fun performances from:\r\n        Coro Latinoamericano-Pittsburgh\r\n        Gateway to the Arts\r\n        Gemini Theater\r\n        Obama Academy Steel Band\r\n        Pittsburgh Belly Dance\r\n        Pittsburgh Musical Theater\r\n        Riversong String Ensemble\r\n        The Uncommon Quartet\r\n        *See full schedule below!\r\n    Personalize a Smiley Cookie with Eat'n Park\r\n    Rock out with Radio Disney & Friends\r\n    Check out the wares from I Made It! Market crafters\r\n    Visit the annual Used Book Sale\r\n    Learn about eating healthy with fun snacks\r\n    Visit with the Pittsburgh Pirates\r\n    Support your Library\r\n    AND SO MUCH MORE...\r\n\r\nBring the whole family! There's fun for everyone!\r\n \r\nThere are so many exciting things happening from 12 - 5!\r\nScheduled Events:\r\nVerizon Performance Tent\r\n\r\n12:00 – Pittsburgh Puppet Works Jewel's Treasure\r\n12:55 – CLP Welcome\r\n1:00 – Pittsburgh Musical Theater\r\n2:00 – Obama Academy Steel Band\r\n3:00 – The Uncommon Quartet - Members of the Edgewood Symphony Orchestra\r\n4:00 – Gemini Theater - presents Alice in Wonderland\r\nQuiet Reading Room\r\n12:30 – Bubbe Tells a Storywith Barbara Russell & Janice Coppola - presented by Gateway to the Arts (for kids)\r\n1:30 – Coro Latinoamericano - Pittsburgh\r\n2:30 – Riversong String Ensemble\r\n3:30 – Pittsburgh Belly Dance\r\nFamily Play Shop Tent\r\n\r\n1:00 – Infant/Toddler Storytime with Amy\r\n2:00 – Infant/Toddler Storytime with Erin\r\n3:00 – Sign Language Infant/Toddler Storytime with Heather\r\n4:00 – Infant/Toddler Storytime with Heather\r\nPittsburgh Ballet Theater Tent\r\n\r\n2:00 – Meet a real ballerina\r\nChildren's Department\r\n\r\n1:00, 2:00, 3:00 and 4:00 Puppet Show – The Bremen Town Musicians\r\nSteve Abrams Tent\r\n\r\n1:30, 2:30, 3:30 – Puppet Shows\r\nEast End Food Co-op Tent\r\n\r\n1:00 – Storytime with Author Paula Weiner – Fred Eats a Pea\r\nFederal Executive Board Hispanic Employment Program (Saturn)\r\n\r\n1:00 – Spanish Storytime - The Outside Dog 2:00 – Spanish Storytime - Juan Bobo 	2012-06-04 17:44:21.186989-04	2012-06-04 17:44:21.18704-04	2012-06-10 12:00:00-04	2012-06-10 17:00:00-04	f	http://www.carnegielibrary.org/summer/extravaganza/	195		t	img/e/banner_nodate.jpg
85	Tech Networking Happy Hour!	Thursday, June 14th\r\n\r\n5:00-7:00\r\nRevv Oakland,\r\n122 Meyran Ave.\r\n\r\nRefreshments Provided!\r\n\r\nTour Oakland's First Tech Incubator Space\r\nNetwork with fellow OBID members\r\nHear about exciting plans for Innovation Oakland, the launch of Scenable (Oakland's mobile app), and more!  	2012-06-13 20:53:53.898682-04	2012-06-13 20:53:53.898733-04	2012-06-14 17:00:00-04	2012-06-14 19:00:00-04	f	https://www.facebook.com/events/303214096437146/	415		t	img/e/Oakland.jpg
\.


--
-- Data for Name: events_event_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY events_event_tags (id, event_id, tag_id) FROM stdin;
6	31	189
7	31	132
8	32	190
9	33	121
10	33	191
11	33	190
12	44	133
13	40	127
15	38	42
16	38	127
18	37	127
19	45	62
20	45	23
23	46	74
25	48	80
26	49	132
27	49	133
28	50	132
29	50	133
30	53	150
42	10	6
43	10	15
44	56	6
45	56	15
46	54	192
47	54	161
48	54	62
52	58	133
53	59	133
55	47	127
56	57	157
57	57	6
58	60	133
59	61	15
60	61	51
61	61	117
62	61	118
63	61	119
64	62	118
65	62	207
66	63	207
67	64	80
68	65	80
69	66	80
70	67	80
71	68	80
72	69	80
73	70	130
74	71	130
75	71	127
76	72	132
77	73	130
78	73	131
79	73	14
80	75	132
81	76	132
82	77	131
83	78	74
84	79	194
85	79	195
86	79	197
87	79	209
88	79	130
89	79	127
90	80	121
91	80	210
92	80	6
93	81	58
94	81	211
95	81	21
96	81	130
97	81	127
98	82	17
99	82	6
100	82	15
101	83	133
102	83	14
103	84	123
\.


--
-- Data for Name: events_eventmeta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY events_eventmeta (id, event_id, key, value) FROM stdin;
2	2	fb_synced_event	288005317935574
3	3	fb_synced_event	101484189984947
4	4	fb_synced_event	125882994204318
5	5	fb_synced_event	182473725205240
6	6	fb_synced_event	402671169745018
7	7	fb_synced_event	425078507509459
8	8	fb_synced_event	391995324146168
9	9	fb_synced_event	271851616226494
10	10	fb_synced_event	414026435290572
11	11	fb_synced_event	197279153719073
12	12	fb_synced_event	308873475842113
13	13	fb_synced_event	360734197303404
14	14	fb_synced_event	310509389003759
15	15	fb_synced_event	327722050621676
16	16	fb_synced_event	119793474810940
17	17	fb_synced_event	361201987249841
18	18	fb_synced_event	215883938513669
19	19	fb_synced_event	140405242755966
20	20	fb_synced_event	374939569217845
21	21	fb_synced_event	277431875675466
22	22	fb_synced_event	203070436470769
23	23	fb_synced_event	251487561613454
24	24	fb_synced_event	109806982484940
25	25	fb_synced_event	200495003392491
26	26	fb_synced_event	369230166443949
30	37	ical_synced_event	https://www.google.com/calendar/ical/bfc4i9egg4qe1lokdd2ehiisl8%40group.calendar.google.com/public/basic.ics;sevdsadm6f47sska6p1fadcmng@google.com
31	38	ical_synced_event	https://www.google.com/calendar/ical/bfc4i9egg4qe1lokdd2ehiisl8%40group.calendar.google.com/public/basic.ics;8bs2c9gpo04ronidid72o6rqc4@google.com
33	40	ical_synced_event	https://www.google.com/calendar/ical/bfc4i9egg4qe1lokdd2ehiisl8%40group.calendar.google.com/public/basic.ics;u8vf6t9p62huead7g6jr98vnq4@google.com
37	44	ical_synced_event	https://www.google.com/calendar/ical/p0pbl2v6rutaomaoact140upvo%40group.calendar.google.com/public/basic.ics;fm33upkd88pgk2h17v8a5gpgq0@google.com
\.


--
-- Data for Name: events_icalendarfeed; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY events_icalendarfeed (id, url, owner_id, name) FROM stdin;
1	https://www.google.com/calendar/ical/oaklandplanning%40gmail.com/public/basic.ics	7	OPDC
2	https://www.google.com/calendar/ical/oaklandplanning%40gmail.com/public/basic.ics	9	Carnegie Museum of Art
3	https://www.google.com/calendar/ical/bfc4i9egg4qe1lokdd2ehiisl8%40group.calendar.google.com/public/basic.ics	\N	CMU Art Department
4	https://www.google.com/calendar/ical/p0pbl2v6rutaomaoact140upvo%40group.calendar.google.com/public/basic.ics	\N	Carnegie Mellon University Lecture Series
5	https://www.google.com/calendar/ical/98cip3n1ltenoad5lg5rhfupn8%40group.calendar.google.com/public/basic.ics	\N	Forbes Craig Activities
6	https://www.google.com/calendar/ical/qk0qs1be57pmk1pbj3ri9ogucc%40group.calendar.google.com/public/basic.ics	\N	Pitt Friday Lectures
7	https://www.google.com/calendar/ical/shacboard%40gmail.com/public/basic.ics	\N	Student Honors Activity Committee
8	https://www.google.com/calendar/ical/rmagh5tkfbgef9sn163tsdsvog%40group.calendar.google.com/public/basic.ics	\N	UHC Scholarships
9	https://www.google.com/calendar/ical/972hb294ibc7k9vo83jeltkr20%40group.calendar.google.com/public/basic.ics	\N	University Honors College Events
\.


--
-- Data for Name: events_icalendarfeed_candidate_places; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY events_icalendarfeed_candidate_places (id, icalendarfeed_id, place_id) FROM stdin;
1	1	62
2	2	195
3	2	197
4	2	196
5	2	198
\.


--
-- Data for Name: events_role; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY events_role (id, event_id, role_type, organization_id) FROM stdin;
4	31	owner	9
5	32	owner	6
6	33	owner	2
9	10	owner	1
10	46	owner	1
11	49	owner	9
12	50	owner	9
13	56	owner	1
14	57	owner	5
15	72	owner	9
16	75	owner	9
17	76	owner	9
18	79	owner	13
19	80	owner	2
20	81	owner	13
21	82	owner	6
22	84	owner	9
23	85	owner	1
\.


--
-- Data for Name: feedback_genericfeedbackcomment; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY feedback_genericfeedbackcomment (id, user_id, feedback) FROM stdin;
1	19	w/r/t: "Do you like the place? Add it to your favorites by clicking the icon under the map."\n\nThe icon is below the graphic on the Dave & Andy's Ice Cream "Single Place Page".\n\n--  tak_15217@yahoo.com
2	19	The "Website" link for the Red Oak Cafe took me to:\nhttp://www.innovationineating.com/sp/1012-fe1012\n\nIt is not what I expected.\n\n-- tak_15217@yahoo.com
3	22	Would recommend removing places from the Now page. It can get overly cluttered that way, and a user can simply click on Places to see all establishments. But, what would be cool is to know what places in Oakland are still open Now. If this was your intention, I think it needs to be more clear with some copy that says something like "Now open". And, upon clicking, having the hours of each establishment and contact info would be awesome!!!
4	22	I recommend increasing the clickable range for Events. I instinctively clicked on the picture/icons first, and had no response. It took a few clicks before I realized only the location (which is non-intuitive, as this could be a "Place") and the event name link to the info page. Although, this may be a habit that a user would learn. 
5	22	Please forget my last feedback. It appears that the pictures are now responsive. Maybe this was a bug or I am hallucinating :)
6	22	Maybe a bug - but upon entering "art" into the Filter it did not pick up any events. Although, I see several events tagged as "art". 
7	22	You may want to consider "check-in" capabilities to places and events. I don't personally use Foursquare, but know many who do. You may have thought of this, but some kind of loyalty system/benefits would also incentive people to use the "check-in" system whether through the Foursquare API or your own Scenable "check-in" system.
8	19	I added an event to my list (POTA Comic Book Day event).  How do I look at just my events?  It shows up in the list of events, along with other ones, but I have not yet added other events to my calendar.\n\n-- tak_15217@yahoo.com
9	24	When I saw the events icon at first, I got the impression that things were actually happening on the 11th. It might be a good idea to change the number to a small grid or somesuch.
10	24	It'd be cool to get some kind of "changes saved!" message after updating your account/profile info. 
11	2	In attempting to upload an Avatar, I keep getting the following error message: Upload a valid image. The file you uploaded was either not an image or a corrupted image.\n\nI know the file isn't corrupted and is a jpg.  Maybe I need to compress it first?
12	31	Brett - I think that you should include the date of the Maya Lin close since it's coming up and the Feb date is confusing (someone might think it was only that day)!
13	37	Just a thought, but if you clicked on a location under places, maybe there could be a link to the events that are happening at that place.  Like clicking on soldiers and sailors will have a list under the description of upcoming events, and if you click on those event links, itll take you to the event page corresponding to it.
14	2	How do I create and event?
15	44	Is there a way to have a more streamlined filtering approach and/or faster "at a glance" search, e.g., on the Places page rather than having 35 separate pages of listings?  As you get more places and other listings in all categories over time just showing the number of choices but only displaying a few may be a problem for users.
16	45	Hey nice job guys!  The search places filter looks pretty good at first, but when I use it and then advance to the next page, it reverts back to the full results as if I never searched on anything.
17	45	I just grabbed the free soup deal...seems simple enough and it looks like it worked!  PS: might want to label the from e-mail something other than "robot@scenable.com"...just a thought.
18	45	It took me a minute to figure out where my "calendar" was supposed to be...  I found it in my profile page.  I would have expected my calendar/events to show up on the Events page... maybe on the side or at least provide a link somewhere prominent in the Events section right to my calendar.  Maybe also add an indicator that the event on the event page is added to your calendar?\n\nProbably asking too much right now, but in a round two development, it might be nice to add these events to a Google or iCal/Outlook calendar or something.
21	46	One of my biggest gripes in advertising is when something is  "free" only when you make a purchase it should say upfront "free w/ purchase" not just "free".  "Free" should be reserved for things that are truly without qualifications or strings attached.
22	45	On the Places page...it appears to be randomly ordered, which is fine, but when advancing through the pages, it seems to mix up the order...so you can never truly scroll through all the listings.\n\nAlong with this, it might be nice to order via Alphabetical.
23	1	in the admin panel it says 15:00:00 and on the client template it says 7pm
24	68	On the title of the Red Oak Café page, the "é" lacks the style. BUT YOU DIDN'T HAVE TO CUT ME OFF...
25	45	Looking better! :)  The listings on the events page are random (actually they looked like they are in a fixed random order), but not randomizing when clicking through the page results.  Yay.\n\nWhen I filter using "food" or "music" or "art" (or even more specific ones like "pizza")...I find that the first page is often repeated on the second page of results.  This doesn't happen when I searched on "Asian" or "Chinese" or "Church" or "School" for some reason.
26	61	Times on overview page do not match times on event detail page.
27	61	Times on overview page do not match times on event detail page.
28	61	Times on overview page do not match times on event detail page.\nNeither one makes sense and neither are accurate.
29	61	Times on overview page do not match times on event detail page.\nNeither one makes sense (both end before they start) and neither are accurate.
30	61	Overall there's too much focus on serving your business interests and commercial customers and not enough attention from the perspective of site users...try to think like them more often than like your advertisers, and you'll serve both better.
31	46	Love the maps that show you exactly where the places are.  Great idea!  
32	84	This all looks great!  I can't wait to see it once you expand to all the other neighborhoods!
33	46	Love the maps that show you exactly where the places are.  Great idea!  \n\nAlso great thought provoking article about the shooting at McD's this morning
34	6	This is a test
35	6	This is a test -- Places Page
\.


--
-- Data for Name: news_article; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY news_article (id, dtcreated, title, blurb, fulltext_url, source_name, source_site, image_url, publication_date) FROM stdin;
1	2012-05-02 12:18:36.895867-04	New 'Dark Knight Rises' trailer hits Web  	A new trailer for "The Dark Knight Rises" is, if possible, even bleaker than the previous ones.\r\n\r\nThe clips from the movie, which was partly filmed in Pittsburgh, depict a broken down Bruce Wayne (Christian Bale) being held captive by Bane (Tom Hardy). It's a little easier to understand the muzzled Bane in this trailer as he tells Wayne, "I'm Gotham's reckoning." In response to Wayne asking why Bane doesn't just kill him, Bane says, "Your punishment must be more severe."\r\n\r\nCity sights are once again featured, although not quite as prominently as in the other trailers. There are brief glimpses of the outside of Mellon Institute in Oakland and Hines Ward running in Heinz Field, along with some Downtown street scenes.	http://triblive.com/aande/movies/1293747-74/bane-trailer-wayne-dark-knight-pittsburgh-rises-although-asking-bale	Pittsburgh Tribune Review	http://triblive.com/	http://triblive.com/csp/mediapool/sites/dt.common.streams.StreamServer.cls?STREAMOID=OPrhYmaoDV28u8jR63ROR8$daE2N3K4ZzOUsqbU5sYuG6wCtiKiaQVeFq1CzplB7WCsjLu883Ygn4B49Lvm9bPe2QeMKQdVeZmXF$9l$4uCZ8QDXhaHEp3rvzXRJFdy0KqPHLoMevcTLo3h8xh70Y6N_U_CryOsw6FTOdKL_jpQ-&CONTENTTYPE=image/jpeg	2012-05-01
2	2012-05-02 12:20:46.943176-04	CMU presents 10-year plan to city	Pittsburgh City Council today is scheduled to take a final vote on a plan that will guide Carnegie Mellon University's development for the next 10 years, an effort involving hundreds of millions of dollars in investment.\r\n\r\n"The economic impact of CMU is felt throughout Western Pennsylvania," Councilman Bill Peduto said Tuesday, after a gathering with university officials to highlight the master plan.\r\n\r\nMr. Peduto added that the city neighborhoods adjoining the campus -- Oakland, Shadyside and Squirrel Hill -- are uniquely affected by campus growth.\r\n\r\nHe said the plan, two years in development and the subject of 40 community meetings, does a good job of balancing university and resident concerns.	http://www.post-gazette.com/stories/local/neighborhoods-city/cmu-presents-10-year-plan-to-city-632959/	Pittsburgh Post-Gazette	http://www.post-gazette.com/	http://proofculture.com/pc/2011/12/pittsburgh_post_gazette260.jpg	2012-04-25
3	2012-05-02 12:22:39.080195-04	City school board delays sale of Schenley High School building	The board of Pittsburgh Public Schools has delayed putting the historic former Pittsburgh Schenley High School building in Oakland up for sale.\r\n\r\nAt its legislative meeting, the board voted 5-4 to table the motion to accept bids on the school up to June 29. Board members wanted to further explore whether the district could retain use of the addition -- built in the 1980s -- housing the gym and pool to meet heavy demand at other schools.\r\n\r\nThose voting to table to motion were Mark Brentley Sr., Regina Holley, Bill Isler, Sharene Shealey and Thomas Sumpter. Opposed to tabling the motion were Theresa Colaizzi, Jean Fink, Sherry Hazuda and Floyd McCrea.	http://www.post-gazette.com/stories/local/breaking/city-school-board-delays-sale-of-schenley-high-school-building-633044/	Pittsburgh Post-Gazette	http://www.post-gazette.com/	http://proofculture.com/pc/2011/12/pittsburgh_post_gazette260.jpg	2012-04-26
4	2012-05-02 12:24:17.482086-04	Pitt suspends some areas of study to save money	The classics, German and religious studies still will be taught at the University of Pittsburgh, but some graduate students in those departments are feeling as if they are part of an endangered species.\r\n\r\nThe University of Pittsburgh has suspended admission to the graduate programs in the three departments. Admission offers already accepted will be honored.\r\n\r\nCurrent students will be able to complete their degrees in a "timely manner," the university stated.\r\n\r\n"We're stunned," said Katrin Mascha, a fifth-year graduate student in German. "It came totally out of the blue."	http://www.post-gazette.com/stories/news/education/pitt-closes-some-areas-of-study-to-save-money-633287/	Pittsburgh Post-Gazette	http://www.post-gazette.com/	http://c4241337.r37.cf2.rackcdn.com/04-27-06_katrin-mascha_420.jpg	2012-04-27
5	2012-05-02 12:25:49.530349-04	Pitt aims to prove therapy can offer new cancer hope	A human clinical trial under way at UPMC's Hillman Cancer Center in Shadyside will help determine whether a combination of approved drugs based on a new theory of cancer can "revolutionize cancer therapy."\r\n\r\nThat's the explanation of lead researcher Michael T. Lotze, who says his team has combined interleukin 2 (IL-2) with hydroxychloroquine in a new therapy designed to be more effective and less toxic in curing cancer than IL-2 alone.\r\n\r\nThe new cancer theory, how the two drugs work in tandem and how the treatment works involve complicated science. The Pitt team starts with IL-2, a drug that strengthens the immune response to cancer but doesn't work in the majority of patients, in part, due to severe toxicity. It then adds an inexpensive drug, hydroxychloroquine, to serve a different role -- to reduce the cancer drug's toxicity and increase its cancer-killing efficiency.	http://www.post-gazette.com/stories/news/health/pitt-aims-to-prove-therapy-can-offer-new-cancer-hope-633322/	Pittsburgh Post-Gazette	http://www.post-gazette.com/	http://proofculture.com/pc/2011/12/pittsburgh_post_gazette260.jpg	2012-04-27
6	2012-05-02 12:27:00.569519-04	University of Pittsburgh graduation goes smoothly 	University of Pittsburgh senior Mike Rosenfeld was evacuated from classes five times during the past semester by bomb threats, but on Sunday he sat in his cap and gown in the bright sunshine outside of the Petersen Events Center with high hopes that his graduation ceremony would not be interrupted by yet another threat.\r\n\r\nHis hopes were fulfilled when the ceremony, which included more than 2,000 graduates and about 10,000 spectators, went off without a hitch.\r\n\r\nUniversity Chancellor Mark Nordenberg, in his remarks, said he had never looked forward to a graduation ceremony as much as he looked forward to Sunday's event, and he credited the resiliency of the university community for the ability to complete the semester in the face of 46 bomb threats between Feb. 13 and April 21 that shut down buildings, forced the cancellation of classes and emptied residence halls in the early morning hours.	http://www.post-gazette.com/stories/local/neighborhoods-city/a-calm-end-to-a-tumultous-year-633663/	Pittsburgh Post-Gazette	http://www.post-gazette.com/	http://c4241337.r37.cf2.rackcdn.com/04-30-43_hi-mom-graduation-cap_420.jpg	2012-04-30
7	2012-05-02 12:29:20.112628-04	CMU student aims for top chess honors	For Iryna Zenyuk, chess is taking a back seat these days to a Ph.D. in mechanical engineering at Carnegie Mellon.\r\n\r\nBut even in this relatively relaxed period, she's still one of the 10 best female chess players in the country. And next week, the 25-year-old Squirrel Hill resident will travel to the U.S. Women's Championship chess tournament in St. Louis -- a competition that she has participated in since she was 18.\r\n\r\nTen years ago, she was practicing five hours a day. Two years ago, she was still waking up before 6:30 a.m. to start her day with a two-hour study session. These days, she squeezes her preparation in on weekends and in short blocks in between lab work and intramural volleyball games.	http://www.post-gazette.com/stories/local/neighborhoods-city/cmu-student-aims-for-top-chess-honors-633829/	Pittsburgh Post-Gazette	http://www.post-gazette.com/	http://c4241337.r37.cf2.rackcdn.com/05-01-44_iryna-zenyuk_420.jpg	2012-05-01
8	2012-05-02 12:31:01.128558-04	City Walkabout / Livehoods.orgs maps a different view of our neighborhoods	Many of us have emotional ties to our neighborhoods and know the boundaries, but what do those boundaries really mean to us?\r\n\r\nThey were fixed by historical use, geography, roadways, built barriers and urban planning. They are really fairly meaningless, and we prove that by crossing them frequently and regularly to do things we need and want to do.\r\n\r\nComputer scientists at Carnegie Mellon University have created a mapping system called "Livehoods" to show -- at www.livehoods.org -- a new kind of boundary, based solely on use.\r\n\r\nFor their model, they collected data from the smartphone application foursquare, via Twitter. Foursquare claims a community of 20 million people worldwide. It's a free application that you can use to check in at cafes, restaurants, stores and other sites, in part to get discounts, in part to get recommendations from other users and maybe to impress people you "friend." Foursquare friends can follow each other by name.	http://www.post-gazette.com/stories/local/morning-file/city-walkabout-social-media-show-a-different-view-of-our-neighborhoods-633862/	Pittsburgh Post-Gazette	http://www.post-gazette.com/	http://c4241337.r37.cf2.rackcdn.com/05-01-27_livehoodsorg_420.jpg	2012-05-01
9	2012-05-02 12:44:23.444583-04	VA to open new Oakland facility	Major upgrades under way for more than a decade at VA Pittsburgh Healthcare System facilities are moving forward with the completion of a $75.8 million Consolidation Building on Oakland's University Drive campus.\r\n\r\nThe building, situated at Brackenridge and Allequippa streets, represents "the new standard in comprehensive, veteran-focused care," according to VA Pittsburgh officials. Key advances include 78 secure, private beds dedicated to psychiatric care in the same building as an outpatient primary-care center to provide greater convenience for veterans.\r\n\r\nCompletion of the Consolidation Building, which combines three facilities into two, along with upgrades at the H.J. Heinz campus in Aspinwall, will allow VA Pittsburgh to close the Highland Drive campus in Lincoln-Lemington.	http://www.post-gazette.com/stories/local/neighborhoods-city/va-to-open-new-oakland-facility-633943/	Pittsburgh Post-Gazette	http://www.post-gazette.com/	http://proofculture.com/pc/2011/12/pittsburgh_post_gazette260.jpg	2012-05-02
10	2012-05-02 12:45:51.867403-04	Anonymous group claims it hacked Pitt’s computer system	First there were bomb threats. Now there is a YouTube threat.\r\n\r\nA group using the name “Anonymous” claims in an April 26 YouTube video that it has hacked into Pitt’s computer system and downloaded personal information about Pitt students, employees and alumni.\r\n\r\nThe group, which used a synthesized voice to deliver its message, claims to have taken more than 200 gigabytes of data, including student and staff passwords and usernames and payment, dorm room and coursework information.\r\n\r\n“We do not agree with your intentions, your lack of care for your students and their valuable — yet vulnerable — information,” the group said in the video, which told Pitt to apologize to its students, staff and local law enforcement and demanded a public apology for irresponsibility on the homepage of Pitt’s website, to be posted for 15 days. The message said that if its demands aren’t met, the group will release the data.	http://pittnews.com/newsstory/anonymous-group-claims-it-hacked-pitts-computer-system/	The Pitt News	http://pittnews.com/	http://pittnews.com/wp-content/uploads/2011/08/masthead.jpg	2012-05-01
11	2012-05-02 12:47:04.942948-04	Port Authority approves drastic cuts to service	Getting around Pittsburgh may get a lot harder next fall.\r\n\r\nThe Port Authority of Allegheny County, which operates public transportation in and around Pittsburgh, approved cuts totaling 35 percent of its current service on Friday, according to a press release.\r\n\r\nThese cuts, which will take effect on Sept. 2 of this year, will eliminate 46 of the 102 routes that the Port Authority operates within Pittsburgh and its surrounding areas. Every remaining route will face some reduction in service, such as discontinuation of weekend service and ending service after 10 p.m. Eighteen park and rides throughout the county will also lose service if these measures take effect.\r\n\r\nThese cuts are aimed at reducing $64 million in the department’s 2012-2013 budget.	http://pittnews.com/newsstory/port-authority-approves-drastic-cuts-to-service/	The Pitt News	http://pittnews.com/	http://pittnews.com/wp-content/uploads/2011/08/masthead.jpg	2012-04-30
12	2012-05-03 11:16:01.575946-04	Sunny outlook for Pittsburgh Marathon runners this weekend	Trying to predict the weather in Pittsburgh four days in advance can be a fool's errand, but organizers for the Pittsburgh Marathon are optimistic for the race this weekend.\r\n\r\nWeather service forecasts issued Wednesday called for temperatures in the mid-50s at the start of the race in the morning, creeping up to the 70s by early afternoon, with a high of 73 or 74. AccuWeather.com predicted a "partly sunny" sky.\r\n\r\n"I've been checking constantly, and I've seen the weather and temperature for [Sunday] change four times since this morning," said race director Patrice Matamoros.\r\n\r\nShe is, however, "cautiously optimistic" that the weather will pan out.\r\nPG VIDEO\r\n\r\nIn addition to good running temperatures, organizers hope the course stays dry. Since the marathon returned from a six-year hiatus in 2009, there has been at least a drizzle on race day every year.	http://www.post-gazette.com/stories/sports/more-sports/sunny-outlook-for-runners-634203/	Pittsburgh Post-Gazette	http://www.post-gazette.com/	http://proofculture.com/pc/2011/12/pittsburgh_post_gazette260.jpg	2012-05-03
13	2012-05-05 10:25:07.612292-04	Officials rescue seven ducklings	City animal-control officers rescued seven ducklings Friday from a Bloomfield storm sewer but couldn't corral the mother after she flew away.\r\n\r\nGerald Akrie, supervisor of animal care and control, said a bystander reported about 11:30 a.m. that the ducklings had fallen through a storm grate and that the mother sat down on the grate and refused to move.\r\n\r\nMr. Akrie said police blocked off the street while his officers pried off the grate and rescued the ducklings, all of which appeared to be in good shape. However, the mother flew away amid the hubbub.\r\n\r\nOfficers put the ducklings in a basket and moved out of the area, hoping the mother would come back to check on her young. But she did not.	http://www.post-gazette.com/stories/local/neighborhoods-city/officials-rescue-seven-ducklings-634441/	Pittsburgh Post-Gazette	http://www.post-gazette.com/	http://proofculture.com/pc/2011/12/pittsburgh_post_gazette260.jpg	2012-05-05
21	2012-05-18 11:04:23.49881-04	Children’s Festival Has Schenley Plaza Buzzing With Activity	Schenley Plaza in Oakland buzzed with activity Wednesday on opening day of the Pittsburgh International Children’s Festival.\r\n\r\nThe biggest star is an inflatable sculpture in Bill Mazeroski field. There’s also sunflowers and giraffes, a duck-footed owl and Mr. McFeely.\r\n\r\nThe International Children’s Festival is back and kids have more hands-on activities than ever.\r\n\r\nFestival Director Pam Lieberman says Oakland is an international stage.	http://pittsburgh.cbslocal.com/2012/05/16/childrens-festival-has-schenley-plaza-buzzing-with-activity/	KDKA News	http://pittsburgh.cbslocal.com/	http://cbspittsburgh.files.wordpress.com/2012/05/childrensfestival1.jpg?w=300	2012-05-16
14	2012-05-07 07:59:37.727305-04	19,000 marathoners bear the heat	Newlyweds Josh and Jessica Troiano ducked into First Presbyterian Church before dawn Sunday morning, the moon still hanging over Downtown, the streets still quiet.\r\n\r\nWithin hours, a record 19,000 entrants would navigate the streets of Pittsburgh for the fourth running of the marathon since its rebirth in 2009.\r\n\r\nBut for a moment, in the peaceful dark wooden pews, the Troianos -- in sneakers and running shorts -- bowed their heads for "The Blessing of the Runners."\r\n\r\nThe Rev. Tom Hall -- through prayer, hymns, and a little humor -- delivered a 30-minute, nondenominational service to some 60 parishioners, clad mostly in running gear and not their Sunday best.\r\n\r\n"Why are you running today?" Rev. Hall asked. "You're going to ask yourself that again around mile 20."\r\n\r\nHe shared the story made famous by the movie "Chariots of Fire" -- and the faith that Eric Liddell, who was a devout Christian, ran with.	http://www.post-gazette.com/stories/local/neighborhoods-city/19000-marathoners-bear-the-heat-634703/	Pittsburgh Post-Gazette	http://www.post-gazette.com/	http://c4241337.r37.cf2.rackcdn.com/05-07-15_the-2012-pittsburgh-marathon_420.jpg	2012-05-07
15	2012-05-10 09:37:38.141744-04	Senate Appropriations Committee aims to restore Pitt funding	The Republican-controlled Pennsylvania Senate Appropriations Committee voted unanimously on Tuesday to maintain Pitt’s state funding at $136.1 million for the next fiscal year, despite Gov. Tom Corbett’s proposed 30 percent cut.\r\n\r\nIn February, Corbett proposed a 30 percent slash to three of the four state-related Universities — Pitt, Penn State and Temple. Lincoln, by far the smallest of the four state-related schools, was to be spared. However, the cuts did not receive support in the General Assembly, as even the committee members of the governor’s own party voted not to cut funding from higher education.\r\n\r\nWhile the ranking Republican in the Senate Appropriations Committee, Sen. Jake Corman (R-Centre), was not available for immediate comment, he previously voiced his opposition to the cuts. 	http://pittnews.com/newsstory/senate-appropriations-committee-aim-to-restore-pitt-funding/	The Pitt News	http://pittnews.com/	http://pittnews.com/wp-content/uploads/2011/08/masthead.jpg	2012-05-08
16	2012-05-11 11:02:51.537399-04	CMU to pay $5 million for diocesan property	Carnegie Mellon University plans to pay the Catholic Diocese of Pittsburgh more than $5 million for a three-story building on a half-acre on Fifth Avenue. The Cardinal Dearden Center is one of five parcels totaling nearly 1 1/2 acres at the site that the diocese hopes to sell to CMU, substantially expanding the university's holdings in the heart of Oakland.\r\n\r\nSale of the Dearden Center, now home to six retired priests, marks another step in Bishop David Zubik's plan to centralize diocesan operations at St. Paul Seminary in Crafton. The Rev. Ron Lengwin, diocese spokesman, said the diocese hopes to complete the transaction by the end of June. CMU officials declined to discuss the purchase or what they planned to do with the land.\r\n\r\n"We defer any comment to the diocese until an agreement is finalized," said Teresa Thomas, a CMU spokeswoman.	http://www.post-gazette.com/stories/news/education/cmu-to-pay-5-million-for-diocesan-property-635378/	Pittsburgh Post-Gazette	http://www.post-gazette.com/	http://c4241337.r37.cf2.rackcdn.com/05-11-19_cardinal-dearden-center_420.jpg	2012-05-11
17	2012-05-11 13:26:47.597116-04	One to hospital, one to jail after failed robbery outside McDonald's in Oakland	One man remains hospitalized and another has been jailed after a robbery attempt sparked a shootout outside a McDonald's in Oakland early this morning.\r\n\r\nA 23-year-old Morningside man and his friend were leaving the McDonald's in the 3900 block of Forbes Avenue about 2:40 a.m. when another man pulled out a gun and tried to rob him of his bracelet, police said.\r\n\r\nThe first man pulled out his own handgun -- one he legally possessed -- and the two exchanged gunshots.\r\n\r\nThe would-be robber was grazed.\r\nJason Woodall\r\n\r\nA bullet hit the first man in the chest. He remains in critical condition at UPMC Presbyterian, where he had surgery.	http://www.post-gazette.com/stories/local/neighborhoods-city/2-shot-outside-original-hot-dog-shop-in-oakland-635464/	Pittsburgh Post-Gazette	http://www.post-gazette.com/	http://proofculture.com/pc/2011/12/pittsburgh_post_gazette260.jpg	2012-05-11
18	2012-05-12 10:25:33.348397-04	Pitt files lawsuit against Big East	he University of Pittsburgh filed suit Friday against The Big East Conference in the Allegheny County Court of Common Pleas for allowing two members -- Texas Christian University and West Virginia University -- to withdraw early from the conference. Conference rules state that members must give 27 months of notice before leaving the league, but Big East officials allowed TCU and WVU to withdraw without giving that much notice.\r\n\r\nAs a result, Pitt said in its lawsuit, Big East officials have "knowingly and intentionally waived any right to enforce a twenty-seven month withdrawal period" and should allow Pitt to withdraw early as well.	http://www.post-gazette.com/stories/sports/pitt-big-east/pitt-files-lawsuit-against-big-east-635561/	Pittsburgh Post-Gazette	http://www.post-gazette.com/	http://proofculture.com/pc/2011/12/pittsburgh_post_gazette260.jpg	2012-05-12
19	2012-05-14 08:19:00.690773-04	Pittsburgh Race for the Cure brings thousands together	Jeannie Horgan of Greenfield hasn't missed any of the 20 Komen Pittsburgh Races for the Cure.\r\n\r\n"I did all the Komens because my mom died of breast cancer when she was young," said Ms. Horgan, 58.\r\n\r\nBut there was more to it than that.\r\n\r\nOn Sunday, she wore the deep pink T-shirt given the survivors who paraded around Flagstaff Hill in Schenley Park, Oakland, before the Komen timed 5K race and fun walk/run. Ms. Horgan was diagnosed with stage 3 breast cancer five years ago and was treated with radiation, a lumpectomy and a masectomy. She had reconstruction done at the same time.\r\nPG VIDEO\r\n\r\n"I'd like to thank my doctor, surgeon Rae Budray, who found my tumor with an MRI," she said.	http://www.post-gazette.com/stories/local/neighborhoods-city/pittsburgh-komen-race-for-the-cure-race-brings-thousands-together-635808/	Pittsburgh Post-Gazette	http://www.post-gazette.com/	http://c4241337.r37.cf2.rackcdn.com/05-14-08_breast-cancer-survivors-unite_original.jpg	2012-05-14
20	2012-05-16 10:45:27.211322-04	Pitt awarded $1.3 million in grants for nuclear research	When professor John Metzger began his tenure as director of Pitt’s nuclear engineering program in 2010, the certificate program focused primarily on academics, placing little emphasis on research.\r\n\r\nIn the two years of his leadership, the nuclear engineering department considerably increased its propensity for research, increasing enrollment in its graduate program. Last week, Metzger’s work won Pitt grants totaling $1.3 million from the U.S. Department of Energy. Through the Department of Energy’s Nuclear Energy University Program, Metzger, fellow Pitt professor Mark Kimber and Pitt graduate student Rita Patel each received funding for their respective projects developing new technology for nuclear energy that could make the process safer.\r\n\r\nThe NEUP focuses on the integration of research and development at universities, national laboratories and industry and on revitalizing nuclear education in the country, according to the Department of Energy’s website. The NEUP also provides funding for the improvement of nuclear research infrastructure on college campuses by improving their research, development and educational capacities.	http://pittnews.com/newsstory/pitt-awarded-1-3-million-in-grants-for-nuclear-research/	The Pitt News	http://pittnews.com/	http://pittnews.com/wp-content/uploads/2011/08/masthead.jpg	2012-05-16
22	2012-05-21 21:12:53.705583-04	Best French Fries In Pittsburgh	Contrary to popular belief, one of America’s most popular foods, the french fry, originated in Belgium and not in France. Variants of this favorite food are plentiful: thick-cut fries, steak fries, shoestring fries, crinkle fries, curly fries, hand-cut fries, tornado fries… Call them whatever you want – Americans scarf down heaping amounts, approximately 28 pounds per person per year. Pittsburghers are no stranger to these luscious cuts of fried root vegetable. After an arduous brainstorming session, this writer narrowed down Pittsburgh’s five best local venues to get your french fry fix on in the ‘Burgh. Beware: this list might surprise you.	http://pittsburgh.cbslocal.com/top-lists/best-french-fries-in-pittsburgh/	KDKA News	http://pittsburgh.cbslocal.com/	http://cbspittsburgh.files.wordpress.com/2012/04/french-fries-thinkstock.jpg?w=300&h=225	2012-05-16
23	2012-05-22 08:15:34.586175-04	Pittsburgh anticipating $3 million from nonprofits	Though an agreement still hasn't been signed, the city expects to receive more than $3 million in contributions from nonprofit groups this year, Mayor Luke Ravenstahl's spokeswoman said Monday.\r\n\r\nLegislation that would establish a new two-year agreement with Pittsburgh Public Service Fund, a consortium of nonprofit groups, will be introduced in city council today.\r\n\r\nThe legislation doesn't specify the amount of donations for 2012 and 2013.	http://www.post-gazette.com/stories/local/neighborhoods-city/pittsburgh-anticipating-3-million-from-nonprofits-636987/	Pittsburgh Post-Gazette	http://www.post-gazette.com/	http://proofculture.com/pc/2011/12/pittsburgh_post_gazette260.jpg	2012-05-22
24	2012-05-23 07:09:16.783238-04	Pittsburgh-based Innovation Works living up to its name	Passing by an Oakland restaurant recently where a local tech CEO was engaged in an intense business lunch with an executive from a major out-of-state venture capital firm, Innovation Works CEO Rich Lunak said he saw the future of the city's tech sector.\r\n\r\nAnd he believes the signs indicate that future is much closer than many, both in and out of the city, realize.\r\n\r\n"The region's been showing great momentum in this area. People are taking notice, not only locally, but nationally," he said.\r\n\r\nLast year, 72 percent of all venture deals in the region went to companies in the portfolio of Innovation Works, a South Oakland-based tech incubator in its 12th year of providing funding, business resources, office space and the aid of seasoned entrepreneurs to promising startups. The Southwestern Pennsylvania Ben Franklin Technology Partner is an initiative of the state Department of Community and Economic Development.	http://www.post-gazette.com/stories/business/news/innovation-works-has-lived-up-to-its-name-637098/	Pittsburgh Post-Gazette	http://www.post-gazette.com/	http://proofculture.com/pc/2011/12/pittsburgh_post_gazette260.jpg	2012-05-23
25	2012-05-23 21:02:02.581951-04	Phipps' Center for Sustainable Landscapes opens today, to be greenest building	Today is the grand opening of the Phipps Center for Sustainable Landscapes (CSL), a building that promises to be one of the greenest in the world.  The CSL is a research, education, and administrative complex, and meets the three highest green building standards: The Living Building Challenge; LEED Platinum; and the SITES landscape rating system.\r\n\r\nThe complex is the centerpiece of the latest phase in a $20 million, multi-year expansion project underway at Phipps to upgrade and expand its facilities with an emphasis on green and sustainability.  While planning the project, Phipps accepted the Living Building Challenge issued by the U.S. Green Building Council, an attempt to raise the bar and define a closer measure of true sustainability in the built environment.\r\n\r\n“In a way this building marks the end of a journey we've been on to really discover and learn about the most effective ways to build and operate our buildings, to be more in harmony and in tune with the environment,” says Richard Piacentini, executive director at Phipps.\r\n\r\nAccording to Piacentini, the Living Building Challenge is a new benchmark that goes far beyond LEED Platinum, requiring that buildings are net-zero energy; that all water is captured and treated on site; and that many commonly-used but toxic materials are not used in construction.	http://www.popcitymedia.com/devnews/phipps052312.aspx	Pop City Media	http://www.popcitymedia.com/	http://www.popcitymedia.com/galleries/development/issue300/phipps_9367_600.jpg	2012-05-23
26	2012-05-29 13:53:12.57454-04	Small fire extinguished at Pitt's Salk Hall	The University of Pittsburgh's Salk Hall, which houses its dental school, was evacuated this morning after a small fire was reported on the fourth floor there.\r\n\r\nThe fire rose to a three-alarm, but no injuries were reported.\r\n\r\nFirefighters and the city's arson squad were called, per protocol, to the building on Terrace Street in Oakland about 11:30 a.m. The fire was reported to be on the fourth floor.\r\n\r\nA university spokesman could not immediately be reached for comment, but the school's emergency notification system reported that the fire was extinguished as of 1 p.m. The building will remain closed until 5 p.m.	http://www.post-gazette.com/stories/local/neighborhoods-city/small-fire-extinguished-at-pitts-salk-hall-638047/	Pittsburgh Post-Gazette	http://www.post-gazette.com/	http://proofculture.com/pc/2011/12/pittsburgh_post_gazette260.jpg	2012-05-29
27	2012-06-04 09:47:34.432606-04	Reunion joins families helped by Magee neonatal unit 	Janice and Chuck Hackett's son beat the odds.\r\n\r\nBorn eight weeks early and weighing just 2 pounds 4 ounces, Cameron Hackett spent 75 days in the Neonatal Intensive Care Unit at Magee-Womens Hospital of UPMC.\r\n\r\n"The nurses at Magee and the doctors are why we have a family," Janice Hackett, 43, of Collier said on Sunday at the 10th annual reunion of former patients of the neonatal unit.\r\n\r\nIt was an emotional day for the Hacketts, who helped sponsor the event. Their son endured blood transfusions, a hole in his heart and two hernia surgeries.\r\n\r\n"He lived a lifetime before he came home," his mother said.\r\n\r\nThis year, Cameron, 3, played soccer.\r\n\r\nAbout 200 children, their parents and extended families attended the reunion at Pittsburgh Zoo & PPG Aquarium.\r\n\r\nThe kids, from tots to teens, met zoo critters and baby animals while their parents swapped stories, reunited with old friends and made new ones.	http://triblive.com/home/1909008-74/magee-neonatal-reunion-unit-family-nicu-born-families-hackett-parents	Pittsburgh Tribune Review	http://triblive.com/	http://triblive.com/csp/mediapool/sites/TribLIVE/assets/img/logo_triblive.gif	2012-06-04
28	2012-06-12 12:42:49.447008-04	 300-plus University of Pittsburgh employees opt for early retirement  Read more	More than 300 employees at the University of Pittsburgh have decided to take advantage of an early retirement incentive the university offered in April.\r\n\r\nBut the retirements are not expected to affect classrooms or educational programs because no faculty are involved, said Pitt spokesman Robert Hill.\r\n\r\nA total of 672 "classified" employees are eligible for the early retirement offer, which is good until Friday. A news release issued Monday by Pitt said 270 of those employees have yet to make a decision, which means the number of retirements could increase. Employees who take the offer will retire as of June 30.\r\n\r\nRead more: http://www.post-gazette.com/stories/news/education/300-plus-university-of-pittsburgh-employees-opt-for-early-retirement-640010/#ixzz1xb8x9V54\r\n	http://www.post-gazette.com/stories/news/education/300-plus-university-of-pittsburgh-employees-opt-for-early-retirement-640010/	Pittsburgh Post-Gazette	http://www.post-gazette.com/	http://proofculture.com/pc/2011/12/pittsburgh_post_gazette260.jpg	2012-06-12
29	2012-06-12 12:44:39.720365-04	Probe into Pitt bomb threats continues, FBI says 	A series of bomb threats that evoked fear and disrupted college life for more than a month at the University of Pittsburgh ended April 21, but the search for the person or persons responsible has continued unabated.\r\n\r\n"We've actually increased our investigation," said Kelly Kochamba, a spokeswoman for the FBI in Pittsburgh. "It's ongoing, it's expanded and we're investigating a few key leads.\r\n\r\n"The Joint Terrorism Task Force is continuing the investigation with both international and domestic law enforcement agencies. We have a lot of people working around the clock on this case. Our task force is fully staffed."\r\n\r\nIn addition to the FBI, other agencies on the region's terrorism task force include the federal Immigration and Customs Enforcement, Internal Revenue Service, U.S. Secret Service, Alcohol, Tobacco, Firearms and Explosives, federal air marshals, and the U.S. Postal Inspection Service, along with local agencies, including Pittsburgh police and Pitt police.\r\n\r\nRead more: http://www.post-gazette.com/stories/local/neighborhoods-city/probe-into-pitt-bomb-threats-continues-fbi-says-639867/#ixzz1xb9SjbOs\r\n	http://www.post-gazette.com/stories/local/neighborhoods-city/probe-into-pitt-bomb-threats-continues-fbi-says-639867/	Pittsburgh Post-Gazette	http://www.post-gazette.com/	http://proofculture.com/pc/2011/12/pittsburgh_post_gazette260.jpg	2012-06-11
\.


--
-- Data for Name: news_article_related_events; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY news_article_related_events (id, article_id, event_id) FROM stdin;
1	12	46
\.


--
-- Data for Name: news_article_related_places; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY news_article_related_places (id, article_id, place_id) FROM stdin;
1	2	217
2	4	356
3	5	36
4	6	284
5	7	217
6	8	217
7	9	232
8	10	284
9	16	217
10	18	286
11	21	412
13	22	45
14	22	414
15	24	217
16	24	323
17	25	230
18	26	386
19	27	228
20	29	284
\.


--
-- Data for Name: places_favorite; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY places_favorite (id, user_id, place_id, dtcreated) FROM stdin;
3	6	40	2012-05-02 21:17:35.253227-04
4	6	186	2012-05-02 21:17:48.858689-04
5	6	156	2012-05-02 21:18:08.047672-04
6	6	26	2012-05-02 21:18:30.488756-04
8	6	164	2012-05-02 21:19:45.118985-04
9	15	73	2012-05-02 21:33:57.621257-04
10	15	235	2012-05-02 21:34:25.834246-04
11	6	73	2012-05-02 21:35:31.305395-04
12	6	235	2012-05-02 21:42:04.260117-04
13	6	241	2012-05-02 21:54:11.781453-04
14	16	73	2012-05-02 21:54:13.865466-04
15	15	137	2012-05-02 22:53:46.205165-04
16	1	238	2012-05-02 22:54:13.287215-04
17	16	235	2012-05-02 22:54:14.407602-04
18	16	239	2012-05-02 22:54:42.163835-04
19	1	73	2012-05-02 22:54:59.145083-04
20	1	26	2012-05-02 22:55:04.888156-04
21	6	142	2012-05-02 22:55:22.944536-04
22	16	230	2012-05-02 22:57:35.819247-04
25	16	45	2012-05-02 22:57:43.171129-04
26	16	7	2012-05-02 22:57:44.519479-04
27	20	195	2012-05-02 23:21:25.352618-04
28	20	241	2012-05-02 23:22:00.448815-04
29	42	44	2012-05-03 10:02:54.900073-04
30	45	40	2012-05-03 11:06:39.533509-04
31	45	45	2012-05-03 11:07:11.605127-04
32	45	83	2012-05-03 11:08:10.845397-04
33	45	18	2012-05-03 11:08:33.748307-04
34	45	68	2012-05-03 11:09:17.299955-04
35	45	180	2012-05-03 11:09:24.085476-04
36	45	198	2012-05-03 11:10:30.797261-04
37	45	184	2012-05-03 11:10:44.291059-04
38	45	259	2012-05-03 11:11:00.578838-04
39	45	204	2012-05-03 11:11:39.458116-04
40	15	45	2012-05-03 12:55:15.795871-04
41	1	62	2012-05-08 16:03:05.910933-04
42	80	254	2012-05-11 13:17:36.606287-04
43	107	44	2012-06-07 08:49:17.628799-04
44	15	241	2012-06-13 19:25:49.303666-04
45	6	78	2012-06-14 18:51:55.534797-04
46	6	44	2012-06-18 14:44:44.237884-04
\.


--
-- Data for Name: places_location; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY places_location (id, country, state, town, postcode, address, latitude, longitude) FROM stdin;
1	US	PA	Pittsburgh	15213	100 Lytton Ave	40.446155	-79.954695
2	US	PA	Pittsburgh	15213	100 N Bellefield Ave	40.447140	-79.951962
3	US	PA	Pittsburgh	15217	101 Panther Hollow Rd	40.438249	-79.946902
4	US	PA	Pittsburgh	15213	107 Atwood St	40.441577	-79.958083
5	US	PA	Pittsburgh	15213	107 Thackeray Ave	40.443715	-79.957294
6	US	PA	Pittsburgh	15213	108 N Dithridge St	40.447397	-79.950012
7	US	PA	Pittsburgh	15213	109 Oakland Ave	40.442059	-79.957543
8	US	PA	Pittsburgh	15213	110 Atwood St	40.441448	-79.958176
9	US	PA	Pittsburgh	15213	111 Meyran Ave	40.441064	-79.958770
10	US	PA	Pittsburgh	15213	113 Meyran Ave	40.441038	-79.958739
11	US	PA	Pittsburgh	15213	114 Atwood St	40.441298	-79.957984
12	US	PA	Pittsburgh	15213	115 Meyran Ave	40.440928	-79.958633
13	US	PA	Pittsburgh	15213	115 Oakland Ave	40.441933	-79.957312
14	US	PA	Pittsburgh	15213	116 Oakland Ave	40.441808	-79.957385
15	US	PA	Pittsburgh	15213	116 S Bouquet St	40.442248	-79.957014
16	US	PA	Pittsburgh	15213	117 Oakland Ave	40.441880	-79.957249
17	US	PA	Pittsburgh	15213	117 S Bouquet St	40.442254	-79.956846
18	US	PA	Pittsburgh	15213	118 Meyran Ave	40.440747	-79.958652
19	US	PA	Pittsburgh	15213	119 Oakland Ave	40.441866	-79.957174
20	US	PA	Pittsburgh	15213	120 Robinson St	40.438407	-79.965252
21	US	PA	Pittsburgh	15213	121 Oakland Ave	40.441820	-79.957131
22	US	PA	Pittsburgh	15213	123 University Pl	40.444665	-79.956812
23	US	PA	Pittsburgh	15213	124 Oakland Ave	40.441680	-79.957223
24	US	PA	Pittsburgh	15213	125 Oakland Ave	40.441789	-79.957139
25	US	PA	Pittsburgh	15213	128 N Craig St	40.448090	-79.949122
27	US	PA	Pittsburgh	15213	136 N Craig St	40.448103	-79.949649
28	US	PA	Pittsburgh	15213	144 N Craig St	40.448692	-79.949737
29	US	PA	Pittsburgh	15213	159 N Bellefield Ave	40.447820	-79.952499
30	US	PA	Pittsburgh	15213	181 Robinson St	40.440045	-79.965665
31	US	PA	Pittsburgh	15213	190 N Craig St	40.449599	-79.950452
32	US	PA	Pittsburgh	15213	192 N Craig St	40.449637	-79.950478
33	US	PA	Pittsburgh	15213	195 N Craig St	40.449385	-79.950889
34	US	PA	Pittsburgh	15213	200 Lothrop St	40.441901	-79.960439
35	US	PA	Pittsburgh	15213	201 N Bellefield Ave	40.449673	-79.953070
36	US	PA	Pittsburgh	15213	201 N Dithridge St	40.449081	-79.952058
38	US	PA	Pittsburgh	15213	207 Atwood St	40.440937	-79.957285
39	US	PA	Pittsburgh	15213	207 S Craig St	40.446086	-79.948774
40	US	PA	Pittsburgh	15213	208 N Bellefield Ave	40.448804	-79.952914
41	US	PA	Pittsburgh	15213	209 Atwood St	40.440911	-79.957054
42	US	PA	Pittsburgh	15213	210 Oakland Ave	40.441240	-79.956704
43	US	PA	Pittsburgh	15213	212 Oakland Ave	40.440983	-79.956432
45	US	PA	Pittsburgh	15213	216 N Craig St	40.450384	-79.951077
46	US	PA	Pittsburgh	15213	216 Oakland Ave	40.441094	-79.956576
48	US	PA	Pittsburgh	15213	219 Atwood St	40.440709	-79.956804
49	US	PA	Pittsburgh	15213	222 Craft Ave	40.436481	-79.962566
51	US	PA	Pittsburgh	15213	228 Semple St	40.439543	-79.958173
52	US	PA	Pittsburgh	15213	229 Atwood St	40.440495	-79.956597
53	US	PA	Pittsburgh	15213	230 Lothrop St	40.442096	-79.961258
54	US	PA	Pittsburgh	15213	233 Atwood St	40.440366	-79.956581
55	US	PA	Pittsburgh	15213	233 Mckee Pl	40.439148	-79.958603
56	US	PA	Pittsburgh	15213	234 Mckee Pl	40.438966	-79.958583
57	US	PA	Pittsburgh	15213	234 Meyran Ave	40.439456	-79.957408
60	US	PA	Pittsburgh	15213	239 Atwood St	40.440264	-79.956398
37	US	PA	Pittsburgh	15213	201 S Craig St	40.446283	-79.948832
59	US	PA	Pittsburgh	15213	237 Atwood St	40.440297	-79.956437
61	US	PA	Pittsburgh	15213	242 Mckee Pl	40.438627	-79.958614
63	US	PA	Pittsburgh	15213	250 N Dithridge St	40.450401	-79.952564
64	US	PA	Pittsburgh	15213	253 Atwood St	40.439901	-79.956028
65	US	PA	Pittsburgh	15213	294 Craft Ave	40.435834	-79.961547
66	US	PA	Pittsburgh	15213	302 Atwood St	40.439476	-79.955911
67	US	PA	Pittsburgh	15213	303 S Craig St	40.445750	-79.948726
68	US	PA	Pittsburgh	15213	Fifth Ave & N Craig St	40.446959	-79.949017
69	US	PA	Pittsburgh	15213	305 S Craig St	40.445555	-79.948686
70	US	PA	Pittsburgh	15213	307 N Craig St	40.452130	-79.952198
71	US	PA	Pittsburgh	15213	310 N Craig St	40.452332	-79.952177
73	US	PA	Pittsburgh	15213	313 N Craig St	40.452172	-79.952365
74	US	PA	Pittsburgh	15213	3153 Forbes Ave	40.436676	-79.963763
75	US	PA	Pittsburgh	15213	317 S Craig St	40.445201	-79.948597
76	US	PA	Pittsburgh	15213	319 S Craig St	40.445132	-79.948636
77	US	PA	Pittsburgh	15213	320 Atwood St	40.439080	-79.955313
78	US	PA	Pittsburgh	15213	3235 Parkview Ave	40.430464	-79.953369
79	US	PA	Pittsburgh	15213	328 Atwood St	40.438961	-79.955124
80	US	PA	Pittsburgh	15213	3315 Hamlet St	40.436006	-79.962796
81	US	PA	Pittsburgh	15213	3333 Fifth Ave	40.438163	-79.963362
82	US	PA	Pittsburgh	15213	3333 Forbes Ave	40.437997	-79.962726
83	US	PA	Pittsburgh	15213	3360 Fifth Ave	40.438963	-79.962277
84	US	PA	Pittsburgh	15213	338 S Bouquet St	40.439978	-79.953346
85	US	PA	Pittsburgh	15213	3400 Fifth Ave	40.439147	-79.961902
86	US	PA	Pittsburgh	15213	3401 Boulevard of the Allies	40.436311	-79.958182
87	US	PA	Pittsburgh	15213	3402 Fifth Ave	40.439245	-79.961906
88	US	PA	Pittsburgh	15213	3404 Fifth Ave	40.439292	-79.961844
89	US	PA	Pittsburgh	15213	341 S Bellefield Ave	40.445093	-79.951246
90	US	PA	Pittsburgh	15213	3411 Boulevard of the Allies	40.435938	-79.958309
91	US	PA	Pittsburgh	15213	3417 Forbes Ave	40.439136	-79.960654
44	US	PA	Pittsburgh	15213	214 N Craig St	40.450315	-79.951035
92	US	PA	Pittsburgh	15213	3433 Bates St	40.436082	-79.956347
93	US	PA	Pittsburgh	15213	344 Atwood St	40.438566	-79.954868
94	US	PA	Pittsburgh	15213	3440 Forbes Ave	40.439386	-79.959845
95	US	PA	Pittsburgh	15213	3444 Forbes Ave	40.439456	-79.959744
96	US	PA	Pittsburgh	15213	3447 Dawson St	40.436076	-79.953160
97	US	PA	Pittsburgh	15213	3454 Bates St	40.436565	-79.955405
98	US	PA	Pittsburgh	15213	3455 Forbes Ave	40.439605	-79.959878
99	US	PA	Pittsburgh	15213	3459 Fifth Ave	40.440494	-79.960369
100	US	PA	Pittsburgh	15213	347 S Bouquet St	40.440002	-79.952789
101	US	PA	Pittsburgh	15213	3471 Fifth Ave	40.440244	-79.960582
102	US	PA	Pittsburgh	15213	3500 5th Ave	40.440329	-79.959924
103	US	PA	Pittsburgh	15213	3500 Forbes Ave	40.439746	-79.959422
104	US	PA	Pittsburgh	15213	3501 Forbes Ave	40.440102	-79.959473
105	US	PA	Pittsburgh	15213	3506 Fifth Ave	40.440626	-79.959718
106	US	PA	Pittsburgh	15213	3507 Cable Pl	40.436614	-79.953767
107	US	PA	Pittsburgh	15213	3516 Fifth Ave	40.440924	-79.959429
108	US	PA	Pittsburgh	15213	3524 Fifth Ave	40.441104	-79.959350
109	US	PA	Pittsburgh	15213	3526 Fifth Ave	40.441108	-79.959345
110	US	PA	Pittsburgh	15213	3529 Boulevard of the Allies	40.435021	-79.955848
111	US	PA	Pittsburgh	15213	352 Atwood St	40.438485	-79.954521
112	US	PA	Pittsburgh	15213	3600 Boulevard of the Allies	40.434429	-79.954404
114	US	PA	Pittsburgh	15213	3601 Fifth Ave	40.441163	-79.959343
116	US	PA	Pittsburgh	15213	3604 Forbes Ave	40.440704	-79.958121
117	US	PA	Pittsburgh	15213	3606 Fifth Ave	40.441433	-79.958914
118	US	PA	Pittsburgh	15213	3606 Forbes Ave	40.440668	-79.958046
119	US	PA	Pittsburgh	15213	3607 Forbes Ave	40.440856	-79.958149
120	US	PA	Pittsburgh	15213	3608 Fifth Ave	40.441491	-79.958828
122	US	PA	Pittsburgh	15213	3609 Forbes Ave	40.440896	-79.958095
123	US	PA	Pittsburgh	15213	3610 Fifth Ave	40.441487	-79.958670
124	US	PA	Pittsburgh	15213	3611 Forbes Ave	40.440854	-79.957987
125	US	PA	Pittsburgh	15213	3612 Forbes Ave	40.440800	-79.957863
126	US	PA	Pittsburgh	15213	3613 Forbes Ave	40.440936	-79.958041
127	US	PA	Pittsburgh	15213	3614 Fifth Ave	40.441544	-79.958586
130	US	PA	Pittsburgh	15213	3618 Forbes Ave	40.440978	-79.957649
131	US	PA	Pittsburgh	15213	3621 Forbes Ave	40.441064	-79.957849
132	US	PA	Pittsburgh	15213	3619 Forbes Ave	40.441017	-79.957916
133	US	PA	Pittsburgh	15213	362 Mckee Pl	40.437035	-79.956176
134	US	PA	Pittsburgh	15213	366 Atwood St	40.438118	-79.954311
135	US	PA	Pittsburgh	15213	370 Atwood St	40.438141	-79.954094
136	US	PA	Pittsburgh	15213	3700 Forbes Ave	40.441175	-79.957348
137	US	PA	Pittsburgh	15213	3703 Forbes Ave	40.441238	-79.957577
138	US	PA	Pittsburgh	15213	3707 Forbes Ave	40.441303	-79.957524
139	US	PA	Pittsburgh	15213	3708 Forbes Ave	40.441229	-79.957282
140	US	PA	Pittsburgh	15213	3710 Fifth Ave	40.442031	-79.958081
141	US	PA	Pittsburgh	15213	3710 Forbes Ave	40.441288	-79.957225
142	US	PA	Pittsburgh	15213	3712 Fifth Ave	40.442013	-79.958046
143	US	PA	Pittsburgh	15213	3712 Forbes Ave	40.441307	-79.957174
144	US	PA	Pittsburgh	15213	3713 Forbes Ave	40.441366	-79.957407
145	US	PA	Pittsburgh	15213	3714 Fifth Ave	40.442211	-79.957853
146	US	PA	Pittsburgh	15213	3714 Forbes Ave	40.441371	-79.957086
147	US	PA	Pittsburgh	15213	3715 Forbes Ave	40.441391	-79.957370
148	US	PA	Pittsburgh	15213	3716 Forbes Ave	40.441330	-79.956892
149	US	PA	Pittsburgh	15213	3718 Fifth Ave	40.442243	-79.957812
150	US	PA	Pittsburgh	15213	3719 Forbes Ave	40.441440	-79.957286
151	US	PA	Pittsburgh	15213	3721 Swinburne St	40.431718	-79.951943
152	US	PA	Pittsburgh	15213	3725 Forbes Ave	40.441580	-79.957124
153	US	PA	Pittsburgh	15213	3750 Childs St	40.429246	-79.951512
154	US	PA	Pittsburgh	15213	3800 Forbes Ave	40.441560	-79.956929
155	US	PA	Pittsburgh	15213	3801 Forbes Ave	40.441658	-79.956992
156	US	PA	Pittsburgh	15213	3803 Forbes Ave	40.441723	-79.956906
157	US	PA	Pittsburgh	15207	3803 Frazier St	40.425744	-79.949830
113	US	PA	Pittsburgh	15213	3600 Forbes Ave	40.440313	-79.957182
160	US	PA	Pittsburgh	15213	3909 Forbes Ave	40.442143	-79.956369
161	US	PA	Pittsburgh	15213	3911 Forbes Ave	40.442389	-79.956350
162	US	PA	Pittsburgh	15213	3939 Forbes Ave	40.442435	-79.955816
163	US	PA	Pittsburgh	15213	3945 Forbes Ave	40.442828	-79.954935
164	US	PA	Pittsburgh	15213	3953 Forbes Ave	40.442836	-79.954906
165	US	PA	Pittsburgh	15213	400 S Craig St	40.445132	-79.948880
166	US	PA	Pittsburgh	15213	400 Semple St	40.437009	-79.954953
167	US	PA	Pittsburgh	15213	4000 Fifth Ave	40.443793	-79.955682
168	US	PA	Pittsburgh	15213	4001 Fifth Ave	40.443180	-79.956573
169	US	PA	Pittsburgh	15213	401 Atwood St	40.438087	-79.953761
170	US	PA	Pittsburgh	15213	4022 Fifth Ave	40.443825	-79.955635
171	US	PA	Pittsburgh	15213	403 Semple St	40.437056	-79.954734
172	US	PA	Pittsburgh	15213	404 S Craig St	40.445078	-79.948896
173	US	PA	Pittsburgh	15213	404 Semple St	40.436788	-79.954860
174	US	PA	Pittsburgh	15213	410 Semple St	40.436837	-79.954717
175	US	PA	Pittsburgh	15213	4100 Bigelow Blvd	40.449223	-79.955581
58	US	PA	Pittsburgh	15213	235 Atwood St	40.440335	-79.956503
177	US	PA	Pittsburgh	15213	4125 Fifth Ave	40.443882	-79.955621
178	US	PA	Pittsburgh	15213	413 S Craig St	40.444845	-79.948637
179	US	PA	Pittsburgh	15213	413 Semple St	40.436990	-79.954397
180	US	PA	Pittsburgh	15213	414 Semple St	40.436734	-79.954607
176	US	PA	Pittsburgh	15213	411 S Craig St	40.444869	-79.948454
158	US	PA	Pittsburgh	15213	3810 Forbes Ave	40.441692	-79.956750
181	US	PA	Pittsburgh	15213	4141 Fifth Ave	40.443932	-79.955549
182	US	PA	Pittsburgh	15213	418 S Craig St	40.444677	-79.948729
183	US	PA	Pittsburgh	15213	416 S Craig St	40.444747	-79.948740
184	US	PA	Pittsburgh	15213	419 S Dithridge St	40.444755	-79.949947
185	US	PA	Pittsburgh	15213	4201 Bigelow Blvd	40.446175	-79.956509
186	US	PA	Pittsburgh	15213	424 Semple St	40.436407	-79.954484
234	US	PA	Pittsburgh	15213	4605 Centre Ave	40.452050	-79.951792
235	US	PA	Pittsburgh	15213	4601 Centre Ave	40.452024	-79.951910
259	US	PA	Pittsburgh	15213	117 Meyran Ave	40.440862	-79.958694
188	US	PA	Pittsburgh	15213	4415 Fifth Ave	40.446960	-79.950761
189	US	PA	Pittsburgh	15213	4609 Centre Ave	40.452104	-79.951642
191	US	PA	Pittsburgh	15213	4612 Forbes Ave	40.444076	-79.947921
192	US	PA	Pittsburgh	15213	4612 Henry St	40.446325	-79.948304
193	US	PA	Pittsburgh	15213	4615 Centre Ave	40.452299	-79.951524
194	US	PA	Pittsburgh	15213	4619 Centre Ave	40.452149	-79.951263
195	US	PA	Pittsburgh	15213	4627 Baum Blvd	40.454221	-79.952179
196	US	PA	Pittsburgh	15213	4632 Centre Ave	40.452163	-79.950745
198	US	PA	Pittsburgh	15213	4643 Baum Blvd	40.454331	-79.951903
199	US	PA	Pittsburgh	15213	4701 Fifth Ave	40.447199	-79.947133
200	US	PA	Pittsburgh	15213	4705 Centre Ave	40.452765	-79.949433
201	US	PA	Pittsburgh	15213	4720 Fifth Ave	40.447134	-79.946515
202	US	PA	Pittsburgh	15213	477 Melwood Ave	40.455920	-79.953527
203	US	PA	Pittsburgh	15213	4801 Centre Ave	40.453588	-79.947233
204	US	PA	Pittsburgh	15213	4905 Fifth Ave	40.447356	-79.943755
205	US	PA	Pittsburgh	15213	5000 Forbes Ave	40.444423	-79.942984
206	US	PA	Pittsburgh	15213	531 N Neville St	40.449735	-79.948300
208	US	PA	Pittsburgh	15213	4725 Centre Ave	40.453256	-79.949043
209	US	PA	Pittsburgh	15213	936 S Millvale Ave	40.453965	-79.947588
210	US	PA	Pittsburgh	15213	Bigelow & Clemente	40.441914	-79.950888
211	US	PA	Pittsburgh	15213	Cathedral of Learning	40.444245	-79.953107
212	US	PA	Pittsburgh	15213	Fifth Ave & Mckee Pl	40.440501	-79.960188
213	US	PA	Pittsburgh	15213	Fifth Ave & S Craig St	40.446959	-79.949017
214	US	PA	Pittsburgh	15260	Forbes Ave & Bigelow Blvd	40.443167	-79.953556
215	US	PA	Pittsburgh	15213	Forbes Ave & Halket St	40.438454	-79.961246
216	US	PA	Pittsburgh	15213	Forbes Ave & Meyran Ave	40.440555	-79.958349
217	US	PA	Pittsburgh	15213	1 Schenley Dr	40.439093	-79.947487
218	US	PA	Pittsburgh	15213		40.444597	-79.959838
219	US	PA	Pittsburgh	15213	University Dr	40.445052	-79.960964
221	US	PA	Pittsburgh	15213	331 S Bouquet St	40.440361	-79.953409
222	US	PA	Pittsburgh	15213	4609 Forbes Ave	40.444581	-79.948212
223	US	PA	Pittsburgh	15213	4607 Forbes Ave	40.444499	-79.948359
224	US	PA	Pittsburgh	15213	417 S Craig St	40.444606	-79.948579
225	US	PA	Pittsburgh	15213	415 S Craig St	40.444857	-79.948626
226	US	PA	Pittsburgh	15213	412 S Craig St	40.444860	-79.948855
228	US	PA	Pittsburgh	15213	311 S Craig St	40.445510	-79.948651
229	US	PA	Pittsburgh	15213	514 N Neville St	40.449859	-79.948526
230	US	PA	Pittsburgh	15213	4709 Centre Ave	40.452784	-79.949350
231	US	PA	Pittsburgh	15213	4635 Centre Ave	40.452294	-79.950808
227	US	PA	Pittsburgh	15213	406 S Craig St	40.445050	-79.948907
232	US	PA	Pittsburgh	15213	4613 Centre Ave	40.452133	-79.951537
233	US	PA	Pittsburgh	15213	4611 Centre Ave	40.452116	-79.951598
236	US	PA	Pittsburgh	15213	301 N Craig St	40.451949	-79.952193
237	US	PA	Pittsburgh	15213	306 N Craig St	40.452257	-79.952227
238	US	PA	Pittsburgh	15213	304 N Craig St	40.452264	-79.952130
239	US	PA	Pittsburgh	15213	4523 Centre Ave	40.451899	-79.952370
240	US	PA	Pittsburgh	15213	4521 Centre Ave	40.451876	-79.952454
241	US	PA	Pittsburgh	15213	257 N Craig St	40.451226	-79.951709
242	US	PA	Pittsburgh	15213	194 N Craig St	40.449664	-79.950634
243	US	PA	Pittsburgh	15260	221 Schenley Dr	40.442895	-79.953223
244	US	PA	Pittsburgh	15213	3807 Forbes Ave	40.441833	-79.956793
245	US	PA	Pittsburgh	15213	3805 Forbes Ave	40.441774	-79.956839
246	US	PA	Pittsburgh	15213	128 Oakland Ave	40.441645	-79.957179
247	US	PA	Pittsburgh	15213	3360 Forbes Ave	40.437939	-79.961937
248	US	PA	Pittsburgh	15213	3508 5th Ave	40.440606	-79.959544
249	US	PA	Pittsburgh	15213	3520 Forbes Ave	40.440250	-79.958591
250	US	PA	Pittsburgh	15213	416 Semple St	40.436539	-79.954730
251	US	PA	Pittsburgh	15213	418 Semple St	40.436629	-79.954481
252	US	PA	Pittsburgh	15213	3459 Ward St	40.436402	-79.954363
253	US	PA	Pittsburgh	15213	3510 Cable Pl	40.436432	-79.953890
254	US	PA	Pittsburgh	15213	449 Atwood St	40.437175	-79.952463
255	US	PA	Pittsburgh	15213	326 Atwood St	40.438918	-79.955306
256	US	PA	Pittsburgh	15213	260 Atwood St	40.439740	-79.956075
257	US	PA	Pittsburgh	15213	300 S Craig St	40.445608	-79.949142
258	US	PA	Pittsburgh	15213	120 Meyran Ave	40.440753	-79.958640
187	US	PA	Pittsburgh	15213	4400 Forbes Ave	40.443628	-79.950626
260	US	PA	Pittsburgh	15213	114 Meyran Ave	40.440847	-79.958761
261	US	PA	Pittsburgh	15213	3608 Forbes Ave	40.440723	-79.957973
220	US	PA	Pittsburgh	15213	3701 Forbes Ave	40.441302	-79.957679
263	US	PA	Pittsburgh	15213	223 Atwood St	40.440810	-79.957280
264	US	PA	Pittsburgh	15213	4200 Fifth Ave	40.444053	-79.953187
265	US	PA	Pittsburgh	15213	3524 Allequippa St	40.443533	-79.964778
266	US	PA	Pittsburgh	15213	3719 Terrace St	40.443061	-79.962273
267	US	PA	Pittsburgh	15206	130 S Whitfield St	40.461028	-79.926310
268	US	PA	Pittsburgh	15222	510 Market St	40.441433	-80.002053
269	US	PA	Pittsburgh	15238	423 Fox Chapel Rd	40.522379	-79.880476
270	US	PA	Pittsburgh	15213	4729 Ellsworth Ave	40.448258	-79.947676
271	US	PA	Pittsburgh			40.445617	-79.953664
272	US	PA	East Washington			40.171747	-80.234337
273	US	PA	West View	15229	386 Perry Hwy	40.517697	-80.030192
274	US	PA	Hopwood	15401	123 Buttermilk Ln	39.862400	-79.702163
275	US	PA	Pittsburgh	15213	3800 Forbes Ave	40.441560	-79.956929
276	US	PA	Pittsburgh	15213	209 Oakland Ave	40.441372	-79.956561
262	US	PA	Pittsburgh	15213	3610 Forbes Ave	40.440771	-79.957912
278	US	PA	Pittsburgh	15213	5200 Forbes Avenue	\N	\N
279	US	PA	Pittsburgh	15213	Forbes Ave and McKee Place	\N	\N
280	US	PA	Pittsburgh	15213	4836 Ellsworth Avenue	\N	\N
277	US	PA	Pittsburgh	15213	3347 Forbes Ave	40.438239	-79.961548
283	US	PA	Pittsburgh	15213	Forbes Avenue and Schenley Drive	\N	\N
284	US	PA	Pittsburgh	15213	4802 Fifth Ave	\N	\N
282	US	PA	Pittsburgh	15213	Forbes Avenue and Bouquet Street	\N	\N
285	US	PA	Pittsburgh	15213	3901 Forbes Avenue	\N	\N
286	US	PA	Pittsburgh	15213	122 Meyran Ave	\N	\N
281	US	PA	Pittsburgh	15213	3454 Forbes Ave	\N	\N
\.


--
-- Data for Name: places_place; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY places_place (id, dtcreated, name, location_id, description, hours, parking, phone, url, fb_id, twitter_username, listed, image) FROM stdin;
31	2012-04-11 17:28:53.70869-04	First Baptist Church	29	OUR COMMISSION: Through our worship, education and outreach we seek to fulfill the call of Matthew 28:19-20 to make disciples of all peoples and teach them to be faithful in following Christ.\n\nOUR AMBITION: As messengers of reconciliation (2 Corinthians 5:18-21) we trust that if we help remove barriers God can work the miracle of new life. We promote an atmosphere where differing ideas can be viewed and expressed freely.\n\nOUR POSITION: As a "house of prayer for all peoples" (Isaiah 56:7) we carry out our ministry in Oakland to people of diverse racial, cultural, and language backgrounds\n\nOUR AFFILIATION is with the American Baptist Churches, USA.			(412) 621-0500	http://www.first-baptist-pittsburgh.org	108697855875679		t	img/p/wgaH0C.jpg
1	2012-04-11 17:28:26.213807-04	Holiday Inn Select – University Center	1	251 Guest Rooms, 100% non-smoking hotel, Comp shuttle within 3 mi radius excluding downtown			(412) 682-6200	www.holidayinn.com	130664376946254		t	img/p/U_SrjW.jpg
10	2012-04-11 17:28:33.373768-04	Hocus Pocus	10	Hocus Pocus offers a complete line of Esoteric supplies for the Magickal practitioners of Witchcraft, Wicca, Ceramonial Magick, Voodoo, Druidry, Shamanism, Hermetic Alchemy, Yoruban Religions, Herbalism, Aromatherapy, Astrology, Kameticism, (Egyptian) Chaos Magick, Kabbalistic studies and Left Hand Path. Our freindly, knowledgeable staff is available to assist you in answering any questions that you might have while shopping. Phone orders are warmly welcomed. Hocus Pocus is stocked with an extensive variety of Magickal Tools including; chalices, wands, athames, swords, altar pentacles, candles, herbs, oils, incense, talismans, pendulumns, scrying mirrors, bells, cauldrons, besoms, statuary, tarot decks, crystal balls, books, burners, quartz crystals, gemstones and much more.			(412) 622-0113	http://www.hocuspocus13.net/store.html			t	img/p/ap3EXw.jpg
2	2012-04-11 17:28:27.295115-04	Community of Reconcilation	2				(412) 682-2751				t	
3	2012-04-11 17:28:27.677687-04	Schenley Park Visitor's Center	3	Out and about in the park and feeling hungry?? Stop in and enjoy something off our fresh menu, which has lunch items sure to please any palette!\nNo time to sit and enjoy the fabulous view? Grab a giant cookie and hit the trails! We're located just above the steps to the Panther Hollow trails!\n\nFeel free to bring your computer and enjoy our complimentary WIFI!	Mon-Sun,10:00am - 04:00pm\n	street\n	(412) 687-1800	http://www.pittsburghparks.org/schenleyparkcafe	205974802752877		t	img/p/kAwIVO.jpg
4	2012-04-11 17:28:28.828819-04	H & R Block	4				(412) 681-2797	www.hrblock.com			t	img/p/RnWnEY.jpg
5	2012-04-11 17:28:29.776937-04	Pittsburgh Science and Technology Academy	5				(412) 622-5980	http://www.pps.k12.pa.us/frick/site/default.asp			t	
32	2012-04-11 17:28:54.809849-04	Friendship Community Presbyterian Church	30	In general, Friendship Church are people who have an earnest desire to be obedient followers of our Lord and Savior, Jesus Christ. Among our individual and corporate gifts the following stand out: faithfulness, courage, wisdom, discernment, service, worship, hospitality, generosity, administration, teaching, knowledge, honesty, hope and above all, love.			(412) 683-0575				t	img/p/E0urMT.gif
6	2012-04-11 17:28:30.060922-04	St. Paul Cathedral Rectory	6	<p>The <b>Cathedral of Saint Paul</b> (commonly known as <b>Saint Paul Cathedral</b>) is the <a href="http://en.wikipedia.org/wiki/Mother_church">mother church</a> of the <a href="http://en.wikipedia.org/wiki/Roman_Catholic">Roman Catholic</a> <a href="http://en.wikipedia.org/wiki/Diocese">Diocese</a> of <a href="http://en.wikipedia.org/wiki/Pittsburgh">Pittsburgh</a>, <a href="http://en.wikipedia.org/wiki/Pennsylvania">Pennsylvania</a>, <a href="http://en.wikipedia.org/wiki/United_States">United States</a>. It should not be confused with <i><a href="http://en.wikipedia.org/wiki/St_Paul's_Cathedral">St Paul's Cathedral</a></i> in the <a href="http://en.wikipedia.org/wiki/City_of_London">City of London</a>, <a href="http://en.wikipedia.org/wiki/England">England</a>.</p><p>It is the center of spiritual life for some three thousand parishioners and more than three quarter million Catholics in the <a href="http://en.wikipedia.org/wiki/Roman_Catholic_Diocese_of_Pittsburgh">Diocese of Pittsburgh</a>.</p><p>The first place of public worship for Catholics in the area was in 1754 in the <a href="http://en.wikipedia.org/wiki/Feedlot">stockyard</a> of <a href="http://en.wikipedia.org/wiki/Fort_Duquesne">Fort Duquesne</a>. From the date of the French evacuation of the fort in 1758 until a church was started in 1808 at the corner of Liberty and Washington Streets, there were no resident priests, but mass was occasionally said in private homes by missionaries traveling west. When the Diocese of Pittsburgh was formed in 1843, Saint Paul's Church at the corner of Fifth and Grant Street was consecrated as a Cathedral. Because of declining downtown population and industrial pollution, this site was sold to <a href="http://en.wikipedia.org/wiki/Henry_Clay_Frick">Henry Clay Frick</a>. A new Cathedral was opened in 1906 at its present location on Fifth Avenue in the <a href="http://en.wikipedia.org/wiki/Oakland_(Pittsburgh)">Oakland</a> neighborhood of Pittsburgh.</p><p>The original cost of the building and furnishings was nearly 1.1 million dollars, including $205,000 for the real estate.</p>			(412) 621-4951		214787775231464		f	img/p/FNgKni.gif
34	2012-04-11 17:28:56.22692-04	Alex's Flowers	32	In 1983, I started Alex's Flowers as a street corner vendor. My goal was to sell fresh and long lasting flowers at a reasonable price. Today, in my store (corner of Craig & Bayard), the goal is still the same. I employ a courteous and knowledgeable staff. Alex's Flowers is a full service florist specializing in flowers, plants, balloons, fruit, munch and gourmet baskets. Same day delivery is available to most destinations.			(412) 687-4128	http://www.alexsflowers.com/			t	img/p/Ml0sZP.jpg
33	2012-04-11 17:28:55.480171-04	Pizza Prima	31				(412) 687-6464				t	img/p/PizzaPrima.jpg
8	2012-04-11 17:28:32.116001-04	Jazz Cuts	8				(412) 561-8809				t	img/p/MinsJazzCuts.jpg
9	2012-04-11 17:28:32.991827-04	Natural Choice	9	We at The Natural Choice are and always will be dedicated to the process of the un-processing your beautiful natural hair. No longer are the days of conforming to the so-called established way of wearing our hair. We are now in a time when we can be proud of every god given natural strand of hair that we possess. Come and let our Natural hair specialists consult with you and show you the endless list of options that you have when going natural. Brothas & Sistas come and explore all of the possibilities of your beautiful natural hair.			(412) 681-7746				t	img/p/hijRcr.jpg
35	2012-04-11 17:28:56.9922-04	Sunoco A-Plus Mini Market	33				(412) 687-7554	www.sunoco.com			t	
36	2012-04-11 17:28:57.296723-04	UPMC Presbyterian	34				(412) 647-2345	www.upmc.edu			t	
240	2012-04-11 17:32:09.64023-04	Culture Shop	227								t	img/p/CultureShop.jpg
239	2012-04-11 17:32:08.862791-04	Yuva India	226								t	img/p/YuvaIndia.jpg
241	2012-04-11 17:32:11.4277-04	Phantom of the Attic	176		Mon-Tues,10:00am - 07:00pm\nWed,10:00am - 08:00pm\nThurs-Sat,10:00am - 07:00pm\nSun,10:00am - 05:00pm\n	street\n	412 621 1210	this,	270567764926		t	img/p/9l3UzC.jpg
242	2012-04-11 17:32:12.348548-04	Oakland Fashion Optical	228	There's only one Oakland Fashion Optical!!!	Mon,10:00am - 05:30pm\nTues,10:00am - 07:00pm\nWed,10:00am - 05:30pm\nThurs,10:00am - 07:00pm\nFri,10:00am - 05:30pm\nSat,10:00am - 05:00pm\nSun,Closed\n	street\nlot\n	412-621-2523	www.oaklandfashionoptical.com	388367546182		t	img/p/rYOr_i.jpg
243	2012-04-11 17:32:13.400196-04	Little Asia	67								t	img/p/LittleAsia.jpg
37	2012-04-11 17:28:57.591377-04	Western PA School for the Blind	35	Located in the heart of Oakland, Pennsylvania, the Western Pennsylvania School for Blind Children is a one-of-a-kind educational facility committed to training visually impaired students with additional disabilities. The School also provides vital early intervention and outreach services to visually impaired students, with or without additional challenges, throughout western Pennsylvania.			(412) 621-0100	http://www.wpsbc.org/wpsbc/site/default.asp			t	img/p/JcT_pi.jpg
46	2012-04-11 17:29:06.025902-04	Gregory's Hair Design	44				(412) 682-1191				t	
38	2012-04-11 17:28:58.625471-04	First Church of Christ Scientist	36				(412) 621-5339	http://www.christiansciencepgh.org/	118316171513854		t	img/p/jgEwKs.jpg
11	2012-04-11 17:28:34.157913-04	Pizza Sola	11	real. good. pizza.\nGiant slices and delicious specialty pizzas all made with the finest ingredients!\nAlso known for their garlic knots, Solazones, wings, salads, dessert pizzas, and drinks.\n\n4 Locations:\nOakland - 114 ATWOOD STREET PITTSBURGH, PA 15213\nEast Side - 6004 PENN CIRCLE S. PITTSBURGH, PA 15206\nSouth Side - 1417 E. CARSON STREET PITTSBURGH, PA 15203\nCranberry - 20012 ROUTE 19 (OAK TREE PLACE) CRANBERRY, PA 16066\n\nLegal:\n\nThe Pizza Sola Fan page is a fun, interactive friendly community for fans to share their thoughts, comments, ideas and stories to engage with those who share similar values and interests and to build up an ongoing dialogue.\n \nWhile we’re excited to hear from you, it’s important to note that postings to this Facebook page are not representative of the opinions of Maniac Exchange or the Pizza Sola Management group, nor do we confirm their accuracy.\n \nAs part of our commitment to you, we’ll do our best to ensure the postings on our page are in line with the companies philosophies. However, we can’t monitor every posting or conversation, Maniac expects that users will not post content that falls into the following categories and reserves the right to remove postings that are:\n \n- Abusive, defamatory, or obscene\n- Fraudulent, deceptive or misleading\n- In violation of any intellectual property right of another\n- In violation of any law or regulation\n- Otherwise offensive\n- Suggestive of new product innovations or advertising ideas	Mon-Thurs,11:00am - 12:00am\nFri,11:00am - 03:00am\nSat,11:30am - 03:00am\nSun,12:30pm - 12:00am\n	street\n	(412) 681-7652	http://www.pizzasola.com/	349097652916		t	img/p/F8wT02.jpg
12	2012-04-11 17:28:35.234633-04	Sweet Berry Frozen Yogurt	12	WELCOME !\nSweet Berry offers \n          perfectly sweet & tart nonfat natural frozen yogurt.\n  \nWith your choice of 16 toppings from fresh fruity to sweet crunchy,   \nSweet Berry’s nonfat natural frozen yogurt is a healthy alternative \nwith no fat or preservatives and low in sugar –  a unique indulgence \nthat’s  sweet yet light enough to enjoy any time of day.\n\nSweet Berry also offers \n    delightful fruit smoothies & blend and fresh brewed coffee.\nSmoothies are custom blended with seasonal fruits, frozen yogurt, \nand ice. Seattle’s Best Coffee – uncommonly smooth.\n\nAlso, try our new summer menu: Pat-Bing-Su!		street\n	(412) 235 7623	http://www.sweetberryus.com/index.html	140995945974331		t	img/p/BgaI5K.jpg
13	2012-04-11 17:28:36.330815-04	Hot Rod Piercing	13	Hot Rod Piercing Co. has been providing the city of Pittsburgh with the most experienced piercing staff and only the best quality body jewelry available for ten years now. We use only the most up to date methods to insure that both your piercing experience and your healing experience are successful.			(412) 687-4320	http://www.hotrodpiercingcompany.com/			t	img/p/cKI15g.jpg
20	2012-04-11 17:28:44.212907-04	Oishii Bento	19	At Oishii Bento, we create authentic Korean/Japanese cuisine with a focus on health and well being. \n\n119 Oakland Ave. \nPittsburgh, PA 15213 \n412-687-3335\n\nM-F 10:30am-9pm \nSat 11am-10pm\n\nhttp://oishiibento.com/	Mon-Fri,10:30am - 09:00pm\nSat,11:00am - 09:00pm\nSun,Closed\n	street\nlot\n	(412) 687-3335	http://oishiibento.com/	128620450510669		t	img/p/7_sV5N.jpg
14	2012-04-11 17:28:37.033368-04	Hair Friends	14				(412) 681-9243				t	
25	2012-04-11 17:28:48.045816-04	Peter's Optical Shoppe	23				(412) 681-8913				t	img/p/PetersOpticalShoppe.jpg
21	2012-04-11 17:28:45.166311-04	St. Agnes Roman Catholic Church	20				(412) 682-1129				t	
16	2012-04-11 17:28:38.443828-04	Crazy Mocha	15	Pittsburgh's favorite place for coffee and desserts!  Locally owned by life long Pittsburgher's.  \n\nFor information on any of our 27 stores, visit www.crazymocha.com.			(412) 621-7440	http://www.crazymocha.com/	127771128936		t	img/p/Y4q8Xo.jpg
17	2012-04-11 17:28:39.396956-04	Hot Tips	16				(412) 682-3105				t	img/p/HotTipsNailSalon.jpg
22	2012-04-11 17:28:45.440664-04	St. Agnes School	20				(412) 682-1129	http://www.stagnesoakland.org/site/			f	
18	2012-04-11 17:28:40.892595-04	Five Guys Burgers and Fries	17	Burgers, Fries, Hot Dogs.  15 Free Toppings.  Check our website for new locations: www.fiveguys.com  Don't forget to follow us on Twitter: @Five_Guys			(412) 781-5590	http://www.fiveguys.com/home.aspx	19836964440		t	img/p/llKQgN.jpg
30	2012-04-11 17:28:52.418764-04	Oakland Catholic High School	28				(412) 682-6633	http://www.oaklandcatholic.org/	194864157210632		t	img/p/NwPIFn.jpg
26	2012-04-11 17:28:48.729526-04	Szechuan Express	24				(412) 670-0126				t	img/p/SzechuanExpress.jpg
19	2012-04-11 17:28:43.062183-04	Peace, Love and Little Donuts	18	We are now Open  Mon- Fri   6am to 7pm     Sat-Sun  11am to 4pm	Mon-Fri,06:00am - 06:00pm\nSat-Sun,11:00am - 04:00pm\n		(412) 379-3930	http://www.peaceloveandlittledonuts.com/	168172703239295		t	img/p/wEojbM.jpg
23	2012-04-11 17:28:45.750251-04	Leena's Food	21		Mon-Thurs,10:00am - 10:00pm\nFri-Sat,10:00am - 03:00am\nSun,Closed\n	street\n	(412)-480-8854		59693855755		t	img/p/eE3Ygj.jpg
29	2012-04-11 17:28:51.415587-04	St. Paul's Cathedral School	27	<p>The <b>Cathedral of Saint Paul</b> (commonly known as <b>Saint Paul Cathedral</b>) is the <a href="http://en.wikipedia.org/wiki/Mother_church">mother church</a> of the <a href="http://en.wikipedia.org/wiki/Roman_Catholic">Roman Catholic</a> <a href="http://en.wikipedia.org/wiki/Diocese">Diocese</a> of <a href="http://en.wikipedia.org/wiki/Pittsburgh">Pittsburgh</a>, <a href="http://en.wikipedia.org/wiki/Pennsylvania">Pennsylvania</a>, <a href="http://en.wikipedia.org/wiki/United_States">United States</a>. It should not be confused with <i><a href="http://en.wikipedia.org/wiki/St_Paul's_Cathedral">St Paul's Cathedral</a></i> in the <a href="http://en.wikipedia.org/wiki/City_of_London">City of London</a>, <a href="http://en.wikipedia.org/wiki/England">England</a>.</p><p>It is the center of spiritual life for some three thousand parishioners and more than three quarter million Catholics in the <a href="http://en.wikipedia.org/wiki/Roman_Catholic_Diocese_of_Pittsburgh">Diocese of Pittsburgh</a>.</p><p>The first place of public worship for Catholics in the area was in 1754 in the <a href="http://en.wikipedia.org/wiki/Feedlot">stockyard</a> of <a href="http://en.wikipedia.org/wiki/Fort_Duquesne">Fort Duquesne</a>. From the date of the French evacuation of the fort in 1758 until a church was started in 1808 at the corner of Liberty and Washington Streets, there were no resident priests, but mass was occasionally said in private homes by missionaries traveling west. When the Diocese of Pittsburgh was formed in 1843, Saint Paul's Church at the corner of Fifth and Grant Street was consecrated as a Cathedral. Because of declining downtown population and industrial pollution, this site was sold to <a href="http://en.wikipedia.org/wiki/Henry_Clay_Frick">Henry Clay Frick</a>. A new Cathedral was opened in 1906 at its present location on Fifth Avenue in the <a href="http://en.wikipedia.org/wiki/Oakland_(Pittsburgh)">Oakland</a> neighborhood of Pittsburgh.</p><p>The original cost of the building and furnishings was nearly 1.1 million dollars, including $205,000 for the real estate.</p>			(412) 621-7023		214787775231464		t	img/p/APtsJE.gif
24	2012-04-11 17:28:47.053645-04	University Club	22	The University Club offers elegant event spaces, breathtaking views of the historic Cathedral of Learning and intimate spaces customizable especially for you.  The Club has been meticulously restored to its 1923 splendor featuring a grand spiral staircase and crystal chandeliers creating an exquisite setting to capture your most important day. Lavishly appointed ballrooms and an intimate rooftop terrace space blends old-world elegance with a modern flair, making the Club the quintessential Pittsburgh event location.  \nOur event consultants provide extraordinary personal service and attention to detail to ensure a flawless day!			(412) 621-1890	http://www.uc.pitt.edu/	286911998047051		t	img/p/VuIzoz.jpg
27	2012-04-11 17:28:50.456854-04	Citizens Bank	25				(412) 621-3344	www.citizensbank.com			t	img/p/J9EvXZ.jpg
255	2012-04-11 17:32:24.745999-04	Unique Impressions Hair Salon	237								t	img/p/UniqueImpressionsHairSalon.jpg
39	2012-04-11 17:28:59.793888-04	Oliverio Hair & Nails	37				(412) 681-4666				t	img/p/OliverioHair.jpg
47	2012-04-11 17:29:06.330658-04	Little Nipper's Pizza	45				(412) 683-3777				t	img/p/LittleNippers.jpg
40	2012-04-11 17:29:00.492881-04	Dave & Andy's Ice Cream	38	A Pittsburgh staple since 1983. Featuring over 200 flavors of homemade ice cream and hand rolled waffle cones.	Mon-Fri,11:30am - 10:00pm\nSat-Sun,12:00pm - 10:00pm\n	street\n	(412) 681-9906		183840534624		t	img/p/cg8xeC.jpg
41	2012-04-11 17:29:01.453719-04	Crepes Parisiennes	39				(412) 683-1912				t	img/p/CrepesParisiennes.jpg
48	2012-04-11 17:29:06.943017-04	Oakland Real Estate Co.	46				(412) 621-2742				t	
42	2012-04-11 17:29:03.35582-04	Small Business Development Cntr.	40	he mission of the Small Business Development Center at the University of Pittsburgh is to grow the economy of Western Pennsylvania by providing entrepreneurs with the education, information and tools necessary to build successful businesses.			(412) 648-1544				t	img/p/AHXONp.jpg
43	2012-04-11 17:29:03.868767-04	Rite Aid	41				(412) 621-4338	www.riteaid.com			t	img/p/5rwTsx.jpg
56	2012-04-11 17:29:14.868957-04	Sorrento's Pizza	54				(412) 621-9129				t	img/p/SorrentosPizza.jpg
44	2012-04-11 17:29:04.357128-04	Uncle Sam's Subs	42	Uncle Sam's is a friendly little joint that makes some of the best sandwiches in the universe. If you don't believe us, check out our reviews. Over the last twenty-five years we have won just about every "best of" award there is to win. Our secret is pretty simple. Unlike those big corporate places, we are owner-operated. That means that usually the guy cooking your food actually owns the place. Plus, we use only the best local ingredients which we have delivered fresh daily. Oh yeah, we're nicer too. Not in the canned "by the manual" sort of way. More in the treat you like a real person sort of way. No big deal really, but we like to let you know we actually appreciate you coming in to eat.			(412) 621-1885	http://www.unclesamssubs.com/			t	img/p/UncleSamsSubs.jpg
45	2012-04-11 17:29:05.107985-04	Fuel & Fuddle	43	It should be noted, Fuel has its first girl 500 mug cult member...Congrats Elizabeth	Mon-Sun,11:00am - 01:00am\n	street\nlot\n	(412) 682-3473	http://www.fuelandfuddle.com/	52775066304		t	img/p/KyqMw0.jpg
61	2012-04-11 17:29:19.532054-04	Oakland Community Council	58	Oakland Community Council was created in 1995 to assist residents in participating in the University of Pittsburgh’s Master Plan process. Since its inception, Oakland Community Council has represented the needs of residents to the City and the institutions.  More and more the City Planning department has directed developers to sit down with the Oakland Community Council to discuss their plans before proceeding with construction.  Oakland Community Council’s goal is to improve the over all quality of life in Oakland.			(412) 687-8568				t	
50	2012-04-11 17:29:07.866643-04	Pizza Romano	48				(412) 621-6200				t	img/p/PizzaRomano.jpg
57	2012-04-11 17:29:15.988832-04	Family House	55	Family House, a non-profit organization in Pittsburgh, PA, provides a special "home away from home" for patients and families who are in Pittsburgh for treatment of serious or life-threatening illnesses.			(412) 647-7777	http://www.familyhouse.org/	306452702240		t	img/p/pkU9VK.jpg
51	2012-04-11 17:29:08.922182-04	Pittsburgh Playhouse	49	The Pittsburgh Playhouse is home to The REP, a professional theatre company, and three student companies: Conservatory Theatre Company, Conservatory Dance Company and Playhouse Jr.		lot\n	(412) 621-4445	http://www.pittsburghplayhouse.com/	125166184463		t	img/p/Lx_hU0.jpg
58	2012-04-11 17:29:16.951491-04	United Jewish Federation	56	At the Heart of Jewish Giving			(412) 681-8000	http://www.jewishfederationpittsburgh.org/	143774118973435		t	img/p/8qeFlw.jpg
53	2012-04-11 17:29:10.550619-04	Tong's Cuisine	51				(412) 918-1484	www.tongscuisine.com/			t	img/p/TongsCuisine.jpg
62	2012-04-11 17:29:19.803565-04	Oakland Planning and Development Corporation	58	OPDC is a nonprofit community development corporation in Pittsburgh, PA that engages in planning and development activities to contribute to the vitality of Oakland.	8:30am-5pm,Mon-Fri\n	street\n	(412) 621-7863	http://www.opdc.org/	281919830556	oaklandplanning	t	img/p/_BhsDB.jpg
54	2012-04-11 17:29:12.292678-04	Oakland General Store	52				(412) 683-0313		220336147980324		t	img/p/5bkkjf.jpg
59	2012-04-11 17:29:18.01975-04	New Oakland Tailor	57				(412) 682-8028				t	img/p/NewOaklandTailor.jpg
55	2012-04-11 17:29:13.394132-04	Eye & Ear Institute	53	This site is for anyone interested in UPMC Eye Center's services, research and events.			(412) 647-2345	www.upmc.edu	128933303885916		t	img/p/tdE3pA.jpg
65	2012-04-11 17:29:23.221641-04	Pittsburgh Parks Conservancy	61	Nurturing Nature. Planting Possibility.			(412) 682-7275	http://www.pittsburghparks.org/	7163241268		t	img/p/oXGyqd.jpg
64	2012-04-11 17:29:22.017525-04	The Black Bean	60	Cuban Sandwiches, Dinners, Wraps, Burgers & much more!			(412) 621-2326	http://www.blackbeancc.com/	172453829465490		t	img/p/ZfC68F.jpg
63	2012-04-11 17:29:20.795252-04	Puccini's	59	2011 is busy busy! call before ya swing by :)  Oakland-412-621-2087 and Cranberry- 724-776-1521			(412) 621-2087	www.twitter.com/salpuccini	163329138211		t	img/p/wGfNB5.jpg
67	2012-04-11 17:29:24.92484-04	Church of Jesus Christ of Latter Day Saints	63				(412) 802-6086				t	
68	2012-04-11 17:29:25.211473-04	Spice Island Tea House	64	Cuisine of Southeast Asia in a funky, festive atmosphere, featuring an eclectic selection of wines, beers, and loose teas.	Mon-Thurs,11:30am - 09:00pm\nFri-Sat,11:30am - 10:00pm\nSun,Closed\n	street\n	(412) 687-8821	http://www.spiceislandteahouse.com/Homepage.html	144419906007		t	img/p/KOGR_Y.jpg
69	2012-04-11 17:29:26.205079-04	Bombay Emporium	65				(412) 682-4965				t	
70	2012-04-11 17:29:26.492004-04	Joe Bellisario Barber	66				(412)681-9725				t	img/p/JoeBellisarioBarber.jpg
82	2012-04-11 17:29:39.949126-04	St. Regis Parish	78	We are a vibrant, multi-lingual parish located in the heart of lower Oakland in Pittsburgh, Pennsylvania.  The Parish of St. Regis is conveniently located near the campuses of the University of Pittsburgh and Carnegie-Mellon University.  Our multi-cultural heritage is celebrated with masses offered in English and Spanish on a regular basis, with special masses in Italian and Polish. 			(412) 681-9365				t	img/p/DE0pko.jpg
71	2012-04-11 17:29:27.823877-04	Irish Design Center	67	Established in 1978, Irish Design Center offers a unique collection of directly imported knitwear, clothing, gifts and jewelry from Ireland and Scotland. We pride ouselves on a reputation for quality products, great prices and friendly service.	Mon-Sat,10:00am - 05:30pm\nSun,Closed\n	street\nlot\n	(412) 682-6125	http://www.irishdesigncenter.com/mysitecaddy/site3/	141800975864810		t	img/p/yqVafX.jpg
83	2012-04-11 17:29:40.607702-04	India Garden	79	India Garden has mastered the art of Indian cooking and it is this mastery we offer to you. Please check our huge lunch buffet and our happy hour 50% off diners. Large selection of Indian beers from our full bar.			(412) 682-3000	www.indiagarden.com			t	img/p/IndiaGarden.jpg
72	2012-04-11 17:29:29.009621-04	The Renaissance & Baroque Society of Pittsburgh	68	Renaissance and Baroque brings the best in Early Music to Pittsburgh from around the world.  Versatile, virtuostic musicians on original instruments playing historically informed music makes for a joyful evening!			(412) 682-5253	http://www.rbsp.org/	55075526512		t	img/p/DCmk4m.jpg
175	2012-04-11 17:31:03.422928-04	University Book Center	167	Your one-stop shop for all things Pitt and more.			(412) 648-1455	http://www.pitt.edu/~bookctr/	182302828453071		t	img/p/Os5u5F.jpg
86	2012-04-11 17:29:44.859249-04	Allegheny County Health Dept.	82	Founded in 1957, the Allegheny County Health Department is charged with protecting the environmental and public health of 1.2 million County residents through Pennsylvania Act 315 , the Local Health Administration Law.	Mon-Fri,08:00am - 04:30pm\nSat-Sun,Closed\n		(412) 687-ACHD	www.achd.org	119535718114755		t	img/p/RQvLeT.jpg
73	2012-04-11 17:29:30.010599-04	Eat Unique	69	Cafe serving a wide selection of sandwiches, salads,homemade soups and pastries. Many vegetarian offerings.  Catering services also available.	Mon-Sun,11:00am - 08:00pm\n	street\n	(412) 683-9993	http://www.eatuniquecafe.com/	110803379044947		t	img/p/m2puh2.jpg
74	2012-04-11 17:29:31.3138-04	Chief's Cafe	70				(412) 683-2936				t	img/p/ChiefsCafe.jpg
84	2012-04-11 17:29:42.402491-04	Hampton Inn	80	Our hotel is conveniently located near the University of Pittsburgh, Carnegie Mellon University, Point Park University, Duquesne University, Carlow University, and Robert Morris University. We are located within walking distance to Magee, Montefiore, and Presbysterian hospitals, along with the Eye & Ear Institute. We offer a free shuttle service within three miles, free wifi, and a free hot breakfast buffet. We are located in Oakland, just two miles from downtown, and we were renovated in 2010.	Mon-Sun,12:00am - 12:00pm\n	lot\n	(412) 681-1000	www.hamptoninn.com	109837018770		t	img/p/kp02LT.jpg
75	2012-04-11 17:29:32.00757-04	Thrifty Cleaners	71				(412) 687-0114				t	img/p/ThriftyCleaners.jpg
87	2012-04-11 17:29:45.902873-04	Job Links	83	JobLinks, a program of Oakland Planning and Development Corporation (OPDC), is a community-based, job readiness, healthcare employment and CPR certification and training center. JobLinks was founded in 1989, when the OPDC board recognized that the economic development taking place in and around Oakland was an opportunity for workforce solutions, and that area residents would need training and certifications to take advantage of the employment opportunities. Through a collaborative effort with Breachmenders Ministries Inc., JobLinks was born. Although based in Oakland, JobLinks has no geographic boundaries and offers services to job-seekers and employers from throughout Pittsburgh.			(412) 621-3821				t	
77	2012-04-11 17:29:33.685662-04	Craig Beer Distributor	73				(412) 621-7200				t	img/p/CraigBeerDistributor.jpg
85	2012-04-11 17:29:43.525631-04	Carlow University	81	Carlow University was founded by the Sisters of Mercy in 1929. Offering both undergraduate and graduate programs, Carlow University is a comprehensive master's institution dedicated to learner-centered education.		street\nlot\n	(412) 578-6000	http://www.carlow.edu/	36137667182		t	img/p/chTW7E.jpg
78	2012-04-11 17:29:35.47873-04	Pittsburgh Pretzel Sandwich Shop	74		Mon,10:00am - 05:00pm\nTues,11:00am - 06:00pm\nWed,10:00am - 05:00pm\nThurs,11:00am - 06:00pm\nFri,10:00am - 05:00pm\nSat,12:00pm - 05:00pm\nSun,Closed\n	street\n	(412) 235-7807	http://www.pittsburghpretzel.com/	194193045351		t	img/p/tmdMHf.jpg
93	2012-04-11 17:29:49.592442-04	Board of Public Education	89	Pittsburgh Public Schools is the largest of 43 school districts in Allegheny County and the second largest in Pennsylvania. We serve approximately 25,000 students in Kindergarten through Grade 12 in 59 schools. In addition, Early Childhood programs serve three- and four-year-olds in classrooms across the city.\n\nWe believe that every child—at every level of academic performance—can achieve excellence. Only by focusing on what we can best control – improving performance at every level of the organization – can we honor our obligation to prepare every student to take maximum advantage of The Pittsburgh Promise ® while also preparing our public school system to be better able to thrive in an era of unprecedented competition.\n\nSince the introduction of our Excellence for All reform agenda in 2006, we have put in place key elements to improve student achievement, including:\n-a rigorous new PreK-12 curriculum; \n-a nationally recognized program to recruit, train, support and compensate \n-principals as instructional leaders; and \n-expanded early childhood offerings so a child's school experience gets off to a better start when transitioning to Kindergarten.\n\nThe good news is that our Excellence For All reform efforts are showing promising results for all of our children. In 2011, Pittsburgh Public Schools made Adequate Yearly Progress (AYP) for the second time in the past three years. Making AYP twice is a formidable accomplishment for an urban school district in just nine years since the federal No Child Left Behind Act (NCLB) was signed into law in January 2002. As a result, the District will move into Making Progress status under NCLB for the 2011-12 school year. Achieving AYP means that the District met all of its targets on each of three standards – high school graduation, test participation and academic performance. \n\nIn terms of academic performance, results from the 2011 Pennsylvania System of School Assessment (PSSA) show that more District students are on track to Promise-Readiness as gains in reading and mathematics proficiency increased on 11 of 14 tests. The number of students performing at the advanced level increased on 10 of 14 tests, while the number of students performing below basic decreased on 13 of 14 PSSA tests. \n\nAccording to Superintendent Linda Lane, the District's overarching goal is to get students Promise-Ready and prepared for success after graduation, “We know that significant progress doesn't happen overnight. While the PSSA results offer evidence that our efforts to improve academic performance are taking hold, we also know that the only way more of our students will become Promise-Ready is if we remain committed to our work to ensure that an effective teacher is in every classroom, every day.” \n\nOver the past four years, the percent of students scoring proficient or advanced has increased on all 14 PSSA exams. While evidence indicates that current reforms are working, the District remains committed to being a continuous learning organization that will making adjustments based on data and results.\n\nIf you are new to Pittsburgh, you're moving to a new neighborhood, or your child is entering Pittsburgh Public Schools for the first time, visit the Registration/Enrollment page on the District's website www.pps.k12.pa.us.\n\nIf you need additional help, please use Contact Us or call the Parent Hotline at 412-622-7920.			(412) 622-3770	http://www.pghboe.net/pps/site/default.asp	294241040320		t	img/p/FCkMin.jpg
88	2012-04-11 17:29:46.192532-04	Salem's Halal Meat Grocery	84				(412) 621-4354		110939620161		t	img/p/8UuFnY.jpg
79	2012-04-11 17:29:36.52473-04	Lucca Restaurant	75	Pittsburgh's own Tuscany	Mon-Fri,"11:30am - 02:00pm, 05:00pm - 10:00pm"\nSat,05:00pm - 10:00pm\nSun,04:30pm - 09:00pm\n	street\nlot\n	(412) 682-3310	http://luccaristorante.com/	140184476011373		t	img/p/v069S9.jpg
80	2012-04-11 17:29:37.69311-04	Kohli's Indian Imports	76				(412) 621-1800	http://www.kohlisindianimports.com/			t	img/p/KohliIndianImports.jpg
90	2012-04-11 17:29:47.826539-04	Best Western	86				(412) 683-6100	www.bestwestern.com			t	img/p/ySe9d0.jpg
81	2012-04-11 17:29:38.401995-04	Burma-Tokyo	77				(412) 802-3163				t	img/p/Burma-Tokyo.jpg
92	2012-04-11 17:29:48.596728-04	Sciulli's Pizza	88	Best food and prices in the Burgh!	Mon-Fri,10:00am - 07:00pm\nSat,11:00am - 04:00pm\nSun,Closed\n	street\n	(412) 687-9287	www.sciullispizza.synthasite.com	117063121645059		t	img/p/MfV9u3.jpg
91	2012-04-11 17:29:48.276446-04	Flaherty & Co. Opticians	87				(412) 621-6027				t	
244	2012-04-11 17:32:14.245541-04	Snowlion Imports	37	Snowlion imports is the first Tibetan and Himalayan regional store in Pittsburgh’s historic Oakland neighborhood. Snowlion Imports Inc. was established in 2001 specializing in Tibetan arts, artifacts, handicrafts and religious items acquired from the countries of the Himalayas. We offer a unique, exotic and beautiful jewelry, clothes, handicrafts and accessories from Nepal, Tibet and India. We also carry a large selection of books and ritual items for the Buddhist practioner.	Mon-Fri,11:00am - 05:30pm\nSat-Sun,11:00am - 04:00pm\n	street\n	412-687-5680	www.snowlionimports.com	275151156848		t	img/p/Jyi0S5.jpg
94	2012-04-11 17:29:50.639485-04	Panera Bread	90	Rules of the Road\n\nOur Facebook page is a place for you to engage with each other and with Panera Bread. We want to hear from our Facebook fans and we encourage you to leave comments, post photos, videos and links but we have some “rules of the road” that you need to follow and understand:\n\n1.\tPlease make sure you comply with Facebook’s terms and policies.  \n2.\tPlease don’t:  post spam or comments that defame, harass, threaten or are otherwise objectionable or that violate the privacy, intellectual property or other rights of others; use profanity in your posts; reference any third party page or site or content that you don’t own or have rights to; delete any attributions, legal notices or proprietary designations or labels in any information posted, or falsify the origin or source of any content posted.\n3.\tWe may monitor posts, so we reserve the right to remove any posts that are not in compliance with these rules, and to block repeat offenders.  \n4.\tPlease remember that we cannot guarantee the accuracy of information posted by others.  We do not endorse third party posts nor do their posts represent the opinions of Panera.  \n5.\tBy posting on this page, you are giving Panera a non-exclusive, royalty-free, worldwide, transferrable right to use your posts and content including your user name.  This means we have the right, but not the obligation, to repost and otherwise use posts and content you supply for any purpose.\n6.    Some links in Panera's posts will bring you to third party articles/websites. We assume no liability for information or statements you may encounter on these third party articles/websites. \n7.\tPanera does not accept liability resulting from your use of or access to this page or any social “like” objects created by Panera.  \nNow, post away!			(412) 683-9616	http://www.panerabread.com/	99044554628		t	img/p/LwxSAJ.jpg
111	2012-04-11 17:30:03.261569-04	Enrico's	107	Enrico's is unique in a way that is distinctive to a male clientele. Growing up in Pittsburgh I have seen many styles and trends come and go. Experiencing all of these I have been able to fine tune all my cuts and styles with precision. A majority of my clientele have been with me for many years. Having a smaller shop I am allowed the opportunity to take time equally with all my clients to understand exactly what they want. My shop has a quiet, relaxing and up close and personal atmosphere.			(412) 682-3738				t	img/p/EnricosHairCutting.jpg
101	2012-04-11 17:29:55.271131-04	Merante Groceria	97				(412) 683-3924				t	
102	2012-04-11 17:29:55.590138-04	Eureka Bank	98				(412) 681-8400	www.eurekabankcorp.com			t	img/p/0r1aiH.gif
103	2012-04-11 17:29:56.103414-04	UPMC Montefiore	99				(412) 647-2345	www.upmc.edu			t	
140	2012-04-11 17:30:32.092442-04	Mad Mex	135	The very first Mad Mex continues to serve the California-Mexican cuisine you've grown to love and has helped spread this American food mashup to Columbus, around Philadelphia and throughout the Greater Pittsburgh region. Stop by, pull a stool, order a drink and see where we got our roots.\n\nOur Mexy Specials include:\n\n*HAPPY HORA\n-Weekdays 4:30pm – 6:30pm \n-$7 Big Azz Margaritas 22oz, $5 Sweet Sixteen Margaritas 16oz and $3 Little Butt Margaritas 12 oz\n-Half off all draft beers!\n\n*LATE NIGHT MEX\n-9pm-11 Every Night\n-$7 Big Azz Margaritas!\n\n*STUDENT HALFSIES\n-Monday - Thursday 2 to 4\n-Half off food with valid ID\n\n*HALF OFF FOOD (select items)\n-Every Night 11pm to 1am\n\nQUESTIONS, COMMENTS, CONCERNS or MEX-CELLENT TIPS? Write on our Wall and tell us what's up! We do ask you to respect the community. All commentary will be reviewed and any items posted that are disruptive, offensive or use profanity will be removed.	Mon-Sun,11:00am - 02:00am\n	street\n	(412) 681-5656	http://bit.ly/MadMexOakland	228954430508292		t	img/p/Khzlj3.jpg
95	2012-04-11 17:29:51.58659-04	Arby's	91				(412) 687-3090	www.arby's.com			t	img/p/XAEn50.jpg
96	2012-04-11 17:29:51.995593-04	People's Oakland	92	Peoples Oakland is a private non-profit agency established by local residents as a community, planning and organizing agency. Originally, the mission was to enhance the integrity of the community through communications and negotiation among residents, merchants and institutional representatives. Peoples Oakland was very successful in its early organizing efforts, leading to the development of several community wide planning structures which still operate today. The Peoples Oakland Mental Health Program was founded in response to the crisis faced by thousands of state mental hospital patients who, through de-institutionalization programs, were released into the community with few supporters or social connections. Peoples Oakland began to organize former patients, providing education to support them in advocating for the rights.			(412) 683-7570				t	img/p/JJoV15.jpg
141	2012-04-11 17:30:33.043963-04	Rite Aid	136				(412) 681-1332	http://www.riteaid.com/			t	img/p/fHmH0u.jpg
97	2012-04-11 17:29:52.441819-04	Mi Ranchito	93	☼       Authentic Mexican Food and a Full Bar\n\n  ☼       Half Off Menu every night 10pm-12am\n\n  ☼        $2.50 domestic and $3.50 imported drafts                   and bottles EVERY DAY\n  \n  ☼       Take out available\n\n  ☼       Drink Specials every night:\n\nMonday: $3 Margaritas (9pm-11)\nTuesday: $1.5 Yuengling (8pm-12)\nWednesday: $1.5 Coors Light (8pm-12)\nThursday: $1.5 Miller Lite (8pm-12)\nFriday/Saturday: $2 Well Drinks (10pm-12)		street\nlot\n	(412) 586-7034	www.miranchitopittsburgh.com	325518643484		t	img/p/ngV7yT.jpg
98	2012-04-11 17:29:53.476068-04	CVS Pharmacy	94				(412) 687-4180	www.cvs.com			t	img/p/HpbXL4.jpg
147	2012-04-11 17:30:39.294038-04	Rita's Italian Ice	142	We serve Italian Ice and Old Fashioned Custard! \n\nCome try a Gelati, Misto, or Blendini today!	Mon-Sun,12:00pm - 09:00pm\n	street\n	(412) 687-9011	http://www.ritasice.com/	209584625743684		t	img/p/UdueNv.jpg
145	2012-04-11 17:30:36.64763-04	Pittsburgh Popcorn Company	140	Taking your favorite snack to the next level.  Craving the traditional or the experimental, we craft our creations by using only the finest ingredients to pop, coat, mix, and season your popcorn. And the best part, its popped fresh all day every day!			(412) 605-0444	http://pghpopcorn.com/	136828270599		t	img/p/Qg3so5.jpg
142	2012-04-11 17:30:33.631537-04	Pamela's	137	Since 1980 we've been serving the best breakfast in Pittsburgh. Try our famous Crepe Style Pancakes.		street\n	(412) 683-4066	http://www.pamelasdiner.com/index.cfm	124675784895		t	img/p/VbaOaX.jpg
146	2012-04-11 17:30:37.759947-04	Fedex Office	141				(412) 687-2752	http://fedex.com/us/office/			t	img/p/FedexOffice.jpg
143	2012-04-11 17:30:34.589689-04	Subway	138	Welcome to the official U.S. SUBWAY® Facebook page. Get to know the restaurant that offers better-for-you choices, built fresh the way you like at a price you'll love.			(412) 687-7550	www.subway.com	224383614973		t	img/p/yu7fhc.jpg
148	2012-04-11 17:30:40.354601-04	Qdoba's Mexican Restaurant	143	A Mexican kitchen where anyone can go to enjoy a fresh, handcrafted meal prepared right in front of them.			(412) 802-7866	http://www.qdoba.com/	32338694442		t	img/p/Z6tTAI.jpg
144	2012-04-11 17:30:35.703083-04	McDonald's	139	Dedicated to everyone who says, “i’m lovin’ it”. To our super fans – We salute you.			(412) 687-3747	http://mcdonalds.com	50245567013		t	img/p/k_XSu7.jpg
150	2012-04-11 17:30:41.668901-04	Dollar Bank	145	For over 155 years, Dollar Bank has grown to become a large, full service, regional bank committed to providing the highest quality of banking services to individuals and businesses. Today, we operate more than 60 branch offices and loan centers throughout the Pittsburgh and Cleveland metropolitan areas.			(412) 621-3177	www.dollarbank.com	106191133646		t	img/p/4uGXlW.jpg
149	2012-04-11 17:30:41.268831-04	Oakland Jewelry Exchange	144				(412) 682-6520				t	img/p/OaklandJewelry.jpg
151	2012-04-11 17:30:42.787531-04	Bruegger's Bagel Bakery	146				(412) 682-6360	www.breugger's.com			t	img/p/BrueggersBagels.jpg
152	2012-04-11 17:30:44.558298-04	Vera Cruz	147				(412) 688-0766				t	img/p/VeraCruz.jpg
333	2012-04-11 17:33:00.732973-04	McGill House	\N								f	
334	2012-04-11 17:33:00.744858-04	Mudge House	\N								f	
99	2012-04-11 17:29:53.970282-04	Jimmy John's	95	I’m JJ, the founder. Started Jimmy John’s when I was 19 at Eastern IL University. I’m the man, behind the man, behind the sandwich. Still rockin’ out sammies after 29 years and diggin it! This BookFace stuff takes time, but hey I love the love!\n\nJimmy John’s Facebook Page is a place for JJ fans to keep it real with Jimmy and with one another. JJ welcomes differing opinions – but not to the detriment or disturbance of the community and its individual members. It’s all about spreading the love!!! It would not be a part of JJ’s culture or the spirit of Facebook in general to prevent fans from interacting with this community. Unfortunately, there will inevitably be a few individuals who, from time to time, feel bad about themselves and find it easier to make others feel bad rather than to fix their own issues. It’s human nature and a very normal defense mechanism. The trick is to not take it personally, but when we see behavior threatening to the JJ FB Community or individuals within it, in accordance with Facebook’s Terms of Service, we will delete comments. If an individual’s disruptive behavior persists, then we may block that user from participating. \n\nThe deal is about keepin’ it real. We ask that you be respectful in your postings and comply with all Facebook terms and policies, including not posting comments, images or other types of content that are:\n\n* Abusive, defamatory or obscene\n* Fraudulent, deceptive or misleading\n* In violation of a law or regulation, or another person’s intellectual property rights\n* Linked to Web sites containing harmful or inappropriate content\n\nThanks for your passion and the love for my brand.\n\nPeace, have fun and keep rockin’!\nJimmy			(412) 681-9010	www.jimmyjohns.com	55341356095		t	img/p/Y28VVI.jpg
100	2012-04-11 17:29:54.984782-04	John N. Elachko Funeral Home	96				(412) 682-3257				t	
160	2012-04-11 17:30:49.283783-04	Rue 21	154	www.rue21.com offers a broad assortment of the newest emerging fashion trends in apparel and accessories for girls and guys. Using a competitive pricing strategy, rue21 makes a specific, unique statement by offering fashion at a value.			(412) 681-1266	www.rue21.com	8754337404		t	img/p/u73OL8.jpg
104	2012-04-11 17:29:56.39069-04	United States Post Office	100	<p>The <b>United States Postal Service</b> (also known as <b>USPS</b>, the <b>Post Office</b> or <b>U.S. Mail</b>) is an independent agency of the United States government responsible for providing <a href="/pages/w/109434905741086">postal service</a> in the United States. It is one of the few government agencies <a href="/pages/w/110996142285936">explicitly authorized by the United States Constitution</a>. The USPS traces its roots to 1775 during the <a href="/pages/w/109273849091280">Second Continental Congress</a>, where <a href="/pages/w/112511012093471">Benjamin Franklin</a> was appointed the first <a href="/pages/w/115691975110988">postmaster general</a>. The <a href="/pages/w/112597985421440">cabinet-level</a> <a href="/pages/w/103121376395138">Post Office Department</a> was created in 1792 from Franklin's operation and transformed into its current form in 1971 under the <a href="/pages/w/132863743416594">Postal Reorganization Act</a>.</p><p>The USPS employs over 574,000 workers and operates over 218,000 vehicles. It is the 2nd largest civilian employer in the United States. The USPS is the operator of the largest <a href="/pages/w/110262318995811">vehicle fleet</a> in the world. The USPS is legally obligated to serve all Americans, regardless of geography, at uniform price and quality. The USPS has exclusive access to <a href="/pages/w/106705369369557">letter box</a>es marked "U.S. Mail" and personal letterboxes in the United States, but still competes against private <a href="/pages/w/111775732174285">package delivery</a> services, such as <a href="/pages/w/108114832542418">UPS</a> and <a href="/pages/w/109391029078703">FedEx</a>.</p><p>On December 5, 2011 the USPS announced it will close more than half of its mail processing centers, eliminate 28,000 jobs and end overnight delivery of first-class mail. This will close down 252 of its 461 processing centers. On December 13, 2011 the USPS agreed to delay the closing of 252 mail processing centers as well as 3,700 local post offices until mid-May 2012.</p>			(412) 621-9713	www.usps.com	108137545887568		t	img/p/uHreGO.gif
114	2012-04-11 17:30:07.940057-04	Oakland Trans. Mgt. Assoc.	58				(412) 687-4505	www.otma-pgh.org	111945712159349		t	img/p/oI1Wk8.jpg
105	2012-04-11 17:29:57.35177-04	Liliane S. Kaufmann Bldg.	101				(412) 647-2345	www.upmc.edu			t	
110	2012-04-11 17:30:02.034678-04	Say Cheese	106	Thank You Pittsburgh for 10 Great Years! \n\nOn-line ordering available: CampusFood.com\nAllmenus.com	Mon-Sat,11:00am - 01:00am\nSun,11:00am - 12:00am\n	street\n	(412) 687-0606	http://www.saycheesepizza.biz	163939822532		t	img/p/r5mgof.jpg
106	2012-04-11 17:29:57.671455-04	Hieber's Pharmacy Inc.	102	The oldest pharmacy in Pittsburgh - Hieber's enters its 153rd year of compounding prescriptions in 2010!	Mon-Fri,09:00am - 05:00pm\nSat,09:00am - 12:00pm\nSun,Closed\n		(412) 681-6400	http://www.hpharmacy.net/	188001794690		t	img/p/qDkyoI.jpg
112	2012-04-11 17:30:05.101-04	Medical Center Opticians	108	Since opening our doors in 1962, this family owned and operated business has been making Oakland more beautiful one person at a time!	Mon-Fri,10:00am - 05:00pm\nSat-Sun,Closed\n	lot\n	(412) 621-6773	to	164341936930309		t	img/p/ep6VEN.jpg
107	2012-04-11 17:29:58.93241-04	Stuckert's Exxon	103				(412) 621-4115	www.exxon.com			t	img/p/z3NEWl.jpg
108	2012-04-11 17:29:59.667812-04	Life Uniform	104	Since Life Uniform opened its first store in 1965 it has grown to several hundred strong and can be found across this country. We're now located in most major malls and many major hospitals.\n\nCome visit us in store or online at www.lifeuniform.com			(412) 682-6373	http://www.lifeuniform.com/LifeUniform.jsp	216796839795		t	img/p/SysLBS.jpg
113	2012-04-11 17:30:06.224735-04	Nellie's Sandwiches	109				(412) 683-7144				t	img/p/Nellies.jpg
115	2012-04-11 17:30:09.09946-04	Bellisario's Automotive	110				(412) 687-6750				t	
116	2012-04-11 17:30:09.384873-04	The Slipped Disc	111				(412) 688 8899				t	img/p/SlippedDiscRecords.jpg
117	2012-04-11 17:30:10.890519-04	Jim's Amoco	112				(412) 687-7799				t	img/p/4EFQFs.png
256	2012-04-11 17:32:25.962331-04	Luna Bar and Grill	238	Luna Bar & Grill on N. Craig Street in Oakland! -- Cheapest beer in Pittsburgh!		street\nlot\n	412-576-0774		253266114749387		t	img/p/vLV1W5.jpg
258	2012-04-11 17:32:28.888895-04	K & T's Fish and Chicken	240				412-621-2526	http://cmu.collegebite.com/restaurants/52-K-T-s-Fish-Chicken	204670580389		t	img/p/fFb0rU.jpg
257	2012-04-11 17:32:27.123203-04	Riviera Jewelers	239								t	img/p/RivieraJewelers.jpg
318	2012-04-11 17:33:00.552014-04	407 South Craig	\N								f	
319	2012-04-11 17:33:00.564259-04	4516 Henry (UTDC)	\N								f	
320	2012-04-11 17:33:00.576429-04	4609 Henry	\N								f	
321	2012-04-11 17:33:00.588714-04	4615 Forbes	\N								f	
128	2012-04-11 17:30:21.552182-04	Campus Bookstore	123	Campus Bookstore began in 1993 with the primary purpose of selling textbooks to students at The University of Pittsburgh for a less expensive price than they could get anywhere on the University campus. This remains our focus today. Textbooks prices have gone up dramatically in the past few years. Campus Bookstore has always maintained a policy of giving you the best deal on textbooks here at Pitt. In fact, we guarantee to have the lowest prices on textbooks of any store on campus. If you find a book at a local store for a lower price, we'll beat it! Campus Bookstore is alumni owned, not part of the university, and we are not run by a large corporation, so we know how textbook prices affect the students. Our store is operated by "clerk service", which means that we will get the books for you while you wait. You'll never have to spend hours in the bookstore searching for your books. We can retrieve your books in about 5 minutes. Just bring your class schedule and we'll take care of the rest!			(412) 681-9770	http://campusbookstore-pitt.com/			t	img/p/dHQjw0.png
119	2012-04-11 17:30:12.882343-04	Falk Clinic	114				(412) 648-3000	www.upmc.edu			t	
130	2012-04-11 17:30:23.233801-04	Ace Athletic	125	Located in Pittsburgh, PA since 1991, Ace Athletic has been at the forefront of the urban footwear and apparel scene for years. With 4  locations we have been outfitting our customers with the latest and greatest fashions from head to toe. Our footwear selection is among the best in the city with brand names like Air Jordan, Nike, Adidas, Timberland and more. The apparel is also strong with name brands like Nike, Jordan, Mitchell & Ness, and more. Of course you can’t complete your outfit without one of our wide selection of fitted caps from New Era. We also carry your hometown favorite teams like the Steelers,Pens, and Pirates. Stop into any of our store locations and get a 10% discount card to use towards your future purchases. More importantly, remember as always, “IF YOU AIN’T GETTIN IT FROM ACE, YOU JUST AIN’T GETTIN IT!”			(412) 578-9711	http://www.aceathleticpa.com/	203003749735986		t	img/p/yjgv7r.jpg
121	2012-04-11 17:30:13.837222-04	Selection Boutique	116				(412) 681-6619				t	img/p/SelectionBoutique.jpg
129	2012-04-11 17:30:22.310886-04	SuperCuts	124	Supercuts is all about the latest cuts - from your hair to your headphones. Because we know what a fresh cut can do for you. Come in now and Rock The Cut at Supercuts.			(412) 682-4440	www.supercuts.com	81874860761		t	img/p/lCQxlk.jpg
123	2012-04-11 17:30:16.55754-04	Radio Shack	118				(412) 681-6550	www.radioshack.com			t	img/p/T3_RiM.jpg
136	2012-04-11 17:30:28.904284-04	Caribou Coffee	131	Life is short. Stay awake for it.\n\nTell us what you stay awake for!\n\nFollow us on Twitter:\nhttp://twitter.com/Caribou_Coffee \n\nand \n\nhttp://twitter.com/CaribouCareers			(412) 687-2617	http://www.cariboucoffee.com/	133270255952		t	img/p/XS9cGl.jpg
124	2012-04-11 17:30:17.074797-04	Golden Palace Buffet	119				(412) 687-2288				t	img/p/GoldenPalaceBuffet.jpg
125	2012-04-11 17:30:18.553582-04	AJ's Peruvian Chicken	120				(412) 687-4666	http://cmu.collegebite.com/restaurants/48-AJ-s-Burger-Peruvian-Chicken	328754675500		t	img/p/_lSSQP.jpg
131	2012-04-11 17:30:24.206807-04	The Exchange	126				(412) 687-4715	www.myexchangefranchise.com			t	img/p/TheExchange.jpg
135	2012-04-11 17:30:27.888614-04	Starbucks	130	Our story began in 1971. Back then we were a roaster and retailer of whole bean and ground coffee, tea and spices with a single store in Seattle’s Pike Place Market.\nToday, we are privileged to connect with millions of customers every day with exceptional products and more than 17,000 retail stores in over 55 countries.			(412) 682-3868	www.starbucks.com	22092443056		t	img/p/wL1eHp.jpg
127	2012-04-11 17:30:20.35897-04	IGA Market on Forbes	122	Fresh Produce, Full Deli, and all your Grocery needs in a fun environment!	Mon-Fri,08:00am - 09:00pm\nSat,11:00am - 09:00pm\nSun,11:00am - 07:00pm\n	street\n	(412) 621-1212	http://oaklandiga.com/	135390396483173		t	img/p/GZk5JN.jpg
132	2012-04-11 17:30:25.385121-04	Prince of India	127				(412) 687-0888	http://oaklandpghpa.collegebite.com/restaurants/33-Prince-of-India	178982284869		t	img/p/1XMtsg.jpg
245	2012-04-11 17:32:15.323071-04	Family House	229	Family House, a non-profit organization in Pittsburgh, PA, provides a special "home away from home" for patients and families who are in Pittsburgh for treatment of serious or life-threatening illnesses.				http://www.familyhouse.org	306452702240		t	img/p/CUHIQC.jpg
139	2012-04-11 17:30:30.996233-04	Oriental Super	134	We specialize in the sale of all Asian groceries with an emphasis on Korean goods, food, and gifts. Produce, meat and fish are available fresh and/or frozen. We have recently added the sale of homemade Korean cuisine and side dishes made by the former chef/owner of Ginza Korean Restaurant. The available menu will be updated on a weekly basis.	Mon-Thurs,09:00am - 07:30pm\nFri,09:00am - 09:00pm\nSat,09:00am - 07:30pm\nSun,10:00am - 07:30pm\n	street\n	(412) 683-2041		188053227905353		t	img/p/laxvyF.jpg
138	2012-04-11 17:30:30.711072-04	The Oakland School	133				(412) 621-7878	http://www.theoaklandschool.org/			t	
137	2012-04-11 17:30:29.821774-04	Chipotle	132				(412) 621-1557	www.chipotle.com	150563584963727		t	img/p/xvk9Kd.jpg
259	2012-04-11 17:32:29.960337-04	Tamarind	241	A bright South Indian Restaurant with a cozy atmosphere and hot food served by the cheery staff.							t	img/p/Tamarind.jpg
122	2012-04-11 17:30:14.76598-04	Milano's Pizza	117				(412) 681-2858				t	img/p/MilanosPizza.jpg
180	2012-04-11 17:31:07.941818-04	Ali Baba	172	Our Ali Baba is called by Pittsburgh magazine, “the best Middle Eastern Restaurant in Pittsburgh”. In 1972, three struggling, native Syrian graduate students opened the doors to a modest ethnic restaurant. Because of their perseverance and dedication to satisfying customers, Ali Baba prospered. In 1973 staff was added which included two chefs who continue to prepare authentic dishes in our kitchen today. Extensive remodeling took place in 1975 and 1982, which changed Ali Baba’s décor into what is seen presently. Ivan Makhoul, one of the original owners, remains committed to his formula of success: providing not only fresh authentic dishes, but also the best possible foods and service to his guests.			(412) 682-2829				t	img/p/t2CbWp.png
153	2012-04-11 17:30:45.082998-04	Joe Mama's Italian Deluxe	148	Joseph Michael Mama was born into a first generation Italian-American immigrant family...way back when. He won't tell us the exact date because he's scared we'll throw him a party. Joe's kind of a grumpy guy. He's got plenty of other faults too, but we won't bore you with them. Actually, most things about Joe are pretty average except his weight, which is a little above average. To be perfectly honest with you, we only know of two things that Joe does really well. One is bowling, which we'll get back to later. The other is cooking the kind of food he grew up on - great big platters of authentic Home Style Italian-American Grub. Honestly, nobody cooks Italian like Joe Mama! Joe learned everything he knows from his Mom and Nonna (That's Italian for Grandma). He says he can't remember a day growing up when those two weren't in the kitchen with a big pot of something good simmering on the stove. Their modest home was always filled with extended family and friends. There was always plenty of heated debate (yelling) and even more laughter. Most importantly, there was the food. We're talking huge platters of delicious Made-From-Scratch Italian Food. (Not to mention, endless jugs of Homemade Wine.) Joe always tells us, "we were pretty close to poor, but we ate like kings." And, that's why he always gives you an honest meal for the buck. You'll think Joe's crazy when you see the food. Back to the bowling...Joe's a real champ. If you don't believe us, check out all the trophies. They're around here somewhere. Joe's the captain of his team, The Bombers. He never misses league night. (Although, sometimes we miss Joe the morning after league night.) The Bombers team slogan is, "We're a drinkin' team with a bowling problem." That pretty much sums it up for you. In the Army, Joe was a Mechanic Crew Sergeant on a B-47 Bomber (Hence, the name for his team.) When he got out, he took over this place with the help of one of those low interest VA loans. That was a long time ago and the place was old then. Back to the bowling...Joe's a real champ. If you don't believe us, check out all the trophies. They're around here somewhere. Joe's the captain of his team, The Bombers. He never misses league night. (Although, sometimes we miss Joe the morning after league night.) The Bombers team slogan is, "We're a drinkin' team with a bowling problem." That pretty much sums it up for you. In the Army, Joe was a Mechanic Crew Sergeant on a B-47 Bomber (Hence, the name for his team.) When he got out, he took over this place with the help of one of those low interest VA loans. That was a long time ago and the place was old then. Other than a couple of expansions over the years, not much about this joint has changed. Believe us, we know it's not much to look at. (Joe always says, "the food's good looking enough!") On the up side, there's no chance of really messing anything up. So relax, listen to some of Joe's tunes, have one of our Famous Tall Cocktails, and most importantly, eat a big platter of some real Home Style Grub. If you get some sauce on your shirt, don't worry... you'll blend right in.			(412) 621-7282	http://www.joemamas.com/			t	img/p/cOs7_k.gif
156	2012-04-11 17:30:47.297245-04	Sestili Nursery	151	Sestili Nursery, founded in 1947, is a complete landscape construction and landscape supply center, serving the Pittsburgh area. Our mission is: - to ensure quality service to our customers, and offer merchandise and designs which sustain and enhance the natural integrity of their homes and businesses. - to support Pittsburgh area neighborhoods and businesses in creating gardens and landscapes of beauty and functionality. - to provide a safe, fair and healthy environment for our employees and customers while achieving an equitable profit. - to maintain the ideals of good business as we strive to continue our goal of professional and excellent service now and in the future.			(412) 681-1200	http://www.sestilinurseryinc.com/			t	img/p/CfrB7H.jpg
154	2012-04-11 17:30:45.763557-04	Citizens Bank	149				(412) 683-1111	www.citizensbank.com			t	img/p/tsTgpt.jpg
155	2012-04-11 17:30:46.216577-04	Gidas Flowers	150	We are full service florist that services dowtown Pittsburgh and surrounding suburbs. We specialize in weddings and events. We have been a family owned and operated business for 4 generations and more than 90 years.	Mon-Fri,07:30am - 05:00pm\nSat,09:00am - 04:00pm\nSun,Closed\n		(412) 621-1300	https://www.gidasflowers.com/	117969668996		t	img/p/PeiVg6.jpg
157	2012-04-11 17:30:47.971508-04	Taiwan Cafe	152				(412) 682-3396				t	img/p/TaiwanCafe.jpg
183	2012-04-11 17:31:12.6407-04	Islamic Center of Pittsburgh	175	The Islamic Center of Pittsburgh is the area's largest Mosque, providing services to Muslim and Non-Muslim communities in Western Pennsylvania, Eastern Ohio, and Northern West Virginia. We were established in 1992, located at 4100 Bigelow Blvd, in Oakland. Our phone number is (412) 682 5555; fax is (412) 682 3111. ICP office hours are between 10 AM and 5 PM. Mosque is open for all prayer times.			(412) 682-5555	http://www.icp-pgh.org/			t	img/p/o02UOv.jpg
158	2012-04-11 17:30:48.540401-04	General Nutrition Center	152				(412) 682-5008	www.gnc.com			t	img/p/swOFNZ.jpg
159	2012-04-11 17:30:48.989047-04	Bellisario's Auto Body	153				(412) 687-9258				t	
181	2012-04-11 17:31:10.243331-04	Mellinger Beer Distributor	173	www.mellingersbeer.com\n\nKing of beers? Champagne of beers? Beer brewed with rocky mountain water?  Dead Guy Ale? With over 500 beers we have the most recent hand crafted ales and all your old favorites.  Stop by and see our ever changing seasonals.	Mon-Wed,10:00am - 10:00pm\nThurs-Sat,10:00am - 11:00pm\nSun,12:00pm - 05:00pm\n	street\n	(412) 682-4396	http://www.mellingersbeer.com	153726191337687		t	img/p/Nelk1y.jpg
206	2012-04-11 17:31:35.211586-04	Lou's Auto	194				(412) 682-6211				t	
246	2012-04-11 17:32:16.344061-04	Family House	22	Family House, a non-profit organization in Pittsburgh, PA, provides a special "home away from home" for patients and families who are in Pittsburgh for treatment of serious or life-threatening illnesses.				http://www.familyhouse.org	306452702240		t	img/p/yevP1Y.jpg
184	2012-04-11 17:31:13.921065-04	Top Notch Art Center	176		Mon-Fri,10:00am - 07:00pm\nSat,10:00am - 05:00pm\nSun,01:00pm - 05:00pm\n	street\n	(412) 683-4444	http://www.tnartsupply.com/	134449299940422		t	img/p/CAI0Lv.jpg
182	2012-04-11 17:31:11.568655-04	Larry & Carol's Pizza	174				(412) 687-1189	http://www.larryncarolspizza.com/	178050436883		t	img/p/tYcxPe.jpg
249	2012-04-11 17:32:19.241254-04	Black Cat Tattoos	227	Black Cat tattoos is the home of tattooers Jason Lambert and Cara Cable, we pride ourselves on our friendly atmosphere, top quality art, and safe, sterile technique.	Mon,11:00am - 06:00pm\nTues-Wed,Closed\nThurs-Sat,11:00am - 06:00pm\nSun,12:30pm - 06:00pm\n	street\n	412-621-1679	http://blackcattattoos.net/home.html	157345207694253		t	img/p/6pU9Ay.jpg
247	2012-04-11 17:32:17.240952-04	Shiraz Kabob and Pizza	230								t	img/p/ShirazKabob.jpg
248	2012-04-11 17:32:18.065154-04	Pizza Bellagio	231		Mon-Thurs,10:00am - 01:00am\nFri-Sat,10:00am - 02:00am\nSun,10:00am - 01:00am\n	street\n	(412) 688-8448	www.pizzabellagio.com	113585148675130		t	img/p/N5Ygy5.jpg
250	2012-04-11 17:32:20.297438-04	Subway	232	Welcome to the official U.S. SUBWAY® Facebook page. Get to know the restaurant that offers better-for-you choices, built fresh the way you like at a price you'll love.				http://www.Subway.com	224383614973		t	img/p/88tUvL.jpg
161	2012-04-11 17:30:50.181422-04	Panera Bread	154	Rules of the Road\n\nOur Facebook page is a place for you to engage with each other and with Panera Bread. We want to hear from our Facebook fans and we encourage you to leave comments, post photos, videos and links but we have some “rules of the road” that you need to follow and understand:\n\n1.\tPlease make sure you comply with Facebook’s terms and policies.  \n2.\tPlease don’t:  post spam or comments that defame, harass, threaten or are otherwise objectionable or that violate the privacy, intellectual property or other rights of others; use profanity in your posts; reference any third party page or site or content that you don’t own or have rights to; delete any attributions, legal notices or proprietary designations or labels in any information posted, or falsify the origin or source of any content posted.\n3.\tWe may monitor posts, so we reserve the right to remove any posts that are not in compliance with these rules, and to block repeat offenders.  \n4.\tPlease remember that we cannot guarantee the accuracy of information posted by others.  We do not endorse third party posts nor do their posts represent the opinions of Panera.  \n5.\tBy posting on this page, you are giving Panera a non-exclusive, royalty-free, worldwide, transferrable right to use your posts and content including your user name.  This means we have the right, but not the obligation, to repost and otherwise use posts and content you supply for any purpose.\n6.    Some links in Panera's posts will bring you to third party articles/websites. We assume no liability for information or statements you may encounter on these third party articles/websites. \n7.\tPanera does not accept liability resulting from your use of or access to this page or any social “like” objects created by Panera.  \nNow, post away!			(412) 683-3727	http://www.panerabread.com/	99044554628		t	img/p/SwXrhO.jpg
176	2012-04-11 17:31:04.374258-04	Bellefield Presbyterian Church	168	Bellefield Presbyterian Church is located in the heart of the University of Pittsburgh campus in Pittsburgh, PA.	Mon,Closed\nTues-Fri,09:00am - 03:30pm\nSat,Closed\nSun,"08:30am - 09:30am, 11:00am - 12:15pm"\n		(412) 687-3222	http://www.bellefield.org/	15698372465		t	img/p/YB3d3U.jpg
163	2012-04-11 17:30:52.242682-04	Gus Miller's News Stand	155				(412) 683-5244				t	img/p/GusMiller.jpg
171	2012-04-11 17:30:59.322734-04	The UPS Store	163	One Stop Shop!	Mon-Fri,09:00am - 07:00pm\nSat-Sun,Closed\n	street\n	(412) 624-0552	http://www.theupsstore.com/Pages/index.aspx	130355633663385		t	img/p/67JVzA.jpg
164	2012-04-11 17:30:53.23397-04	Primanti Brothers	156	Home of the Almost Famous Sandwich! Check out 19 other locations at www.primantibros.com	Mon-Sun,12:00am - 12:00am\n	street\nlot\n	(412) 621-4444	http://www.primantibros.com/	15349859252		t	img/p/XaorWC.jpg
165	2012-04-11 17:30:54.172284-04	New Light Baptist Church	157				(412) 621-0640				t	
172	2012-04-11 17:31:00.403459-04	7-Eleven	164				(412) 682-6108	http://www.7-eleven.com/			t	img/p/Hl0rBx.jpg
221	2012-04-11 17:31:51.551411-04	Pep Boys	209	With more than 7,000 service bays in more than 700 locations in 35 states and Puerto Rico, Pep Boys offers name-brand tires; automotive maintenance and repair; parts and expert advice.	Mon-Fri,07:00am - 09:00pm\nSat,08:00am - 08:00pm\nSun,09:00am - 06:00pm\n		(412) 578-0467	www.pepboys.com	285534371468276		t	img/p/zrQ2Jr.jpg
179	2012-04-11 17:31:07.353513-04	Bootlegger's	171				(412) 682-3060				t	img/p/D5GGTo.jpg
173	2012-04-11 17:31:00.922804-04	LuLu's Noodle Shop	165				(412) 687-7777	http://cmu.collegebite.com/restaurants/36-Lu-Lu-s-Noodle-Shop	188580067517		t	img/p/3d5nZ6.jpg
168	2012-04-11 17:30:56.80481-04	Dunkin Donuts	160				(412) 687-1308	www.dunkindonuts.com			t	img/p/FfCEHU.jpg
177	2012-04-11 17:31:05.512595-04	Sphinx Cafe	169	THE ONLY EGYPTIAN HOOKAH BAR & COFFEE HOUSE IN TOWN	Mon-Thurs,04:00pm - 01:00am\nFri-Sat,04:00pm - 02:00am\nSun,04:00pm - 01:00am\n	street\n	(412) 621-1153	www.sphinx-cafe.com	120300144652011		t	img/p/omXVgI.jpg
169	2012-04-11 17:30:57.27646-04	Hemingway's Cafe	161	$1.50 Miller Lite Drafts, $5 Miller Lite Pitchers, $6 Yuengling Pitchers ALL DAY EVERY DAY!!!  Wednesday Night: Karaoke at 10 p.m.  Thursday Night:  DJ Donnelly at 11 p.m.	Mon-Fri,11:00am - 02:00am\nSat,06:00pm - 02:00am\nSun,Closed\n	street\n	(412) 621-4100	http://www.hemingways-cafe.com/	43656360946		t	img/p/Oym8po.jpg
170	2012-04-11 17:30:58.241685-04	Pitt Shop	162	The Pitt Shop is your source for officially licensed Pitt merchandise.\nThe Pitt Shop is owned and operated by the University of Pittsburgh - all purchases benefit the University of Pittsburgh.	Mon-Thurs,09:00am - 06:00pm\nFri-Sat,08:30am - 05:00pm\nSun,Closed\n		(412) 648-2606	http://store.thepittshop.com/	159056180876154		t	img/p/qA9vo0.jpg
174	2012-04-11 17:31:02.215601-04	Campus Deli	166		Mon,11:00am - 04:30pm\nTues-Thurs,11:00am - 10:30pm\nFri-Sat,11:00am - 11:30pm\nSun,11:00am - 08:30pm\n		(412) 683-3200	http://www.campusfood.com/restaurant.asp?campusid=147&mlid=32845	10978218110		t	img/p/lw3doH.jpg
178	2012-04-11 17:31:06.456755-04	PNC Bank	170	PNC Bank, a member of The PNC Financial Services Group, is one of the nation’s largest diversified financial services organizations, serving approximately 5.8 million customers through 2,900 branches and 6,800 ATMs in 19 states (and Washington, D.C.). \n\nFor more than 150 years, we have been committed to providing our clients with great service and powerful financial expertise to help them meet their financial goals. We offer a wide range of services for all our customers, from individuals and small businesses, to corporations and government entities. No matter how simple or complicated your needs, we're sure to have the products, knowledge and resources necessary for financial success.\n\nWeb: www.pnc.com\nTwitter: www.twitter.com/pncnews\nYouTube: www.youtube.com/pnc\n\nUpdated:  4/7/12			(412) 621-0300	www.pnc.com	224986157558341		t	img/p/3o7SXl.jpg
251	2012-04-11 17:32:21.323802-04	Pizza Pronto	233		Mon-Thurs,11:00am - 12:00am\nFri-Sat,11:00am - 01:00am\nSun,11:00am - 12:00am\n		412-621-7700		198385751071		t	img/p/pndzDg.jpg
260	2012-04-11 17:32:30.974792-04	Legume	44	Just like Laurel's Kitchen except with more fat, salt, and meat.		valet\n	412-621-2700	www.legumebistro.com	42547425833		t	img/p/Q0rXpI.jpg
252	2012-04-11 17:32:22.46308-04	Bombay Food Market	234								t	img/p/BombayFoodMart.jpg
253	2012-04-11 17:32:23.335401-04	Sultan Bey Global Market	235								t	img/p/SultanBey.jpg
254	2012-04-11 17:32:24.327396-04	Logan's Pub	236								t	img/p/LogansPub.jpg
185	2012-04-11 17:31:15.03984-04	Pittsburgh Athletic Association	177	<p>The <b>Pittsburgh Athletic Association</b> is a <a href="http://en.wikipedia.org/wiki/Gentlemen's_club">private social club</a> and <a href="http://en.wikipedia.org/wiki/Club">athletic club</a> in in <a href="http://en.wikipedia.org/wiki/Pittsburgh">Pittsburgh</a>, <a href="http://en.wikipedia.org/wiki/Pennsylvania">Pennsylvania</a>, <a href="http://en.wikipedia.org/wiki/United_States">USA</a>. Its clubhouse is listed on the <a href="http://en.wikipedia.org/wiki/National_Register_of_Historic_Places">National Register of Historic Places</a>.</p><p>Located at the corner of <a href="http://en.wikipedia.org/wiki/Fifth_Avenue_(Pittsburgh)">Fifth Avenue</a> and Bigelow Boulevard in the city's <a href="http://en.wikipedia.org/wiki/Oakland_(Pittsburgh)">Oakland</a> district, it faces three other landmark buildings: the <a href="http://en.wikipedia.org/wiki/University_of_Pittsburgh">University of Pittsburgh</a>'s <a href="http://en.wikipedia.org/wiki/Cathedral_of_Learning">Cathedral of Learning</a> and <a href="http://en.wikipedia.org/wiki/William_Pitt_Union">William Pitt Union</a> as well as the <a href="http://en.wikipedia.org/wiki/Soldiers_and_Sailors_National_Military_Museum_and_Memorial">Soldiers and Sailors National Military Museum and Memorial</a>.</p><p>Architect <a href="http://en.wikipedia.org/wiki/Benno_Janssen">Benno Janssen</a> (1874—1964) used a Venetian Renaissance palace as a prototype for his design, perhaps <a href="http://en.wikipedia.org/wiki/Palazzo_Grimani_di_San_Luca">Palazzo Grimani</a> or Libreria on Piazza San Marco. He completed the structure in 1911.</p><p>The Pittsburgh Athletic Association is a nonprofit membership club chartered in 1908. It continues today to offer comprehensive athletic facilities, sports lessons, spa services, fine dining, and overnight accommodations. Some of the building's more interesting features include a pool on the third floor, full basketball and squash courts, a 16 lane bowling alley, and a room dedicated to former University of Pittsburgh football coach <a href="http://en.wikipedia.org/wiki/Johnny_Majors">Johnny Majors</a>. The club has several annual events, the most popular including an Easter brunch, a lobster dinner, and collegiate boxing events.</p>			(412) 621-2400	http://www.paaclub.com/Club/Scripts/Home/home.asp	103110366395904		t	img/p/ciRS68.gif
230	2012-04-11 17:31:58.688093-04	Phipps Conservatory & Botanical Gardens	217	phipps.conservatory.org\n\nOpen daily from 9:30 a.m. to 5 p.m. and until 10 p.m. on Fridays.\n\nFor info : 412/622-6914			(412) 622-6914	http://phipps.conservatory.org/	104851729258		t	img/p/MGgR2p.jpg
186	2012-04-11 17:31:16.011844-04	Union Grill	178	Please visit our website for menus and more!\n\nhttp://pghdining.com/index.php?option=com_content&view=article&id=11:sample&catid=13:alphabetical-listing-a-z&Itemid=18	Mon-Thurs,11:30am - 10:00pm\nFri-Sat,11:30am - 11:00pm\nSun,12:00pm - 09:00pm\n	street\n	(412) 681-8620	http://pghdining.com/index.php?option=com_content&view=article&id=11&Itemid=18	107604845966237		t	img/p/2cv6zl.jpg
232	2012-04-11 17:32:00.719713-04	VA Pgh. Healthcare System	219	VA Pittsburgh Healthcare System is an integrated healthcare system that proudly serves the Veteran population throughout the tri-state area of Pennsylvania, Ohio and West Virginia. It is our mission to care for America’s Veterans and provide them with excellent health care.\n\nVAPHS consists of three campuses: a major medical and surgical tertiary care facility, a behavioral health facility, and a community living center and a Veterans recovery center all complemented by five community based outpatient clinics.	Mon-Fri,08:00am - 04:30pm\nSat-Sun,Closed\n	lot\n	(412) 688-6000	http://www.pittsburgh.va.gov/	374660806819		t	img/p/WYtFjI.jpg
187	2012-04-11 17:31:16.896841-04	Vera Cruz Mexican Grocery	179				(412) 621-7405				t	img/p/VeraCruzGrocery.jpg
188	2012-04-11 17:31:17.833714-04	Korea Garden Restaurant	180	Korea Garden has been the best Korean restaurant at Pittsburgh over than 30 years. We provide delicious Korean and Korean-style Chinese cuisine with great taste.			(412)681-6460				t	img/p/KoreaGarden.jpg
231	2012-04-11 17:31:59.689505-04	Heinz Memorial Chapel	218	<p><b>Heinz Memorial Chapel</b> is a <a href="/pages/w/137104802976972">Pittsburgh History and Landmarks Foundation</a> Historic Landmark and a <a href="/pages/w/111653488863454">contributing property</a> to the <a href="/pages/w/114370705245238">Schenley Farms</a> <a href="/pages/w/107818619241049">National Historic District</a> on the campus of the <a href="/pages/w/103721419666144">University of Pittsburgh</a> in <a href="/pages/w/114943251851302">Pittsburgh</a>, <a href="/pages/w/105528489480786">Pennsylvania</a>, <a href="/pages/w/112463092102121">United States</a>.</p><h2>History</h2><p>The chapel was a gift of <a href="http://en.wikipedia.org/wiki/German-American" class="wikipedia">German-American</a> <a href="/pages/w/132815833424935">Henry John Heinz</a>, founder of the <a href="/pages/w/112381515455322">H.J. Heinz Company</a>, who wanted to honor his mother, Anna Margaretta Heinz, with a building at the university. Upon his death in 1919, Heinz’s three surviving children (Howard, Irene, and Clifford) added to his bequest in order to memorialize their grandmother and honor their father. Their choice of a chapel for a memorial was guided by the concepts of education and religion which Anna Margaretta Heinz imbued in her children.</p><p>Howard Heinz, Chancellor <a href="/pages/w/119541424759362">John Gabbert Bowman</a>, and Joh Weber, business manager and university secretary, were the driving energy behind the chapel’s concept and execution. Working with them were other members of the Heinz family, and two well-known clergymen, Dr. Hugh Thomson Kerr, pastor of <a href="/pages/w/106028029428164">Shadyside Presbyterian Church</a>, and Dr. <a href="/pages/w/135136773184764">Henry Sloane Coffin</a>, president of <a href="/pages/w/112438812105716">Union Theological Seminary</a>.</p>			(412) 624-4157	http://www.heinzchapel.pitt.edu/	106287052735114		t	img/p/guWAk9.gif
189	2012-04-11 17:31:18.9829-04	Soldiers & Sailors Memorial Hall	181	We honor all the men and women of Pennsylvania who serve in the United States military. Soldiers & Sailors pays tribute to our military with exhibits from the Civil War to the present.	Mon-Sat,10:00am - 04:00pm\nSun,Closed\n	street\n	(412) 621-4253	http://www.soldiersandsailorshall.org/	79888000570		t	img/p/QzjKl1.jpg
236	2012-04-11 17:32:05.323591-04	Hillel Jewish University Center of Pittsburgh	223	Hillel's mission is to enrich the lives of Jewish undergraduate and graduate students so that they may enrich the Jewish people and the world.				www.hilleljuc.org	91028384678		t	img/p/KZzm1T.jpg
190	2012-04-11 17:31:20.079511-04	Subway	182	Welcome to the official U.S. SUBWAY® Facebook page. Get to know the restaurant that offers better-for-you choices, built fresh the way you like at a price you'll love.			(412) 687-6728	www.subway.com	224383614973		t	img/p/pMb7Qz.jpg
234	2012-04-11 17:32:02.789779-04	Iron City Bikes	221	No attitude. Just Bikes! Stop by and say hi. We're in Oakland.							t	img/p/PLKtvA.png
191	2012-04-11 17:31:21.131953-04	Caliban Book Shop	183	Used Books and New Music in Pittsburgh	Mon-Wed,11:00am - 05:30pm\nThurs,11:00am - 08:00pm\nFri-Sat,11:00am - 05:30pm\nSun,01:00pm - 05:30pm\n	street\n	(412) 681-9111	www.calibanbooks.com	126412670722686		t	img/p/DZadP5.jpg
192	2012-04-11 17:31:22.140157-04	St. Nicholas Greek Orthodox Cathedral	184	St. Nicholas can trace its membership back to the turn of the century, when many of the first Greek immigrants made their way to Pittsburgh. Among them were men who were enlisted by the city's early industrialists to paint the buildings and smokestacks of the iron and steel mills. The present church building was purchased in 1923. It formerly housed a Congregational (Protestant) congregation.			(412) 682-3866				t	img/p/gPcDjH.jpg
235	2012-04-11 17:32:04.259789-04	Orient Express	222								t	img/p/OrientExpress.jpg
193	2012-04-11 17:31:22.839955-04	20th Century Club	185	Welcome to The Twentieth Century Club, a private women’s club founded in 1894, whose elegant facilities are available for both member and non-member functions. The Club’s experienced and attentive staff, fulltime head chef and kitchen staff will provide you with unparalleled meeting and dining experiences. The Club has a wide choice of rooms appointed with beautiful silver and linens for a lunch as small as two to a function serving 750. The Club is known in particular for its Art Deco ballroom, considered to be one of the finest examples of the style remaining in the United States. The ballroom and the Club’s main dining room are the perfect settings for weddings and other special events. The Twentieth Century Club is located in the heart of Oakland at 4201 Bigelow Boulevard and is easily accessible from all parts of the city. The building itself is a 4-story 16th Century Italian Renaissance Revival whose main entrance with its circular drive graciously welcomes you.			(412) 621-2353	http://www.thetwentiethcenturyclub.com/			t	img/p/trE9oS.jpg
194	2012-04-11 17:31:23.56416-04	Burgers & Rice Bowl	186				(412) 953-3999				t	img/p/BurgersRiceBowl.jpg
199	2012-04-11 17:31:27.768396-04	Pittsburgh Chamber Music Society	187	To buy tickets call: 412-624-4129    www.pittsburghchambermusic.org			(412) 624-4129	http://www.pittsburghchambermusic.org/newSite/	85378651541		t	img/p/gXbZ7h.jpg
195	2012-04-11 17:31:24.49971-04	Carnegie Library of Pittsburgh	187	Engaging our Community in Literacy and Learning		street\nlot\n	(412) 622-3114	http://www.clpgh.org/	73877691965	CLP_tweets	t	img/p/ZJzsVz.jpg
200	2012-04-11 17:31:28.676492-04	Kevin's Deli	188				(412) 621-6368	http://kevinsdeli.com/index.htm			t	img/p/eroZX6.jpg
197	2012-04-11 17:31:26.387089-04	Carnegie Music Hall	187				(412) 622-3131	http://www.carnegiemuseums.org/interior.php?pageID=30			t	img/p/4o1FMp.jpg
215	2012-04-11 17:31:42.377047-04	Stuckert's Towing	203				(412) 621-6876				t	
207	2012-04-11 17:31:35.491815-04	Auto Palace	195	Auto Palace in Pittsburgh, PA treats the needs of each individual customer with paramount concern. We know that you have high expectations, and as a car dealer we enjoy the challenge of meeting and exceeding those standards each and every time.	Mon-Thurs,09:00am - 06:00pm\nFri,09:00am - 05:00pm\nSat,10:00am - 02:00pm\nSun,Closed\n	street\nlot\n	(412) 687-4000	http://www.auto-palace.com/ou/pittsburgh-porsche/	118139271700		t	img/p/T2l82X.jpg
198	2012-04-11 17:31:26.788136-04	Carnegie Museum of Natural History	187	Mission Statement: To conduct scientific inquiry, generate knowledge, and promote stewardship of the Earth. Through public engagement, we share the joy of discovery about the processes that shape the diversity of our world and its inhabitants.	Mon,Closed\nTues-Wed,10:00am - 05:00pm\nThurs,10:00am - 08:00pm\nFri-Sat,10:00am - 05:00pm\nSun,12:00pm - 05:00pm\n	street\nlot\n	(412) 622-3131	http://www.carnegiemnh.org/	31539090679		t	img/p/hdaH3f.jpg
201	2012-04-11 17:31:29.712082-04	New China Inn	189				(412) 621-6199	http://cmu.collegebite.com/restaurants/26-New-China-Inn	194045876982		t	img/p/vLyCMC.jpg
208	2012-04-11 17:31:36.526127-04	Mitchell's Tavern/ Charlie's	196				(412) 682-9530				t	img/p/Mitchells.jpg
203	2012-04-11 17:31:32.602215-04	First Niagara Bank	191				(412) 681-4200	www.fnfg.com			t	img/p/beXqck.gif
204	2012-04-11 17:31:33.313628-04	Townsend Booksellers	192	Fine used, rare, out-of-print, scholarly and unusual books in all fields bought & sold. Over 30,000 volumes. We are an open shop in the Pittsburgh neighborhood of Oakland, the cultural center of Pittsburgh, near the University of Pittsburgh, Carnegie Mellon University and the Carnegie Museum and Library.			(412) 682-8030	http://www.townsendbooksellers.com/			t	img/p/w68J7G.jpg
213	2012-04-11 17:31:40.373693-04	Central Catholic High School	201	Central Catholic is an all-boys Catholic high school in the Lasallian tradition	Mon-Fri,08:00am - 03:30pm\nSat-Sun,Closed\n	lot\n	(412) 621-8189	http://www.centralcatholichs.com/	130802130287924		t	img/p/FakKOK.jpg
205	2012-04-11 17:31:34.313242-04	Centre Cleaners	193				(412) 683-6466				t	img/p/CentreDryCleaners.jpg
218	2012-04-11 17:31:49.175934-04	First Trinity Evangelical Lutheran	206	Cathdral parish of the Lutheran Church - Missouri Synod located in the Shadyside neighborhood within walking distance of the University of Pittsburgh and Carnegie Mellon University.		street\nlot\n	(412) 683-4121	www.FirstTrinity.net	104930072884104		t	img/p/aOVkrk.jpg
210	2012-04-11 17:31:38.013726-04	A-1 Self Storage	198				(412) 621-5947	http://www.a1storage.com/			t	
217	2012-04-11 17:31:48.20534-04	Carnegie Mellon University	205	Andrew Carnegie said: "My heart is in the work." No statement better captures the passion and drive of our people to make a real difference. \n\nAt Carnegie Mellon University, we're not afraid of the work.\n\nOur educational environment creates problem solvers, drivers of innovation and pioneers in technology and the arts.  \n\nEmployers in every field say our graduates are ready to hit the ground running the day they graduate. And that's just what they do.\n\nCMU alumni around the globe are inventors and Nobel Prize winners, decorated actors and artists, business leaders and scientists.			(412) 268-2000	www.cmu.edu	7133766387		t	img/p/uMHKxt.jpg
211	2012-04-11 17:31:38.326639-04	Seoul Mart	199				(412) 683-8767				t	img/p/SeoulMart.jpg
214	2012-04-11 17:31:41.360245-04	Pittsburgh Filmmakers	202	Pittsburgh's nonprofit media arts center.			(412) 681-5449	http://pfm.pittsburgharts.org/	140954329326030		t	img/p/yWGbjM.jpg
216	2012-04-11 17:31:42.695823-04	Rodef Shalom Congregation	204				(412) 621-6566	http://rodefshalom.org/	155098914506223		t	img/p/w3BDlo.jpg
212	2012-04-11 17:31:39.200071-04	Salim's Middle Eastern Store & Deli	200		Mon-Fri,10:30am - 07:00pm\nSat,11:00am - 07:00pm\nSun,11:00am - 06:00pm\n	street\n	(412) 621-8110	http://www.salimsfoods.com/	98788647369		t	img/p/M8SJo2.jpg
220	2012-04-11 17:31:51.12969-04	CVS Pharmacy	208				(412) 682-1088	www.cvs.com			t	img/p/Cun_dY.jpg
237	2012-04-11 17:32:06.767087-04	Starbucks	224		Mon-Fri,05:30am - 09:00pm\nSat-Sun,06:30am - 09:00pm\n		1 (412) 687-2494		148908658467476		t	img/p/5umaS3.jpg
261	2012-04-11 17:32:31.915312-04	Food for Thought	242	Come in to enjoy Pittsburgh's BEST corned beef sandwiches! Have a cup of matzo ball soup, and a home made potato latke too!	Mon,09:00am - 06:00pm\nTues-Thurs,Closed\nFri,09:00am - 06:00pm\nSat,09:00am - 03:00pm\nSun,Closed\n	street\n	(412) 682-5033	www.foodforthoughtdeli.com	332191845288		t	img/p/NUK8qs.jpg
262	2012-04-11 17:32:34.039367-04	Porch	243	Situated within beautiful Schenley Plaza, The Porch is a come-as-you-are, no reservations restaurant serving the University community, neighborhood regulars, and park users alike.  Creating simple, delicious, scratch-made food that we love to cook and eat; The Porch is an authentic everyday experience for a casual meal, a special occasion destination, or a great place to enjoy the sights and sounds of Oakland while unwinding with a cold drink and friends new and old. \n\nBe sure to swing by and “Pick Up The Porch” at our convenient walk up window! Get a great made-to-order breakfast treat and a warm cup of Coffee Tree Roasters coffee, weekday mornings starting at 7:30.	Mon-Thurs,11:00am - 11:00pm\nFri,11:00am - 12:00am\nSat,10:00am - 12:00am\nSun,10:00am - 10:00pm\n	street\n	412-687-6724	www.ThePorchAtSchenley.com	153047761455085		t	img/p/jgSmLZ.jpg
269	2012-04-11 17:32:40.621168-04	First National Bank	249								t	img/p/FirstNationalBank.jpg
263	2012-04-11 17:32:35.041296-04	T-Mobile	244								t	img/p/GGzHbz.jpg
222	2012-04-11 17:31:52.498817-04	Frick Fine Arts Building	\N	<p>The <b>Henry Clay Frick Fine Arts Building</b> is a landmark <a href="/pages/w/108184865875634">Renaissance</a> <a href="/pages/w/112965068717748">villa</a> and a <a href="/pages/w/111653488863454">contributing property</a> to the <a href="/pages/w/112467428765043">Schenley Farms-Oakland Civic Historic District</a> on the campus of the <a href="/pages/w/103721419666144">University of Pittsburgh</a> in <a href="/pages/w/114943251851302">Pittsburgh</a>, <a href="/pages/w/105528489480786">Pennsylvania</a>, <a href="/pages/w/112463092102121">United States</a>. It consists of classrooms, a library, and art galleries around an open cloister and contains a 45 feet (14 m) high octagon capped by a pyramidal roof.</p><p>It sits on the southern edge of <a href="/pages/w/106067466091314">Schenley Plaza</a>, opposite <a href="/pages/w/103122986394038">The Carnegie Institute</a>, and is the home of Pitt’s History of Art and Architecture Department, Studio Arts Department, and the Frick Fine Arts Library. Before its front steps is <a href="/pages/w/113767545300643">Mary Schenley Memorial Fountain</a>. The <a href="/pages/w/135181376514977">Schenley Park Casino</a>, Pittsburgh’s first multi-purpose arena with an indoor ice skating rink, sat on the location of the building before burning down in December 1896.</p><p>A noted 1965 low relief portrait of Henry Clay Frick by <a href="/pages/w/135326859830932">Malvina Hoffman</a> in limestone sits above the entrance to the building. Hoffman was 79 years old when she accepted the commission. She could not sculpt it herself because union rules prevented sculptors from working on a relief attached to a building. However, she climbed up on the scaffolding to oversee the completion of the work.</p>			(412) 648-2410	http://www.tour.pitt.edu/tour-060.html	109424739075604		t	img/p/7HIGQl.gif
229	2012-04-11 17:31:57.757085-04	Razzy Fresh	216	Those who have been there can't explain, Those who haven't been there will never understand...\n\nhttp://razzyfresh.com/	Mon-Sun,12:00pm - 11:30pm\n		412-586-7924	http://www.razzyfresh.com/	117733734917057		t	img/p/wTOfFD.jpg
227	2012-04-11 17:31:56.5691-04	Stephen Foster Memorial	214	<p>The <b><a href="/pages/w/108069372554198">Stephen Collins Foster</a> Memorial</b> is a performing arts center, museum and archive at the <a href="/pages/w/103721419666144">University of Pittsburgh</a> in <a href="/pages/w/107849519242700">Pittsburgh</a>, Pennsylvania, <a href="/pages/w/112463092102121">USA</a>.</p><p>It is a <a href="/pages/w/111653488863454">contributing property</a> to the <a href="/pages/w/114370705245238">Schenley Farms</a> <a href="/pages/w/107818619241049">National Historic District</a>, is designated as a <a href="/pages/w/137104802976972">Pittsburgh History and Landmarks Foundation</a> <a href="/pages/w/143797182364503">Historical Landmark</a>, and is a landmark whose significance is designated by a <a href="/pages/w/105570276143990">Pennsylvania Historical and Museum Commission</a> <a href="/pages/w/146297778723568">Historical Marker</a>. It is located along <a href="/pages/w/138636916156047">Forbes Avenue</a> in the <a href="/pages/w/120017098044789">Oakland</a> neighborhood on the campus of the University of Pittsburgh, often referred to as Pitt.</p><p>The main structure houses the two theaters that serve as performance spaces for the university's <a href="/pages/w/144825322194845">Department of Theatre Arts</a>: the 478-seat Charity Randall Theatre and 151-seat Henry Heymann Theatre. The left wing of the building houses the Stephen Foster Memorial Museum and the Center for American Music which contains the <a href="/pages/w/103721419666144">University of Pittsburgh</a>'s Foster Hall Collection that includes manuscripts, copies of over 200 of his musical compositions, examples of recordings, songsters, broadside, programs, books, various memorabilia, and several musical instruments, including one of Foster's pianos. The memorial is also home to the university's <a href="/pages/w/104068596295980">Ethelbert Nevin</a> Collection and the <a href="/pages/w/108085125886962">Society for American Music</a>.</p>			(412) 624-4100	http://www.tour.pitt.edu/tour-235.html	112125882137098		t	img/p/b4PjBg.gif
223	2012-04-11 17:31:53.414202-04	Nationality Classrooms	211	<p>The <b>Cathedral of Learning</b>, a Pittsburgh landmark listed in the National Register of Historic Places, is the centerpiece of the <a href="/pages/w/103721419666144">University of Pittsburgh</a>'s main campus in the <a href="/pages/w/120017098044789">Oakland</a> neighborhood of <a href="/pages/w/114943251851302">Pittsburgh, Pennsylvania</a>, <a href="/pages/w/112463092102121">United States</a>. Standing at 535 feet (&#62;163 m), the 42-story <a href="/pages/w/108373259187703">Late Gothic Revival</a> Cathedral is the tallest educational building in the <a href="/pages/w/110259392336572">Western hemisphere</a> and the second tallest university building (fourth <a href="/pages/w/132924450078453">tallest educationally-purposed building</a>) in the world. The Cathedral of Learning was commissioned in 1921 and ground was broken in 1926. The first class was held in the building in 1931 and its exterior finished in October 1934, prior to its formal dedication in June, 1937. The Cathedral is a steel frame structure overlaid with <a href="http://en.wikipedia.org/wiki/Indiana_limestone" class="wikipedia">Indiana limestone</a> and contains more than 2,000 rooms and windows. The building is often used by the University in photographs, postcards, and other advertisements.</p>			(412) 624-6000	http://www.pitt.edu/~natrooms/	103800759658071		t	img/p/A3YSA3.gif
224	2012-04-11 17:31:54.319866-04	Rangos Research Center	212				(412) 692-5325				t	
228	2012-04-11 17:31:57.479864-04	Magee Womens Hospital	215				(412) 641-1000	www.magee.edu			t	
225	2012-04-11 17:31:54.599482-04	St. Paul Cathedral	213	<p>The <b>Cathedral of Saint Paul</b> (commonly known as <b>Saint Paul Cathedral</b>) is the <a href="http://en.wikipedia.org/wiki/Mother_church">mother church</a> of the <a href="http://en.wikipedia.org/wiki/Roman_Catholic">Roman Catholic</a> <a href="http://en.wikipedia.org/wiki/Diocese">Diocese</a> of <a href="http://en.wikipedia.org/wiki/Pittsburgh">Pittsburgh</a>, <a href="http://en.wikipedia.org/wiki/Pennsylvania">Pennsylvania</a>, <a href="http://en.wikipedia.org/wiki/United_States">United States</a>. It should not be confused with <i><a href="http://en.wikipedia.org/wiki/St_Paul's_Cathedral">St Paul's Cathedral</a></i> in the <a href="http://en.wikipedia.org/wiki/City_of_London">City of London</a>, <a href="http://en.wikipedia.org/wiki/England">England</a>.</p><p>It is the center of spiritual life for some three thousand parishioners and more than three quarter million Catholics in the <a href="http://en.wikipedia.org/wiki/Roman_Catholic_Diocese_of_Pittsburgh">Diocese of Pittsburgh</a>.</p><p>The first place of public worship for Catholics in the area was in 1754 in the <a href="http://en.wikipedia.org/wiki/Feedlot">stockyard</a> of <a href="http://en.wikipedia.org/wiki/Fort_Duquesne">Fort Duquesne</a>. From the date of the French evacuation of the fort in 1758 until a church was started in 1808 at the corner of Liberty and Washington Streets, there were no resident priests, but mass was occasionally said in private homes by missionaries traveling west. When the Diocese of Pittsburgh was formed in 1843, Saint Paul's Church at the corner of Fifth and Grant Street was consecrated as a Cathedral. Because of declining downtown population and industrial pollution, this site was sold to <a href="http://en.wikipedia.org/wiki/Henry_Clay_Frick">Henry Clay Frick</a>. A new Cathedral was opened in 1906 at its present location on Fifth Avenue in the <a href="http://en.wikipedia.org/wiki/Oakland_(Pittsburgh)">Oakland</a> neighborhood of Pittsburgh.</p><p>The original cost of the building and furnishings was nearly 1.1 million dollars, including $205,000 for the real estate.</p>			(412) 621-4951		214787775231464		t	img/p/qhhH1Z.gif
226	2012-04-11 17:31:55.635627-04	PNC Bank	\N	PNC Bank, a member of The PNC Financial Services Group, is one of the nation’s largest diversified financial services organizations, serving approximately 5.8 million customers through 2,900 branches and 6,800 ATMs in 19 states (and Washington, D.C.). \n\nFor more than 150 years, we have been committed to providing our clients with great service and powerful financial expertise to help them meet their financial goals. We offer a wide range of services for all our customers, from individuals and small businesses, to corporations and government entities. No matter how simple or complicated your needs, we're sure to have the products, knowledge and resources necessary for financial success.\n\nWeb: www.pnc.com\nTwitter: www.twitter.com/pncnews\nYouTube: www.youtube.com/pnc\n\nUpdated:  4/7/12			(412) 683-7161	www.pnc.com	224986157558341		t	img/p/DdGxT2.jpg
238	2012-04-11 17:32:07.803977-04	Maximum Flavor	225	Maximum Flavor Pizza Shop!	Mon-Fri,10:30am - 11:30pm\nSat,11:00am - 11:30pm\nSun,11:30am - 11:30pm\n	street\n	4126211773	http://www.campusfood.com/restaurant.asp?campusid=147&mlid=82873&gclid=CN3P__nSz58CFY6F7Qod9laqYw	282017818396		t	img/p/fz6nhz.jpg
271	2012-04-11 17:32:42.120799-04	Uncle Jimmy's Bar	251		Mon-Sun,11:00am - 02:30am\n		4126817480		110774195655675		t	img/p/iwqBxN.jpg
264	2012-04-11 17:32:35.57475-04	Noodles & Company	245	Our History:\nThe story begins in 1993 when serving fresh food fast was virtually unheard of. In fact, the term "fast casual" didn't even exist. The only option for busy people and families on the go was the fast food drive thru window. Not exactly a healthy or wholesome option. Our founder Aaron Kennedy was living in New York City at the time and asked the question, "Why not?" Why couldn't a restaurant bridge the gap and offer convenience and fresh, flavorful food. Radical thinking, right? \nBeing in one of the restaurant capitals of the world, Aaron also saw a lot of niche restaurants-Italian, American, Chinese-but that required everyone to be in the mood for the same thing. So he asked himself another question, "Why not offer all of these great flavors under one roof?" But there was something missing. There had to be an anchor, something that would tie the concept together. Enter the noodle. Noodles and pasta are part of almost every cuisine-from Pad Thai in Thailand to Lo Mein in China to Mac & Cheese in Wisconsin. So why not put the world's best loved noodle and pasta dishes on one menu and serve them fast and fresh? \nFast forward to 1995 and that's what he did. What started as a single restaurant in the Cherry Creek neighborhood of Denver, Colorado has now grown to hundreds of restaurants nationwide. And along the way we've expanded the "& Company" part of the menu by adding soups, salads and sandwiches				www.noodles.com	29530040245		t	img/p/JjWFBV.jpg
270	2012-04-11 17:32:41.103577-04	Fez Grill	250		Mon-Thurs,11:00am - 11:00pm\nFri-Sat,11:00am - 12:00am\nSun,12:00pm - 10:00pm\n	street\n	(412)802-0200		247662965273555		t	img/p/_3rZ4S.jpg
265	2012-04-11 17:32:36.570215-04	The Tanning Pitt	246	Level 1: 20 minute laydown!\n-$6 - single session\n-$25 - five sessions\n-$50 - month unlimited\n\nLevel 2: 11 minute standup!\n-$8 - single session\n-$35 - five sessions\n-$60 - month unlimited\n\nLevel 3: 12 minute laydown!\n-$13 - single session\n-$55 - five sessions\n-$90 - ten sessions\n\nLevel 4: 9 minute standup!\n-$16 - single session\n-$65 - five sessions\n-$115 - ten sessions\n\nSpray Tan: 7 minute, hand held spray gun, done by technician!\n-$30 - single session\n-$125 - five sessions\n-$200 - ten sessions	Mon-Sat,10:00am - 08:00pm\nSun,12:00pm - 05:00pm\n		412-681-6464	tanningpitt.com	101312886615571		t	img/p/oUoP_N.jpg
266	2012-04-11 17:32:37.720678-04	Jester's Court Tattoos	13								t	img/p/MULjyl.jpg
267	2012-04-11 17:32:38.679031-04	School 2 Career	247				412.682.1144	www.s2c.opdc.org	144604442237881		t	img/p/wHQXO3.jpg
272	2012-04-11 17:32:43.151071-04	Corner Store	252								t	img/p/CornerStore.jpg
268	2012-04-11 17:32:39.715156-04	Hurley Associates	248	Since 1988, Hurley Associates has provided the management, coaching and professional services to assist clients in choosing strategies that offer a comfortable today and a secure tomorrow. Our specialists examine each aspect of a client's financial life and then design and execute a plan to satisfy both short term and long term objectives. This is done with the client in collaboration to insure that the plan not only meets the client's financial objectives, but is also in alignment with the client's personal philosophies and values. Hurley Associates has built its practice on the integrity of its practitioners and the trust and confidence of its clients. Contact us today to see what we can do for you.							t	img/p/HurleyAssociates.jpg
278	2012-04-11 17:32:51.803487-04	Nebby Beauty Care	258	HOURS OF OPERATION: MON thur SAT / 10AM - 7PM\nSUNDAY BY APPT ONLY			412.682.0581	www.nebbybeautycare.com	241740689219898		t	img/p/oI0u4N.jpg
273	2012-04-11 17:32:43.880768-04	Dana's Dunkin' Duds Laundry	253								t	img/p/DanasDunkinDuds.jpg
274	2012-04-11 17:32:45.60675-04	Oakland Mini Market	254								t	img/p/OaklandMiniMarket.jpg
323	2012-04-11 17:33:00.61296-04	Project Olympus	\N								f	
275	2012-04-11 17:32:47.43443-04	Las Palmas	255								t	img/p/LasPalmas.jpg
322	2012-04-11 17:33:00.600768-04	4616 Henry (INI)	\N								f	
276	2012-04-11 17:32:48.936011-04	It's Dogg'n It	256								t	img/p/ItsDogginIt.jpg
277	2012-04-11 17:32:50.697835-04	Razzy Fresh	257	Those who have been there can't explain, Those who haven't been there will never understand...\n\nhttp://razzyfresh.com/					117733734917057		t	img/p/fZVryU.jpg
324	2012-04-11 17:33:00.624922-04	Boss House	\N								f	
325	2012-04-11 17:33:00.637108-04	Doherty Apartments	\N								f	
326	2012-04-11 17:33:00.649273-04	Donner House	\N								f	
327	2012-04-11 17:33:00.661469-04	Fairfax Apartments	\N								f	
328	2012-04-11 17:33:00.673282-04	Fraternity Quadrangle	\N								f	
329	2012-04-11 17:33:00.685246-04	Hamerschlag House	\N								f	
330	2012-04-11 17:33:00.697259-04	Henderson House	\N								f	
331	2012-04-11 17:33:00.70898-04	London Terrace Apartments	\N								f	
332	2012-04-11 17:33:00.720864-04	Margaret Morrison Sorority Houses	\N								f	
280	2012-04-11 17:32:53.785731-04	S & T Nails	260	Located in the heart of Oakland, we are a family-owned Nail Studio specializing in creative nail designs as well as nail services. Our services include high quality acrylics and solar nails, pedicures, manicures, nail health, quality products, sanitation, and exemplary client care. Please stop by and enjoy our services. Walk-ins are always welcome!							t	img/p/ZJ2Z2B.jpg
289	2012-04-11 17:33:00.200815-04	Porter Hall	\N								f	
281	2012-04-11 17:32:54.529294-04	Game Stop	261								t	img/p/M34h5G.jpg
290	2012-04-11 17:33:00.212706-04	Bramer House	\N								f	
283	2012-04-11 17:32:56.087592-04	Garage Door Saloon	263								t	img/p/GarageDoorSaloon.jpg
304	2012-04-11 17:33:00.382825-04	Pittsburgh Technology Center	\N								f	
284	2012-04-11 17:32:57.616219-04	Cathedral of Learning	264	<p>The <b>Cathedral of Learning</b>, a Pittsburgh landmark listed in the National Register of Historic Places, is the centerpiece of the <a href="/pages/w/103721419666144">University of Pittsburgh</a>'s main campus in the <a href="/pages/w/120017098044789">Oakland</a> neighborhood of <a href="/pages/w/114943251851302">Pittsburgh, Pennsylvania</a>, <a href="/pages/w/112463092102121">United States</a>. Standing at 535 feet (&#62;163 m), the 42-story <a href="/pages/w/108373259187703">Late Gothic Revival</a> Cathedral is the tallest educational building in the <a href="/pages/w/110259392336572">Western hemisphere</a> and the second tallest university building (fourth <a href="/pages/w/132924450078453">tallest educationally-purposed building</a>) in the world. The Cathedral of Learning was commissioned in 1921 and ground was broken in 1926. The first class was held in the building in 1931 and its exterior finished in October 1934, prior to its formal dedication in June, 1937. The Cathedral is a steel frame structure overlaid with <a href="http://en.wikipedia.org/wiki/Indiana_limestone" class="wikipedia">Indiana limestone</a> and contains more than 2,000 rooms and windows. The building is often used by the University in photographs, postcards, and other advertisements.</p>					103800759658071		t	img/p/8GNn7y.gif
291	2012-04-11 17:33:00.224896-04	Collaborative Innovation Center	\N								f	
285	2012-04-11 17:32:58.54138-04	Fitzgerald Field House	265	<p><b>Fitzgerald Field House</b> is a 4,122-seat multi-purpose athletic venue on the campus of the <a href="/pages/w/103721419666144">University of Pittsburgh</a> in <a href="/pages/w/107849519242700">Pittsburgh</a>, <a href="/pages/w/105528489480786">Pennsylvania</a>, <a href="/pages/w/112463092102121">United States</a>. Fitzgerald Field House is named for <a href="/pages/w/129235813784705">Rufus Fitzgerald</a>, a past <a href="/pages/w/109254189092507">chancellor</a> (1945–1955) of the university.</p><h2>Usage</h2><p>Fitzgerald Field House is the competitive venue for the Pitt varsity sports of <a href="/pages/w/110320585686089">volleyball</a>, gymnastics, and <a href="/pages/w/114528558557312">wrestling</a>. With an indoor track, the Field House also serves as the primary indoor facility for the university's <a href="/pages/w/110832715608677">track and field</a> team, as well as housing the wrestling training facility and the primary training and weight facilities for Pitt's Olympic sports. In addition, it contains the offices and locker rooms for <a href="/pages/w/135051766529268">baseball</a>, cross country, soccer, softball, swimming and diving, and tennis. The facility also has <a href="/pages/w/109469199070946">squash</a> courts. The Field House is connected by an underground tunnel to Trees Pool and the Gymnastics Training Center, both located in <a href="/pages/w/140487702645114">Trees Hall</a>.</p><p>Built in 1951, Fitzgerald Field House was, for five decades, the home of <a href="/pages/w/112548005423927">Pitt's basketball program</a>. It also served as the home basketball court of Pitt's <a href="/pages/w/119385911441054">intracity rival</a>, the <a href="/pages/w/108047995890084">Duquesne University Dukes</a>, from 1956-57 to 1963-64. From the 1980s until 2002, the Pitt men's basketball team also played selected <a href="/pages/w/112476615434365">Big East Conference</a> and non-conference games at <a href="/pages/w/106207572744412">Mellon Arena</a>. <a href="/pages/w/107317555964353">Pitt's women's basketball team</a> also used the Field House as their primary home court. Both the men's and women's Pitt basketball teams moved to the <a href="/pages/w/108576002499545">Petersen Events Center</a> in 2002.</p>					138570156170859		t	img/p/cjRkbU.gif
297	2012-04-11 17:33:00.297682-04	Hillman Center for Future-Generation Technologies	\N								f	
292	2012-04-11 17:33:00.23753-04	College of Fine Arts	\N								f	
286	2012-04-11 17:32:59.512781-04	Petersen Events Center	266	<p><i>Not to be confused with <a href="/pages/w/116479975065913">Petersen Sports Complex</a>.</i></p><p><b>The John M. and Gertrude E. Petersen Events Center</b> (more commonly known as the <b>Petersen Events Center</b> or <b>"The Pete"</b>) is a 12,508-seat multi-purpose <a href="/pages/w/105986246098810">arena</a> on the campus of the <a href="/pages/w/103721419666144">University of Pittsburgh</a> in the <a href="/pages/w/120017098044789">Oakland neighborhood</a> of <a href="/pages/w/114943251851302">Pittsburgh, Pennsylvania</a>. It hosts the men's and women's <a href="/pages/w/113404725336948">Pitt Panthers</a> basketball teams. The arena is named for philanthropists John Petersen and his wife Gertrude, who donated $10 million for its construction. John Petersen, a Pitt alumnus, is a native of nearby <a href="/pages/w/108306975863361">Erie, Pennsylvania</a> and is the retired President and CEO of <a href="/pages/w/104061032965070">Erie Insurance Group</a>. The Petersen Events Center was winner of the 2003 Innovative Architecture & Design Honor Award from <i>Recreation Management</i> magazine.</p>					108576002499545		t	img/p/SzjZ10.gif
287	2012-04-11 17:33:00.176833-04	Alumni House	\N								f	
288	2012-04-11 17:33:00.188934-04	Baker Hall	\N								f	
301	2012-04-11 17:33:00.346002-04	Margaret Morrison Carnegie Hall	\N								f	
293	2012-04-11 17:33:00.249482-04	Cyert Hall	\N								f	
298	2012-04-11 17:33:00.309857-04	Hamburg Hall	\N								f	
294	2012-04-11 17:33:00.261431-04	Doherty Hall	\N								f	
295	2012-04-11 17:33:00.273519-04	Facilities Managmenet Services Building	\N								f	
296	2012-04-11 17:33:00.285627-04	Gates Center for Computer Science	\N								f	
299	2012-04-11 17:33:00.321961-04	Hamershchlag Hall	\N								f	
302	2012-04-11 17:33:00.358226-04	Mellon Institute	\N								f	
300	2012-04-11 17:33:00.333838-04	Hunt Library	\N								f	
306	2012-04-11 17:33:00.406809-04	Roberts Engineering Hall	\N								f	
303	2012-04-11 17:33:00.370553-04	Newell-Simon Hall	\N								f	
305	2012-04-11 17:33:00.394765-04	Rand Building	\N								f	
308	2012-04-11 17:33:00.430776-04	Skibo Gymnasium	\N								f	
307	2012-04-11 17:33:00.418703-04	Scaife Hall	\N								f	
309	2012-04-11 17:33:00.442536-04	Smith Hall	\N								f	
310	2012-04-11 17:33:00.454602-04	Software Engineering Institute	\N								f	
311	2012-04-11 17:33:00.466758-04	Solar Decathlon House	\N								f	
312	2012-04-11 17:33:00.478972-04	University Center	\N								f	
313	2012-04-11 17:33:00.490712-04	Warner Hall	\N								f	
314	2012-04-11 17:33:00.502955-04	Wean Hall	\N								f	
315	2012-04-11 17:33:00.515138-04	Whitfield Hall	\N								f	
316	2012-04-11 17:33:00.527437-04	300 South Craig	\N								f	
317	2012-04-11 17:33:00.539818-04	311 South Craig	\N								f	
398	2012-04-11 17:55:21.945206-04	The Hillman Center for Performing Arts	269	Celebrating our Sixth Season of live community and professional performing arts!	Mon-Fri,09:00am - 09:00pm\nSat-Sun,Closed\n		412-968-3040	www.thehillman.org	43587112789		f	img/p/xz0foo.jpg
335	2012-04-11 17:33:00.756713-04	Roselawn Houses	\N								f	
365	2012-04-11 17:33:01.120785-04	Forbes Craig Apartments	\N								f	
336	2012-04-11 17:33:00.768963-04	Shady Oak Apartments	\N								f	
337	2012-04-11 17:33:00.780804-04	Shirley Apartments	\N								f	
384	2012-04-11 17:33:01.349484-04	Posvar Hall	\N								f	
338	2012-04-11 17:33:00.793053-04	Spirit House	\N								f	
366	2012-04-11 17:33:01.132811-04	Forbes Pavilion	\N								f	
339	2012-04-11 17:33:00.805034-04	Stever House	\N								f	
340	2012-04-11 17:33:00.81759-04	Tech House	\N								f	
341	2012-04-11 17:33:00.830014-04	Webster Hall	\N								f	
367	2012-04-11 17:33:01.144892-04	Gardner Steel Conference Center	\N								f	
342	2012-04-11 17:33:00.841842-04	Welch House	\N								f	
343	2012-04-11 17:33:00.854033-04	West Wing	\N								f	
399	2012-04-11 17:55:48.366798-04	Church of The Ascension	270				+1 (412) 621-4361	www.ascensionpittsburgh.org	111584942214189		f	img/p/vO68yL.jpg
344	2012-04-11 17:33:00.866012-04	Woodlawn Apartments	\N								f	
368	2012-04-11 17:33:01.156847-04	Hillman Library	\N								f	
345	2012-04-11 17:33:00.878128-04	Allen Hall	\N								f	
346	2012-04-11 17:33:00.890076-04	Alumni Hall	\N								f	
385	2012-04-11 17:33:01.361499-04	Ruskin Hall	\N								f	
347	2012-04-11 17:33:00.901834-04	Amos Hall	\N								f	
369	2012-04-11 17:33:01.168749-04	Holland Hall	\N								f	
348	2012-04-11 17:33:00.913445-04	Barco Law Building	\N								f	
349	2012-04-11 17:33:00.925273-04	Bellefield Hall	\N								f	
350	2012-04-11 17:33:00.937712-04	Bellefield Towers	\N								f	
370	2012-04-11 17:33:01.180972-04	Information Sciences Building	\N								f	
351	2012-04-11 17:33:00.949854-04	Benedum Hall	\N								f	
352	2012-04-11 17:33:00.962017-04	Biomedical Science Tower	\N								f	
400	2012-04-11 17:55:54.284415-04	Alumni Hall	271	<p><b>Alumni Hall</b> at the <a href="/pages/w/103721419666144">University of Pittsburgh</a> is a <a href="/pages/w/137104802976972">Pittsburgh History and Landmarks Foundation</a> Historic Landmark that was formerly known as the <b>Masonic Temple</b> in <a href="/pages/w/107849519242700">Pittsburgh</a>. Constructed in 1914-1915, it was designed by renowned architect <a href="/pages/w/113339828715130">Benno Janssen</a> of Janssen & Abbot Architects. Other buildings in <a href="/pages/w/107849519242700">Pittsburgh’s</a> <a href="/pages/w/120017098044789">Oakland</a> Cultural District designed by Janssen include the <a href="/pages/w/103110366395904">Pittsburgh Athletic Association</a>, <a href="/pages/w/112061378812569">Mellon Institute</a>, and Pitt’s <a href="/pages/w/111017818950110">Eberly Hall</a> (which was known as Alumni Hall prior to 1998).</p><p>The building’s design is that of a classical temple with a well-defined base, midsection and ornamental terra cotta pediment, topped with a clay tile roof. The structure is steel, clad primarily in limestone with terra cotta details. The rear elevation is brick.</p><h2>Dimensions</h2><p>Alumni Hall spans 200 feet (61 m) along <a href="/pages/w/110225835694913">Fifth Avenue</a> on Pitt’s campus and runs 120 feet (37 m) deep. It is nine stories high with two-story spaces throughout, has 98,000 square feet (9,100 m2) of functional space as well as an additional 12,000 square feet (1,100 m2) accommodating entrances, corridors, stairwells, and elevators. There are three main entrances on Fifth, Lytton, and Tennyson Avenues.</p>					108904389133986		f	img/p/edOXua.gif
353	2012-04-11 17:33:00.97428-04	Biomedical Science Tower 3	\N								f	
371	2012-04-11 17:33:01.193136-04	Langley Hall	\N								f	
354	2012-04-11 17:33:00.986204-04	Bruce Hall	\N								f	
355	2012-04-11 17:33:00.998103-04	Bouquet Gardens	\N								f	
386	2012-04-11 17:33:01.373518-04	Salk Hall	\N								f	
356	2012-04-11 17:33:01.010516-04	Cathedral of Learning	\N								f	
372	2012-04-11 17:33:01.204888-04	Learning Research and Development Center	\N								f	
357	2012-04-11 17:33:01.022533-04	Chevron Science Center	\N								f	
358	2012-04-11 17:33:01.034853-04	Clapp Hall	\N								f	
359	2012-04-11 17:33:01.047181-04	Cost Sports Center	\N								f	
373	2012-04-11 17:33:01.217022-04	Litchfield Towers	\N								f	
360	2012-04-11 17:33:01.060481-04	Craig Hall	\N								f	
361	2012-04-11 17:33:01.072697-04	Crawford Hall	\N								f	
362	2012-04-11 17:33:01.08464-04	David Lawrence Hall	\N								f	
374	2012-04-11 17:33:01.229144-04	Loeffler Building	\N								f	
363	2012-04-11 17:33:01.096516-04	Eberly Hall	\N								f	
364	2012-04-11 17:33:01.108602-04	Fraternity Housing Complex	\N								f	
387	2012-04-11 17:33:01.385822-04	Sennott Square	\N								f	
375	2012-04-11 17:33:01.240844-04	Log Cabin	\N								f	
376	2012-04-11 17:33:01.252731-04	Lothrop Hall	\N								f	
377	2012-04-11 17:33:01.265006-04	McCormick Hall	\N								f	
388	2012-04-11 17:33:01.398121-04	Space Research Coordination Center	\N								f	
378	2012-04-11 17:33:01.277144-04	Mervis Hall	\N								f	
379	2012-04-11 17:33:01.289105-04	Music Building	\N								f	
380	2012-04-11 17:33:01.301293-04	Old Engineering Hall	\N								f	
389	2012-04-11 17:33:01.410271-04	Sutherland Hall	\N								f	
381	2012-04-11 17:33:01.313247-04	Oxford Building	\N								f	
382	2012-04-11 17:33:01.325493-04	Panther Hall	\N								f	
383	2012-04-11 17:33:01.337507-04	Petersen Sports Complex	\N								f	
390	2012-04-11 17:33:01.42211-04	Thaw Hall	\N								f	
391	2012-04-11 17:33:01.433945-04	Thomas Detre Hall of the WPIC	\N								f	
392	2012-04-11 17:33:01.445762-04	Trees Hall	\N								f	
393	2012-04-11 17:33:01.457684-04	University Place Office Building	\N								f	
394	2012-04-11 17:33:01.469937-04	Van de Graaff Building	\N								f	
395	2012-04-11 17:33:01.482043-04	Victoria Building	\N								f	
396	2012-04-11 17:54:29.764731-04	CLP - East Liberty	267								f	
397	2012-04-11 17:54:48.165525-04	Fairmont Pittsburgh	268	Located at 510 Market Street, Fairmont Pittsburgh is situated in the heart of Downtown Pittsburgh and within walking distance to the city’s thriving Cultural District, the newly renovated Market Square, eclectic shopping and world-class sporting venues.  The Four Diamond, 185-room property is LEED certified at the Gold level and features a contemporary art and industry design theme.		lot\nvalet\n	+1 412 773 8800	www.fairmont.com/pittsburgh	169064927035		f	img/p/ZEpE1J.jpg
401	2012-04-11 17:55:57.773406-04	Lew Hays Pony Field	272						215736895125587		f	img/p/QACH7r.png
402	2012-04-11 17:55:58.727702-04	West View VFW Post 2754	273								f	
403	2012-04-11 17:55:59.738595-04	AmVets Post 103	274								f	
166	2012-04-11 17:30:54.482347-04	New Balance Pittsburgh	158	Best New Balance Selection in Pittsburgh at Two Locations: Oakland & The Waterfront	Mon-Sat,10:00am - 07:00pm\nSun,12:00pm - 05:00pm\n	street\nlot\n	(412) 697-1333	http://stores.newbalance.com/pittsburgh/default.aspx?s3=ppc	118061484906426		t	img/p/5TBbl3.jpg
411	2012-05-03 11:38:10.185456-04		282								f	
109	2012-04-11 17:30:00.683217-04	Miller, Werrin & Gruendel	105		Mon-Thurs,07:15am - 05:00pm\nFri,07:15am - 04:00pm\nSat,08:00am - 12:00pm\nSun,Closed\n	lot\n	(412) 641-0200	http://www.dentalpgh.com/	172090269508339		t	img/p/0diXFy.jpg
7	2012-04-11 17:28:31.055281-04	Maggie & Stella's Gifts	276	Oakland's premier gift shop in the heart of Pitt's campus.	Mon-Thurs,09:00am - 06:00pm\nFri,09:00am - 05:00pm\nSat,10:00am - 05:00pm\nSun,Closed\n	street\nlot\ngarage\n	(412) 648-1353	http://www.maggieandstellasgifts.com/	83057190581	Maggieandstella	t	img/p/a3PtZj.jpg
406	2012-05-02 18:19:08.936963-04	Purnell Center for the Arts	205								t	img/p/CMU_Logo.jpg
407	2012-05-02 18:24:46.218821-04	The Frame	278	The Frame is a non-profit, student-run gallery at Carnegie Mellon University.  It is committed to showcasing the artistic work of Carnegie Mellon students and to promoting ambitious and experimental art within both our university committee and the Pittsburgh scene. Please visit our website for more information, or our flickr and youtube for super art and video! 				http://www.cmu.edu/theframe/			t	img/p/CMU_Logo_1.jpg
282	2012-04-11 17:32:55.041733-04	Red Oak Café	262	"Fast, Fresh, Healthy"	Mon-Thurs,07:00am - 07:00pm\nFri,07:00am - 07:00pm\nSat,10:00am - 04:00pm\nSun,Closed\n	street\n	(412)-621-2221	http://www.innovationineating.com/	154785357899970	Otysmoothie	t	img/p/n4pM7E.jpg
60	2012-04-11 17:29:18.600815-04	Oakland BID	58	We keep our community up-to-date on all of the happenings, promotions and events in and around Oakland!  As the epicenter of diversity, cultural attractions, universities and the medical community of Pittsburgh, Oakland always has something new and exciting to share.	8:30am-5:00pm,Mon--Fri\n	street\n	(412) 683-6243	http://www.onlyinoakland.org/	351740933073	Only_in_Oakland	t	img/p/Uc0mCK.jpg
279	2012-04-11 17:32:52.87809-04	Underground Printing	259	Underground Printing offers custom screenprinted and embroidered apparel, produced entirely in-house, that is simply better, faster and cheaper than you'll find anywhere else. We also provide promotional products of all kinds through our network of vendors. We are fully Greek & Collegiate licensed. Art help is provided free of charge. Experience how easy, fun, and affordable making custom shirts can be with Underground Printing!	Mon-Fri,10:30am - 07:00pm\nSat-Sun,Closed\n	street\n	412-927-0201	http://www.undergroundshirts.com/	105935139489670	ugpsteelcity	t	img/p/znZT0n.jpg
408	2012-05-02 20:03:38.928228-04		279								t	
409	2012-05-02 20:27:22.977325-04	Friend's Meeting House	280	Pittsburgh Friends Meeting meets in a picturesque former mansion near University of Pittsburgh and Carnegie Mellon University. We are members of The Religious Society of Friends, better known as Quakers.\r\n\r\nWe meet at a Meeting House in silence. We wait expectantly for the Spirit to inspire.\r\n\r\nWith no paid minister, we all undertake the responsibilities of ministry.\r\n\r\nWe have no creed and no statement of belief.  Each of us is responsible for working out our spirituality. 							t	img/p/HouseFront.png
89	2012-04-11 17:29:47.183987-04	The Comfort Zone	85	Relax and let Comfort Zone Salon take care of all of your hair coloring, cutting, waxing, and other beauty salon services. We welcome walk-ins and offer UPMC™ and student discounts as well as monthly specials. We are locally owned and operated and have 10+ years of experience. Call us today for more information.			(412) 688-9311	http://www.comfortzonesalons.com/			t	img/p/Comfort_Zone.JPG
405	2012-04-17 17:24:21.175414-04	Rick Gottlieb, DMD	277	Dental Office	7AM-6PM,Mon-Fri\n	street\nlot\n	412-682-7017				t	
404	2012-04-13 10:34:44.008893-04	Touch of Gold and Silver Jewelry Store	275	Full Service Jewelry store including in house design and repair services. \r\nWe carry Fine Jewelry, Wedding bands, Engagement rings, Pearls, Watches, Sterling Silver,  fashion jewelry and accesories.	10:00 am-5:30 pm,Mon-Fri\n	street\nlot\ngarage\n	412-687-3867	http://touchofgoldandsilverjewelrystore.com/	Touch of Gold and Silver		t	img/p/LOGO_002.JPG
118	2012-04-11 17:30:11.344764-04	Quaker Steak and Lube	113	Commonly referred to as “The Lube,” the restaurant features a unique blend of great service, award-winning food, supercharged events and the most eye-popping décor in the restaurant industry. Today, with over 30 locations, The Lube serves over 70 million wings annually, sells its bottled sauces around the world, has won the title of “Best Wings USA,” and has over 100 local, national and international awards for its wings and 21 signature wing sauces.\r\n\r\nIn addition to its award-winning chicken wings, The Lube boasts a large selection of menu items including burgers, sandwiches, fresh salads, steaks and ribs. With a large following of loyal customers ages 2 to 82, The Lube welcomes singles, couples, families, sports enthusiasts and seniors to enjoy an eating experience like no other. Guests will gawk at the muscle cars, vintage cars, trucks and a vast selection of custom and antique motorcycles that have been rescued and restored to adorn the walls and ceilings of the restaurants.\r\n\r\nThere’s always something FUN happening at the Lube as the restaurants feature weekly events/specials like “Kids Eat Free Mondays,” “All-You-Can-Eat Tuesdays,” and “Bike-Night Wednesdays.” Additionally, guests are welcome to put their heat-seeking skills to the test as they bravely take on The Lube’s famous “Atomic Wing Challenge,” which includes consuming some of the hottest wings known to man and living to talk about it the next day.	Mon-Thurs,11:00am - 11:00pm\nFri-Sat,11:00am - 12:00am\nSun,11:00am - 10:00pm\n	street\n	(412) 381-9464	http://www.quakersteakandlube.com/	214598471933322	qsloakland	t	img/p/kPBUfp.jpg
233	2012-04-11 17:32:01.746154-04	3 Guys Optical Center	220	We are your partner in optical excellence	Mon-Fri,09:00am - 05:30pm\nSat,10:00am - 02:00pm\nSun,Closed\n	street\nlot\n	(412) 682 1499	http://3guysoptical.com/	161961833858809		t	img/p/qhHBQy.jpg
412	2012-05-16 10:53:49.47607-04	Schenley Plaza	283	When Schenley Plaza was purchased by the City of Pittsburgh from Mary Schenley, the area was known as St. Pierre's Ravine.  In 1897, the Bellefield Bridge was built across the ravine, serving as the primary entrance to Schenley Park.  But the City's Director of Public Works, Edward Bigelow, envisioned a grand entrance to the park. In 1911, Frederick Law Olmsted Jr.'s report Pittsburgh Main Thoroughfares and the Down Town District suggested filling in the ravine and creating a formal entrance plaza. In the next year or two, the ravine was indeed filled, likely with the remains of the Grant Street "hump," a small hill in downtown Pittsburgh. \r\n\r\nAlso in 1911, a design competition was held to create a memorial to Mary Schenley. The winning design, Victor David Brenner's A Song to Nature, was announced in 1913, by which point it seemed logical to locate the massive sculpture on top of the now-buried Bellefield Bridge. A second design competition was held in 1915, this time to determine the future of the Schenley Plaza site. The winning design by Horace W. Sellers and H. Bartol Register placed A Song to Nature in a formal planted setting, with the landscape design later completed by James Greenleaf, who had served as President of the American Society of Landscape Architects. The memorial was dedicated in 1918 and the Plaza completed in 1923.\r\n\r\nWith Oakland's growth came the demand for more parking spaces, and gradually the Plaza lost any function as a park. Forbes Field, the Plaza's immediate next-door neighbor, brought thousands of spectators to Pittsburgh Pirates games from 1909 through 1970. The expanding universities, businesses, and healthcare community all created a shortage of parking in the area, and the Plaza was officially designated a parking lot in 1949, a far cry from the envisioned grand entrance to Schenley Park. \r\n\r\nThe restored Schenley Plaza, as you experience it today, is the result of ten years of planning and partnership to revitalize and reclaim a prized piece of historic Schenley Park. Work officially began in 2004 to convert the parking lot back into a park, including the creation of a new traffic plan that would add street parking to replace most of the spots lost with the demolition of the parking lot. Less than 100 parking spots were actually eliminated as part of the Plaza's transformation. \r\n\r\nSchenley Plaza finally fulfilled the vision of its original planners in June 2006, when a grand opening event brought 40,000 people into Oakland to visit the new park. The design for Schenley Plaza was modeled after New York City’s Bryant Park.  This historic park, once a rundown haven for illicit activity, has been called one of our country’s “great urban redevelopment success stories.”   The Schenley Plaza design team incorporated Bryant Park’s best design features, such as permeable edges, lush gardens, a carousel, quality lighting, a great lawn, food kiosks, space for programming events and activities, and moveable tables and chairs. The Plaza has continued to grow each year under the Pittsburgh Parks Conservancy's management, and it has become a destination for families, students, businesspeople, and community groups looking for a great space to appreciate what the city has to offer.\r\nFuture Plans\r\n\r\nWhile the revitalized Schenley Plaza is certainly welcoming and vibrant, we’ve got bigger ideas for the future.  Your support can help make these amenities and programs come to life:\r\n\r\n    Free lending library offering on-site use of newspapers, magazines and books\r\n    Games, including backgammon, checkers and chess\r\n    Carriage rides\r\n    Winter programming\r\n    Public art\r\n				http://www.pittsburghparks.org/schenleyplaza			t	img/p/Schenley_Plaza.JPG
413	2012-05-17 09:20:58.478073-04	WQED Studios	284	America's first community-sponsored television station in Pittsburgh, PA, Mister Rogers' Neighborhood. We LOVE Pittsburgh!				http://www.wqed.org/	WQEDPittsburgh		t	img/p/WQED.jpg
196	2012-04-11 17:31:25.467517-04	Carnegie Museum of Art	187	Carnegie Museum of Art was founded by industrialist and philanthropist Andrew Carnegie in 1895. One of the four Carnegie Museums of Pittsburgh, it is nationally and internationally recognized for its distinguished collection of American and European works from the 16th century to the present, its Decorative Arts and Design collection, and for its commitment, since its founding, to collect the "old masters of tomorrow". The Carnegie International returns in October, 2013. Initiated in 1896, The International is one of the world's preeminent surveys in contemporary art.	Mon-Wed,10:00am - 05:00pm\nThurs,10:00am - 08:00pm\nFri-Sat,10:00am - 05:00pm\nSun,12:00am - 05:00pm\n	lot\n	(412) 622-3131	http://web.cmoa.org/	38014611787	cmoa	t	img/p/HSh0ku.jpg
414	2012-05-21 21:21:59.13986-04	The Original Hot Dog Shop	285	The Original Hot Dog Shop opened in Pittsburgh, in June 1960 near Forbes Field and the University of Pittsburgh. The restaurant quickly became known for its hot dogs and large portions of French fries, although the menu also includes sandwiches, salads and pizza. In 2001, Gourmet Magazine ranked the hot dogs fourth-best in America and The New York Times named it to a list of one of the "high spots in a nation of hot-dog heavens" in 2002.\r\n\r\nThe University of Pittsburgh's student newspaper The Pitt News named The O "Best French Fries" in 2002, 2003, 2004, 2005, 2006, 2007 and 2008.					143319765710644		t	img/p/TheO.jpg
415	2012-06-13 20:53:04.192701-04	Revv Oakland	286	Revv is a coworking space for technology startup companies, located in the heart of Pittsburgh’s Oakland neighborhood at 122 Meyran Ave. Our 5000 sq ft facility offers a centrally located, affordable and productive work environment for early stage companies that need to move fast without breaking the bank. We offer inexpensive monthly leases, and connections to resources that save time and money, so that you can focus on building product, getting customers and growing your business.				http://www.revvoakland.com/			t	
410	2012-05-03 11:33:28.67712-04	Hilton Garden Inn	281	Located in the heart of Pittsburgh, Pennsylvania's medical and educational district, the new 13-story Hilton Garden Inn Pittsburgh University Place is one of the best full-service, upscale, contemporary hotels of the Pittsburgh/Oakland area.\r\nDescription\r\nLocated 18 miles from Pittsburgh International Airport (PIT) and perfectly set in an urban environment, this Hilton Garden Inn hotel has meticulously been renovated with a custom décor package unlike any other Hilton Garden Inn. Spacious guest rooms feature Hilton Garden Inn Evolution bedding, large work area with well-lit desk, modern décor and complimentary high-speed internet. The Hilton Garden...See More\r\nGeneral Information\r\nHilton Garden Inn Pittsburgh University Place is located in the heart of Oakland and is home to world-class universities and colleges, most within walking distance of the hotel. Nearby universities include:\r\n\r\nUniversity of Pittsburgh\r\nCarnegie Mellon University\r\nCarlow University\r\nChatham University\r\nDuquesne University\r\nPoint Park University\r\n\r\nHilton Garden Inn Pittsburgh University Place is minutes from the University of Pittsburgh Medical Center. UPMC's $8 billion campus integrates 20 hospitals, 400 physician and outpatient sites with the nearby University of Pittsburgh. Most UPMC award-winning locations are within a half mile of the hotel:\r\n\r\nChildren's Hospital of Pittsburgh UPMC\r\nUPMC Shadyside\r\nMagee-Women's Hospital of UPMC\r\nMontefiore Hospital\r\nUPMC Presbyterian\r\nUniversity of Pittsburgh Cancer Institute\r\nUPMC Mercy		valet\n	1 (412) 683-2040	http://hiltongardeninn.hilton.com/en/gi/hotels/index.jhtml?ctyhocn=PITUCGI	371455053761		t	img/p/261079_371455053761_598444707_n.jpg
\.


--
-- Data for Name: places_place_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY places_place_tags (id, place_id, tag_id) FROM stdin;
1	1	1
2	1	2
3	2	3
4	2	4
5	2	5
6	3	6
7	3	7
8	3	8
9	4	9
10	4	10
11	4	11
12	4	12
13	5	13
14	5	14
15	6	3
16	6	4
17	6	5
18	7	15
19	7	16
20	7	17
21	8	18
22	8	19
23	8	20
24	8	21
25	9	20
26	9	21
27	9	18
28	10	15
29	10	22
30	10	23
31	10	24
32	11	6
33	11	25
34	12	6
35	12	26
36	13	27
37	14	20
38	14	28
39	14	29
47	16	6
48	16	7
49	16	8
50	17	20
51	17	28
52	17	21
53	17	19
54	17	36
55	18	6
56	18	37
57	18	38
58	19	6
59	19	39
60	19	8
61	20	6
62	20	37
63	20	40
64	21	3
65	21	4
66	21	5
67	22	14
68	22	13
69	22	3
70	22	4
71	22	5
72	23	6
73	23	37
74	23	41
75	24	42
76	24	43
77	25	15
78	25	16
79	25	44
80	25	45
81	26	6
82	26	37
83	26	46
84	26	40
85	27	10
86	27	11
87	27	47
88	27	48
93	29	3
94	29	4
95	29	5
96	30	13
97	30	14
98	31	3
99	31	4
100	31	5
101	32	3
102	32	4
103	32	5
104	33	6
105	33	25
106	33	38
107	34	15
108	34	16
109	34	50
110	34	51
111	35	16
112	35	47
113	35	52
114	35	53
115	35	54
116	35	55
117	35	6
118	35	56
119	36	44
120	36	57
121	37	13
122	37	14
123	38	3
124	38	4
125	38	5
126	39	20
127	39	28
128	39	29
129	40	6
130	40	26
131	41	6
132	41	37
133	41	58
134	42	13
135	42	14
136	42	42
137	43	15
138	43	44
139	43	59
140	43	60
141	43	61
142	44	6
143	44	37
144	44	38
145	45	6
146	45	62
147	45	37
148	46	20
149	46	28
150	46	29
151	47	6
152	47	25
153	48	63
156	50	6
157	50	25
158	50	38
159	51	66
160	51	42
166	53	6
167	53	37
168	53	46
169	53	40
170	54	16
171	54	15
172	54	52
173	54	53
174	54	54
175	54	55
176	54	6
177	55	44
178	55	59
179	55	70
180	56	6
181	56	25
182	57	57
183	57	2
184	58	3
185	59	71
186	59	72
187	59	73
188	60	74
189	61	74
190	62	74
191	63	20
192	63	28
193	63	29
194	64	6
195	64	37
196	64	75
197	65	76
198	65	77
201	67	3
202	67	4
203	67	5
204	68	6
205	68	37
206	68	40
207	69	78
208	69	6
209	70	20
210	70	18
211	71	15
212	71	16
213	71	79
214	72	80
215	73	6
216	73	37
217	73	7
218	73	38
219	73	8
220	74	62
221	74	81
222	74	82
223	74	52
224	74	83
225	75	71
229	77	83
230	78	6
231	78	37
232	78	38
233	79	84
234	79	37
235	79	6
236	80	15
237	80	16
238	80	78
239	80	6
240	81	6
241	81	37
242	81	40
243	81	85
244	81	86
245	82	3
246	82	4
247	82	5
248	83	6
249	83	37
250	83	78
251	84	1
252	84	2
253	85	14
254	85	42
255	86	44
256	86	87
257	87	14
258	87	88
259	88	89
260	88	90
261	88	6
262	88	41
266	90	1
267	90	2
268	91	15
269	91	16
270	91	44
271	92	6
272	92	25
273	93	14
274	94	6
275	94	7
276	94	37
277	94	8
278	95	6
279	95	37
280	96	74
281	97	6
282	97	91
283	97	37
284	98	15
285	98	61
286	98	44
287	98	59
288	98	60
289	99	6
290	99	37
291	99	38
292	100	92
293	101	16
294	101	15
295	101	89
296	101	90
297	101	6
298	101	93
299	102	10
300	102	11
301	102	48
302	103	44
303	103	57
304	104	94
305	104	95
306	105	44
307	105	59
308	105	70
309	106	15
310	106	16
311	106	44
312	106	59
313	106	60
314	107	96
315	107	56
316	108	15
317	108	97
320	109	98
321	110	6
322	110	25
323	111	20
324	111	21
325	111	19
326	111	18
327	112	15
328	112	16
329	112	44
330	113	6
331	113	37
332	113	41
333	113	38
334	114	74
335	115	99
336	116	16
337	116	80
338	116	100
339	117	56
340	118	6
341	118	37
342	119	44
343	119	42
344	119	14
348	121	15
349	121	97
350	122	6
351	122	37
352	122	25
353	122	38
354	123	15
355	123	102
356	123	103
357	124	6
358	124	37
359	124	46
360	124	40
361	125	6
362	125	37
363	125	104
366	127	6
367	127	90
368	128	15
369	128	22
370	128	23
371	129	20
372	129	28
373	129	29
374	130	15
375	130	16
376	130	106
377	130	107
378	131	15
379	131	16
380	131	80
381	132	6
382	132	37
383	132	78
391	135	6
392	135	8
393	136	6
394	136	8
395	136	7
396	137	6
397	137	37
398	137	91
399	138	13
400	138	14
401	139	6
402	139	90
403	139	55
404	139	40
405	140	6
406	140	37
407	140	91
408	140	81
409	140	82
410	140	83
411	141	15
412	141	44
413	141	59
414	141	60
415	141	61
416	142	6
417	142	37
418	142	110
419	142	111
420	142	8
421	143	6
422	143	37
423	143	38
424	144	6
425	144	37
426	145	6
427	146	112
428	146	113
429	146	114
430	147	6
431	147	26
432	148	6
433	148	37
434	148	91
435	148	81
436	148	82
437	148	83
438	149	15
439	149	115
440	149	93
441	150	10
442	150	11
443	150	48
444	151	16
445	151	116
446	151	6
447	151	38
448	151	111
449	152	6
450	152	37
451	152	91
452	153	6
453	153	81
454	153	82
455	153	37
456	153	84
457	153	83
458	154	10
459	154	11
460	154	47
461	154	48
462	155	15
463	155	16
464	155	50
465	155	51
466	156	117
467	156	118
468	156	119
469	157	6
470	157	37
471	157	40
472	158	44
473	158	120
474	158	16
475	159	99
476	160	15
477	160	97
478	161	6
479	161	7
480	161	37
481	161	8
485	163	15
486	163	55
487	164	6
488	164	81
489	164	82
490	164	37
491	164	83
492	164	38
493	165	3
494	165	4
495	165	5
496	166	15
497	166	16
498	166	106
499	166	107
506	168	6
507	168	37
508	168	8
509	169	6
510	169	37
511	169	81
512	169	82
513	169	52
514	169	83
515	170	15
516	170	97
517	170	42
518	171	94
519	171	95
520	171	113
521	171	112
522	172	15
523	172	52
524	172	53
525	172	54
526	172	55
527	172	6
528	173	6
529	173	37
530	173	40
531	173	46
532	174	6
533	174	122
534	174	38
535	175	14
536	175	42
537	175	123
538	176	3
539	176	4
540	176	5
541	177	6
542	177	37
543	177	8
544	177	124
545	178	10
546	178	11
547	178	47
548	178	48
549	179	6
550	179	81
551	179	82
552	179	83
553	180	6
554	180	37
555	180	41
556	181	83
557	181	125
558	182	6
559	182	25
560	183	3
561	183	4
562	183	126
563	184	15
564	184	16
565	184	127
566	185	42
567	185	128
568	185	107
569	186	6
570	186	37
571	186	38
572	187	6
573	187	90
574	187	55
575	187	91
576	188	6
577	188	37
578	188	40
579	188	129
580	189	130
581	189	127
582	189	131
583	190	6
584	190	37
585	190	38
586	191	15
587	191	22
588	191	23
589	192	3
590	192	4
591	192	5
592	192	6
593	193	43
594	193	128
595	193	6
596	194	6
597	194	37
598	194	40
599	194	46
600	195	23
601	195	123
602	195	132
603	196	130
604	196	127
605	197	80
606	197	133
607	198	134
608	198	135
609	198	136
610	198	137
611	199	80
612	200	6
613	200	122
614	200	38
615	201	6
616	201	37
617	201	46
618	201	40
628	203	10
629	203	11
630	203	47
631	203	48
632	204	15
633	204	16
634	204	123
635	204	23
636	205	72
637	205	73
638	206	99
639	207	139
640	208	6
641	208	37
642	208	81
644	210	140
645	211	55
646	211	40
647	211	129
648	212	6
649	212	37
650	212	41
651	213	13
652	213	14
653	214	141
654	214	14
655	214	142
656	215	96
657	215	143
658	216	3
659	216	131
660	216	127
661	216	144
662	216	4
663	217	13
664	217	14
665	217	42
666	218	3
667	218	4
668	218	5
671	220	15
672	220	61
673	220	44
674	220	59
675	220	60
676	221	16
677	221	96
678	221	99
679	222	14
680	222	42
681	223	13
682	223	14
683	224	14
684	224	42
685	225	3
686	225	4
687	225	5
688	226	10
689	226	11
690	226	47
691	226	48
692	227	42
693	227	66
694	228	44
695	228	59
696	228	70
697	229	6
698	229	26
699	230	76
700	230	77
701	230	147
702	231	3
703	231	4
704	231	5
705	232	44
706	232	57
707	233	15
708	233	16
709	233	44
710	234	148
711	235	46
712	235	6
713	235	40
714	235	37
715	236	149
716	236	42
717	237	6
718	237	8
719	238	6
720	238	25
721	238	38
722	239	6
723	239	37
724	239	78
725	240	16
726	240	15
727	241	150
728	241	23
729	242	45
730	242	16
731	243	46
732	243	6
733	243	40
734	243	37
735	244	16
736	244	40
737	244	151
738	245	57
739	245	2
740	246	57
741	246	2
742	247	6
743	247	37
744	247	25
745	247	124
746	247	41
747	248	25
748	248	6
749	249	152
750	249	27
751	250	6
752	250	37
753	250	38
754	251	25
755	251	6
756	252	78
757	252	6
758	253	55
759	254	81
760	254	52
761	254	82
762	254	83
763	255	20
764	255	21
765	255	19
766	256	81
767	256	52
768	256	82
769	256	83
770	257	115
771	258	6
772	258	37
773	259	78
774	259	6
775	259	37
776	260	6
777	260	37
778	261	6
779	261	37
780	261	7
781	261	122
782	261	153
783	262	6
784	262	37
785	262	25
786	262	38
787	263	154
788	263	16
789	264	6
790	264	40
791	264	37
792	265	21
793	265	155
794	266	152
795	266	27
796	267	14
797	268	156
798	269	10
799	269	11
800	269	48
801	270	6
802	270	37
803	270	157
804	270	158
805	271	6
806	271	81
807	271	82
808	271	83
809	272	16
810	272	6
811	272	55
812	273	159
813	274	55
814	274	6
815	275	6
816	275	37
817	275	91
818	276	55
819	276	83
820	277	6
821	277	26
822	278	19
823	278	21
824	279	160
825	280	36
826	280	21
827	281	16
828	281	161
829	282	6
830	282	37
831	282	7
832	282	8
833	282	38
834	283	81
835	283	52
836	283	82
837	283	83
838	284	42
839	284	14
840	285	162
841	285	42
842	286	162
843	286	42
844	287	93
845	288	93
846	289	93
847	290	93
848	291	93
849	292	93
850	293	93
851	294	93
852	295	93
853	296	93
854	297	93
855	298	93
856	299	93
857	300	93
858	301	93
859	302	93
860	303	93
861	304	93
862	305	93
863	306	93
864	307	93
865	308	93
866	309	93
867	310	93
868	311	93
869	312	93
870	313	93
871	314	93
872	315	93
873	316	93
874	317	93
875	318	93
876	319	93
877	320	93
878	321	93
879	322	93
880	323	93
881	324	93
882	325	93
883	326	93
884	327	93
885	328	93
886	329	93
887	330	93
888	331	93
889	332	93
890	333	93
891	334	93
892	335	93
893	336	93
894	337	93
895	338	93
896	339	93
897	340	93
898	341	93
899	342	93
900	343	93
901	344	93
902	345	93
903	346	93
904	347	93
905	348	93
906	349	93
907	350	93
908	351	93
909	352	93
910	353	93
911	354	93
912	355	93
913	356	93
914	357	93
915	358	93
916	359	93
917	360	93
918	361	93
919	362	93
920	363	93
921	364	93
922	365	93
923	366	93
924	367	93
925	368	93
926	369	93
927	370	93
928	371	93
929	372	93
930	373	93
931	374	93
932	375	93
933	376	93
934	377	93
935	378	93
936	379	93
937	380	93
938	381	93
939	382	93
940	383	93
941	384	93
942	385	93
943	386	93
944	387	93
945	388	93
946	389	93
947	390	93
948	391	93
949	392	93
950	393	93
951	394	93
952	395	93
953	60	163
954	404	121
955	404	164
956	109	167
957	109	168
962	62	178
963	62	179
964	62	180
965	62	181
966	62	182
967	62	183
968	62	184
969	62	185
970	62	186
971	282	111
972	406	42
974	407	127
975	409	3
976	409	4
977	89	20
978	89	28
979	89	29
980	410	1
981	410	2
982	196	193
983	196	194
984	196	195
985	196	196
986	196	197
987	196	7
988	196	136
989	405	198
990	405	199
991	405	200
992	405	169
993	405	202
994	405	203
995	405	204
996	405	201
997	233	205
998	233	206
999	233	45
1000	412	77
1001	413	66
1002	413	131
1003	413	133
1004	413	74
1005	413	141
1006	413	14
1007	413	195
1008	413	62
1009	413	127
1010	414	6
1011	415	212
\.


--
-- Data for Name: places_placemeta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY places_placemeta (id, place_id, key, value) FROM stdin;
1	1	fb_synced_field	description
2	1	fb_synced_field	image
3	1	fb_last_synced	2012-04-11T17:28:27.022635
4	3	fb_synced_field	description
5	3	fb_synced_field	image
6	3	fb_synced_field	hours
7	3	fb_synced_field	parking
8	3	fb_last_synced	2012-04-11T17:28:28.533140
9	6	fb_synced_field	description
10	6	fb_synced_field	image
11	6	fb_last_synced	2012-04-11T17:28:30.759508
12	7	fb_synced_field	description
13	7	fb_synced_field	image
14	7	fb_synced_field	hours
15	7	fb_synced_field	parking
16	7	fb_last_synced	2012-04-11T17:28:31.839637
17	11	fb_synced_field	description
18	11	fb_synced_field	image
19	11	fb_synced_field	hours
20	11	fb_synced_field	parking
21	11	fb_last_synced	2012-04-11T17:28:34.970356
22	12	fb_synced_field	description
23	12	fb_synced_field	url
24	12	fb_synced_field	image
25	12	fb_synced_field	parking
26	12	fb_last_synced	2012-04-11T17:28:36.043685
27	16	fb_synced_field	description
28	16	fb_synced_field	image
29	16	fb_last_synced	2012-04-11T17:28:39.108500
30	18	fb_synced_field	description
31	18	fb_synced_field	image
32	18	fb_last_synced	2012-04-11T17:28:42.793525
33	19	fb_synced_field	description
34	19	fb_synced_field	image
35	19	fb_synced_field	hours
36	19	fb_last_synced	2012-04-11T17:28:43.922680
37	20	fb_synced_field	description
38	20	fb_synced_field	image
39	20	fb_synced_field	hours
40	20	fb_synced_field	parking
41	20	fb_last_synced	2012-04-11T17:28:44.870945
42	23	fb_synced_field	image
43	23	fb_synced_field	hours
44	23	fb_synced_field	parking
45	23	fb_last_synced	2012-04-11T17:28:46.737889
46	24	fb_synced_field	description
47	24	fb_synced_field	image
48	24	fb_last_synced	2012-04-11T17:28:47.755904
49	29	fb_synced_field	description
50	29	fb_synced_field	image
51	29	fb_last_synced	2012-04-11T17:28:52.124635
52	30	fb_synced_field	image
53	30	fb_last_synced	2012-04-11T17:28:53.433682
54	31	fb_synced_field	description
55	31	fb_synced_field	url
56	31	fb_synced_field	image
57	31	fb_last_synced	2012-04-11T17:28:54.518648
58	38	fb_synced_field	url
59	38	fb_synced_field	image
60	38	fb_last_synced	2012-04-11T17:28:59.502357
61	40	fb_synced_field	description
62	40	fb_synced_field	image
63	40	fb_synced_field	hours
64	40	fb_synced_field	parking
65	40	fb_last_synced	2012-04-11T17:29:01.163931
66	45	fb_synced_field	description
67	45	fb_synced_field	image
68	45	fb_synced_field	hours
69	45	fb_synced_field	parking
70	45	fb_last_synced	2012-04-11T17:29:05.736431
71	51	fb_synced_field	description
72	51	fb_synced_field	image
73	51	fb_synced_field	parking
74	51	fb_last_synced	2012-04-11T17:29:09.678031
75	54	fb_synced_field	image
76	54	fb_last_synced	2012-04-11T17:29:13.127005
77	55	fb_synced_field	description
78	55	fb_synced_field	image
79	55	fb_last_synced	2012-04-11T17:29:14.590884
80	57	fb_synced_field	description
81	57	fb_synced_field	image
82	57	fb_last_synced	2012-04-11T17:29:16.683721
83	58	fb_synced_field	description
84	58	fb_synced_field	image
85	58	fb_last_synced	2012-04-11T17:29:17.754294
86	60	fb_synced_field	description
87	60	fb_synced_field	image
88	60	fb_last_synced	2012-04-11T17:29:19.272905
89	62	fb_synced_field	description
90	62	fb_synced_field	image
91	62	fb_synced_field	parking
92	62	fb_last_synced	2012-04-11T17:29:20.515905
93	63	fb_synced_field	description
94	63	fb_synced_field	url
95	63	fb_synced_field	image
96	63	fb_last_synced	2012-04-11T17:29:21.741282
97	64	fb_synced_field	description
98	64	fb_synced_field	image
99	64	fb_last_synced	2012-04-11T17:29:22.939212
100	65	fb_synced_field	description
101	65	fb_synced_field	image
102	65	fb_last_synced	2012-04-11T17:29:24.012418
103	68	fb_synced_field	description
104	68	fb_synced_field	image
105	68	fb_synced_field	hours
106	68	fb_synced_field	parking
107	68	fb_last_synced	2012-04-11T17:29:25.916613
108	71	fb_synced_field	description
109	71	fb_synced_field	image
110	71	fb_synced_field	hours
111	71	fb_synced_field	parking
112	71	fb_last_synced	2012-04-11T17:29:28.726847
113	72	fb_synced_field	description
114	72	fb_synced_field	image
115	72	fb_last_synced	2012-04-11T17:29:29.719332
116	73	fb_synced_field	description
117	73	fb_synced_field	hours
118	73	fb_synced_field	parking
119	73	fb_last_synced	2012-04-11T17:29:31.016943
120	78	fb_synced_field	image
121	78	fb_synced_field	hours
122	78	fb_synced_field	parking
123	78	fb_last_synced	2012-04-11T17:29:36.227920
124	79	fb_synced_field	description
125	79	fb_synced_field	image
126	79	fb_synced_field	hours
127	79	fb_synced_field	parking
128	79	fb_last_synced	2012-04-11T17:29:37.404648
129	84	fb_synced_field	description
130	84	fb_synced_field	image
131	84	fb_synced_field	hours
132	84	fb_synced_field	parking
133	84	fb_last_synced	2012-04-11T17:29:43.226098
134	85	fb_synced_field	description
135	85	fb_synced_field	image
136	85	fb_synced_field	parking
137	85	fb_last_synced	2012-04-11T17:29:44.569116
138	86	fb_synced_field	description
139	86	fb_synced_field	image
140	86	fb_synced_field	hours
141	86	fb_last_synced	2012-04-11T17:29:45.605812
142	88	fb_synced_field	image
143	88	fb_last_synced	2012-04-11T17:29:46.885805
144	92	fb_synced_field	description
145	92	fb_synced_field	url
146	92	fb_synced_field	image
147	92	fb_synced_field	hours
148	92	fb_synced_field	parking
149	92	fb_last_synced	2012-04-11T17:29:49.322923
150	93	fb_synced_field	description
151	93	fb_synced_field	image
152	93	fb_last_synced	2012-04-11T17:29:50.351593
153	94	fb_synced_field	description
154	94	fb_synced_field	image
155	94	fb_last_synced	2012-04-11T17:29:51.302340
156	97	fb_synced_field	description
157	97	fb_synced_field	url
158	97	fb_synced_field	image
159	97	fb_synced_field	parking
160	97	fb_last_synced	2012-04-11T17:29:53.191828
161	99	fb_synced_field	description
162	99	fb_synced_field	image
163	99	fb_last_synced	2012-04-11T17:29:54.698738
164	104	fb_synced_field	description
165	104	fb_synced_field	image
166	104	fb_last_synced	2012-04-11T17:29:57.050643
167	106	fb_synced_field	description
168	106	fb_synced_field	image
169	106	fb_synced_field	hours
170	106	fb_last_synced	2012-04-11T17:29:58.646230
171	108	fb_synced_field	description
172	108	fb_synced_field	image
173	108	fb_last_synced	2012-04-11T17:30:00.375589
174	109	fb_synced_field	image
175	109	fb_synced_field	hours
176	109	fb_last_synced	2012-04-11T17:30:01.752397
177	110	fb_synced_field	description
178	110	fb_synced_field	url
179	110	fb_synced_field	image
180	110	fb_synced_field	hours
181	110	fb_synced_field	parking
182	110	fb_last_synced	2012-04-11T17:30:02.955078
183	112	fb_synced_field	description
184	112	fb_synced_field	url
185	112	fb_synced_field	image
186	112	fb_synced_field	hours
187	112	fb_synced_field	parking
188	112	fb_last_synced	2012-04-11T17:30:05.923804
189	114	fb_synced_field	image
190	114	fb_last_synced	2012-04-11T17:30:08.825768
191	118	fb_synced_field	description
192	118	fb_synced_field	image
193	118	fb_synced_field	hours
194	118	fb_synced_field	parking
195	118	fb_last_synced	2012-04-11T17:30:12.582611
196	125	fb_synced_field	url
197	125	fb_synced_field	image
198	125	fb_last_synced	2012-04-11T17:30:19.444668
199	127	fb_synced_field	description
200	127	fb_synced_field	image
201	127	fb_synced_field	hours
202	127	fb_synced_field	parking
203	127	fb_last_synced	2012-04-11T17:30:21.249057
204	129	fb_synced_field	description
205	129	fb_synced_field	image
206	129	fb_last_synced	2012-04-11T17:30:22.934644
207	130	fb_synced_field	description
208	130	fb_synced_field	image
209	130	fb_last_synced	2012-04-11T17:30:23.919939
210	132	fb_synced_field	url
211	132	fb_synced_field	image
212	132	fb_last_synced	2012-04-11T17:30:26.277137
213	135	fb_synced_field	description
214	135	fb_last_synced	2012-04-11T17:30:28.620019
215	136	fb_synced_field	description
216	136	fb_synced_field	image
217	136	fb_last_synced	2012-04-11T17:30:29.538900
218	137	fb_synced_field	image
219	137	fb_last_synced	2012-04-11T17:30:30.442729
220	139	fb_synced_field	description
221	139	fb_synced_field	image
222	139	fb_synced_field	hours
223	139	fb_synced_field	parking
224	139	fb_last_synced	2012-04-11T17:30:31.818788
225	140	fb_synced_field	description
226	140	fb_synced_field	url
227	140	fb_synced_field	image
228	140	fb_synced_field	hours
229	140	fb_synced_field	parking
230	140	fb_last_synced	2012-04-11T17:30:32.755486
231	142	fb_synced_field	description
232	142	fb_synced_field	image
233	142	fb_synced_field	parking
234	142	fb_last_synced	2012-04-11T17:30:34.303216
235	143	fb_synced_field	description
236	143	fb_synced_field	image
237	143	fb_last_synced	2012-04-11T17:30:35.412882
238	144	fb_synced_field	description
239	144	fb_synced_field	url
240	144	fb_synced_field	image
241	144	fb_last_synced	2012-04-11T17:30:36.344332
242	145	fb_synced_field	description
243	145	fb_synced_field	image
244	145	fb_last_synced	2012-04-11T17:30:37.474645
245	147	fb_synced_field	description
246	147	fb_synced_field	image
247	147	fb_synced_field	hours
248	147	fb_synced_field	parking
249	147	fb_last_synced	2012-04-11T17:30:40.069736
250	148	fb_synced_field	description
251	148	fb_synced_field	image
252	148	fb_last_synced	2012-04-11T17:30:40.981010
253	150	fb_synced_field	description
254	150	fb_synced_field	image
255	150	fb_last_synced	2012-04-11T17:30:42.498748
256	155	fb_synced_field	description
257	155	fb_synced_field	image
258	155	fb_synced_field	hours
259	155	fb_last_synced	2012-04-11T17:30:47.028091
260	160	fb_synced_field	description
261	160	fb_synced_field	image
262	160	fb_last_synced	2012-04-11T17:30:49.916800
263	161	fb_synced_field	description
264	161	fb_synced_field	image
265	161	fb_last_synced	2012-04-11T17:30:50.838576
271	164	fb_synced_field	description
272	164	fb_synced_field	image
273	164	fb_synced_field	hours
274	164	fb_synced_field	parking
275	164	fb_last_synced	2012-04-11T17:30:53.874019
276	166	fb_synced_field	description
277	166	fb_synced_field	image
278	166	fb_synced_field	hours
279	166	fb_synced_field	parking
280	166	fb_last_synced	2012-04-11T17:30:55.389892
281	169	fb_synced_field	description
282	169	fb_synced_field	image
283	169	fb_synced_field	hours
284	169	fb_synced_field	parking
285	169	fb_last_synced	2012-04-11T17:30:57.960851
286	170	fb_synced_field	description
287	170	fb_synced_field	image
288	170	fb_synced_field	hours
289	170	fb_last_synced	2012-04-11T17:30:59.031234
290	171	fb_synced_field	description
291	171	fb_synced_field	image
292	171	fb_synced_field	hours
293	171	fb_synced_field	parking
294	171	fb_last_synced	2012-04-11T17:31:00.115226
295	173	fb_synced_field	url
296	173	fb_synced_field	image
297	173	fb_last_synced	2012-04-11T17:31:01.943696
298	174	fb_synced_field	url
299	174	fb_synced_field	image
300	174	fb_synced_field	hours
301	174	fb_last_synced	2012-04-11T17:31:03.119302
302	175	fb_synced_field	description
303	175	fb_synced_field	image
304	175	fb_last_synced	2012-04-11T17:31:04.072732
305	176	fb_synced_field	description
306	176	fb_synced_field	image
307	176	fb_synced_field	hours
308	176	fb_last_synced	2012-04-11T17:31:05.238653
309	177	fb_synced_field	description
310	177	fb_synced_field	url
311	177	fb_synced_field	image
312	177	fb_synced_field	hours
313	177	fb_synced_field	parking
314	177	fb_last_synced	2012-04-11T17:31:06.149623
315	178	fb_synced_field	description
316	178	fb_synced_field	image
317	178	fb_last_synced	2012-04-11T17:31:07.088240
318	181	fb_synced_field	description
319	181	fb_synced_field	url
320	181	fb_synced_field	image
321	181	fb_synced_field	hours
322	181	fb_synced_field	parking
323	181	fb_last_synced	2012-04-11T17:31:11.297357
324	182	fb_synced_field	image
325	182	fb_last_synced	2012-04-11T17:31:12.366779
326	184	fb_synced_field	image
327	184	fb_synced_field	hours
328	184	fb_synced_field	parking
329	184	fb_last_synced	2012-04-11T17:31:14.739762
330	185	fb_synced_field	description
331	185	fb_synced_field	image
332	185	fb_last_synced	2012-04-11T17:31:15.726045
333	186	fb_synced_field	description
334	186	fb_synced_field	url
335	186	fb_synced_field	image
336	186	fb_synced_field	hours
337	186	fb_synced_field	parking
338	186	fb_last_synced	2012-04-11T17:31:16.628930
339	189	fb_synced_field	description
340	189	fb_synced_field	image
341	189	fb_synced_field	hours
342	189	fb_synced_field	parking
343	189	fb_last_synced	2012-04-11T17:31:19.788894
344	190	fb_synced_field	description
345	190	fb_synced_field	image
346	190	fb_last_synced	2012-04-11T17:31:20.840831
347	191	fb_synced_field	description
348	191	fb_synced_field	image
349	191	fb_synced_field	hours
350	191	fb_synced_field	parking
351	191	fb_last_synced	2012-04-11T17:31:21.864044
352	195	fb_synced_field	description
353	195	fb_synced_field	image
354	195	fb_last_synced	2012-04-11T17:31:25.179509
355	196	fb_synced_field	description
356	196	fb_synced_field	image
357	196	fb_synced_field	hours
358	196	fb_synced_field	parking
359	196	fb_last_synced	2012-04-11T17:31:26.122386
360	198	fb_synced_field	description
361	198	fb_synced_field	image
362	198	fb_synced_field	hours
363	198	fb_synced_field	parking
364	198	fb_last_synced	2012-04-11T17:31:27.503480
365	199	fb_synced_field	description
366	199	fb_synced_field	image
367	199	fb_last_synced	2012-04-11T17:31:28.375097
368	201	fb_synced_field	url
369	201	fb_synced_field	image
370	201	fb_last_synced	2012-04-11T17:31:30.743287
371	207	fb_synced_field	description
372	207	fb_synced_field	image
373	207	fb_synced_field	hours
374	207	fb_synced_field	parking
375	207	fb_last_synced	2012-04-11T17:31:36.225063
376	212	fb_synced_field	url
377	212	fb_synced_field	image
378	212	fb_synced_field	hours
379	212	fb_synced_field	parking
380	212	fb_last_synced	2012-04-11T17:31:40.074449
381	213	fb_synced_field	description
382	213	fb_synced_field	image
383	213	fb_synced_field	hours
384	213	fb_synced_field	parking
385	213	fb_last_synced	2012-04-11T17:31:41.095620
386	214	fb_synced_field	description
387	214	fb_synced_field	image
388	214	fb_last_synced	2012-04-11T17:31:42.082800
389	216	fb_synced_field	image
390	216	fb_last_synced	2012-04-11T17:31:47.913507
391	217	fb_synced_field	description
392	217	fb_synced_field	image
393	217	fb_last_synced	2012-04-11T17:31:48.900272
394	218	fb_synced_field	description
395	218	fb_synced_field	url
396	218	fb_synced_field	image
397	218	fb_synced_field	parking
398	218	fb_last_synced	2012-04-11T17:31:50.001903
399	221	fb_synced_field	description
400	221	fb_synced_field	image
401	221	fb_synced_field	hours
402	221	fb_last_synced	2012-04-11T17:31:52.231342
403	222	fb_synced_field	description
404	222	fb_synced_field	image
405	222	fb_synced_field	location.town
406	222	fb_synced_field	location.state
407	222	fb_synced_field	location.latitude
408	222	fb_synced_field	location.longitude
409	222	fb_last_synced	2012-04-11T17:31:53.147110
410	223	fb_synced_field	description
411	223	fb_synced_field	image
412	223	fb_last_synced	2012-04-11T17:31:54.053478
413	225	fb_synced_field	description
414	225	fb_synced_field	image
415	225	fb_last_synced	2012-04-11T17:31:55.364879
416	226	fb_synced_field	description
417	226	fb_synced_field	image
418	226	fb_last_synced	2012-04-11T17:31:56.306109
419	227	fb_synced_field	description
420	227	fb_synced_field	image
421	227	fb_last_synced	2012-04-11T17:31:57.214602
422	229	fb_synced_field	description
423	229	fb_synced_field	image
424	229	fb_synced_field	hours
425	229	fb_last_synced	2012-04-11T17:31:58.421359
426	230	fb_synced_field	description
427	230	fb_synced_field	image
428	230	fb_last_synced	2012-04-11T17:31:59.416228
429	231	fb_synced_field	description
430	231	fb_synced_field	image
431	231	fb_last_synced	2012-04-11T17:32:00.410028
432	232	fb_synced_field	description
433	232	fb_synced_field	image
434	232	fb_synced_field	hours
435	232	fb_synced_field	parking
436	232	fb_last_synced	2012-04-11T17:32:01.463386
437	233	fb_synced_field	description
438	233	fb_synced_field	image
439	233	fb_synced_field	hours
440	233	fb_synced_field	parking
441	233	fb_last_synced	2012-04-11T17:32:02.515132
442	236	fb_synced_field	description
443	236	fb_synced_field	url
444	236	fb_last_synced	2012-04-11T17:32:06.471028
445	237	fb_synced_field	phone
446	237	fb_synced_field	image
447	237	fb_synced_field	hours
448	237	fb_last_synced	2012-04-11T17:32:07.510954
449	238	fb_synced_field	description
450	238	fb_synced_field	phone
451	238	fb_synced_field	url
452	238	fb_synced_field	image
453	238	fb_synced_field	hours
454	238	fb_synced_field	parking
455	238	fb_last_synced	2012-04-11T17:32:08.575100
456	241	fb_synced_field	phone
457	241	fb_synced_field	url
458	241	fb_synced_field	image
459	241	fb_synced_field	hours
460	241	fb_synced_field	parking
461	241	fb_last_synced	2012-04-11T17:32:12.085474
462	242	fb_synced_field	description
463	242	fb_synced_field	phone
464	242	fb_synced_field	url
465	242	fb_synced_field	image
466	242	fb_synced_field	hours
467	242	fb_synced_field	parking
468	242	fb_last_synced	2012-04-11T17:32:13.111604
469	244	fb_synced_field	description
470	244	fb_synced_field	phone
471	244	fb_synced_field	url
472	244	fb_synced_field	image
473	244	fb_synced_field	hours
474	244	fb_synced_field	parking
475	244	fb_last_synced	2012-04-11T17:32:15.044975
476	245	fb_synced_field	description
477	245	fb_synced_field	url
478	245	fb_synced_field	image
479	245	fb_last_synced	2012-04-11T17:32:16.031476
480	246	fb_synced_field	description
481	246	fb_synced_field	url
482	246	fb_synced_field	image
483	246	fb_last_synced	2012-04-11T17:32:16.951378
484	248	fb_synced_field	phone
485	248	fb_synced_field	url
486	248	fb_synced_field	image
487	248	fb_synced_field	hours
488	248	fb_synced_field	parking
489	248	fb_last_synced	2012-04-11T17:32:18.979633
490	249	fb_synced_field	description
491	249	fb_synced_field	phone
492	249	fb_synced_field	url
493	249	fb_synced_field	image
494	249	fb_synced_field	hours
495	249	fb_synced_field	parking
496	249	fb_last_synced	2012-04-11T17:32:20.004881
497	250	fb_synced_field	description
498	250	fb_synced_field	url
499	250	fb_synced_field	image
500	250	fb_last_synced	2012-04-11T17:32:21.026559
501	251	fb_synced_field	phone
502	251	fb_synced_field	image
503	251	fb_synced_field	hours
504	251	fb_last_synced	2012-04-11T17:32:22.169411
505	256	fb_synced_field	description
506	256	fb_synced_field	phone
507	256	fb_synced_field	image
508	256	fb_synced_field	parking
509	256	fb_last_synced	2012-04-11T17:32:26.832645
510	258	fb_synced_field	phone
511	258	fb_synced_field	url
512	258	fb_synced_field	image
513	258	fb_last_synced	2012-04-11T17:32:29.662932
514	260	fb_synced_field	description
515	260	fb_synced_field	phone
516	260	fb_synced_field	url
517	260	fb_synced_field	image
518	260	fb_synced_field	parking
519	260	fb_last_synced	2012-04-11T17:32:31.624739
520	261	fb_synced_field	description
521	261	fb_synced_field	phone
522	261	fb_synced_field	url
523	261	fb_synced_field	image
524	261	fb_synced_field	hours
525	261	fb_synced_field	parking
526	261	fb_last_synced	2012-04-11T17:32:33.767673
527	262	fb_synced_field	description
528	262	fb_synced_field	phone
529	262	fb_synced_field	url
530	262	fb_synced_field	image
531	262	fb_synced_field	hours
532	262	fb_synced_field	parking
533	262	fb_last_synced	2012-04-11T17:32:34.748684
534	264	fb_synced_field	description
535	264	fb_synced_field	url
536	264	fb_synced_field	image
537	264	fb_last_synced	2012-04-11T17:32:36.310059
538	265	fb_synced_field	description
539	265	fb_synced_field	phone
540	265	fb_synced_field	url
541	265	fb_synced_field	image
542	265	fb_synced_field	hours
543	265	fb_last_synced	2012-04-11T17:32:37.433551
544	267	fb_synced_field	phone
545	267	fb_synced_field	url
546	267	fb_synced_field	image
547	267	fb_last_synced	2012-04-11T17:32:39.412288
548	270	fb_synced_field	phone
549	270	fb_synced_field	image
550	270	fb_synced_field	hours
551	270	fb_synced_field	parking
552	270	fb_last_synced	2012-04-11T17:32:41.857099
553	271	fb_synced_field	phone
554	271	fb_synced_field	image
555	271	fb_synced_field	hours
556	271	fb_last_synced	2012-04-11T17:32:42.860261
557	277	fb_synced_field	description
558	277	fb_synced_field	image
559	277	fb_last_synced	2012-04-11T17:32:51.521492
560	278	fb_synced_field	description
561	278	fb_synced_field	phone
562	278	fb_synced_field	url
563	278	fb_synced_field	image
564	278	fb_last_synced	2012-04-11T17:32:52.447834
565	279	fb_synced_field	description
566	279	fb_synced_field	phone
567	279	fb_synced_field	url
568	279	fb_synced_field	image
569	279	fb_synced_field	hours
570	279	fb_synced_field	parking
571	279	fb_last_synced	2012-04-11T17:32:53.517508
572	282	fb_synced_field	description
573	282	fb_synced_field	phone
574	282	fb_synced_field	url
575	282	fb_synced_field	image
576	282	fb_synced_field	hours
577	282	fb_synced_field	parking
578	282	fb_last_synced	2012-04-11T17:32:55.813935
579	284	fb_synced_field	description
580	284	fb_synced_field	image
581	284	fb_last_synced	2012-04-11T17:32:58.272252
582	285	fb_synced_field	description
583	285	fb_synced_field	image
584	285	fb_last_synced	2012-04-11T17:32:59.223790
585	286	fb_synced_field	description
586	286	fb_synced_field	image
587	286	fb_last_synced	2012-04-11T17:33:00.172585
588	396	dynamically_generated	fb_event:174330602687048
589	397	dynamically_generated	fb_event:125882994204318
590	398	dynamically_generated	fb_event:308873475842113
591	399	dynamically_generated	fb_event:277431875675466
592	400	dynamically_generated	fb_event:203070436470769
593	401	dynamically_generated	fb_event:109806982484940
594	402	dynamically_generated	fb_event:200495003392491
595	403	dynamically_generated	fb_event:369230166443949
\.


--
-- Data for Name: south_migrationhistory; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY south_migrationhistory (id, app_name, migration, applied) FROM stdin;
1	tastypie	0001_initial	2012-04-25 14:03:28.029168-04
\.


--
-- Data for Name: specials_coupon; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY specials_coupon (id, special_id, user_id, dtcreated, dtused, was_used, uuid) FROM stdin;
2	4	15	2012-05-02 22:16:43.077988-04	\N	f	0ef81436-d268-4325-8f68-c70400e4b1c3
3	4	6	2012-05-02 22:55:37.644824-04	\N	f	e718eb97-a9ca-4418-9b6d-e4c087f53b8d
4	4	16	2012-05-02 22:57:59.269252-04	\N	f	17badc37-ca71-4d50-8c6d-f25be468b5b9
5	4	22	2012-05-02 23:28:02.19668-04	\N	f	e3a3491c-9e15-471e-b975-30bd83263cbe
6	4	24	2012-05-03 00:06:54.675192-04	\N	f	02d88adc-51d4-429d-bb36-a94f132e1686
7	4	2	2012-05-03 07:45:40.947734-04	\N	f	cc787f22-40c8-4c0e-b06f-0fc6b02619e7
8	4	40	2012-05-03 09:21:31.699963-04	\N	f	50666727-9262-4064-995c-64faef120a4f
9	4	45	2012-05-03 10:40:37.762331-04	\N	f	b69c478a-2463-4934-aa94-4585c5b8c61c
10	1	2	2012-05-03 11:02:44.285114-04	\N	f	a3f834ca-1e08-4442-aabd-d76670d963d0
11	5	65	2012-05-08 14:32:04.667329-04	\N	f	6b33ca3e-beae-472d-a633-4a22e6501e70
12	4	69	2012-05-09 11:09:29.083308-04	\N	f	3962b8fe-aff4-46fa-add2-f21954515050
13	4	68	2012-05-09 14:44:44.785115-04	\N	f	4c6440f6-7533-4d16-8cf6-5e52c5ee7aa0
14	6	99	2012-05-19 13:22:27.012904-04	\N	f	481128db-abdf-4d1e-85b9-337c75e36d8a
\.


--
-- Data for Name: specials_special; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY specials_special (id, title, description, points, place_id, dexpires, dstart, total_available, total_sold, dtcreated) FROM stdin;
1	30-50% off All Diamond Jewelry	Recieve 30-50% off any instore diamond purchase.\r\nOffer excludes any custom work or special order items.	0	404	2012-04-30	2012-04-02	\N	0	2012-04-13 10:37:35.737978-04
2	$50 off New Patient Exam and cleaning! 	Plus get a free toothbrush, toothpaste and dental floss! $135 value!	0	109	2012-10-31	2012-04-11	\N	0	2012-04-12 11:27:09.179894-04
5	Hospital / University ID Discount	Show your valid Hospital or University (Staff or Student) and receive 10% off your regular price purchase. Minimum purchase of $75 and cannot be combined with any other discounts. Some exclusions may apply.	0	166	\N	2012-05-02	\N	0	2012-05-02 09:04:53.689071-04
4	Free soup	Free small soup with any regular salad or sandwich purchase!	0	282	2012-05-06	2012-04-30	\N	0	2012-04-19 14:21:20.612562-04
6	Loser Tuesday	Monday "upgrade Monday " buy a small get a large pizza and buy large and get Xtra large pizza. Tuesday "loser Tuesday" bring in losing lottery ticket and get 10% off your bill . Wednesday "Hoagie Wednesday" any hoagie $6 .	0	122	2012-05-31	2012-05-15	\N	0	2012-05-12 10:32:49.861743-04
7	PUZZLING	Receive half off the original price of any puzzle from Pomegranate.  Print this coupon and bring it into the store to receive your discount.	0	7	2012-06-22	2012-05-21	\N	0	2012-05-16 11:13:00.281567-04
\.


--
-- Data for Name: specials_special_tags; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY specials_special_tags (id, special_id, tag_id) FROM stdin;
1	1	121
2	1	165
3	2	169
6	5	106
7	5	107
8	5	15
9	4	187
10	7	17
11	7	208
\.


--
-- Data for Name: specials_specialmeta; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY specials_specialmeta (id, special_id, key, value) FROM stdin;
\.


--
-- Data for Name: tags_tag; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tags_tag (id, name, dtcreated) FROM stdin;
1	hotel	2012-04-11 17:28:26.217953-04
2	lodging	2012-04-11 17:28:26.223475-04
3	religious	2012-04-11 17:28:27.297312-04
4	place-of-worship	2012-04-11 17:28:27.30128-04
5	church	2012-04-11 17:28:27.305874-04
6	food	2012-04-11 17:28:27.679932-04
7	cafe	2012-04-11 17:28:27.684059-04
8	coffee	2012-04-11 17:28:27.688127-04
9	accounting	2012-04-11 17:28:28.831088-04
10	finance	2012-04-11 17:28:28.835282-04
11	money	2012-04-11 17:28:28.83926-04
12	taxes	2012-04-11 17:28:28.842986-04
13	school	2012-04-11 17:28:29.779204-04
14	education	2012-04-11 17:28:29.783342-04
15	shopping	2012-04-11 17:28:31.057947-04
16	store	2012-04-11 17:28:31.062206-04
17	gifts	2012-04-11 17:28:31.066239-04
18	barber	2012-04-11 17:28:32.118161-04
19	salon	2012-04-11 17:28:32.122149-04
20	hair	2012-04-11 17:28:32.126101-04
21	beauty	2012-04-11 17:28:32.130179-04
22	book-store	2012-04-11 17:28:33.379263-04
23	reading	2012-04-11 17:28:33.383431-04
24	magick	2012-04-11 17:28:33.387262-04
25	pizza	2012-04-11 17:28:34.163534-04
26	ice-cream	2012-04-11 17:28:35.24025-04
27	piercing	2012-04-11 17:28:36.333117-04
28	makeover	2012-04-11 17:28:37.039362-04
29	beauty-salon	2012-04-11 17:28:37.044086-04
36	nails	2012-04-11 17:28:39.412206-04
37	restaurant	2012-04-11 17:28:40.898238-04
38	sandwiches	2012-04-11 17:28:40.902476-04
39	donuts	2012-04-11 17:28:43.067364-04
40	asian	2012-04-11 17:28:44.221701-04
41	middle-eastern	2012-04-11 17:28:45.758768-04
42	university	2012-04-11 17:28:47.055955-04
43	weddings	2012-04-11 17:28:47.060321-04
44	health	2012-04-11 17:28:48.057208-04
45	glasses	2012-04-11 17:28:48.061619-04
46	chinese	2012-04-11 17:28:48.739168-04
47	atm	2012-04-11 17:28:50.465478-04
48	bank	2012-04-11 17:28:50.469299-04
50	florist	2012-04-11 17:28:56.235903-04
51	flowers	2012-04-11 17:28:56.239709-04
52	drink	2012-04-11 17:28:57.001093-04
53	cigarettes	2012-04-11 17:28:57.00539-04
54	lottery	2012-04-11 17:28:57.00935-04
55	convenience-store	2012-04-11 17:28:57.013094-04
56	gas-station	2012-04-11 17:28:57.019918-04
57	hospital	2012-04-11 17:28:57.302211-04
58	french	2012-04-11 17:29:01.462614-04
59	medical	2012-04-11 17:29:03.877718-04
60	pharmacy	2012-04-11 17:29:03.881918-04
61	drug-store	2012-04-11 17:29:03.885995-04
62	entertainment	2012-04-11 17:29:05.113857-04
63	real-estate	2012-04-11 17:29:06.945236-04
66	theater	2012-04-11 17:29:08.924534-04
70	doctor	2012-04-11 17:29:13.403534-04
71	laundry	2012-04-11 17:29:18.021878-04
72	dry-cleaning	2012-04-11 17:29:18.025838-04
73	tailor	2012-04-11 17:29:18.029846-04
74	community	2012-04-11 17:29:18.602939-04
75	cuban	2012-04-11 17:29:22.027137-04
76	recreation	2012-04-11 17:29:23.224013-04
77	park	2012-04-11 17:29:23.22838-04
78	indian	2012-04-11 17:29:26.207914-04
79	irish	2012-04-11 17:29:27.833653-04
80	music	2012-04-11 17:29:29.012354-04
81	bar	2012-04-11 17:29:31.322093-04
82	alcohol	2012-04-11 17:29:31.328011-04
83	beer	2012-04-11 17:29:31.33871-04
84	italian	2012-04-11 17:29:36.527107-04
85	japanese	2012-04-11 17:29:38.413344-04
86	sushi	2012-04-11 17:29:38.417301-04
87	government	2012-04-11 17:29:44.865774-04
88	career	2012-04-11 17:29:45.909436-04
89	supermarket	2012-04-11 17:29:46.195463-04
90	grocery	2012-04-11 17:29:46.200325-04
91	mexican	2012-04-11 17:29:52.447235-04
92	funeral-home	2012-04-11 17:29:54.987504-04
93		2012-04-11 17:29:55.290419-04
94	post-office	2012-04-11 17:29:56.393067-04
95	mail	2012-04-11 17:29:56.397301-04
96	car	2012-04-11 17:29:58.934665-04
97	clothing-store	2012-04-11 17:29:59.6733-04
98	dentist	2012-04-11 17:30:00.692151-04
99	car-repair	2012-04-11 17:30:09.101761-04
100	vinyl	2012-04-11 17:30:09.393377-04
102	electronics-store	2012-04-11 17:30:16.563228-04
103	cell-phones	2012-04-11 17:30:16.567375-04
104	peruvian	2012-04-11 17:30:18.562804-04
106	shoes	2012-04-11 17:30:23.242802-04
107	athletic	2012-04-11 17:30:23.247157-04
110	diner	2012-04-11 17:30:33.640367-04
111	breakfast	2012-04-11 17:30:33.644697-04
112	printing	2012-04-11 17:30:37.762056-04
113	copying	2012-04-11 17:30:37.765983-04
114	office-supplies	2012-04-11 17:30:37.769836-04
115	jewelry-store	2012-04-11 17:30:41.274681-04
116	bakery	2012-04-11 17:30:42.792981-04
117	nursery	2012-04-11 17:30:47.300091-04
118	plants	2012-04-11 17:30:47.305059-04
119	landscaping	2012-04-11 17:30:47.30953-04
120	nutrition	2012-04-11 17:30:48.546731-04
121	jewelry	2012-04-11 17:30:51.110064-04
122	deli	2012-04-11 17:31:02.22162-04
123	books	2012-04-11 17:31:03.431732-04
124	hookah	2012-04-11 17:31:05.524726-04
125	alchohol	2012-04-11 17:31:10.252039-04
126	mosque	2012-04-11 17:31:12.649676-04
127	art	2012-04-11 17:31:13.930006-04
128	club	2012-04-11 17:31:15.04541-04
129	korean	2012-04-11 17:31:17.846-04
130	museum	2012-04-11 17:31:18.985119-04
131	history	2012-04-11 17:31:18.992338-04
132	library	2012-04-11 17:31:24.508628-04
133	lectures	2012-04-11 17:31:26.392675-04
134	musuem	2012-04-11 17:31:26.790385-04
135	natural-history	2012-04-11 17:31:26.794418-04
136	architecture	2012-04-11 17:31:26.798425-04
137	dinosaurs	2012-04-11 17:31:26.802457-04
139	car-dealer	2012-04-11 17:31:35.493958-04
140	storage	2012-04-11 17:31:38.016174-04
141	film	2012-04-11 17:31:41.362677-04
142	movie-theater	2012-04-11 17:31:41.369864-04
143	towing	2012-04-11 17:31:42.382523-04
144	synagogue	2012-04-11 17:31:42.707733-04
147	garden	2012-04-11 17:31:58.697819-04
148	bike-store	2012-04-11 17:32:02.792278-04
149	jewish	2012-04-11 17:32:05.325897-04
150	comics	2012-04-11 17:32:11.430036-04
151	shoppin	2012-04-11 17:32:14.254575-04
152	tattoo	2012-04-11 17:32:19.243672-04
153	catering	2012-04-11 17:32:31.930678-04
154	cell-phone	2012-04-11 17:32:35.043716-04
155	tanning	2012-04-11 17:32:36.578485-04
156	insurance	2012-04-11 17:32:39.717453-04
157	greek	2012-04-11 17:32:41.11192-04
158	mediterranean	2012-04-11 17:32:41.115983-04
159	laundromat	2012-04-11 17:32:43.882876-04
160	screen-printing	2012-04-11 17:32:52.880473-04
161	games	2012-04-11 17:32:54.534999-04
162	sports	2012-04-11 17:32:58.543695-04
163	oakland	2012-04-13 08:43:13.266572-04
164	repair	2012-04-13 10:34:44.138057-04
165	engagement-rings	2012-04-13 10:37:35.766538-04
166	kameleon	2012-04-13 10:44:28.673678-04
167	whitening	2012-04-12 11:21:54.220184-04
168	root-canals	2012-04-12 11:33:28.120584-04
169	dental	2012-04-13 12:53:10.284956-04
171	tooth-pain	2012-04-17 17:24:21.212156-04
178	development	2012-04-19 14:10:46.868837-04
179	youth	2012-04-19 14:10:46.869873-04
180	community-gardens	2012-04-19 14:10:46.870335-04
181	greening	2012-04-19 14:10:46.870814-04
182	urban-planning	2012-04-19 14:10:46.871273-04
183	nonprofit	2012-04-19 14:10:46.871742-04
184	employment	2012-04-19 14:10:46.8722-04
185	workforce-development	2012-04-19 14:10:46.872671-04
186	volunteer	2012-04-19 14:10:46.873126-04
187	soup	2012-04-19 14:21:20.664001-04
188	creativity	2012-04-29 15:21:13.32239-04
189	knitting	2012-04-30 15:19:41.700606-04
190	mothers-day	2012-05-01 16:53:29.420516-04
191	50-off	2012-05-02 10:13:41.539711-04
192	teens	2012-05-02 22:12:48.863722-04
193	exhibitions	2012-05-03 14:12:17.314808-04
194	artist	2012-05-03 14:12:17.340307-04
195	culture	2012-05-03 14:12:17.340722-04
196	design	2012-05-03 14:12:17.341124-04
197	events	2012-05-03 14:12:17.341579-04
198	dental-implants	2012-05-05 05:00:59.12349-04
199	dental-crowns	2012-05-05 05:00:59.167889-04
200	dental-cleanings	2012-05-05 05:00:59.168424-04
201	dental-check-ups	2012-05-05 05:00:59.16888-04
202	dental-emergencies	2012-05-05 05:00:59.169342-04
203	teeth	2012-05-05 05:00:59.169813-04
204	cosmetic-dentistry	2012-05-05 05:00:59.170276-04
205	eye-exams	2012-05-09 14:57:33.139922-04
206	sunglasses	2012-05-09 14:57:33.17617-04
207	kids	2012-05-12 11:00:18.990078-04
208	puzzle	2012-05-16 11:13:00.427981-04
209	poetry	2012-05-17 12:49:00.735452-04
210	shamballa	2012-05-17 17:27:41.833952-04
211	impressionism	2012-05-18 10:40:06.26361-04
212	technology	2012-06-13 20:52:24.468592-04
\.


--
-- Data for Name: tastypie_apiaccess; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tastypie_apiaccess (id, identifier, url, request_method, accessed) FROM stdin;
\.


--
-- Data for Name: tastypie_apikey; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY tastypie_apikey (id, user_id, key, created) FROM stdin;
\.


--
-- Data for Name: thumbnail_kvstore; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY thumbnail_kvstore (key, value) FROM stdin;
sorl-thumbnail||image||f494eeb42a03b8c915a3d1de985c30ce	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/U_SrjW.jpg", "size": [200, 134]}
sorl-thumbnail||image||bf9a992ac614ac6fa08ff2dcf385ebf7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b9/99/b9990d97415e926de270d44eec78af26.jpg", "size": [50, 50]}
sorl-thumbnail||image||8ea4feb8ade7ff8a805bb3895fee1dc7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/8c/fd/8cfd20f9200a62c316a93a03ec351839.jpg", "size": [130, 130]}
sorl-thumbnail||image||9c5fb03e196bd025b6bd09f77bbcc353	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/52/7c/527c7cef1b9af2335d671c2647b90288.jpg", "size": [130, 130]}
sorl-thumbnail||image||1d9bc7f56889fd710bb2ca64ebb0971d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/kAwIVO.jpg", "size": [200, 150]}
sorl-thumbnail||image||c0c564c34cea67c95c81db74e8e628c2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a9/89/a9899d21f53e64e14361e4a893ef612a.jpg", "size": [50, 50]}
sorl-thumbnail||image||dde4bb461d7fb105db4f1f0a7bfa5814	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/2c/aa/2caa4c1418a4aea37d03260e5e3e2ee3.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||f494eeb42a03b8c915a3d1de985c30ce	["9c5fb03e196bd025b6bd09f77bbcc353", "bf9a992ac614ac6fa08ff2dcf385ebf7", "d3acb6cd86d67697966fbba1c2d8ac05"]
sorl-thumbnail||image||dc8227ef09fa66e068635aa7b71a2525	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/RnWnEY.jpg", "size": [180, 180]}
sorl-thumbnail||image||9b925050cf0510b145d68361e9cc8631	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/9d/24/9d2443baa3be395f8d58a09d7f21b69a.jpg", "size": [50, 50]}
sorl-thumbnail||image||5b50260753350cf22fe93790e9017a35	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/13/31/13312793630adb9f7469f1fbcf0fde33.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||3e7a78d5fe9be7e85cabe0d8b93bdb98	["c665bb187cea80c51274263947029b47", "697105a2bd51a8a734c1cd576edae7aa", "1dd71f64a09a4c399d60205af55bfd72", "35bac82766d8e3a955e891f414ce8aad"]
sorl-thumbnail||image||8d93d158287281179fb185afc32b7689	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/FNgKni.gif", "size": [198, 126]}
sorl-thumbnail||image||6615c9fc06059fecdd6d20a8aac0813b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b4/70/b470dac966c2ee3888c1e123ac2b50f5.jpg", "size": [50, 50]}
sorl-thumbnail||image||504b9f6323b668d77c6da06458e5e7c2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/hijRcr.jpg", "size": [170, 227]}
sorl-thumbnail||image||b6e6b2c3cfb99fd7ae6701584f43cd70	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e7/8a/e78ad6761a1a560e5f96b552133b0810.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||8d93d158287281179fb185afc32b7689	["b6e6b2c3cfb99fd7ae6701584f43cd70", "6615c9fc06059fecdd6d20a8aac0813b"]
sorl-thumbnail||image||3e7a78d5fe9be7e85cabe0d8b93bdb98	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/a3PtZj.jpg", "size": [180, 180]}
sorl-thumbnail||image||35bac82766d8e3a955e891f414ce8aad	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/79/1a/791a3048b0591cc21a5ebe88a548f7df.jpg", "size": [50, 50]}
sorl-thumbnail||image||1dd71f64a09a4c399d60205af55bfd72	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b0/9a/b09a3634c1e42c8f5085bc0baeaa264b.jpg", "size": [130, 130]}
sorl-thumbnail||image||69197fe273498332b0a40bc40d6b85f0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/MinsJazzCuts.jpg", "size": [1736, 1576]}
sorl-thumbnail||image||ad9233fc9e30f02be72e2b8e00f3115c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a9/b8/a9b84bfb8457ac756fd909ecb5dea938.jpg", "size": [50, 50]}
sorl-thumbnail||image||b8fafa29846bd03a9356c1c79c055aec	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c6/3d/c63d9fa8e8e5361bc615e07ee8339652.jpg", "size": [50, 50]}
sorl-thumbnail||image||d40154ce371766c0120d3417978d5f0b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/2f/f7/2ff739d7814279fca41dcdaec09e5fff.jpg", "size": [50, 50]}
sorl-thumbnail||image||0925d7d41d98c95db4e5e4cc65dcdd15	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6b/66/6b66cde5e8caa6bca52deb64469966e3.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||1d9bc7f56889fd710bb2ca64ebb0971d	["c0c564c34cea67c95c81db74e8e628c2", "1626201d216b1f9fe7929161c739b50c", "dde4bb461d7fb105db4f1f0a7bfa5814"]
sorl-thumbnail||image||4f007767aefb4d5072cbf723757167cd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/ap3EXw.jpg", "size": [288, 384]}
sorl-thumbnail||image||6d9fac818f2399ae6580203e91699045	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/5a/96/5a961b989fc9259cca040f74aea07539.jpg", "size": [50, 50]}
sorl-thumbnail||image||0b6ad8aae9ff611f114f2025d00f9b08	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/8e/53/8e53e78a75634d50f54a83a7ec858399.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||4f007767aefb4d5072cbf723757167cd	["6d9fac818f2399ae6580203e91699045", "0b6ad8aae9ff611f114f2025d00f9b08"]
sorl-thumbnail||image||18ec04740aa403e5133a5283a443cb68	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/F8wT02.jpg", "size": [200, 200]}
sorl-thumbnail||image||71dd5d5a1bfcd80cf346f817a1865834	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/BgaI5K.jpg", "size": [184, 205]}
sorl-thumbnail||image||584f7cda41244c97c6fd6fd98fe23e3d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/37/75/37756fe2dee745e22be012fdec8b745c.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||18ec04740aa403e5133a5283a443cb68	["b8fafa29846bd03a9356c1c79c055aec", "584f7cda41244c97c6fd6fd98fe23e3d"]
sorl-thumbnail||image||4890887c662cb0ca82d6246995459e92	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/87/df/87df733cd69c59af723086c7ec43f83f.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||504b9f6323b668d77c6da06458e5e7c2	["0925d7d41d98c95db4e5e4cc65dcdd15", "d40154ce371766c0120d3417978d5f0b", "e6065b9bf30067bdf2dc497276d0387e"]
sorl-thumbnail||image||42c54b55f37c238dce0dd6aacdc3d5de	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/wEojbM.jpg", "size": [199, 265]}
sorl-thumbnail||image||4ddd66a88e4957deb1066baca5216132	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/eb/f4/ebf49c4e4c368b60e170cbf961faceb1.jpg", "size": [130, 130]}
sorl-thumbnail||image||4c3c54b711f8fb6a24dacafb7b760d05	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/cKI15g.jpg", "size": [300, 225]}
sorl-thumbnail||image||a3255ababdedb680d16cfd16476e6ff4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/81/ef/81ef0267f01deab9f79971a0d722b1ec.jpg", "size": [50, 50]}
sorl-thumbnail||image||a3d05828ffcaebd76fc25ab482e143e3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b7/1b/b71bfdac28b21c22d30d9af6cd570b6b.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||4c3c54b711f8fb6a24dacafb7b760d05	["a3d05828ffcaebd76fc25ab482e143e3", "a3255ababdedb680d16cfd16476e6ff4"]
sorl-thumbnail||image||8e4bdccc0fda916958b9aaee9bb47b90	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/12/08/1208394fd574423e525db43a80958d17.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||c4876c3a749068ebdbb7f1484399d295	["3f3e73bd30c0eb228c95bccba35a704f", "33aeaff506beee6a7f5e2fcdcf3e247c", "dae2ee9243b884a03b536466cb6fd808"]
sorl-thumbnail||image||6a48ce8371c6a690334b6f4a8343bad1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/45/22/4522c54be529b3505561b750e32e58cb.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||042466f8a180342c17f234fb6bfbb5bb	["43b7dc9253b46c53b005f0b48f3d9938", "fa8bd4d3133e174652c26a9da37b122c", "4b0a8ff1a00dd7627ffd51febe4e2055"]
sorl-thumbnail||image||b97491e934468e8909f8897c93489ec6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/58/d8/58d83644affb861b904615385546c045.jpg", "size": [130, 130]}
sorl-thumbnail||image||45b778a051481f604fa0ad31bccf1598	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Y4q8Xo.jpg", "size": [200, 204]}
sorl-thumbnail||image||6d0e90b91fa5d3956b3bce88c197f331	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a0/35/a035f9f54e78eb2096a9ec21a6035cdb.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||42c54b55f37c238dce0dd6aacdc3d5de	["8e4bdccc0fda916958b9aaee9bb47b90", "b97491e934468e8909f8897c93489ec6"]
sorl-thumbnail||image||67ef21c5f167d51332dc9007e376fa35	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3c/99/3c997a7a79c66fb73a1fb700d0a8ee0c.jpg", "size": [130, 130]}
sorl-thumbnail||image||c4876c3a749068ebdbb7f1484399d295	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/HotTipsNailSalon.jpg", "size": [2388, 1840]}
sorl-thumbnail||image||dae2ee9243b884a03b536466cb6fd808	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/7c/a4/7ca41cdb559d4c57276697cd1b2e3800.jpg", "size": [50, 50]}
sorl-thumbnail||image||3f3e73bd30c0eb228c95bccba35a704f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/98/09/9809ef6538879b612e963ea768b41e5e.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||71dd5d5a1bfcd80cf346f817a1865834	["4890887c662cb0ca82d6246995459e92", "4ddd66a88e4957deb1066baca5216132", "db087a392f5dae7a7a7bd92703b89041"]
sorl-thumbnail||image||9a0b38d5781bffd3367dad2f8cb5f629	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/llKQgN.jpg", "size": [180, 180]}
sorl-thumbnail||image||73cc87e5709934c3d69ce2d2d92775a9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/42/97/4297d25b8bc993335bf36a401e34eeaf.jpg", "size": [50, 50]}
sorl-thumbnail||image||c10a5bf7e98ee017134596007b19f8d2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/7_sV5N.jpg", "size": [200, 200]}
sorl-thumbnail||image||1eef92955ea3b1eda960d2851272facf	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/db/6d/db6da266cfd0e86a28fbb10168e89dff.jpg", "size": [130, 130]}
sorl-thumbnail||image||f67107748215e67dc63801fdbe58665a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e6/2a/e62afe2d1292d6f39e8123e94ec095ff.jpg", "size": [50, 50]}
sorl-thumbnail||image||77dac309c74d2e5135b7744a52e1682e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/22/fd/22fd8efa687e043f19a18f0bd6814767.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||c10a5bf7e98ee017134596007b19f8d2	["f67107748215e67dc63801fdbe58665a", "77dac309c74d2e5135b7744a52e1682e"]
sorl-thumbnail||image||a1375ffe22a354ee077701969c727c5d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/eE3Ygj.jpg", "size": [200, 133]}
sorl-thumbnail||image||420dee957f9cb7a18c7f17166373f006	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/9f/a5/9fa5129db080e31847bf5f2e838ce675.jpg", "size": [50, 50]}
sorl-thumbnail||image||69a0cba082d7d658c10987e909599029	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/PetersOpticalShoppe.jpg", "size": [1664, 912]}
sorl-thumbnail||image||bcf2a4084122e9747143291f9a4dab62	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/99/22/992232714d91fe616d389a54b78db1a3.jpg", "size": [130, 130]}
sorl-thumbnail||image||042466f8a180342c17f234fb6bfbb5bb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/VuIzoz.jpg", "size": [180, 139]}
sorl-thumbnail||image||43b7dc9253b46c53b005f0b48f3d9938	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/53/b2/53b2cae7bd1417bbfea4fb9873e82da9.jpg", "size": [50, 50]}
sorl-thumbnail||image||fa8bd4d3133e174652c26a9da37b122c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/49/94/49945a69bb1baf7b238d53e1f7dee66d.jpg", "size": [130, 130]}
sorl-thumbnail||image||c9dabf00f2ef1b6e0cef6466736efec2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f7/9f/f79f31f5d2b7069c7e9091311b785b16.jpg", "size": [50, 50]}
sorl-thumbnail||image||8c1e49f7398e10759d4188a37b53ff5d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c6/53/c6539f7e89724a93065bd7d23beb7f51.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||2490aa33a807e9cff8601ee9b1de92de	["4e81681a03dceba44eb49a1237079eeb", "8c1e49f7398e10759d4188a37b53ff5d"]
sorl-thumbnail||image||b19c23439bdab8c8b9e09f3840e4e660	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d3/aa/d3aa632a387efbd1755f64d89c24bbc7.jpg", "size": [130, 130]}
sorl-thumbnail||image||ed90dd1f6b2d4079063eb5ba3b9225f0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/SzechuanExpress.jpg", "size": [3264, 1840]}
sorl-thumbnail||image||2d83f9a933a17f47c9013ee19b58b066	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/fc/ee/fceed413eaee4fc5e0ad4de0e01a5c99.jpg", "size": [50, 50]}
sorl-thumbnail||image||2771745f4c31c145a733c50572f935bf	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/68/ea/68eafa00ca0119d3e70cc430dccd3707.jpg", "size": [50, 50]}
sorl-thumbnail||image||eb47c8a6742b52dbf9e545b8cfb24b67	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/7e/61/7e61d38861fc826e9f51c14802587106.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||0eac3cd4fb64580047659a2f07220ec3	["d278259ec153f69719ffc9375b85ede8", "7cd47806c4a16689b50144cfd59c7ed0", "b3d062e0b4e8322fd9b11c718b6edbb0"]
sorl-thumbnail||image||cb5356caa48cf32b5e168e07ae2b0461	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/J9EvXZ.jpg", "size": [180, 180]}
sorl-thumbnail||image||3cf569ccc85457ad961021e7b971eb39	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c8/2b/c82b4858d9c3bd7f761a1a06f365eb14.jpg", "size": [50, 50]}
sorl-thumbnail||image||c490d14ca9ab367e2314cf01a750929b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/8a/ee/8aeebce3cebe607b0486bd86211172fd.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||cb5356caa48cf32b5e168e07ae2b0461	["3cf569ccc85457ad961021e7b971eb39", "c490d14ca9ab367e2314cf01a750929b"]
sorl-thumbnail||image||b028234fa6cb53fb6d3c14e6549be954	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/APtsJE.gif", "size": [198, 126]}
sorl-thumbnail||image||2004684b3216eab98f6ae58ade815b17	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/27/c8/27c80648343ecfd316b854749e1c0bad.jpg", "size": [50, 50]}
sorl-thumbnail||image||d278259ec153f69719ffc9375b85ede8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/32/1e/321e3a7a4c68e97d6c76440f3a5411b5.jpg", "size": [50, 50]}
sorl-thumbnail||image||c9ba932727ac4a7cc9b821f5e0d3a0be	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e4/19/e419548e819ca4261f37c0444f5ba8c2.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||b028234fa6cb53fb6d3c14e6549be954	["c9ba932727ac4a7cc9b821f5e0d3a0be", "2004684b3216eab98f6ae58ade815b17"]
sorl-thumbnail||image||5cf3f56556dd54e4d1bcf9b55a96fc0c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/NwPIFn.jpg", "size": [200, 134]}
sorl-thumbnail||image||62fd93f43a7162a485b13e3076a0dce8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/fb/d3/fbd3c1501ef26feed68271f94b03290b.jpg", "size": [50, 50]}
sorl-thumbnail||image||f234d0682d60412945ea7d039c8dcf2e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f0/f2/f0f29109c66469e5ab20b01a64866e51.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||5cf3f56556dd54e4d1bcf9b55a96fc0c	["62fd93f43a7162a485b13e3076a0dce8", "f234d0682d60412945ea7d039c8dcf2e"]
sorl-thumbnail||image||d775ae2d8d6bf23f357ab4f4d761e393	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/wgaH0C.jpg", "size": [200, 249]}
sorl-thumbnail||image||5bd09848ff48b8d32f9c77226b48def4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d2/15/d215dc0ba5ed46494be42a9c0f2857d1.jpg", "size": [50, 50]}
sorl-thumbnail||image||eeec17071e4702cf0e7f8bf850a6fa5c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/37/86/378610a8c019b3e9cfefa4026a2c24f1.jpg", "size": [130, 130]}
sorl-thumbnail||image||48287df9fce0ed315d0d84f1435c5374	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/67/7d/677d0f6e4126f4d744256bbc7330de3b.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||0f6ae12eafd82dcd6a492ae9ae2fb149	["de1f66ff4688b4a8b71315204a2bbe85", "e6b1f1ae2a6d3c3cf31584e6bacbe342", "6e8c8549e17a6b77025e1e4dabd00452"]
sorl-thumbnail||image||0b4183760b8bbcad370ab4a545a6454b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/E0urMT.gif", "size": [441, 133]}
sorl-thumbnail||thumbnails||0b4183760b8bbcad370ab4a545a6454b	["eeec17071e4702cf0e7f8bf850a6fa5c", "2771745f4c31c145a733c50572f935bf"]
sorl-thumbnail||image||066a49105b273124b5e5a80291ce8107	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/PizzaPrima.jpg", "size": [1425, 1217]}
sorl-thumbnail||image||7a6322c472bee41be28bdb2d77a58689	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/cb/e6/cbe6b6d1612c7bf2a9f03847f49c81ec.jpg", "size": [50, 50]}
sorl-thumbnail||image||1b356ce358d1364b5d8bf5cea1aba78a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3d/44/3d44af51342a6bc4fc66aa299bccaa71.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||066a49105b273124b5e5a80291ce8107	["7a6322c472bee41be28bdb2d77a58689", "1b356ce358d1364b5d8bf5cea1aba78a"]
sorl-thumbnail||image||0eac3cd4fb64580047659a2f07220ec3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Ml0sZP.jpg", "size": [400, 372]}
sorl-thumbnail||image||0f6ae12eafd82dcd6a492ae9ae2fb149	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/JcT_pi.jpg", "size": [617, 394]}
sorl-thumbnail||image||7cd47806c4a16689b50144cfd59c7ed0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/33/15/33158efed02e3fc0a088fde94ceff509.jpg", "size": [130, 130]}
sorl-thumbnail||image||e6b1f1ae2a6d3c3cf31584e6bacbe342	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c9/5e/c95e1d672b1092a083c6495abceab6a7.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||69a0cba082d7d658c10987e909599029	["b19c23439bdab8c8b9e09f3840e4e660", "c9dabf00f2ef1b6e0cef6466736efec2", "12eb211f5e5ac226fe01367dbb7eaad0"]
sorl-thumbnail||image||2490aa33a807e9cff8601ee9b1de92de	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/PizzaRomano.jpg", "size": [2061, 1561]}
sorl-thumbnail||thumbnails||ed90dd1f6b2d4079063eb5ba3b9225f0	["d3d9903c5f03c117890d9bd7ffe4d3cc", "eb47c8a6742b52dbf9e545b8cfb24b67", "2d83f9a933a17f47c9013ee19b58b066"]
sorl-thumbnail||image||6e8c8549e17a6b77025e1e4dabd00452	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ff/b1/ffb1cb08c3634396af1f6a8c35b212fc.jpg", "size": [130, 130]}
sorl-thumbnail||image||b20ad1dc535a9c100c7528449a147ae3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/jgEwKs.jpg", "size": [180, 135]}
sorl-thumbnail||image||9c50532b8eb144161ea2c33a9a278b3f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3e/3e/3e3e07e0706082525c201741bf60a9dd.jpg", "size": [50, 50]}
sorl-thumbnail||image||b596f3e501a78d0704fc08bb6f1c8d79	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/0d/5e/0d5e7082d6515bd1d12eb4ab3617b150.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||b20ad1dc535a9c100c7528449a147ae3	["b596f3e501a78d0704fc08bb6f1c8d79", "9c50532b8eb144161ea2c33a9a278b3f"]
sorl-thumbnail||image||e4bdf655caba7b13c270570346d3d5af	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/OliverioHair.jpg", "size": [1293, 1421]}
sorl-thumbnail||image||2f2c1edcaa41145341be111b3f9ceee7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/43/77/43772b6ddefeaa847a72b22f7b3ff982.jpg", "size": [50, 50]}
sorl-thumbnail||image||ca7bca401a55a4a2ab3050f6c8c5be31	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/0e/43/0e43e165b150fe84a492e1fe67482840.jpg", "size": [50, 50]}
sorl-thumbnail||image||1de76f767b78eae9c129a22fd1eb2423	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ee/30/ee305a7c434dceeed0a73df2872682ea.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||e4bdf655caba7b13c270570346d3d5af	["2f2c1edcaa41145341be111b3f9ceee7", "1de76f767b78eae9c129a22fd1eb2423"]
sorl-thumbnail||image||0d889b31a8efb4d2d34d6c8f8319f351	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/cg8xeC.jpg", "size": [200, 267]}
sorl-thumbnail||image||153b2609a4b6895bb9fed22dd3029055	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/69/8b/698bed2ac9947687f5fa22ecd2ed0b23.jpg", "size": [50, 50]}
sorl-thumbnail||image||e2d19e0fb1507bf16c87fc996f88d0cd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f8/fe/f8fed43e80f499c910ae4b538b0d8478.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||b0767db6fda4bc30bdbc5584de94b398	["d36720b909b348f9adaea74416556578", "ca7bca401a55a4a2ab3050f6c8c5be31", "465edca9438347cc1d985ba00dacd638"]
sorl-thumbnail||image||a0905ccf28d2c9e5dcaadac89f8c237e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/CrepesParisiennes.jpg", "size": [3264, 1840]}
sorl-thumbnail||image||2e86b928e7a1465ef03b6ff4a452af1d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a3/4a/a34a88c1403fa7af1a62be1888d004f3.jpg", "size": [50, 50]}
sorl-thumbnail||image||682883711b8094e71dc8a56ff0ca9f96	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ce/a5/cea5607f08bbc6cf3f908588f6ad175b.jpg", "size": [130, 130]}
sorl-thumbnail||image||1768b451a3efc704413678414f76358b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ed/f6/edf63b0cee3a03ec643bd19d297c37b0.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||a0905ccf28d2c9e5dcaadac89f8c237e	["1768b451a3efc704413678414f76358b", "2e86b928e7a1465ef03b6ff4a452af1d"]
sorl-thumbnail||image||269cd618763d8f431bf32616931d1512	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/AHXONp.jpg", "size": [470, 74]}
sorl-thumbnail||image||7b5dd75977f052173bcc8f806857b567	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/07/da/07da2e0360068ae124e61b32116b8a2b.jpg", "size": [50, 50]}
sorl-thumbnail||image||e6b3aeae65f8838e9e9dd78e016372f5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/89/aa/89aa00a1a5ce819be82834185ed89e37.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||3506c72dfe6cd9befbe3b5d6ded6fe4a	["8f02c04ae368b207ed64cdd646b59a9c", "eeb62b1f995450649be2e388213a8ea1", "0dcd3dee1626c610274e1c4a99dbab6f"]
sorl-thumbnail||image||01f586e500800a271b8280fd8ebfd44b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/5rwTsx.jpg", "size": [180, 180]}
sorl-thumbnail||image||95781c3d82b87f864eb9a4cc1697f560	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c7/d7/c7d7794f00283a79691acdb7afd2934b.jpg", "size": [50, 50]}
sorl-thumbnail||image||3506c72dfe6cd9befbe3b5d6ded6fe4a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/UncleSamsSubs.jpg", "size": [1513, 1345]}
sorl-thumbnail||image||8f02c04ae368b207ed64cdd646b59a9c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/27/41/2741505c64161eb9c6bc7914abd8e177.jpg", "size": [50, 50]}
sorl-thumbnail||image||0dcd3dee1626c610274e1c4a99dbab6f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/cd/b8/cdb8f71afa988777f53bb41d68b72ee8.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||0d889b31a8efb4d2d34d6c8f8319f351	["446b834189025c1811fd305d895ca5ce", "e2d19e0fb1507bf16c87fc996f88d0cd", "153b2609a4b6895bb9fed22dd3029055"]
sorl-thumbnail||image||b0767db6fda4bc30bdbc5584de94b398	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/KyqMw0.jpg", "size": [200, 136]}
sorl-thumbnail||image||465edca9438347cc1d985ba00dacd638	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/01/0e/010e90657bf979d0339596d451893ca3.jpg", "size": [130, 130]}
sorl-thumbnail||image||34a33979f5844147e4ca298a2603611b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/LittleNippers.jpg", "size": [1225, 1177]}
sorl-thumbnail||image||8e80b364c4d07ecff86e3caf0fd8c0a8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6e/3e/6e3eab9fe355a4c50a1dad4c4830110d.jpg", "size": [50, 50]}
sorl-thumbnail||image||482451e3ec597ca7511682b29c679395	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3f/1f/3f1f76ad30a0d6bfd0c744749dc2d23b.jpg", "size": [53, 80]}
sorl-thumbnail||image||33b51687648b7a290e9bf9fac663231e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/01/ac/01ac8443a9eed4f73ecd12aed4da559b.jpg", "size": [130, 130]}
sorl-thumbnail||image||4e81681a03dceba44eb49a1237079eeb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/31/81/3181787f84feac0454d4f327635361b6.jpg", "size": [50, 50]}
sorl-thumbnail||image||168b99ade09c7322e8c50df0beccc33b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Lx_hU0.jpg", "size": [180, 261]}
sorl-thumbnail||image||16c31a5006e4caccc94574efac68811c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/02/7d/027dd3158f3ee7147d1a55f47cdec73e.jpg", "size": [50, 50]}
sorl-thumbnail||image||968110ed53799ceefcadabe50323c7e2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6c/78/6c78c5d1b7fdba4b2f9380559f8afdbc.jpg", "size": [130, 130]}
sorl-thumbnail||image||332dfe3a3d20a9a53ce184340ba06c52	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/07/1d/071da9cdad2473b5bc59cb9cefa86929.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||168b99ade09c7322e8c50df0beccc33b	["332dfe3a3d20a9a53ce184340ba06c52", "16c31a5006e4caccc94574efac68811c"]
sorl-thumbnail||image||ea528352187450a1bc1eadfabc06cc5e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/TongsCuisine.jpg", "size": [3264, 1840]}
sorl-thumbnail||image||cac200364e5833edf6d9a2dbee0d5ecf	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/11/4b/114b2c86bbb023d2db357a5f4e05387a.jpg", "size": [50, 50]}
sorl-thumbnail||image||ff16a19851c423b6337b298384afbbb8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/69/2d/692dd7135544b403badb82f1405e616a.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||51b9862465de2a9ed39119d3240d31a8	["6642d629dc941891f34e9d16501b6c82", "375a22f6fb33e070142a69423689affc", "aee6fe210f3ef053187858887d53fa6e"]
sorl-thumbnail||image||317080d46b897a6d97f9ed628d695000	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/5bkkjf.jpg", "size": [200, 150]}
sorl-thumbnail||image||629400a63c5554b54d3274ce50f836ab	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b3/a3/b3a3a403c0f180b983e546124f49958d.jpg", "size": [50, 50]}
sorl-thumbnail||image||53eaeda3622cde261ff3bc058a73c5fb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3f/52/3f52897ebbd9fd0132f9122bfcfcf146.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||ab647c10cc8710efd38f6ea2909a7391	["e5e5dee0e80ebb85a1af0b770786eef7", "968110ed53799ceefcadabe50323c7e2", "bafd63b30f07c91b577e9a12b24b70a8"]
sorl-thumbnail||image||51b9862465de2a9ed39119d3240d31a8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/tdE3pA.jpg", "size": [180, 167]}
sorl-thumbnail||image||375a22f6fb33e070142a69423689affc	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ac/67/ac67be5ada59f61ea10883e1a28bcf9b.jpg", "size": [50, 50]}
sorl-thumbnail||image||d79680081b74ead429fcb2ba969fe393	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/8qeFlw.jpg", "size": [180, 116]}
sorl-thumbnail||image||aee6fe210f3ef053187858887d53fa6e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/20/7c/207ccb9b960bd61075b709a03a702073.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||d0c2190005d47be073a134c33697a883	["e3254cba96b96627a3ae7f853041f322", "9888f96eb442f089b905b773f826ed36", "6a51c98ed3aa0e812d98471795c01134"]
sorl-thumbnail||image||d0c2190005d47be073a134c33697a883	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/SorrentosPizza.jpg", "size": [1953, 1610]}
sorl-thumbnail||image||e3254cba96b96627a3ae7f853041f322	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/60/c5/60c5cd928d7c425c3a0872672af0e447.jpg", "size": [50, 50]}
sorl-thumbnail||image||6a51c98ed3aa0e812d98471795c01134	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/10/ae/10ae7cce66e446efd84c1bb91abc69f2.jpg", "size": [130, 130]}
sorl-thumbnail||image||ab647c10cc8710efd38f6ea2909a7391	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/pkU9VK.jpg", "size": [190, 79]}
sorl-thumbnail||image||bafd63b30f07c91b577e9a12b24b70a8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d2/ce/d2ceb0a6fc4e379ee19283cfa03586df.jpg", "size": [50, 50]}
sorl-thumbnail||image||4ff07eb32b8b550de0bff46f20664125	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/0e/af/0eaf05b884b112c3558b50b76525e793.jpg", "size": [50, 50]}
sorl-thumbnail||image||990eb734cdc53c5e0167e54d75ae0665	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/9a/b0/9ab04233c1435921c9f8bd76f56d1818.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||ea528352187450a1bc1eadfabc06cc5e	["ff16a19851c423b6337b298384afbbb8", "3d73c82092e4906b726963082c799b49", "cac200364e5833edf6d9a2dbee0d5ecf"]
sorl-thumbnail||image||546933cb468dd3197585037d285fbd76	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/NewOaklandTailor.jpg", "size": [1049, 941]}
sorl-thumbnail||image||cf6233bb2355b5f5944462c218d39ee2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/17/64/1764a024a6a081a9c32a865189e3b1aa.jpg", "size": [50, 50]}
sorl-thumbnail||image||00f6bd3111e798a38883661ee3e0a98e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ee/0e/ee0e93822cfaa6fdb2d884b93f193507.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||d79680081b74ead429fcb2ba969fe393	["4ff07eb32b8b550de0bff46f20664125", "b73e32ad1244feb24b6a9373b57ab451", "990eb734cdc53c5e0167e54d75ae0665"]
sorl-thumbnail||image||628e56a1dcb013f462c5d9a335baf552	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Uc0mCK.jpg", "size": [180, 270]}
sorl-thumbnail||image||b8c79edf79d6d518fb5484a771fa3879	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/33/4b/334bb533e7da5f43070fa4694a6794fa.jpg", "size": [50, 50]}
sorl-thumbnail||image||20548dd82b6a2a8d2199ace684a7b83e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/76/d1/76d126778dfcec00677c763854e35daa.jpg", "size": [130, 130]}
sorl-thumbnail||image||9731f2a550248e07f4e4d1450639e66d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/_BhsDB.jpg", "size": [180, 173]}
sorl-thumbnail||image||fef8333fdaeca4feeecf05d2c679e3d1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3b/bd/3bbd6b52b567323bcdb6493bcaea133b.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||546933cb468dd3197585037d285fbd76	["e4800a815eed7e88c23f5a8ca11f79e1", "cf6233bb2355b5f5944462c218d39ee2", "00f6bd3111e798a38883661ee3e0a98e"]
sorl-thumbnail||image||99d06795b71e99b82bbec98117532eea	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/16/81/168130def52db4fc88885b0ecd031d81.jpg", "size": [130, 130]}
sorl-thumbnail||image||b4713b2c30250e309d8e72fc15f89668	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/wGfNB5.jpg", "size": [200, 150]}
sorl-thumbnail||image||00479604b45afffea3f3bc826e6840b6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a2/df/a2df39c5c9fa985719aab7f2ecef9e88.jpg", "size": [50, 50]}
sorl-thumbnail||image||5bf45f177a0afacb5f8ce90204b9fca3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c9/e9/c9e9fb7692ccb16d6cec7dc686830e49.jpg", "size": [50, 50]}
sorl-thumbnail||image||24651ed8646b7f7e76a7bdaf644a490e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/37/b9/37b9308c2148ddaa0d7eee756399c369.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||b4713b2c30250e309d8e72fc15f89668	["24651ed8646b7f7e76a7bdaf644a490e", "00479604b45afffea3f3bc826e6840b6"]
sorl-thumbnail||image||65c1b22ad583a52fda87ee3faa63f3ed	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/ZfC68F.jpg", "size": [200, 217]}
sorl-thumbnail||image||227ba93f380f9cd093248b1de20f50bc	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b0/14/b014e0bba0d9c6e53b7dfd70bd10fd34.jpg", "size": [50, 50]}
sorl-thumbnail||image||adb24729ae12cd4760df3a45ce6ce6b3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ed/05/ed0545a5218283f15ec334562c0607cb.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||14dd84f93d05fce767c72f264380eda2	["d1af5de57dd6293c8cfba4b7a27a62e5", "2728c72bf42a4c9a66d6ed3a255575ad", "73410dcdcb5f18ea7c0ea71f48c722ce"]
sorl-thumbnail||image||14dd84f93d05fce767c72f264380eda2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/oXGyqd.jpg", "size": [200, 132]}
sorl-thumbnail||image||2728c72bf42a4c9a66d6ed3a255575ad	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/2c/bc/2cbc98a9aa6de3eb40ffa4c470deabfc.jpg", "size": [50, 50]}
sorl-thumbnail||image||960c41768919d578e905ce0b82517089	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/94/9d/949db85a8de2d5e43623a4363db10bf6.jpg", "size": [50, 50]}
sorl-thumbnail||image||d1af5de57dd6293c8cfba4b7a27a62e5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/23/e8/23e80bf6e1b0c0aa61866a6f280fcaaf.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||17b61b0eea6f34c07ff6c5f44f8fd165	["960c41768919d578e905ce0b82517089", "6c2a59098934dd7fd382214d41634190", "d3712e24d5b077bb49a24a3eb8101fcd"]
sorl-thumbnail||image||d64beae28b14def8f1918158cd1108cb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/KOGR_Y.jpg", "size": [150, 150]}
sorl-thumbnail||image||52698d849100a194443b0ab2ffabca2c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/82/c9/82c988d345b50e65d15700f5f3390ccb.jpg", "size": [50, 50]}
sorl-thumbnail||image||fe9f54871aecb2a08b72782fc1672019	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6e/a2/6ea2fd7a886f4df371e477f157c5d3d8.jpg", "size": [130, 130]}
sorl-thumbnail||image||d012de3e648d4b6c1eeb16192b057b74	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/JoeBellisarioBarber.jpg", "size": [2510, 1593]}
sorl-thumbnail||image||30a4c7f8ef7ef5b60eedcf3d4b5e0c7c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/30/1d/301dd52ea0bba963259203ba5324e0f1.jpg", "size": [50, 50]}
sorl-thumbnail||image||16cbee3318bd03cfaf01034285889a7d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/de/04/de04a6e461f5fc65476882de4eea54c7.jpg", "size": [130, 130]}
sorl-thumbnail||image||c22d46fbdbd7dba167e1093cd1f66315	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/df/6a/df6a6367f75e5837b6a22f23e6b43c02.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||d012de3e648d4b6c1eeb16192b057b74	["c22d46fbdbd7dba167e1093cd1f66315", "30a4c7f8ef7ef5b60eedcf3d4b5e0c7c"]
sorl-thumbnail||image||27d26eacc32e137d1cbd05a987ded7fa	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/yqVafX.jpg", "size": [200, 151]}
sorl-thumbnail||thumbnails||27d26eacc32e137d1cbd05a987ded7fa	["16cbee3318bd03cfaf01034285889a7d", "5bf45f177a0afacb5f8ce90204b9fca3"]
sorl-thumbnail||image||ac616a77593227459df84e47eb77aab3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/DCmk4m.jpg", "size": [200, 202]}
sorl-thumbnail||image||eb4538a72808be57f7ccdcf03ad95c6e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/03/a0/03a06c281f0cd491c5a5a3219ec2e06b.jpg", "size": [50, 50]}
sorl-thumbnail||image||79d7a6c821e8d248d72105ab69a8cb58	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/76/8f/768f8fa4e568114faf0ac17c039e0e81.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||ac616a77593227459df84e47eb77aab3	["79d7a6c821e8d248d72105ab69a8cb58", "eb4538a72808be57f7ccdcf03ad95c6e"]
sorl-thumbnail||image||17b61b0eea6f34c07ff6c5f44f8fd165	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/m2puh2.jpg", "size": [450, 300]}
sorl-thumbnail||image||fb35ac04c99ee5f70652b518bff226c6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/ChiefsCafe.jpg", "size": [1017, 1561]}
sorl-thumbnail||image||d3712e24d5b077bb49a24a3eb8101fcd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/19/04/19042363a468da74fcc9dc2d5c6fd488.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||d64beae28b14def8f1918158cd1108cb	["ea648a039c914546b95a2cc97fdcb949", "fe9f54871aecb2a08b72782fc1672019", "52698d849100a194443b0ab2ffabca2c"]
sorl-thumbnail||image||fcfb9538de8d0724d6049b7fecf84014	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1e/c4/1ec4284a0277b09a1eabe10a4fef9111.jpg", "size": [50, 50]}
sorl-thumbnail||image||60c175f594e7a1b3425af7d6e54b1148	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/LOGO_002.JPG", "size": [393, 262]}
sorl-thumbnail||thumbnails||65c1b22ad583a52fda87ee3faa63f3ed	["442a54aefd61e60110a380d27080880c", "adb24729ae12cd4760df3a45ce6ce6b3", "227ba93f380f9cd093248b1de20f50bc"]
sorl-thumbnail||thumbnails||fb35ac04c99ee5f70652b518bff226c6	["c68fda062596edeb4c222b03b667456c", "6920d914ea74f28ee295710c8f443982", "fcfb9538de8d0724d6049b7fecf84014"]
sorl-thumbnail||image||6920d914ea74f28ee295710c8f443982	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c9/8f/c98f45f5b4139bdb48d0eac651285f31.jpg", "size": [130, 130]}
sorl-thumbnail||image||5c97fe809eb3827d0aed6abe79f867fb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/ThriftyCleaners.jpg", "size": [1521, 1839]}
sorl-thumbnail||image||0bc932b28d103c9164f6a71f59bceeef	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d1/5b/d15b4931499b6f967138ceeee3766d16.jpg", "size": [50, 50]}
sorl-thumbnail||image||d8d7e2a04b27fb9ac6da38fc9fc33f73	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/39/66/39667257f5dd37da0a5fbff52306800f.jpg", "size": [50, 50]}
sorl-thumbnail||image||6908bba43bc8511709263f70cd870272	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ec/9c/ec9cecffb481f377b43435eb9f18307b.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||7176c5571edb92a58e99b92c2f663609	["6fab18232e29c6182f7214dda2b374b0", "ca96dee1fa53f6208069a6ed2f02c8c0", "8de19fa029fafd2169d3094db3e8246c"]
sorl-thumbnail||image||7176c5571edb92a58e99b92c2f663609	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/CraigBeerDistributor.jpg", "size": [3264, 1840]}
sorl-thumbnail||image||8de19fa029fafd2169d3094db3e8246c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/46/c8/46c8bde0b76fc2eac3fd244aefd6ef9f.jpg", "size": [50, 50]}
sorl-thumbnail||image||ca96dee1fa53f6208069a6ed2f02c8c0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f3/b1/f3b191d1b41ab5fb68ccf4ee6202410c.jpg", "size": [130, 130]}
sorl-thumbnail||image||72ae94434fdb3e331e718422f19b4ae2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/tmdMHf.jpg", "size": [200, 145]}
sorl-thumbnail||image||9cc84c9a224d1725c038d010468012a1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/59/66/59660dc3a85cf84c14b45b8b5a77262f.jpg", "size": [50, 50]}
sorl-thumbnail||image||90d84a9489178e6c24212ab97be1b808	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/9c/3d/9c3d392120217c20a57347961e4362b0.jpg", "size": [130, 130]}
sorl-thumbnail||image||6812fa6549777735adb6a12cc2baf31a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/93/65/9365c8a1af3a111975991500b5150cb0.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||c8dc63aa5c112a5048688da7b2b45a00	["f32f5421e192739b1a7b6eb43cf26a61", "5ee3af9af7f38b46a7463a64ea4b19fb", "d6d1c5dff79d96ce78ef22d747196e74"]
sorl-thumbnail||image||69f80dd804d614bef15384bd1146d8d5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/v069S9.jpg", "size": [200, 155]}
sorl-thumbnail||image||f9fb48e17d66a3b0adad3b028651c165	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e2/67/e26782298c99afd768579fcbb57ffb1c.jpg", "size": [50, 50]}
sorl-thumbnail||image||5f939ceaa85ea722732287c96c8a354d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a1/6c/a16c080ee9c1e8d5451810b895e967c7.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||69f80dd804d614bef15384bd1146d8d5	["f9fb48e17d66a3b0adad3b028651c165", "5f939ceaa85ea722732287c96c8a354d"]
sorl-thumbnail||image||fb14cf9dded41c64525e9c76952f3123	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/KohliIndianImports.jpg", "size": [1657, 933]}
sorl-thumbnail||image||3bcbf80a5d467dd2982816e15787303b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1c/43/1c4368ecba225a4fc1c6876bc2c75e9f.jpg", "size": [50, 50]}
sorl-thumbnail||image||22e3aa4a38f5852b40b78b59bac9c813	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e6/55/e655c7073dfb3aba0bb3e319c0f71f76.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||fb14cf9dded41c64525e9c76952f3123	["3bcbf80a5d467dd2982816e15787303b", "22e3aa4a38f5852b40b78b59bac9c813"]
sorl-thumbnail||image||aec1747b72a8313e021669d7ea8e30dd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Burma-Tokyo.jpg", "size": [1840, 3264]}
sorl-thumbnail||image||f1d4a7094b515fafeffff4016ea260ca	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b7/2c/b72c5b82e5beea1d29fe8cdd67aa38e2.jpg", "size": [50, 50]}
sorl-thumbnail||image||c8dc63aa5c112a5048688da7b2b45a00	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/DE0pko.jpg", "size": [802, 128]}
sorl-thumbnail||image||d6d1c5dff79d96ce78ef22d747196e74	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/73/e7/73e7a800652694db3150c4f27945fadc.jpg", "size": [50, 50]}
sorl-thumbnail||image||f32f5421e192739b1a7b6eb43cf26a61	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/4a/4a/4a4a606d53155aeadd07d6b6258dbe10.jpg", "size": [130, 130]}
sorl-thumbnail||image||bcd59f0c63585b898f6a712f1dd561d3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/IndiaGarden.jpg", "size": [3264, 1840]}
sorl-thumbnail||image||d81905b42aa934800cfc909286e0ecaf	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/kp02LT.jpg", "size": [180, 119]}
sorl-thumbnail||image||c5b017f96905bca43b8ae11964338d24	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/9c/46/9c466718541fb3323e335867f35fe596.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||5c97fe809eb3827d0aed6abe79f867fb	["6908bba43bc8511709263f70cd870272", "0bc932b28d103c9164f6a71f59bceeef", "1ad9dfc1a1062406f9f48c802c3d077b"]
sorl-thumbnail||image||88351b212dc74ca0467aadef28126a28	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e3/c1/e3c16675646e5db139fab65e0a1074b3.jpg", "size": [50, 50]}
sorl-thumbnail||image||58c263e005e7e3dc9bd6a95a14dd938e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/41/96/4196dd14d06fd58656e304cd4bf4aed3.jpg", "size": [50, 50]}
sorl-thumbnail||image||d802d04755ff79ce79250487783525dd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/99/3b/993b55650c36e4e2f8601edc99da3e10.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||bcd59f0c63585b898f6a712f1dd561d3	["d8d7e2a04b27fb9ac6da38fc9fc33f73", "c5b017f96905bca43b8ae11964338d24", "98662c818aaeae828236bda97cb86b8e"]
sorl-thumbnail||image||be12af506287f4be2fd64c12e6b86926	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/chTW7E.jpg", "size": [180, 142]}
sorl-thumbnail||image||4dccfa7a3871ecbcc6db766ab3cd270d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a0/3c/a03c59c281edbb08f99ce00500b637f6.jpg", "size": [50, 50]}
sorl-thumbnail||image||ae357ac0cb82939458a03d320721c8d9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/XAEn50.jpg", "size": [200, 200]}
sorl-thumbnail||image||046288b5dba7e0a429ccf34da91f5b70	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/48/38/48380fe03a8aa8e0343455ab231be3d8.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||be12af506287f4be2fd64c12e6b86926	["4dccfa7a3871ecbcc6db766ab3cd270d", "046288b5dba7e0a429ccf34da91f5b70"]
sorl-thumbnail||image||798cef94bbce7270157dd50bb0eb533c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/RQvLeT.jpg", "size": [200, 143]}
sorl-thumbnail||image||530832ae383b0d3f5657c9dcca90df50	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/41/f5/41f58b1b5e4e09ce21b1d4810a2192a1.jpg", "size": [50, 50]}
sorl-thumbnail||image||12e48fc8b9d202e074fda21da12019a8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/fb/a2/fba2805df7993b82768733044fb64a58.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||798cef94bbce7270157dd50bb0eb533c	["530832ae383b0d3f5657c9dcca90df50", "12e48fc8b9d202e074fda21da12019a8"]
sorl-thumbnail||image||2979f647a89bbbb9a301a7f8cc8394aa	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/8UuFnY.jpg", "size": [200, 142]}
sorl-thumbnail||image||e032cc44df4ca549089195a80a043706	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a6/64/a6647914995771a2971bb8babecd8e46.jpg", "size": [50, 50]}
sorl-thumbnail||image||1364e2bbc44118ba83e83cae6a44fb7f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/4b/d7/4bd7f9e73d7425367ac81c508087b4ef.jpg", "size": [130, 130]}
sorl-thumbnail||image||9fcfb86b1dc3140b9b544b24cd2e916b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e4/51/e4518d71f71bfd5834e4ded37392ab80.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||2979f647a89bbbb9a301a7f8cc8394aa	["9fcfb86b1dc3140b9b544b24cd2e916b", "e032cc44df4ca549089195a80a043706"]
sorl-thumbnail||image||c2ad8b64a0941fcf5c7bc7638e54505f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/J528_q.jpg", "size": [646, 172]}
sorl-thumbnail||image||77e7d02dc749be0e157d43853b2e8119	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3f/44/3f44c0ded751bc5a1eee9b619f4cf29b.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||ae357ac0cb82939458a03d320721c8d9	["b4bd79f82bb944de39b295757be3a6b5", "d8bc59e4a509a84bd3f0b6fe6cf26f6b", "e3c244eb157e7d3c7fa902da97fd7ff9"]
sorl-thumbnail||image||5dfff4e5c5de2325bae4358d4cf6f446	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ec/d9/ecd9d919684af98ca2fd60b5763cad15.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||c2ad8b64a0941fcf5c7bc7638e54505f	["5dfff4e5c5de2325bae4358d4cf6f446", "77e7d02dc749be0e157d43853b2e8119"]
sorl-thumbnail||image||cc466a98a1cccc13cb0441ac187d6c53	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/ySe9d0.jpg", "size": [180, 180]}
sorl-thumbnail||image||30cb63592d30235c0a8be5a49d696ded	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/44/0d/440d9ae25817eec39314f40ffbb136c2.jpg", "size": [50, 50]}
sorl-thumbnail||image||07d03e8d396e4e9c4d4f04ba655b5468	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/07/7c/077c611246506ab5d7e125734848a92f.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||d81905b42aa934800cfc909286e0ecaf	["d802d04755ff79ce79250487783525dd", "88351b212dc74ca0467aadef28126a28", "acaf8cea9459139970c828c8a0697b7d"]
sorl-thumbnail||image||237e7e8aa25049ec92652091ffdf3cc9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/MfV9u3.jpg", "size": [200, 268]}
sorl-thumbnail||image||2b534d6563062d47483e82f52ba35ebe	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/67/ca/67caaa083b123ad3cb572d62c600a4bb.jpg", "size": [50, 50]}
sorl-thumbnail||image||3177f51b7aea30e5c906d09c97b9a40b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/FCkMin.jpg", "size": [200, 117]}
sorl-thumbnail||image||e41a2fe63639aff64d98fbcb9c7eb4c7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/74/18/74181c05c79698af29e5546a7425484d.jpg", "size": [50, 50]}
sorl-thumbnail||image||a249bd9b8e37b88f97360499651ec568	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/9d/ac/9dac0fb15d6e33857a7dbfdefe64477b.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||cc466a98a1cccc13cb0441ac187d6c53	["424e26867bab3f592ccffd902426696c", "07d03e8d396e4e9c4d4f04ba655b5468", "30cb63592d30235c0a8be5a49d696ded"]
sorl-thumbnail||image||f0867cd78795bcaf29b6f9ca9a3804d4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/LwxSAJ.jpg", "size": [180, 180]}
sorl-thumbnail||image||9e5aef0977a6f459a99e9a8faf2f61fc	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1e/ac/1eac38249a1863c89a270980c55e8d14.jpg", "size": [50, 50]}
sorl-thumbnail||image||98e8e9c6745981b4a252e091b292c6b4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/86/5e/865e092497b3c1c4db38849b14c33400.jpg", "size": [130, 130]}
sorl-thumbnail||image||e3c244eb157e7d3c7fa902da97fd7ff9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/dd/2f/dd2f2b281b2fd72a16846958bf1b80ce.jpg", "size": [50, 50]}
sorl-thumbnail||image||ba7a270d35a32fcb4e18f8ffdc158fed	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/4e/62/4e62c52f9cf073dfc90efcd10279a72e.jpg", "size": [130, 130]}
sorl-thumbnail||image||b4bd79f82bb944de39b295757be3a6b5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b3/4b/b34b827f7f3bfd5448fc94c314793924.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||f0867cd78795bcaf29b6f9ca9a3804d4	["9e5aef0977a6f459a99e9a8faf2f61fc", "fa82f3353ced5e91d34ce0c644a973d1", "98e8e9c6745981b4a252e091b292c6b4"]
sorl-thumbnail||thumbnails||3177f51b7aea30e5c906d09c97b9a40b	["e41a2fe63639aff64d98fbcb9c7eb4c7", "a249bd9b8e37b88f97360499651ec568", "006b5a68f9b3cde954d3b967df9d966f"]
sorl-thumbnail||image||3d67f3b5d02fc0dce058f9fdb119cdab	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/JJoV15.jpg", "size": [504, 179]}
sorl-thumbnail||image||33d5e105efad6d5e5887a1415fa2f230	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/5e/a6/5ea643bb5658f9794d711daac0c2e177.jpg", "size": [50, 50]}
sorl-thumbnail||image||8310f48d2c24fd6cb9dda1f42b76c43d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1c/e0/1ce0af00a73b96f617a9fa707bf7ae5d.jpg", "size": [130, 130]}
sorl-thumbnail||image||a46af5cdd0395b774e994bc75e795cef	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e3/4f/e34f0fd8d2073dd47358298093a9c4eb.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||55e359b7d80fab50631f4d84ed74cf5a	["7af2f3eb8c160160f7d7dbc32814dff8", "c7952c88c058d3707abf0ff73c8f613f", "09b6b55f1a467cc7e62830d1554cd024"]
sorl-thumbnail||image||b2858ca22806b55fd0d17e0339dd87a2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/ngV7yT.jpg", "size": [200, 145]}
sorl-thumbnail||image||5000ceaae487ce9f96fe04d2b3cd7eca	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/86/33/86339bd179c91132f7c8fcc5ab219025.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||fa8145373dafdee86c871340af55ddaa	["207dc6b4b9435491270a5a59c78e6c9f", "d3fde9e217464b438e850037073e2f45", "abaab3bbad28227071af9f565eaff570"]
sorl-thumbnail||image||6050d1a32dc8b54cdf7c92d985c08724	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/7d/87/7d87e42f4a35ee5b716acef5952cee48.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||8fcba59cff18e92d36739bac77d35da9	["bb5553d53965eb390d000f3f37c64ec5", "bac16799a751c3f062e6739dd5a6f44f", "93ec1cc71377bc50b62bc48c037d4830"]
sorl-thumbnail||image||fa8145373dafdee86c871340af55ddaa	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/HpbXL4.jpg", "size": [180, 180]}
sorl-thumbnail||image||abaab3bbad28227071af9f565eaff570	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/bb/d2/bbd2b9b5d78e5b0da544bfd0b1f7f602.jpg", "size": [50, 50]}
sorl-thumbnail||image||207dc6b4b9435491270a5a59c78e6c9f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3f/1d/3f1d2ba9b5cd93700e29a3027774ba52.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||b2858ca22806b55fd0d17e0339dd87a2	["fdff0247c284d4cde6f876dbb6d51d56", "5000ceaae487ce9f96fe04d2b3cd7eca", "6050d1a32dc8b54cdf7c92d985c08724"]
sorl-thumbnail||image||336432243e38dbbde98e527f1ac30fb2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Y28VVI.jpg", "size": [180, 180]}
sorl-thumbnail||image||a10b8ec49b909f502e802ac73fee231e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e2/fa/e2fab725c9259f6befb8161d82d55c47.jpg", "size": [50, 50]}
sorl-thumbnail||image||ee4fa19ceb98aaacb8ab266cec313c38	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/qDkyoI.jpg", "size": [180, 264]}
sorl-thumbnail||image||d7ca5f127f1f1ccf0b066bac81a26c08	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/9e/1e/9e1efe19de69ef25393de43fc283b38e.jpg", "size": [130, 130]}
sorl-thumbnail||image||e04eed67fe35feade0955b8b5e1aa537	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/0r1aiH.gif", "size": [504, 84]}
sorl-thumbnail||image||4d22603413d0127e38fe3cd968554dd2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/65/16/6516a8189996879c9c4d4063e6613db5.jpg", "size": [50, 50]}
sorl-thumbnail||image||0f0880ec082f34b55528185cc57a1a97	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/0e/f2/0ef2acc933a7a26e84010c99e517022f.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||ee4fa19ceb98aaacb8ab266cec313c38	["91c1b1cde7ef8646ea9d782cad7fcd04", "1b8f309605543c2756029ca637fdba5a", "5eab4b9b1f32a5e13b2c76eda8ae229d"]
sorl-thumbnail||image||0e4c039027ba87588808b489db0547d6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/uHreGO.gif", "size": [198, 126]}
sorl-thumbnail||image||428e91d6345033c6f97f0529d31a9b13	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/45/3b/453b4d8884a2ed2b0b36cf3c754525a9.jpg", "size": [50, 50]}
sorl-thumbnail||image||93ec1cc71377bc50b62bc48c037d4830	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/2e/30/2e30c88dc944a95d1a6a427c5b2fc301.jpg", "size": [50, 50]}
sorl-thumbnail||image||5eab4b9b1f32a5e13b2c76eda8ae229d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/bf/2b/bf2b4b5e1d8c7f5b2aec2b160637fcb6.jpg", "size": [50, 50]}
sorl-thumbnail||image||1b8f309605543c2756029ca637fdba5a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/9a/39/9a39ff3f7facdf3cb5ef74609242bab4.jpg", "size": [130, 130]}
sorl-thumbnail||image||55e359b7d80fab50631f4d84ed74cf5a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/z3NEWl.jpg", "size": [70, 40]}
sorl-thumbnail||image||c7952c88c058d3707abf0ff73c8f613f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/5c/42/5c42180e236286b393ee57224eaf9596.jpg", "size": [50, 50]}
sorl-thumbnail||image||7af2f3eb8c160160f7d7dbc32814dff8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/29/8f/298fac8a4f8d2cf2fd175088884f6c5b.jpg", "size": [130, 130]}
sorl-thumbnail||image||dc9fa6e6a6b3c33d4ce86bffaff85c87	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e7/1c/e71cebe2f25f8b8b9db72350bcfb31f9.jpg", "size": [200, 200]}
sorl-thumbnail||image||8fcba59cff18e92d36739bac77d35da9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/SysLBS.jpg", "size": [180, 180]}
sorl-thumbnail||image||13cbffaf127fd62f2cff43d6b7c3b275	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/0diXFy.jpg", "size": [180, 167]}
sorl-thumbnail||image||bac16799a751c3f062e6739dd5a6f44f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f1/1a/f11adade85bac3284c9fcea5558b559a.jpg", "size": [130, 130]}
sorl-thumbnail||image||31e419d9f100dc48d6bf402c3de47ed8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1f/34/1f347eb783add6f26d105f34cdd7361f.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||3d67f3b5d02fc0dce058f9fdb119cdab	["33d5e105efad6d5e5887a1415fa2f230", "a46af5cdd0395b774e994bc75e795cef", "042ef52d127996acd5bf294c50ab8b6d"]
sorl-thumbnail||image||33946edcac86ab36613968268e3163b2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/SlippedDiscRecords.jpg", "size": [1840, 3264]}
sorl-thumbnail||image||62d650229d6a3abe20519d36006b157b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/0f/e3/0fe3ea76ecd57fbe9d276346b0552d0a.jpg", "size": [130, 130]}
sorl-thumbnail||image||da24fb533de854ffaa492d4d1e39af49	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/15/1d/151db72c83af5bbd2a2218b44387147e.jpg", "size": [200, 200]}
sorl-thumbnail||image||72d1d34b7538f53adc395e19c8a83d0a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/r5mgof.jpg", "size": [200, 63]}
sorl-thumbnail||image||58c03ecde603ac96c6f8cc1bcfe47481	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/cb/3f/cb3f0810338c52ba2c3b2ace89ddd743.jpg", "size": [50, 50]}
sorl-thumbnail||image||d2a7697d9bebad661d9b5c4d00fe53db	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3f/7c/3f7c16cb67e5f70bb71510e88b93d0d8.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||6ef332ece8e2956dfc607b11a25f289e	["ba24c84074db536aab4d8a8857e069f3", "5dbb20bbd036a8d92635c9155762729d", "359c80b85110de758ee3ff04912e59f7"]
sorl-thumbnail||image||6ef332ece8e2956dfc607b11a25f289e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/EnricosHairCutting.jpg", "size": [3264, 1840]}
sorl-thumbnail||image||5dbb20bbd036a8d92635c9155762729d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/0d/e0/0de0261826eb11e6b39536842c648d7c.jpg", "size": [50, 50]}
sorl-thumbnail||image||bda3eab918f55fdf4db1d8d64e283dd3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b7/bd/b7bde5f179f2c78f303f7a2504e82b1d.jpg", "size": [50, 50]}
sorl-thumbnail||image||ba24c84074db536aab4d8a8857e069f3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/81/ec/81ec7412179972bc8a35086275d9080f.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||1d8bd1748aee52c7de426e066c057a05	["d6154f83bf33547558d158f69b79367c", "ac19d200d3f5a4727af7026a630537f5", "9825f7dc0eadd532fcd4580f3ed7964f", "d0211141a35e4f9e14b064d76e171f6a"]
sorl-thumbnail||image||b9b20057edf418f2661fcaff59447863	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/ep6VEN.jpg", "size": [200, 267]}
sorl-thumbnail||image||89352258401e1404cdec6e95575e83c8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/22/79/227978b30767eeb4fd0e16e2c59dbb36.jpg", "size": [50, 50]}
sorl-thumbnail||image||6ef17978a965f17d777a38361dcf7ba7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f7/a1/f7a19938908515c6f3835e37bc148d25.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||154cffe82fc13b9f6f1d0bb8a686ed6a	["dca9e8d9dfabf8b8da9f15eb548ebcb8", "2d45cdd4e2ed49746e3bd75c355a847b", "8db5c6e3e2525fa02053bf9167880a1f"]
sorl-thumbnail||image||45a1e32b814f55ef9aa3965375621f41	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Nellies.jpg", "size": [3264, 1840]}
sorl-thumbnail||image||e993d80399391f65a54e90d373b382ad	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/94/6a/946a9b1db19b8d75acb7ad6d69986514.jpg", "size": [50, 50]}
sorl-thumbnail||image||d6154f83bf33547558d158f69b79367c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/43/b2/43b212a335047ce966c3588b264b457c.jpg", "size": [50, 50]}
sorl-thumbnail||image||74f26b3cbaa89797daebb13ea0715cc6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e4/34/e434f7226346dd42cf48bd17fd748816.jpg", "size": [130, 130]}
sorl-thumbnail||image||154cffe82fc13b9f6f1d0bb8a686ed6a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/oI1Wk8.jpg", "size": [180, 270]}
sorl-thumbnail||image||8db5c6e3e2525fa02053bf9167880a1f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/5b/3a/5b3af4c34787200326cad3bdc26b7599.jpg", "size": [50, 50]}
sorl-thumbnail||image||dca9e8d9dfabf8b8da9f15eb548ebcb8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/90/4d/904da0d713e3415bd029c328799ed98f.jpg", "size": [130, 130]}
sorl-thumbnail||image||d8b9478a428c9e5cbf4403761ddbed8f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/57/9d/579dceafeab34773e183e6970a68fe91.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||33946edcac86ab36613968268e3163b2	["d8b9478a428c9e5cbf4403761ddbed8f", "bda3eab918f55fdf4db1d8d64e283dd3"]
sorl-thumbnail||image||5d1ff3b1d5f7e32fd70ed26eb0f4e33e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/4EFQFs.png", "size": [180, 145]}
sorl-thumbnail||image||d6507bf57e4b58399779231ab8ca3044	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/66/36/6636cb55d7d07d2bf309b3bc36953456.jpg", "size": [50, 50]}
sorl-thumbnail||image||b102950c998b259b635562ec7050030e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1f/22/1f229e963036dcb2a320dff2324ab899.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||5d1ff3b1d5f7e32fd70ed26eb0f4e33e	["d6507bf57e4b58399779231ab8ca3044", "b102950c998b259b635562ec7050030e"]
sorl-thumbnail||image||1d8bd1748aee52c7de426e066c057a05	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/kPBUfp.jpg", "size": [180, 180]}
sorl-thumbnail||image||244bd7a0f5993f8841c37496c27b9b30	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/SelectionBoutique.jpg", "size": [1577, 1721]}
sorl-thumbnail||image||9825f7dc0eadd532fcd4580f3ed7964f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/66/fd/66fd6288f6623f1c4a48002af629b652.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||45a1e32b814f55ef9aa3965375621f41	["e993d80399391f65a54e90d373b382ad", "74f26b3cbaa89797daebb13ea0715cc6", "355b4ce38a80b82ea6e0ce32a99353fb"]
sorl-thumbnail||image||dd87d8703ef182b9b842c64b0de45b8a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/09/9f/099f2dfd91ea3efbc0eab44a84ed62a0.jpg", "size": [50, 50]}
sorl-thumbnail||image||118ffec5a140c2dedcaf764e8a886a66	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/LOGO_004.bmp", "size": [637, 264]}
sorl-thumbnail||image||7a36a4a265172543a46939edb56b9720	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/83/bc/83bc036474cdcb7307c6366379f6d625.jpg", "size": [130, 130]}
sorl-thumbnail||image||b81f94a6fb859fd115d7f3e764ca7e4e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/88/77/887799e227ccc5b4ca5d380778533f17.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||244bd7a0f5993f8841c37496c27b9b30	["dd87d8703ef182b9b842c64b0de45b8a", "b81f94a6fb859fd115d7f3e764ca7e4e"]
sorl-thumbnail||image||8992991c7a2f2caf4528f5cbfad697f6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/MilanosPizza.jpg", "size": [3264, 1840]}
sorl-thumbnail||image||8a3e3926174f94057925164a9ba0e1a3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/2d/57/2d575ac96e4a7e3776fa57730358aa0e.jpg", "size": [50, 50]}
sorl-thumbnail||image||411f917678f8c5133fed2ac0d1dc77c1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/19/5f/195f4dd8031e1393723a1df7b79b3261.jpg", "size": [50, 50]}
sorl-thumbnail||image||ae3089a1ca093bc5802d6c0b9dec3e12	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1b/6d/1b6d5764402336a74b2d7393c48db267.jpg", "size": [130, 130]}
sorl-thumbnail||image||787acc6ffb7194b07623efdf4fcc95b0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/T3_RiM.jpg", "size": [180, 180]}
sorl-thumbnail||image||2ee2932347528f8369c8a438b7e24c11	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/4d/6f/4d6fd8f10a486b0756c737b2818075ee.jpg", "size": [50, 50]}
sorl-thumbnail||image||8c6695c4b978ef6967969fd716b2a4dc	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/18/cb/18cb6011e07693f5b878d458181fc46d.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||787acc6ffb7194b07623efdf4fcc95b0	["2ee2932347528f8369c8a438b7e24c11", "8c6695c4b978ef6967969fd716b2a4dc"]
sorl-thumbnail||image||2e7dd16246439a716b79e0b8754a915c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/GoldenPalaceBuffet.jpg", "size": [1599, 3073]}
sorl-thumbnail||image||9d923982bf2ef3a0253f60f79964d6e5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/02/ff/02ffc7fd2e46bbfc7e922374528d0872.jpg", "size": [50, 50]}
sorl-thumbnail||image||605913e496c9148e5e326742c33a0216	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/34/94/349419f06a2000fb87f7dce24fd67501.jpg", "size": [50, 50]}
sorl-thumbnail||image||77a68922bcf914d4969e4f9aaf5ee9c3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f0/27/f027f16a58fb853676fc4561123f24c2.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||420816dfb9c4c1b67db1739a766bd90a	["bb929eca5df7e70164593911d153a39e", "4179464921297d7d3a9799a8ccbf51a6", "ef73a36c9657f85737bae519de97c7ef"]
sorl-thumbnail||image||bc2e766fdc85177ffd72e56c95720383	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/_lSSQP.jpg", "size": [200, 93]}
sorl-thumbnail||image||168d7b5c54eb8f2dd0b88bf250cb05b8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/7c/d0/7cd0faf3d43099b583781a8e049333e4.jpg", "size": [50, 50]}
sorl-thumbnail||image||129b6416d5c3fe6b6dec0a86bb967077	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/9d/06/9d067020973371891e8c897aea0dc769.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||cd4ec0db5eca4ad38b7d6b23b4d37f7f	["411f917678f8c5133fed2ac0d1dc77c1", "29862746e2fc765a4b7b9b3b54f47aab", "6837ae47feda951c4903c0dff8b5e9df"]
sorl-thumbnail||image||d116d0ecf2ad1511a5ae6a614ed88066	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/GZk5JN.jpg", "size": [200, 133]}
sorl-thumbnail||image||70444c3f543c98b480ef3af7e5dfaec6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6d/32/6d324f9524fbe303be2df621cb6de6f1.jpg", "size": [50, 50]}
sorl-thumbnail||image||29862746e2fc765a4b7b9b3b54f47aab	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/8d/ea/8dea208b3e73b718d10dcc35fc41dd7f.jpg", "size": [130, 130]}
sorl-thumbnail||image||7ed2ab7d6b3ee023e5dbec211373a4c3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/10/2c/102ca8328d3746cbdba3e37135483dd7.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||d116d0ecf2ad1511a5ae6a614ed88066	["70444c3f543c98b480ef3af7e5dfaec6", "7ed2ab7d6b3ee023e5dbec211373a4c3"]
sorl-thumbnail||image||cd4ec0db5eca4ad38b7d6b23b4d37f7f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/dHQjw0.png", "size": [180, 208]}
sorl-thumbnail||thumbnails||8992991c7a2f2caf4528f5cbfad697f6	["ae3089a1ca093bc5802d6c0b9dec3e12", "8a3e3926174f94057925164a9ba0e1a3", "38389535133c82ac3b6f7df0ff1342ee"]
sorl-thumbnail||image||735d4de786c70632dc8ca6e80569b1e1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/lCQxlk.jpg", "size": [180, 228]}
sorl-thumbnail||image||ac5f092c2690afa40aaac71640208474	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f6/9e/f69e774d3b6156c850bb80ea8e837084.jpg", "size": [50, 50]}
sorl-thumbnail||image||551c8a9dc4427d0f3161166d718fa4cb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/01/ab/01aba07f23f73b6f392c72e948955aa9.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||735d4de786c70632dc8ca6e80569b1e1	["551c8a9dc4427d0f3161166d718fa4cb", "ac5f092c2690afa40aaac71640208474"]
sorl-thumbnail||image||8a49e179d015c2c07ab4b298acea17fb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/yjgv7r.jpg", "size": [200, 73]}
sorl-thumbnail||image||420816dfb9c4c1b67db1739a766bd90a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/TheExchange.jpg", "size": [1505, 2473]}
sorl-thumbnail||image||bfc59670cb4f6d85be145ee06a175f60	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/35/61/3561c417ff413099bf0f5150b4605170.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||8a49e179d015c2c07ab4b298acea17fb	["605913e496c9148e5e326742c33a0216", "bfc59670cb4f6d85be145ee06a175f60"]
sorl-thumbnail||image||ef73a36c9657f85737bae519de97c7ef	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/43/19/4319b0af709a9b330554aee85a7535e9.jpg", "size": [50, 50]}
sorl-thumbnail||image||79fc8a416991a8900623327230a9a0d3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f8/c9/f8c9a64677b583a51a249b8dbba66c58.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||2e7dd16246439a716b79e0b8754a915c	["c8231accbad0fbc6fa47b9db94a8bce3", "9d923982bf2ef3a0253f60f79964d6e5", "77a68922bcf914d4969e4f9aaf5ee9c3"]
sorl-thumbnail||image||bb929eca5df7e70164593911d153a39e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/44/5f/445fafff4b70e8818da9d2e0d276e038.jpg", "size": [130, 130]}
sorl-thumbnail||image||ad0be2172ce69c86114821c9c1999f2b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/1XMtsg.jpg", "size": [200, 76]}
sorl-thumbnail||image||dc061da7a0d455296460bfc81299d0bd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/91/37/9137ea6b18ca63e803fc5f6cef5f860d.jpg", "size": [50, 50]}
sorl-thumbnail||image||228adce2edc1b14059ef68be092f631f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/14/31/14316b2a1b82249d49e736585f9c60f4.jpg", "size": [50, 50]}
sorl-thumbnail||image||3f8edaf19b76ceed1e7ac5521ff7c197	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a3/12/a31229a40cb79ad435b1c46096443924.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||ad0be2172ce69c86114821c9c1999f2b	["dc061da7a0d455296460bfc81299d0bd", "3f8edaf19b76ceed1e7ac5521ff7c197"]
sorl-thumbnail||image||33cd225915de22b76e17b1e010ea26de	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/wL1eHp.jpg", "size": [200, 200]}
sorl-thumbnail||image||95d99c374687a25f53fcda7def920824	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c1/f8/c1f8fbfd3805d52a508cec0bd22bfaa6.jpg", "size": [50, 50]}
sorl-thumbnail||image||ece8dbfcc6e128fd62c32c9dc28bae43	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/bc/1b/bc1bbcd4ccb8921158d559b528835e5d.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||33cd225915de22b76e17b1e010ea26de	["95d99c374687a25f53fcda7def920824", "ece8dbfcc6e128fd62c32c9dc28bae43"]
sorl-thumbnail||image||4cad2f3133ab31a111327187528ed16a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/XS9cGl.jpg", "size": [200, 200]}
sorl-thumbnail||image||9b9e19ed9d8e1f651b647783a9e04dca	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/98/7f/987faf214f09c83d968290bf0de72148.jpg", "size": [50, 50]}
sorl-thumbnail||image||186a4a9b0ab7f10104f5975090db4694	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f6/a9/f6a9629c1a01cae64f36031a0595e37a.jpg", "size": [130, 130]}
sorl-thumbnail||image||be82490efe56e45f0a2cc1c1d7a6931b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/aa/46/aa46622d42f3e460e2e5c870ea872423.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||6203f4a5a138b72c913a5c7416c08a10	["97eed0fa47952afb36543d07ab1a8fc5", "d173dd0016c524b9147037d811687be1", "6a08e33bd5c037b797816538ec4a2f69"]
sorl-thumbnail||image||f196331a42a919e39b0ea4edd58b4f13	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/xvk9Kd.jpg", "size": [180, 180]}
sorl-thumbnail||image||198069be6d55cef7d5bb6a5c4fe5f590	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/37/fa/37fa42360649ccf37b09e5a969bb6713.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||4cad2f3133ab31a111327187528ed16a	["9b9e19ed9d8e1f651b647783a9e04dca", "be82490efe56e45f0a2cc1c1d7a6931b", "ca29c5180c2d41f0af1961551b56f403"]
sorl-thumbnail||image||87908fb707b521550ae41c625b9f5d47	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/u73OL8.jpg", "size": [180, 180]}
sorl-thumbnail||image||612e46f46632521ee15a47280f453049	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c6/13/c613ae60040ddfb67ea8cd3a9c87479b.jpg", "size": [130, 130]}
sorl-thumbnail||image||821ea637559c4faaed338de71dad07fa	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/laxvyF.jpg", "size": [200, 150]}
sorl-thumbnail||image||0260536033014a07269a6ff376394880	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/9b/3c/9b3c8b9ef60626bcbf7d4468a0fe764b.jpg", "size": [50, 50]}
sorl-thumbnail||image||a06afff56dd4933372d16aa0c2e4b688	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/0a/b9/0ab9a0a6d6eafcea6502ca38826bb4ee.jpg", "size": [130, 130]}
sorl-thumbnail||image||a0ecf6450a462cfdbb158d5bb7c99878	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Khzlj3.jpg", "size": [180, 431]}
sorl-thumbnail||image||000ff92f1778a216ef0cfcfaa18d3a8d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c5/32/c5328f640f87cddcabaa9e64446206b5.jpg", "size": [50, 50]}
sorl-thumbnail||image||6203f4a5a138b72c913a5c7416c08a10	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/fHmH0u.jpg", "size": [180, 180]}
sorl-thumbnail||image||97eed0fa47952afb36543d07ab1a8fc5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d3/3e/d33e65906d71670e19f89b3c0b15eb7e.jpg", "size": [50, 50]}
sorl-thumbnail||image||6a08e33bd5c037b797816538ec4a2f69	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f1/98/f19825b0dec98a60797a5ef94586bc84.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||2a4bdfa22123ba5ddc9698a6b363accf	["228adce2edc1b14059ef68be092f631f", "308962acc3cd8b78a90dead6bcac8b3f", "54adb862cfd148ab0d22cead684578f3"]
sorl-thumbnail||image||2a4bdfa22123ba5ddc9698a6b363accf	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/VbaOaX.jpg", "size": [200, 204]}
sorl-thumbnail||image||9f62df41667f500ef729b4f8ee87c704	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/yu7fhc.jpg", "size": [180, 180]}
sorl-thumbnail||image||54adb862cfd148ab0d22cead684578f3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/fe/cf/fecf35087723cc90c83222284b2d5b43.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||821ea637559c4faaed338de71dad07fa	["0260536033014a07269a6ff376394880", "a06afff56dd4933372d16aa0c2e4b688", "4cd0624a1f7ac2ca7a95683582417e75"]
sorl-thumbnail||image||50f7d3b4f5ccee2ffe3afec837b330c1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3d/f2/3df21b10bb61d43c533cbeebc944e7c2.jpg", "size": [50, 50]}
sorl-thumbnail||image||3e237fec917926fd5aa3e77c71344f1d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/cOs7_k.gif", "size": [800, 510]}
sorl-thumbnail||image||eaca9277da45a5237debe8e725054f19	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/16/d1/16d111a7a8827f162d087712d00a908c.jpg", "size": [130, 130]}
sorl-thumbnail||image||c4fb12ede394f59d4e3ecde9608cb8a7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/60/8f/608f2ccc526fe564f94c178508164489.jpg", "size": [50, 50]}
sorl-thumbnail||image||c93f237dec6abd76f155aaa98b0bef49	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/k_XSu7.jpg", "size": [180, 164]}
sorl-thumbnail||image||a837c0b417c2a696e5077cea4ad11997	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/48/99/489959f4b868c0977fedea93b046a978.jpg", "size": [50, 50]}
sorl-thumbnail||image||e430db7d474b1f87621d8171ba8eff11	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3d/ef/3def98ac1af41253c5b3827fc13fbf97.jpg", "size": [50, 50]}
sorl-thumbnail||image||a5fc622808c6c802b7a2e0e8da64c368	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/fb/c4/fbc44cd9f9dda36877d376f3347d0e04.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||c93f237dec6abd76f155aaa98b0bef49	["a5fc622808c6c802b7a2e0e8da64c368", "a837c0b417c2a696e5077cea4ad11997"]
sorl-thumbnail||image||a1b215894ed6beb96e026d39b35e7222	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Qg3so5.jpg", "size": [180, 160]}
sorl-thumbnail||image||652cbecc87e441895e84b6bbc1802565	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/8b/c2/8bc2dfcb966f442b5ff73a78334d4c1e.jpg", "size": [50, 50]}
sorl-thumbnail||image||a8e863d5ab1a1b541a886f123c7b0637	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e9/d3/e9d335aec6626ee49585076c06fcd683.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||a1b215894ed6beb96e026d39b35e7222	["a8e863d5ab1a1b541a886f123c7b0637", "652cbecc87e441895e84b6bbc1802565"]
sorl-thumbnail||image||28b89f31920276b9a14800bb70d371f6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/FedexOffice.jpg", "size": [1840, 3264]}
sorl-thumbnail||image||8fe9e06e8bb75fb0ad3ebd1384502c15	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ff/84/ff8469aa060e1eb173318930062df35c.jpg", "size": [50, 50]}
sorl-thumbnail||image||aae42778acc2b4aae63cd6fdb01d6e33	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1b/29/1b29a26ce9f465535c29fe4b94a400e1.jpg", "size": [130, 130]}
sorl-thumbnail||image||e66c33c9db204301515f1ba34c0e8738	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/5f/27/5f277163c8762ca46af95c79a2614a34.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||0943e6f0cc9af654ff7bbf67f1bd7c15	["fca8157e89c7825b028f0bead6359696", "546955862f028aea55a8c93aea73860d", "55e03ec4f66dcfd76660d2cf2a587d58"]
sorl-thumbnail||image||4dc73637ab7a1ce9a3018193c37d12de	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/UdueNv.jpg", "size": [180, 157]}
sorl-thumbnail||image||da1924e791fa0922b4f712e98d014801	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c5/6d/c56dbb7c866fa2b2d58788c7ca1b3101.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||28b89f31920276b9a14800bb70d371f6	["e66c33c9db204301515f1ba34c0e8738", "8fe9e06e8bb75fb0ad3ebd1384502c15", "3954c253c83b4fcdff20836cd2a8f1db"]
sorl-thumbnail||image||c998c82a9f632e222dadc0547def4428	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/fd/d4/fdd4752d3f176df618b98c5d4d9da73d.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||446e66efd42c95d7deb3c7eafa0ff33d	["3a01f3462d95e0eae59895df444b936b", "d1226c2e6b84e4ae76a438d2b8a0263c", "4343e1f203a56337b14a4f485c391f8c"]
sorl-thumbnail||image||0943e6f0cc9af654ff7bbf67f1bd7c15	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Z6tTAI.jpg", "size": [180, 180]}
sorl-thumbnail||image||546955862f028aea55a8c93aea73860d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c6/c4/c6c44d35cdb26d3a4b1a37d7ed90fe80.jpg", "size": [50, 50]}
sorl-thumbnail||image||55e03ec4f66dcfd76660d2cf2a587d58	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/48/b6/48b68b0ddf027e33c306e48b1e0b334f.jpg", "size": [130, 130]}
sorl-thumbnail||image||10af944aa35d2c332e58d2848f55cd4e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/OaklandJewelry.jpg", "size": [555, 381]}
sorl-thumbnail||image||f28cdf6f2f0933e28f0381336d98b65b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1b/6f/1b6f0f1acecb6d6f79ba8b89319feec6.jpg", "size": [50, 50]}
sorl-thumbnail||image||d4177310a5f11ffa88fed96fc14b2ba0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/4uGXlW.jpg", "size": [180, 180]}
sorl-thumbnail||image||c07fa5a6fe38448fb72fc31a7bf84a86	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/5e/ac/5eac37e9089301c95e420c182d61d175.jpg", "size": [50, 50]}
sorl-thumbnail||image||b0124f1ee7209934e0c4a9e6eec89715	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6e/6a/6e6ab7c14df26a38dc38fdfa990e0e2d.jpg", "size": [130, 130]}
sorl-thumbnail||image||6b7f8902d2f2e136bf720b41cf12eb79	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/BrueggersBagels.jpg", "size": [3264, 1840]}
sorl-thumbnail||image||446e66efd42c95d7deb3c7eafa0ff33d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/VeraCruz.jpg", "size": [1205, 705]}
sorl-thumbnail||image||3f11b051012c1edc26775e58618a1f07	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/8b/6c/8b6cc5bb365e0ded7585992f3342bd95.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||6b7f8902d2f2e136bf720b41cf12eb79	["e430db7d474b1f87621d8171ba8eff11", "3f11b051012c1edc26775e58618a1f07"]
sorl-thumbnail||image||d1226c2e6b84e4ae76a438d2b8a0263c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d9/0f/d90f7ff159c537a0621f4badbb1155be.jpg", "size": [50, 50]}
sorl-thumbnail||image||c4aeec21172355bc8881cdcf48fd7717	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e3/64/e36411cdfdab494eac32d52329469fb9.jpg", "size": [130, 130]}
sorl-thumbnail||image||3a01f3462d95e0eae59895df444b936b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/40/bb/40bb2a860a734465e184e5fa94e17870.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||10af944aa35d2c332e58d2848f55cd4e	["f28cdf6f2f0933e28f0381336d98b65b", "aae42778acc2b4aae63cd6fdb01d6e33", "5d7418b7411287c7aa1397e11a3d3ba3"]
sorl-thumbnail||image||2e7aaffd2890f8aada52b72e7c0997db	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c7/ee/c7ee3e75234053d0965911ef4b22b889.jpg", "size": [84, 80]}
sorl-thumbnail||image||0002606515b86a8c79a544418748656d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/tsTgpt.jpg", "size": [180, 180]}
sorl-thumbnail||image||947514dd5f9b4d6dab845de49d3e85d2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/0f/25/0f25bb29a2edd4bb62585c5052cd8c68.jpg", "size": [50, 50]}
sorl-thumbnail||image||2292d0a2179e989e5774ffe03575d6cd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/GusMiller.jpg", "size": [1837, 1441]}
sorl-thumbnail||image||e2d40739b8eaf24467fad66e1cd0e96c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f8/4b/f84b9a45dd41fd327c47a3768aca01d1.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||0002606515b86a8c79a544418748656d	["e2d40739b8eaf24467fad66e1cd0e96c", "947514dd5f9b4d6dab845de49d3e85d2"]
sorl-thumbnail||image||f37f8a693f70863a91a7cd5c0eb411b3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/PeiVg6.jpg", "size": [200, 133]}
sorl-thumbnail||image||ce64a734e0f3d86a5b5b57a7d101c35f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d7/2d/d72d19ea2528ef5760ee8f2f6abfcd1a.jpg", "size": [50, 50]}
sorl-thumbnail||image||37d871913ebd56e967b42a8c337779df	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/02/3b/023b8efe0d35ed0db53bb2bc627233ad.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||3bd839971442a5c9c85e61c518786582	["a3f254f9cc592c413540e1485461fd8b", "ad708365bfb75313f3f2331ce0bb3d25", "617aa8656d8a8a57de498dcdd8db1a96"]
sorl-thumbnail||image||c36152f38d9fff445ce06360d0429868	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/CfrB7H.jpg", "size": [559, 145]}
sorl-thumbnail||image||3064734cc994c662567072dfc8827602	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/9b/8c/9b8cab146b7cb4675d72d6e1f878578b.jpg", "size": [50, 50]}
sorl-thumbnail||image||40a48eafdfa0d98ffc766721d885aba0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/30/5e/305e59f78b0dd924be54620a0f934cc5.jpg", "size": [130, 130]}
sorl-thumbnail||image||c098ff742b5791b51ef3a2197c91e7b7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/91/e0/91e0c26fd4eada58bbe6eb0b251d9d52.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||2292d0a2179e989e5774ffe03575d6cd	["fd9a8de6fea4d2f14461010d32210d6d", "1d83871083835fdadc7daf12a5519a56", "955d24c25e9d2d2e972c2ef00d3e758c"]
sorl-thumbnail||image||3bd839971442a5c9c85e61c518786582	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/TaiwanCafe.jpg", "size": [1601, 721]}
sorl-thumbnail||image||ad708365bfb75313f3f2331ce0bb3d25	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1c/c1/1cc1ad7e7ea61dad7921b076bd507d28.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||baf507d90705e478948a8d52ca4553e7	["972fd82fee6ab9c53536822bb4446fc5", "1e56b1c405eb86c18702c6f63b78e90a", "d7796c23da7a30161c00108585a3ba65"]
sorl-thumbnail||image||a3f254f9cc592c413540e1485461fd8b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/34/af/34afd288bfe38fa72df06c72662ab998.jpg", "size": [130, 130]}
sorl-thumbnail||image||82f9c9571328af473acaa7676ceabd2b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/swOFNZ.jpg", "size": [170, 170]}
sorl-thumbnail||image||ea1ef5298076711df898e568b4a40b24	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e0/7f/e07f8487fdfbf3fc2fdfc1a2d2223d16.jpg", "size": [50, 50]}
sorl-thumbnail||image||76e505620c9d3ba5fe9ec4ab80255156	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/96/9b/969b161830bab9d265a813651395c497.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||3e237fec917926fd5aa3e77c71344f1d	["c4fb12ede394f59d4e3ecde9608cb8a7", "31a141a9f9142f28f1948929737b4151", "7a36a4a265172543a46939edb56b9720"]
sorl-thumbnail||image||0715e590bfa2ad648cd33a457b9797a6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/16/ec/16ec2e24ed0e8b83ae03f74d87702b7b.jpg", "size": [50, 50]}
sorl-thumbnail||image||baf507d90705e478948a8d52ca4553e7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/SwXrhO.jpg", "size": [180, 180]}
sorl-thumbnail||image||d7796c23da7a30161c00108585a3ba65	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/02/b2/02b20fed06bf0deb0d302955d9714845.jpg", "size": [50, 50]}
sorl-thumbnail||image||1e56b1c405eb86c18702c6f63b78e90a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/28/c9/28c97f6124467748f0874e8a1d7082b5.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||f37f8a693f70863a91a7cd5c0eb411b3	["37d871913ebd56e967b42a8c337779df", "10903beeffeb7bb30019cf70f86aaa4c", "ce64a734e0f3d86a5b5b57a7d101c35f"]
sorl-thumbnail||image||78df97456f8a9a1a4ff9a6bf927520d0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/lGxf2m.jpg", "size": [200, 73]}
sorl-thumbnail||image||434d036f253d9991f2c12650b7bdb273	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/89/2c/892c50751d0c843ee52781e391319fa8.jpg", "size": [50, 50]}
sorl-thumbnail||image||63d8697c6a6bf832e0f803f01a15965e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a4/65/a465bca9e4e85ff46b62a2c182af443d.jpg", "size": [130, 130]}
sorl-thumbnail||image||1d83871083835fdadc7daf12a5519a56	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c6/ff/c6ffed9469fbfd33d4e294b7ecd1b656.jpg", "size": [50, 50]}
sorl-thumbnail||image||955d24c25e9d2d2e972c2ef00d3e758c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/55/0e/550ecaa3cf5810c75e9dec2e2a50c58c.jpg", "size": [130, 130]}
sorl-thumbnail||image||d9a9ac407fd5d0af1de814269c308fd6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/0d/dc/0ddcbe524bde86badfe09fc1c7c664b4.jpg", "size": [193, 80]}
sorl-thumbnail||image||07215828b2e08be95ba2ebd7bd890835	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/8e/df/8edff5a3137f8914506254b3192aa4fa.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||87908fb707b521550ae41c625b9f5d47	["0715e590bfa2ad648cd33a457b9797a6", "40a48eafdfa0d98ffc766721d885aba0", "07215828b2e08be95ba2ebd7bd890835"]
sorl-thumbnail||image||d68deb876b6bec0b1663ec0587e0da1d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/XaorWC.jpg", "size": [180, 180]}
sorl-thumbnail||image||9255e485c81c98edd5cff908af878196	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/51/b1/51b14e11b8af6417250efd7c4e862b61.jpg", "size": [50, 50]}
sorl-thumbnail||image||9a21358e1713e827390f1070871946e4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/38/0c/380ca7f3f05b339a273f96de031a8c43.jpg", "size": [130, 130]}
sorl-thumbnail||image||9c138dcc950afcba25734aeb6b76b517	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/29/70/2970739b97e966f507388dbb402c3aac.jpg", "size": [130, 130]}
sorl-thumbnail||image||fdc8a7cbb6620b6268c2a3ec270ff122	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/5TBbl3.jpg", "size": [180, 154]}
sorl-thumbnail||image||193eebdf1e50e3f0aa29c22dc77cc6a7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1a/90/1a901934f97d45ec8ee7dd8a5619fa34.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||2e7e97c15b58234cba9f18499e587ad9	["14a9a35bad3589c87fbccf45e84776e6", "9a21358e1713e827390f1070871946e4"]
sorl-thumbnail||image||604e0cf42bcada413c7c4136295b467f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/74/ff/74fffbd3af0fb0be296124d392fc1cdc.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||118ffec5a140c2dedcaf764e8a886a66	["79fc8a416991a8900623327230a9a0d3", "c4aeec21172355bc8881cdcf48fd7717", "d9a9ac407fd5d0af1de814269c308fd6"]
sorl-thumbnail||image||ad628d2f282c64651af09ab8e6979936	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/13/ba/13bab65a845c2e627989f448e045fa39.jpg", "size": [200, 200]}
sorl-thumbnail||image||ce8b7283f387020965256dce5c9e9ad2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/67JVzA.jpg", "size": [200, 150]}
sorl-thumbnail||thumbnails||c63d1290d1acafdbfb11bd54ef266503	["3355afce4757cde88bddcf8517cc7776", "c343a3a1b0c6f4a374979a4d9e188f87", "0b117c37e43cae96000887e0c0940fe7"]
sorl-thumbnail||image||4a49eb5b05f08fffc1e803418f5ee6e8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/2a/c3/2ac3008c04c3e31136400e592b2ed785.jpg", "size": [50, 50]}
sorl-thumbnail||image||2a1ba750b95f6a992f95649c5d24f5d2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/FfCEHU.jpg", "size": [180, 180]}
sorl-thumbnail||image||f19e18121b37bb1fec2a808cd49174d0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6d/61/6d61555df0917e9a143a66971cb31cb0.jpg", "size": [50, 50]}
sorl-thumbnail||image||d8959a906eef8a376eb85fcc42f83af3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/3d5nZ6.jpg", "size": [200, 29]}
sorl-thumbnail||image||c2cb4e4be2dddd18aa38b6a6a66cd589	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1a/49/1a49ca144029f1deccfc86906b18048e.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||2a1ba750b95f6a992f95649c5d24f5d2	["f19e18121b37bb1fec2a808cd49174d0", "c2cb4e4be2dddd18aa38b6a6a66cd589"]
sorl-thumbnail||image||de67eeef36f55370425be630b4057604	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Oym8po.jpg", "size": [130, 97]}
sorl-thumbnail||image||61a96efac42ba6d01196448decfc0407	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b4/6a/b46ab01c5416fae7a29fc72ee87f648b.jpg", "size": [50, 50]}
sorl-thumbnail||image||52f1205254a7b0d8bf297b9a2291ed00	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/09/b7/09b71e7ffd7383eae685ef0db0fc9a49.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||ce8b7283f387020965256dce5c9e9ad2	["5b55664d4b8248af87ed0bc835654977", "aa4e1ac5df0177e2bb359b020176ce6c", "4a49eb5b05f08fffc1e803418f5ee6e8"]
sorl-thumbnail||image||2e7e97c15b58234cba9f18499e587ad9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/qA9vo0.jpg", "size": [180, 180]}
sorl-thumbnail||image||14a9a35bad3589c87fbccf45e84776e6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/cb/b0/cbb0753067224610493a19fc0d9ff93b.jpg", "size": [50, 50]}
sorl-thumbnail||image||5b55664d4b8248af87ed0bc835654977	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d7/0a/d70a2e3e0d3c217b5a1e5d24face8b40.jpg", "size": [130, 130]}
sorl-thumbnail||image||c63d1290d1acafdbfb11bd54ef266503	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Hl0rBx.jpg", "size": [180, 180]}
sorl-thumbnail||image||c343a3a1b0c6f4a374979a4d9e188f87	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c3/ef/c3ef497307893eb28c1ac090e522ee41.jpg", "size": [50, 50]}
sorl-thumbnail||image||311ddd1614872100c631f930651a3bec	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/34/7c/347c98cbc29a984cf8a2cc563a6b105a.jpg", "size": [50, 50]}
sorl-thumbnail||image||3355afce4757cde88bddcf8517cc7776	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/dc/1f/dc1f03223e086622fe2511e4a5741151.jpg", "size": [130, 130]}
sorl-thumbnail||image||f7ca2bdc90b488bb7b2e0dce9f00446e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a4/40/a440407df47c7d9e5c8fe2839d0853ae.jpg", "size": [50, 50]}
sorl-thumbnail||image||2949daa75fdbca7fd9fba8418a81ff63	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/21/9b/219b452fcc54977f25f573b53808e77b.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||d8959a906eef8a376eb85fcc42f83af3	["2949daa75fdbca7fd9fba8418a81ff63", "311ddd1614872100c631f930651a3bec"]
sorl-thumbnail||image||f8e782d29791341bdd486f9b05437823	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/lw3doH.jpg", "size": [200, 93]}
sorl-thumbnail||image||204c1038c45847f7d2505237a132a72f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Os5u5F.jpg", "size": [180, 236]}
sorl-thumbnail||image||7d54ae8d48f740dff6af217d3b2efeeb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/2f/f4/2ff45090035d6f2115e178b6732c27dd.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||d68deb876b6bec0b1663ec0587e0da1d	["9255e485c81c98edd5cff908af878196", "3ddae10719e81b7f7c6736caa748f65c", "9c138dcc950afcba25734aeb6b76b517"]
sorl-thumbnail||image||7082374bead2d411037ce05b3de63ca8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/0a/4b/0a4b6d1bd57e0b526895ff56fd8b62a2.jpg", "size": [50, 50]}
sorl-thumbnail||image||98dad094649a4dd366b9fc04a053994e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Nelk1y.jpg", "size": [180, 177]}
sorl-thumbnail||image||46847fd56701fd7d38809c3f99cecc29	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/90/e2/90e2352063fdfda757ed80750ee7a65d.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||204c1038c45847f7d2505237a132a72f	["46847fd56701fd7d38809c3f99cecc29", "7082374bead2d411037ce05b3de63ca8"]
sorl-thumbnail||image||a1d07cd0195afeba9877885f0565aa4c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/YB3d3U.jpg", "size": [200, 266]}
sorl-thumbnail||image||fc356a39e6352314ac5d6628be80990d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/fa/de/fade59d6b423f6bfcad9b894b291adf5.jpg", "size": [50, 50]}
sorl-thumbnail||image||3e3e1277634385e2145f2434eba4e3f4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/cd/2e/cd2e1fa1eeac3a2d0c9158c51b7e616c.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||9615761a12a763955d49ae5dd9fc3d44	["2c6556c37aabb7dbff7a59a4a718098b", "39a0f7facfb9303c4e118a02d4c498b1", "21bfba8aeeb3d6a81cc916790a212d6c"]
sorl-thumbnail||image||0c3c7fc727dbcb3fcc19c1ec07137c36	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/omXVgI.jpg", "size": [180, 255]}
sorl-thumbnail||image||54d2eb2495a93b8f64c10376679bfe93	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6b/e4/6be48a37fe6fe2f8727bda8430093635.jpg", "size": [50, 50]}
sorl-thumbnail||image||60f825fca40bcf25158bdfa8c4d84ce9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a5/d9/a5d92ccb09ffb3e0194e257f73259f40.jpg", "size": [50, 50]}
sorl-thumbnail||image||a00cdac822a7a43274809d3d740db079	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/0c/6a/0c6adb64e9ad4b559c2bf147047b9a61.jpg", "size": [130, 130]}
sorl-thumbnail||image||2e97ec58c23eea5a7079e5ac9c10c052	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/3o7SXl.jpg", "size": [180, 200]}
sorl-thumbnail||image||c694ecc4963ed8a29065c2460bc60d2c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b1/27/b12769cf4c1825310faee0d85676c238.jpg", "size": [50, 50]}
sorl-thumbnail||image||2e76e1ffd79896e703e9a5d2b4e61787	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/11/88/118882b03246fcf9ba9f1423b613276c.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||2e97ec58c23eea5a7079e5ac9c10c052	["c694ecc4963ed8a29065c2460bc60d2c", "2e76e1ffd79896e703e9a5d2b4e61787"]
sorl-thumbnail||image||77a813b41c5621ebf75585b7bb752051	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/D5GGTo.jpg", "size": [200, 218]}
sorl-thumbnail||image||01084c7cf191cb4ef54251a1a169808e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/11/9b/119b9c9cc6cc33d8f11f3f12688ba4db.jpg", "size": [50, 50]}
sorl-thumbnail||image||97586efefd41122258389ce06273c4be	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c4/ec/c4eccd0d6474b3a596fb2bdb8c730567.jpg", "size": [50, 50]}
sorl-thumbnail||image||39c326e0b5c7d680cfcca31401b82ce9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/58/63/5863af98e102bb35f20776b098eaa8bc.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||a1d07cd0195afeba9877885f0565aa4c	["3e3e1277634385e2145f2434eba4e3f4", "fc356a39e6352314ac5d6628be80990d", "ad628d2f282c64651af09ab8e6979936"]
sorl-thumbnail||image||9615761a12a763955d49ae5dd9fc3d44	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/t2CbWp.png", "size": [804, 1192]}
sorl-thumbnail||image||39a0f7facfb9303c4e118a02d4c498b1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c7/8a/c78a0737e4bfcbf2f50399f4d0488bd3.jpg", "size": [50, 50]}
sorl-thumbnail||image||21bfba8aeeb3d6a81cc916790a212d6c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/99/ea/99ea38c56fc8d42664a7c03651ca3f1a.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||6c46564c8a0a497ef4ea0c699667bcbb	["5d7406c9e6fb955948f754b2c280a882", "c0f3594c2a7c7c6ff0f979ff310bde71", "9e029c89fc123eb922e81cca35474967"]
sorl-thumbnail||image||2da4401fcddc0ccb04f5a69df911d616	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/da/36/da36eeaed8e3adc211a1a6536ea1bbd4.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||0c3c7fc727dbcb3fcc19c1ec07137c36	["a7fe400ae7c28f2f45cd2e37be2f0df8", "a00cdac822a7a43274809d3d740db079", "54d2eb2495a93b8f64c10376679bfe93"]
sorl-thumbnail||image||e4d0c53e3be948a67929b63ff1ffc250	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/tYcxPe.jpg", "size": [200, 131]}
sorl-thumbnail||image||19f839050dcfd5858f4556ff12c2a1af	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/2a/66/2a66d0dab53cbb50bf0611d5d72aed82.jpg", "size": [50, 50]}
sorl-thumbnail||image||1df513926a2fb6f20282601f043f7f68	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/cd/ff/cdff4f7fe1e5c86b62a5cc403409a678.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||98dad094649a4dd366b9fc04a053994e	["2da4401fcddc0ccb04f5a69df911d616", "60f825fca40bcf25158bdfa8c4d84ce9", "eec2425de3d825b2dadd98f22d7d742c"]
sorl-thumbnail||image||648238c9a700afd3c6dd87ed0b9a12d9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/o02UOv.jpg", "size": [940, 412]}
sorl-thumbnail||image||6c46564c8a0a497ef4ea0c699667bcbb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/CAI0Lv.jpg", "size": [180, 101]}
sorl-thumbnail||image||ba4cfe80bed61bacd8d4b1b29d93d1f2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d4/29/d429e1323b1c0b25f0224210f246a762.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||648238c9a700afd3c6dd87ed0b9a12d9	["97586efefd41122258389ce06273c4be", "ba4cfe80bed61bacd8d4b1b29d93d1f2"]
sorl-thumbnail||image||9e029c89fc123eb922e81cca35474967	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/87/58/8758b50ee341ebeb8b6ef47ff6de8c0a.jpg", "size": [50, 50]}
sorl-thumbnail||image||c665bb187cea80c51274263947029b47	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/8e/36/8e365ea6f0b8a19e72828fd7e75d00d0.jpg", "size": [80, 80]}
sorl-thumbnail||thumbnails||77a813b41c5621ebf75585b7bb752051	["39c326e0b5c7d680cfcca31401b82ce9", "01084c7cf191cb4ef54251a1a169808e", "5f8199d5b9b8e2835ba4e0b8945ed6c1"]
sorl-thumbnail||image||c0f3594c2a7c7c6ff0f979ff310bde71	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/98/ad/98ada464e18be19df49c2f9d7fbfa3a2.jpg", "size": [130, 130]}
sorl-thumbnail||image||f51d77259c39927a51f51ae26c7f0e30	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/ciRS68.gif", "size": [198, 126]}
sorl-thumbnail||image||18ea1971db25d44aef90c7782b724183	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/de/fa/defa4236c841a73c4e9a16e5cd3a090c.jpg", "size": [50, 50]}
sorl-thumbnail||image||121adb6924471e480664ff472bef099a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3a/d3/3ad33e6ca0d88e094a14ba78d354a939.jpg", "size": [50, 50]}
sorl-thumbnail||image||5fb8bf89275ee78a4620b8707978f147	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/41/32/4132a8b55e355d29f00635c4a48d108e.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||4525f0dff43b4dfc8fc61761f91e3320	["f07d982e98672bbde01627e298df149c", "556de6eb587e170de40b1506f1cba883", "412948c18f88d0fb9079d256332290e9"]
sorl-thumbnail||image||5e7ef4332f5d0518829d5fe58e7977bd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/2cv6zl.jpg", "size": [200, 107]}
sorl-thumbnail||image||6ceb961a3f53fa6f6ab69551f364f69e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/52/3b/523bd22b2c47885cea21a2d8c16bf7b8.jpg", "size": [50, 50]}
sorl-thumbnail||image||ccc15b83bb7364512f0e04c2c2fd35db	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/10/05/10058cb88ffb7be94520365eba7ec0e6.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||e0cc366079c3ddae96087a24c814ade1	["c64a02b7abe0bd0c9b039dbb3aafd9aa", "58085abc7c7b7c8ac73cc265097fbbf3", "0e2e56cdc5d036f64982d6349a197ded"]
sorl-thumbnail||image||e0cc366079c3ddae96087a24c814ade1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/VeraCruzGrocery.jpg", "size": [2049, 1385]}
sorl-thumbnail||image||58085abc7c7b7c8ac73cc265097fbbf3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/60/13/6013741699d4689c8fdf79eecf9f7d6c.jpg", "size": [50, 50]}
sorl-thumbnail||image||556de6eb587e170de40b1506f1cba883	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/5a/ba/5aba5b8700dd212aa48a33a0f44374c3.jpg", "size": [130, 130]}
sorl-thumbnail||image||0e2e56cdc5d036f64982d6349a197ded	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c8/91/c891ec677d528c20a92ff5e40e1ce7ba.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||542a375ad154ac3fe9b3f003e81ab16e	["4bdda13ac11e21db67151c18ed12d103", "839ab817bba5b6aa75b9b1aa9dedd3db", "8cc96a6e1af96e91ed8fe19c897d78fb"]
sorl-thumbnail||image||a7e2929d0dee6a7649de707ffe07156b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/KoreaGarden.jpg", "size": [1663, 2489]}
sorl-thumbnail||image||f7fe764442e0f675ff3535d863a47f8f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/71/55/7155fabbefe79a6359f015d26bb32a54.jpg", "size": [50, 50]}
sorl-thumbnail||image||00fadf797ccad558354bb64f574ac815	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c4/45/c4459d1f130153b01d83c016df9e5196.jpg", "size": [130, 130]}
sorl-thumbnail||image||34d2b09c905090ab74ca697884f8df4f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/QzjKl1.jpg", "size": [180, 176]}
sorl-thumbnail||image||cffa3ad4e6c595b860cbf457b8cada26	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/57/cc/57ccfdd1192daad184257c323baf4fcf.jpg", "size": [50, 50]}
sorl-thumbnail||image||68a9103cf32bb4569a135441553b4021	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/bb/6c/bb6cbdd40d688565b1bd1439f7d8a12c.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||34d2b09c905090ab74ca697884f8df4f	["cffa3ad4e6c595b860cbf457b8cada26", "68a9103cf32bb4569a135441553b4021"]
sorl-thumbnail||image||4525f0dff43b4dfc8fc61761f91e3320	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/pMb7Qz.jpg", "size": [180, 180]}
sorl-thumbnail||image||412948c18f88d0fb9079d256332290e9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/4e/4b/4e4b4ba9dc826520c25e75f47afdcce8.jpg", "size": [50, 50]}
sorl-thumbnail||image||542a375ad154ac3fe9b3f003e81ab16e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/DZadP5.jpg", "size": [180, 270]}
sorl-thumbnail||image||8cc96a6e1af96e91ed8fe19c897d78fb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/50/b4/50b4da331917a8a22686d8e312ea8dfe.jpg", "size": [50, 50]}
sorl-thumbnail||image||4bdda13ac11e21db67151c18ed12d103	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d4/3b/d43bae0042992e7281201b0fe50a4bb1.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||f51d77259c39927a51f51ae26c7f0e30	["5fb8bf89275ee78a4620b8707978f147", "c5c8a784235b39074d8dfc2c81186cb2", "18ea1971db25d44aef90c7782b724183"]
sorl-thumbnail||image||80e7a8f3f71276c76e8e0fcf789cbe7a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/gPcDjH.jpg", "size": [300, 200]}
sorl-thumbnail||image||43d6f3af300b46e3099485d284179e4d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/trE9oS.jpg", "size": [1005, 590]}
sorl-thumbnail||image||1df2fa9e6379df0ebfa07a8a79977968	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c5/b1/c5b123ae788287fd19581c6431037605.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||5e7ef4332f5d0518829d5fe58e7977bd	["6ceb961a3f53fa6f6ab69551f364f69e", "ccc15b83bb7364512f0e04c2c2fd35db", "cc52495ad31724477fffba5a82490763"]
sorl-thumbnail||image||afdee77ff6eb5e3ffb690cf31770225f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ca/89/ca8935c0ef13c8d84692f91aa41b2515.jpg", "size": [50, 50]}
sorl-thumbnail||image||cd1db1f4aa8830fe3d4ac4d918f29395	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/beXqck.gif", "size": [180, 43]}
sorl-thumbnail||image||fffb5c15986ea2ec53386faccc7e53b0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/87/77/8777508fd49f69e7b332b6028981181b.jpg", "size": [130, 130]}
sorl-thumbnail||image||d7d711153547552ae6f11ec3070d1074	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/07/2f/072f6ff704e305595faf22fb15e75fa2.jpg", "size": [130, 130]}
sorl-thumbnail||image||34556f644de554ade73cc9a4dfd00ed9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/BurgersRiceBowl.jpg", "size": [1233, 2465]}
sorl-thumbnail||image||92979c875c70fa47523b1f414ae3b617	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/37/43/3743c0a401932c2e5949eaf176d0392b.jpg", "size": [50, 50]}
sorl-thumbnail||image||5cde9c17a47978a2ed8b0158f08da4c1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/87/e3/87e3353478c143aebccda944db8d5127.jpg", "size": [200, 73]}
sorl-thumbnail||image||b96b472e5b62855f7c4ff040c84d8f33	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/40/d8/40d8e7b6c1b7dfb7bc329e346b735760.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||0175c1fbbcaaa69851d318f67c3d60ad	["bafe27a59faaca704fff9258fceb9cc6", "60d29ba8e4c4070b5b9e18d4a3475c45", "8d780623660162857883e151376c6282", "4f9793521466c244941fd132f72565a8"]
sorl-thumbnail||image||0175c1fbbcaaa69851d318f67c3d60ad	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/ZJzsVz.jpg", "size": [180, 180]}
sorl-thumbnail||image||bafe27a59faaca704fff9258fceb9cc6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a1/0b/a10b403cbfd60ef11d98ddfb302fe00e.jpg", "size": [50, 50]}
sorl-thumbnail||image||8d780623660162857883e151376c6282	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/27/bb/27bbd5d5c84a29db89f97aaa515a6fad.jpg", "size": [130, 130]}
sorl-thumbnail||image||167de1b97379ac0ffa6d69ff3ab16abc	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/4f/20/4f2022d368ba63e6982301eb12504d55.jpg", "size": [200, 200]}
sorl-thumbnail||image||18953354dd9afd1d69cd198887ab42ef	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/HSh0ku.jpg", "size": [180, 180]}
sorl-thumbnail||image||5deea5264e595c9bf3c7674f0e0f3659	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ef/18/ef18f0c7427d7547d190bee7bb4f615c.jpg", "size": [50, 50]}
sorl-thumbnail||image||d20d61de4e8f7555f9d736f8a4175999	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/50/73/5073da3506b4c2cda366b769ccdd7421.jpg", "size": [130, 130]}
sorl-thumbnail||image||f9ebbeab428b83df6a706297479489d6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/24/cd/24cd37e2416a780375edae0112996f5f.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||34556f644de554ade73cc9a4dfd00ed9	["3bc8481feb137caf8a2633dada2165e8", "92979c875c70fa47523b1f414ae3b617", "b96b472e5b62855f7c4ff040c84d8f33"]
sorl-thumbnail||image||7bf9a4635d72aa5afcacf7c05b51eb63	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/4o1FMp.jpg", "size": [180, 139]}
sorl-thumbnail||image||f8e9b2a5f141918091fbf7bfb78214c5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/cf/0b/cf0ba3e819cf4e57c676482911c3b903.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||7b5372bcc43c194e424c295e389d847a	["04a25bbda9c91b23b60c4b6ef8a97c42", "d20d61de4e8f7555f9d736f8a4175999"]
sorl-thumbnail||image||05c0c69391bcb8dd0ccd675d6ce6b4a7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/25/11/25110ba45dbacd28457996feb728b65a.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||e92a0b18f1bfc84c68b141d6e1642490	["923a5e4d4f19022862b6cd389109d0b4", "f1500c237a4b6a2ddb190eea8ed419ee", "139eac0cc658d6ba950f50e87c7254ec"]
sorl-thumbnail||image||8c7f36878f7a67c45eeed69d2c691841	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/hdaH3f.jpg", "size": [180, 180]}
sorl-thumbnail||image||45ac48538020b01d78dfd08397f85ea9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/8d/0c/8d0c65ca5dfc78f5043cb91276e0b8f6.jpg", "size": [50, 50]}
sorl-thumbnail||image||af5fb37a77ef0837a8e5f9e1d4ce4b86	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b9/a1/b9a1f6d259bacfe7a6dae4cf1865f148.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||43d6f3af300b46e3099485d284179e4d	["e6547c1a720ef372222839c9bf3bbe17", "afdee77ff6eb5e3ffb690cf31770225f", "fffb5c15986ea2ec53386faccc7e53b0"]
sorl-thumbnail||image||7b5372bcc43c194e424c295e389d847a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/gXbZ7h.jpg", "size": [200, 150]}
sorl-thumbnail||image||04a25bbda9c91b23b60c4b6ef8a97c42	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a4/a6/a4a65240e49455c6621c8aed9c365e0c.jpg", "size": [50, 50]}
sorl-thumbnail||image||a33ad536f22c1757f2e905275010f842	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/eroZX6.jpg", "size": [750, 400]}
sorl-thumbnail||image||23121eb565b5a97b200bec53e7e1d617	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f5/a9/f5a94de8ed2ad7a69685bba01de9f7ec.jpg", "size": [50, 50]}
sorl-thumbnail||image||e92ab54d6cb409ebb3fb93aa4e35fa8d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b6/93/b6934689af6ae8a1a3cf374d60e168f2.jpg", "size": [130, 130]}
sorl-thumbnail||image||e92a0b18f1bfc84c68b141d6e1642490	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/vLyCMC.jpg", "size": [200, 76]}
sorl-thumbnail||image||b666f34dd725032c8bcb38321650b578	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/yWGbjM.jpg", "size": [180, 180]}
sorl-thumbnail||image||139eac0cc658d6ba950f50e87c7254ec	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/88/84/8884f0cba01d413b96e9fcb52dae28c7.jpg", "size": [50, 50]}
sorl-thumbnail||image||923a5e4d4f19022862b6cd389109d0b4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/2a/02/2a02d45cd2376b02c926900af2715692.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||18953354dd9afd1d69cd198887ab42ef	["5deea5264e595c9bf3c7674f0e0f3659", "f9ebbeab428b83df6a706297479489d6", "89ac99f1c2b83a897e5a65eb9dc89c57", "b37bfb5c471be8ff356b9fb975b0a047"]
sorl-thumbnail||image||8b553c32174c322032de12afad8235fc	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c7/a9/c7a9632bba6a74c8da2e84b64cfdbafa.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||13cbffaf127fd62f2cff43d6b7c3b275	["167de1b97379ac0ffa6d69ff3ab16abc", "31e419d9f100dc48d6bf402c3de47ed8", "62d650229d6a3abe20519d36006b157b"]
sorl-thumbnail||image||180b5a671b4a4a03f25ac6caedd6e560	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/48/46/48465fb29998c56065a8b86d0969a116.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||a33ad536f22c1757f2e905275010f842	["23121eb565b5a97b200bec53e7e1d617", "daeb55c6b05e9abe7a81f27a953bec0c", "e92ab54d6cb409ebb3fb93aa4e35fa8d"]
sorl-thumbnail||image||03bcc2c0b5d3773f9af7b44b4ea64094	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/58/ab/58ab1517376dfd2f1c0fb6951c3e3664.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||708459f537f1791490909fc026c32ebc	["10d33fc1edede3e4481be28274808afd", "d53624d4bb6baaa2965aaef1f0d6ce64"]
sorl-thumbnail||image||96fbfe8ae2f388d3efe876a6931d5745	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c4/b1/c4b18a6148e83b1d27e1424428d52a02.jpg", "size": [130, 130]}
sorl-thumbnail||image||c4b9779f0355e09ebf1fcc0afbbf978f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/w68J7G.jpg", "size": [248, 277]}
sorl-thumbnail||image||feb891f6a3ac5d151c392be3274bbb83	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/cd/c5/cdc502db2a6c5779951ad06fc59d07bb.jpg", "size": [50, 50]}
sorl-thumbnail||image||4d49adf4c31cfe0cfab1effce228579b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/5c/ad/5cada9a52b7bfcd1745cbf53fbe949bd.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||db7be3d54e10e65583dd8fb67d41e88c	["b9c238e03683f96812d474cb5876ea8a", "1f965202c10bf20e3afcd84316528e0a", "68b782a376685f19b2ee50e90f6415f2"]
sorl-thumbnail||image||783df27382bcdf161414c966212b9561	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/CentreDryCleaners.jpg", "size": [1673, 1329]}
sorl-thumbnail||image||b05d0f1853df33e44ed5448dade881e8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/06/3a/063af3447d263611859df7f8eb151bd9.jpg", "size": [50, 50]}
sorl-thumbnail||image||4cb4546aa2ce8ed75214bcd83db7cacb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/M8SJo2.jpg", "size": [200, 149]}
sorl-thumbnail||image||e47d6150186254eaaf890aece46a1a54	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/dc/22/dc220c6d00374902feaca8b75ae638f1.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||783df27382bcdf161414c966212b9561	["b05d0f1853df33e44ed5448dade881e8", "e47d6150186254eaaf890aece46a1a54"]
sorl-thumbnail||image||db7be3d54e10e65583dd8fb67d41e88c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/T2l82X.jpg", "size": [180, 120]}
sorl-thumbnail||image||1f965202c10bf20e3afcd84316528e0a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3b/0a/3b0a5e227badc76929cbdc75f2fc310c.jpg", "size": [50, 50]}
sorl-thumbnail||image||68b782a376685f19b2ee50e90f6415f2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6d/8d/6d8da11013d465fff02dfe6a1d91cb5a.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||e9d6f49b877b203d88dd89d6b3d94e8b	["8dd14102e7e64e07ad103c0923d37ed8", "6c50e074e279dc92d3032585a0980589", "75df45e46948663d047cafac7ae364fd"]
sorl-thumbnail||image||99bbadbb03007e25c85dddc9d8fb5e74	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Mitchells.jpg", "size": [2241, 1649]}
sorl-thumbnail||image||04365375df66c171b633c5bbe4a9ee86	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/0b/8f/0b8fd12dfa363c415bb8a9b03cb3c77d.jpg", "size": [50, 50]}
sorl-thumbnail||image||bc497ea8899c880972c0689117d22185	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/7e/24/7e247b87e938f15b2dc26ca7706e462e.jpg", "size": [50, 50]}
sorl-thumbnail||image||bf9f3f0dd66d55ebaeb197a2f787cfae	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e2/e7/e2e7f95d744d78983765e857c72d5ba7.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||c4b9779f0355e09ebf1fcc0afbbf978f	["4d49adf4c31cfe0cfab1effce228579b", "2dc8d3226f3c00842dc2f56adf52abb7", "feb891f6a3ac5d151c392be3274bbb83"]
sorl-thumbnail||image||708459f537f1791490909fc026c32ebc	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/SeoulMart.jpg", "size": [1689, 1433]}
sorl-thumbnail||image||d53624d4bb6baaa2965aaef1f0d6ce64	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/43/63/4363bd732567627eef3e9dff4b302672.jpg", "size": [50, 50]}
sorl-thumbnail||image||8dd14102e7e64e07ad103c0923d37ed8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/28/48/28485785cad4e8bef22fc67dbc3d521b.jpg", "size": [130, 130]}
sorl-thumbnail||image||10d33fc1edede3e4481be28274808afd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e3/40/e3408d70d6fd418e94c4b17c90d96111.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||cd1db1f4aa8830fe3d4ac4d918f29395	["03bcc2c0b5d3773f9af7b44b4ea64094", "96fbfe8ae2f388d3efe876a6931d5745", "c8be0c29f0f988b06571758b3ff6ab1e"]
sorl-thumbnail||image||100d4ab395efd26f3b193fea4a1eb846	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/38/28/382801bc0fdacd9ea0df5799b95c075c.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||4cb4546aa2ce8ed75214bcd83db7cacb	["bc497ea8899c880972c0689117d22185", "100d4ab395efd26f3b193fea4a1eb846"]
sorl-thumbnail||image||e9d6f49b877b203d88dd89d6b3d94e8b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/FakKOK.jpg", "size": [200, 199]}
sorl-thumbnail||image||75df45e46948663d047cafac7ae364fd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/cc/42/cc4250b6687caf46bb02e69d6df2b0d2.jpg", "size": [50, 50]}
sorl-thumbnail||image||12ee57e676423d85034172fb68f4f31c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/w3BDlo.jpg", "size": [200, 200]}
sorl-thumbnail||image||41f6a0cd87e606bbef94fe7c4b541955	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/35/f4/35f45910bad6e88f750d3ae669e0471d.jpg", "size": [50, 50]}
sorl-thumbnail||image||34f4d9d2dd6382bb72a04a51d2b71619	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/dd/77/dd77caf332f839aaec6e71b9b24017a3.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||b666f34dd725032c8bcb38321650b578	["34f4d9d2dd6382bb72a04a51d2b71619", "41f6a0cd87e606bbef94fe7c4b541955"]
sorl-thumbnail||image||a1be901d693551f6cac926c3335f1796	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3e/95/3e959606995309c004c95746d77b61de.jpg", "size": [50, 50]}
sorl-thumbnail||image||48c47023172185d0c3b557074fdef889	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/85/61/85610b7c42e6301b9f2b263d46ddb943.jpg", "size": [83, 80]}
sorl-thumbnail||thumbnails||12ee57e676423d85034172fb68f4f31c	["a1be901d693551f6cac926c3335f1796", "d7d711153547552ae6f11ec3070d1074"]
sorl-thumbnail||image||ab903a95b553281c43ade60f9cb0c9d5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/uMHKxt.jpg", "size": [180, 179]}
sorl-thumbnail||image||f224ec5c659b4fde5e9c53a0de0ff932	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/7e/a3/7ea3ea1caa097ef1535d8fbfb9449d8b.jpg", "size": [50, 50]}
sorl-thumbnail||image||8d670db63c2404642607168c8e89dfc3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/b4PjBg.gif", "size": [198, 126]}
sorl-thumbnail||image||88dba9b2886fb560b624a7c96053fe57	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/36/08/3608539c1de74eaa6e0f77a91c741a66.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||b465f61109621e7e24f27aa7b0d49524	["4ff2112caf35427265134767fc3b975e", "2841622e2369931ad25f03c635d1f93a", "470d66c7ce776280fc268163abd400eb"]
sorl-thumbnail||image||28937eac3e9e82f60a38c139eb515dd0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/aOVkrk.jpg", "size": [200, 200]}
sorl-thumbnail||image||af1dcaf4407a499592e7d9c75970b2de	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c1/67/c167193f978a459e925fd97208d0557d.jpg", "size": [50, 50]}
sorl-thumbnail||image||2215049a13f8ba338e7be6736a439fc0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/11/4f/114f1d27aa4c196ef5e9dc38659abd46.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||28937eac3e9e82f60a38c139eb515dd0	["2215049a13f8ba338e7be6736a439fc0", "af1dcaf4407a499592e7d9c75970b2de"]
sorl-thumbnail||image||75c92e7194cc9af120bb239e6996b8b8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Cun_dY.jpg", "size": [180, 180]}
sorl-thumbnail||image||b19f45bd732eb4eb625be10c378adbd6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/46/fb/46fb3d6d7c3916fb513c675a54fd296f.jpg", "size": [50, 50]}
sorl-thumbnail||image||2841622e2369931ad25f03c635d1f93a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6b/8b/6b8b0e05c7d8399a89604db917b387b1.jpg", "size": [130, 130]}
sorl-thumbnail||image||cf03c7eedfa8f57704339c1ef34ad214	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/83/20/8320d8ea6b9ed7f329690d7f4d317456.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||75c92e7194cc9af120bb239e6996b8b8	["b19f45bd732eb4eb625be10c378adbd6", "cf03c7eedfa8f57704339c1ef34ad214"]
sorl-thumbnail||image||e46c501a847aa17a038534f19070e148	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/zrQ2Jr.jpg", "size": [180, 180]}
sorl-thumbnail||image||d7be2451407e04327fd710c2e52040a4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/11/03/1103cc40825d453c3fddba55341b2555.jpg", "size": [50, 50]}
sorl-thumbnail||image||a7900c4b42288197f90aa07edb48a108	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c1/80/c18059986edf2bf46144d9ed4f3a3724.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||e46c501a847aa17a038534f19070e148	["d7be2451407e04327fd710c2e52040a4", "a7900c4b42288197f90aa07edb48a108"]
sorl-thumbnail||image||63daec350386bddd126e08c0f166847b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/7HIGQl.gif", "size": [198, 126]}
sorl-thumbnail||image||c3011ec7f03f51413a331cdb5c682e0d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/87/9b/879b4a80a63e22796239768e2264490d.jpg", "size": [50, 50]}
sorl-thumbnail||image||84648721430cb200a501fbcbf9c14b99	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/bb/eb/bbeb2fa160341845d6ce01a40bcfe060.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||63daec350386bddd126e08c0f166847b	["c3011ec7f03f51413a331cdb5c682e0d", "84648721430cb200a501fbcbf9c14b99"]
sorl-thumbnail||image||b465f61109621e7e24f27aa7b0d49524	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/A3YSA3.gif", "size": [198, 126]}
sorl-thumbnail||image||4ff2112caf35427265134767fc3b975e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f2/c1/f2c1e5ca67dcfb88d3404d22a60ceabe.jpg", "size": [50, 50]}
sorl-thumbnail||image||df65dcc3f8c4418cad4dd34a095f5aa4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/qhhH1Z.gif", "size": [198, 126]}
sorl-thumbnail||image||d63919d1c6787e1f4985b72f700012fe	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/52/a2/52a2f5b08a315c7079dd8b0ee12a61bd.jpg", "size": [50, 50]}
sorl-thumbnail||image||0f54271f1e540668179da26692e8f4e6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/44/75/44753ee003233820b031e335df9067ef.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||df65dcc3f8c4418cad4dd34a095f5aa4	["d63919d1c6787e1f4985b72f700012fe", "0f54271f1e540668179da26692e8f4e6"]
sorl-thumbnail||image||612ca1afbc911d9cef3eab3b6e2ae879	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/DdGxT2.jpg", "size": [180, 200]}
sorl-thumbnail||image||8a59af3ff00e1e21bcb9141029fb2771	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/42/ca/42ca3c3bb1c2f5dd89a3755ddcbfe275.jpg", "size": [50, 50]}
sorl-thumbnail||image||1abc636867ca742118ea562e882add46	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6c/a0/6ca04f4a9884c2e06b626a4a2263a016.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||612ca1afbc911d9cef3eab3b6e2ae879	["1abc636867ca742118ea562e882add46", "8a59af3ff00e1e21bcb9141029fb2771"]
sorl-thumbnail||image||c6580d3b2abb97b8851c71fc4e014140	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/14/e7/14e78a8d3e42427211147726c06db1a2.jpg", "size": [50, 50]}
sorl-thumbnail||image||a51573ef5bd964caa5ba6e42a836919c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/56/0c/560c3bbbe1f0d90d33894a9a75e606a9.jpg", "size": [107, 80]}
sorl-thumbnail||image||c05a62520bf72f9f5fc0bbf9cb13345f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c3/fc/c3fcbfed665ddfe47656781a5b59a801.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||8d670db63c2404642607168c8e89dfc3	["c05a62520bf72f9f5fc0bbf9cb13345f", "c6580d3b2abb97b8851c71fc4e014140"]
sorl-thumbnail||image||88baa5096f4b378f564f45722bc185ca	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/84/a4/84a4c78ddbaea2b121df43a8754aeccf.jpg", "size": [200, 200]}
sorl-thumbnail||image||e7ce6a2a6804a917eb8003899fbed502	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/wTOfFD.jpg", "size": [200, 134]}
sorl-thumbnail||image||805ca441bdc0fab6188f41a1f49d6f73	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/4b/d3/4bd3239f5c2de600a39276b92a03f46e.jpg", "size": [50, 50]}
sorl-thumbnail||image||8f18e044b2f17dc15e5e491a24e97bf8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/8e/14/8e1458982a554c68c9fd2a7e010cd56c.jpg", "size": [130, 130]}
sorl-thumbnail||image||93e39c3acc193a7eeb8a1ce700c3a557	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/00/e8/00e84bb78a4357e5bc2d3f4feb1d1e37.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||e7ce6a2a6804a917eb8003899fbed502	["805ca441bdc0fab6188f41a1f49d6f73", "93e39c3acc193a7eeb8a1ce700c3a557"]
sorl-thumbnail||image||c8984f4075d07178a59347152e16ad5b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/MGgR2p.jpg", "size": [180, 179]}
sorl-thumbnail||image||b2d14f863b02910a712ffdec8bbf4f4b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/de/25/de255520c5c419315f07743c1c52b5eb.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||bae21be3bd4d3e3b65a299a5f15d15b1	["8f18e044b2f17dc15e5e491a24e97bf8", "574a79cbeb4be1d68ae94d77f987e1c5"]
sorl-thumbnail||image||2d7e5339656e41768dfde9282abb1ad3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d9/e0/d9e06bfea0f7f7da08afdba3938d8bc1.jpg", "size": [130, 130]}
sorl-thumbnail||image||54870ba1535f9561876648c5e1a13993	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/guWAk9.gif", "size": [198, 126]}
sorl-thumbnail||image||fb34d44b19d7dba51a020dd35e0dcc8a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/62/d6/62d6f596696671070144fb38ff81b832.jpg", "size": [50, 50]}
sorl-thumbnail||image||361ad6b089615f0b34193a373e8528d0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/72/0f/720f3e7beef9779719c83e9fd40adf2c.jpg", "size": [130, 130]}
sorl-thumbnail||image||4da8c6f67dac398df08c82d307202a9f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/WYtFjI.jpg", "size": [180, 180]}
sorl-thumbnail||image||b10b93ae4b2b00342e9801efa1c6aa17	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/25/07/2507c056832a15a058fed628c97d4639.jpg", "size": [50, 50]}
sorl-thumbnail||image||435f0c5f25e25b1405d31e69cfed6c96	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/OrientExpress.jpg", "size": [2337, 1693]}
sorl-thumbnail||image||71f3a2425be4a882155ba331269858fe	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d6/25/d625f5c78f08a98e9faaee8da05ab7f0.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||4da8c6f67dac398df08c82d307202a9f	["71f3a2425be4a882155ba331269858fe", "b10b93ae4b2b00342e9801efa1c6aa17"]
sorl-thumbnail||image||935850d633b8f1d8eedcb10c0ddef84c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/qhHBQy.jpg", "size": [200, 146]}
sorl-thumbnail||image||5035b5762b512eb412970f23c421c897	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f6/79/f679c3d3ebb16e5a7c052ff2e0d4fb5a.jpg", "size": [50, 50]}
sorl-thumbnail||image||007d4f81792daa9bce5f6c19c07ae811	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b5/0f/b50f1def9829ab243a5da779934b816c.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||75743dbd33a93ee83abe39a5ef0ebcd6	["4bb491f0449fadf3d4cf061a18278013", "06bd17ec17dc95459057455d7c07bc0d", "8a75c679c5856702deb702a2a1ee099f"]
sorl-thumbnail||image||bae21be3bd4d3e3b65a299a5f15d15b1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/PLKtvA.png", "size": [216, 180]}
sorl-thumbnail||image||574a79cbeb4be1d68ae94d77f987e1c5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b9/20/b92001d03529f16dc21ae630c82f3541.jpg", "size": [50, 50]}
sorl-thumbnail||image||4bb491f0449fadf3d4cf061a18278013	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/24/de/24de62a5fc1973b220667d8cfa6a0fc2.jpg", "size": [50, 50]}
sorl-thumbnail||image||7518e3a897d73a339145b20c15fc0d10	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/77/97/7797c12f4e6230e05080d738f3e3e391.jpg", "size": [50, 50]}
sorl-thumbnail||image||d3703c950e5db46aaca65fd24f7b5d8a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/38/72/3872f01eb103d28e120e3510f3e6237c.jpg", "size": [130, 130]}
sorl-thumbnail||image||0488321d7de3ee0809a0f5ce4f43513f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/KZzm1T.jpg", "size": [200, 137]}
sorl-thumbnail||image||eedde295a4d05559512c007723af3f9b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f1/c9/f1c96deb9db2133b4df6f6f7716adc66.jpg", "size": [50, 50]}
sorl-thumbnail||image||8c2a5842713ffdbc5e448137284b691a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/35/ca/35ca312204325e06f0650f07e7dc48e7.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||0488321d7de3ee0809a0f5ce4f43513f	["eedde295a4d05559512c007723af3f9b", "8c2a5842713ffdbc5e448137284b691a"]
sorl-thumbnail||image||75743dbd33a93ee83abe39a5ef0ebcd6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/5umaS3.jpg", "size": [180, 180]}
sorl-thumbnail||image||6711dad01129e990e3a19342da071577	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/fz6nhz.jpg", "size": [200, 150]}
sorl-thumbnail||image||8a75c679c5856702deb702a2a1ee099f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e9/af/e9afacb120185fe513b524a17ac0e184.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||54870ba1535f9561876648c5e1a13993	["fb34d44b19d7dba51a020dd35e0dcc8a", "361ad6b089615f0b34193a373e8528d0", "e8c93f528fc666cfff7669c37b34e7d1"]
sorl-thumbnail||thumbnails||7dfaa27629db1cd8da925d6c90a32264	["6041a9381fb6f02609c34ef26c96a32a", "dce97a3a83d51dcc190fcc08c0b0f41e"]
sorl-thumbnail||image||f89cfe5ccbdc91cd0b13e3045039f5bc	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/de/8a/de8acb37fea81fef9400cc7983f15074.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||c8984f4075d07178a59347152e16ad5b	["b2d14f863b02910a712ffdec8bbf4f4b", "2d7e5339656e41768dfde9282abb1ad3", "65c93ba85a1592a32792ee8a77e2a9cf"]
sorl-thumbnail||image||0a622a61ece9526c3669211db667043d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Jyi0S5.jpg", "size": [180, 38]}
sorl-thumbnail||image||b8779f4bcb86421d8ddb88572059f433	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ac/22/ac223e09450736431d458ed4d10d383e.jpg", "size": [130, 130]}
sorl-thumbnail||image||82e821b3797b8e8dcde53407733c8b66	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/YuvaIndia.jpg", "size": [1461, 1513]}
sorl-thumbnail||image||c622fd2c11223583a67eae31491673ac	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/2b/45/2b454c7585fd2a6454142780b6ca6b3f.jpg", "size": [50, 50]}
sorl-thumbnail||image||7b051195e020e6c5ae2075494827e531	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c5/d4/c5d415082ebacf017b9f8cd402910a69.jpg", "size": [130, 130]}
sorl-thumbnail||image||b222fd008f9505a24552f0331fc43c59	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/CultureShop.jpg", "size": [3264, 1840]}
sorl-thumbnail||image||9751ed6244c0408ebcec80090f8d4fe7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e4/f5/e4f5216c9c93d82f6e5089fb007889fc.jpg", "size": [50, 50]}
sorl-thumbnail||image||96f2ffed6cf43c22b31f72d346c67b68	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/32/03/3203ed3efbd7fc9c215a646109fb6931.jpg", "size": [50, 50]}
sorl-thumbnail||image||78440b157d8db1be68d393a323597374	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f5/72/f572b98e4d9b85f8b9f26b40c8d7132e.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||b222fd008f9505a24552f0331fc43c59	["9751ed6244c0408ebcec80090f8d4fe7", "78440b157d8db1be68d393a323597374"]
sorl-thumbnail||image||f50a8b0831bfb74b5ccaeac74decadec	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/9l3UzC.jpg", "size": [180, 266]}
sorl-thumbnail||image||af005d101fdb1394d4cfa66581cdaf1a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/56/a8/56a8776c93ca922328cf143e49680992.jpg", "size": [50, 50]}
sorl-thumbnail||image||3a1701322b3792b877f4e8d6f959462f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/22/86/2286dda5b806cbda8c33104fdf9f0db2.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||6711dad01129e990e3a19342da071577	["2617de6a1ce8e9a629c96a1400562475", "f89cfe5ccbdc91cd0b13e3045039f5bc", "b8779f4bcb86421d8ddb88572059f433"]
sorl-thumbnail||image||0838fa786d8696259b240adbf8b57978	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/rYOr_i.jpg", "size": [200, 150]}
sorl-thumbnail||image||31a5266263d6d9bd52e24683af0a93b0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1c/1d/1c1d5a3d3f840d6a9293e04393985f5f.jpg", "size": [50, 50]}
sorl-thumbnail||image||6f647859959a59342fe3e0aadce6cd66	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/92/2e/922e1229e0d3e504ad1aeff0a0b81f41.jpg", "size": [50, 50]}
sorl-thumbnail||image||19b9018c1540bc890855069de2972bfb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ec/d3/ecd37ef8d62db12b2db3b1e9f0d848ea.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||622a43311921cf17c3d7c79e1cd01bdc	["fc26f375abff5eb595e28168db4ead58", "941f6b91b58db0be24996db31edf590a", "5a466bf285ac555c1784b2b100218f7f"]
sorl-thumbnail||image||437a63b9647f0eeaf81c590fd1d7ed8c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/LittleAsia.jpg", "size": [1429, 1767]}
sorl-thumbnail||image||d09762b856d865a3498e0ba2d57a67fa	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/86/46/86469f126ab7a7f2939bdcb19c8271e1.jpg", "size": [50, 50]}
sorl-thumbnail||image||fbb60e305981c5a70f4ea788ad23854e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/dd/a8/dda857250dd2ae424d31d0b00446872f.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||437a63b9647f0eeaf81c590fd1d7ed8c	["d09762b856d865a3498e0ba2d57a67fa", "fbb60e305981c5a70f4ea788ad23854e"]
sorl-thumbnail||image||117cbdb9cbe971f83c975fab42c55722	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ad/84/ad84a8604f257ac0784aed158b0dc327.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||0838fa786d8696259b240adbf8b57978	["f51d7b0cb1c10dbfa6b4e8fd16293fbf", "31a5266263d6d9bd52e24683af0a93b0", "19b9018c1540bc890855069de2972bfb"]
sorl-thumbnail||image||622a43311921cf17c3d7c79e1cd01bdc	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/CUHIQC.jpg", "size": [190, 79]}
sorl-thumbnail||image||941f6b91b58db0be24996db31edf590a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b2/ba/b2bafa9993d6b0811cd47e7b02f96183.jpg", "size": [50, 50]}
sorl-thumbnail||image||5a466bf285ac555c1784b2b100218f7f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/22/b5/22b565861cac058b3e021aea73b3c278.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||97c9b15252d7f24ce3912b15b7c17b1f	["f78ceb4d71efed4a09f3c72b0b452ca1", "6f647859959a59342fe3e0aadce6cd66", "f1791b9be0ff3beb75aa8467e1678e8e"]
sorl-thumbnail||image||97c9b15252d7f24ce3912b15b7c17b1f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/yevP1Y.jpg", "size": [190, 79]}
sorl-thumbnail||image||63859ce5ec1345598c43a534946323f8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/ShirazKabob.jpg", "size": [2009, 1209]}
sorl-thumbnail||image||f78ceb4d71efed4a09f3c72b0b452ca1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3e/c9/3ec98e7e54a38b28961d300e009b42b3.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||f50a8b0831bfb74b5ccaeac74decadec	["3a1701322b3792b877f4e8d6f959462f", "04606fb23c02deca3d4f50d30f80bed3", "af005d101fdb1394d4cfa66581cdaf1a"]
sorl-thumbnail||image||e7e2fd7e374ff1cac3dc2664975800da	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/8c/72/8c72db4d2c8e60352689fa5e38b4b143.jpg", "size": [50, 50]}
sorl-thumbnail||image||60d29ba8e4c4070b5b9e18d4a3475c45	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/81/a7/81a7a8228398cbcb78960456607eb311.jpg", "size": [80, 80]}
sorl-thumbnail||thumbnails||60c175f594e7a1b3425af7d6e54b1148	["88baa5096f4b378f564f45722bc185ca", "58c263e005e7e3dc9bd6a95a14dd938e", "ba7a270d35a32fcb4e18f8ffdc158fed"]
sorl-thumbnail||image||2f7a291f513638fe900734985e70377a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/cb/d8/cbd8fc4090612702abca77c085e7b710.jpg", "size": [130, 130]}
sorl-thumbnail||image||2e25e5bd69883eaa3ad0e5ce7e55fa71	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/N5Ygy5.jpg", "size": [180, 131]}
sorl-thumbnail||image||6fab6309c39647261cf86b7b435a7d96	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/74/9a/749af5897ca35e2b5033bd9329475d45.jpg", "size": [50, 50]}
sorl-thumbnail||image||7eec417ee440f558f71aad552fb9bb4a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/0e/53/0e5352ce68df0f7d45ea35fe90555318.jpg", "size": [50, 50]}
sorl-thumbnail||image||507d0f8e601bf40a9e0826f86c528de5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/37/c0/37c002a6ba9768bccfa29052d65337dc.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||568d1303588af392594115e0831a30cd	["da6067d1f3501c40c36bf769f0e47d89", "1bf6209b762abbf1fab0d0b104ceb321", "babe98254fe87515c5f8e1bf9471310c"]
sorl-thumbnail||image||2ea7b355de2e594d9ab4f4213ed58995	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/6pU9Ay.jpg", "size": [180, 139]}
sorl-thumbnail||image||9dddc50cf3c8ea76a05c106c667bf9f5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/64/0e/640eaf2135080f8390cd5781b448456c.jpg", "size": [50, 50]}
sorl-thumbnail||image||a39cd66a07836d508f99a9d2567ec839	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6e/f4/6ef490c44955778d2d27681ed6975680.jpg", "size": [130, 130]}
sorl-thumbnail||image||b1d73d64236cb069be1f89e1ac789ff6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/88tUvL.jpg", "size": [180, 180]}
sorl-thumbnail||image||fa51447258c8f6cc1c818e3884eed480	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/df/a3/dfa3fd7f4d2c5c6a9b427eedb87cac18.jpg", "size": [50, 50]}
sorl-thumbnail||image||8b6bfef7aeed67e4409c3cc535646ed3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e4/57/e457b37eb3efaf0618f314080fed404b.jpg", "size": [130, 130]}
sorl-thumbnail||image||d428e4f1bc82df82b9a4331073e02fd7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/69/3e/693e63a509fa8d5fedc9eb714e187869.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||b1d73d64236cb069be1f89e1ac789ff6	["d428e4f1bc82df82b9a4331073e02fd7", "fa51447258c8f6cc1c818e3884eed480"]
sorl-thumbnail||image||87b50acfd221a2e9645a06245b409398	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/pndzDg.jpg", "size": [200, 152]}
sorl-thumbnail||image||297afa0bd2f768239b3248714d3d89b7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d7/56/d756267d944c8e51afe3f19c59fe884b.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||f542c90a69c56b414ba38d71e57dd8d4	["8b6bfef7aeed67e4409c3cc535646ed3", "28a73231d7c9872bfad614b6ab028572"]
sorl-thumbnail||image||49bf9a1537966afb28e8f328b17a33f5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/45/d7/45d7451e8c6c57b9c422dfd013e70037.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||87b50acfd221a2e9645a06245b409398	["297afa0bd2f768239b3248714d3d89b7", "49bf9a1537966afb28e8f328b17a33f5"]
sorl-thumbnail||image||568d1303588af392594115e0831a30cd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/BombayFoodMart.jpg", "size": [1673, 1449]}
sorl-thumbnail||image||babe98254fe87515c5f8e1bf9471310c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ad/80/ad80b2da71353f643cd859cc2cacb2d1.jpg", "size": [50, 50]}
sorl-thumbnail||image||1bf6209b762abbf1fab0d0b104ceb321	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a9/16/a916931f379f60d7c0dba8657f459a82.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||f7322d5525d90d28785b7c09153f62e8	["2337607ebaa22484e61548f151991d1b", "68ec101bc46533ece24770641c2f0e45", "7eec417ee440f558f71aad552fb9bb4a"]
sorl-thumbnail||image||f542c90a69c56b414ba38d71e57dd8d4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/SultanBey.jpg", "size": [2193, 1513]}
sorl-thumbnail||image||28a73231d7c9872bfad614b6ab028572	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6e/67/6e6756df783389366d7fbd2b4a126a7f.jpg", "size": [50, 50]}
sorl-thumbnail||image||6aa00fd975862640d7df757c953c9dfd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/LogansPub.jpg", "size": [669, 493]}
sorl-thumbnail||image||986e4b661324bd5564f149469bc2050a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/7c/8f/7c8f33c7b8ebc904ad732f7ce05f6da4.jpg", "size": [50, 50]}
sorl-thumbnail||image||a1fdb470d96650c2aa271b5356e30309	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d9/84/d9845c6c7bc855962b451e58f7bb00f8.jpg", "size": [130, 130]}
sorl-thumbnail||image||f7322d5525d90d28785b7c09153f62e8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/UniqueImpressionsHairSalon.jpg", "size": [2153, 1839]}
sorl-thumbnail||image||0665d93190fc0aec731c5a78469b02ac	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/vLV1W5.jpg", "size": [180, 123]}
sorl-thumbnail||image||68ec101bc46533ece24770641c2f0e45	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ab/55/ab55706f95c2c6fe484dac0a35969420.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||2ea7b355de2e594d9ab4f4213ed58995	["9dddc50cf3c8ea76a05c106c667bf9f5", "a39cd66a07836d508f99a9d2567ec839", "057009a3b6af532939be315cbd52fa54"]
sorl-thumbnail||image||250fce2507d940f0e6ae99b3be1bceb3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ee/e2/eee29395665d1216567727699301c59b.jpg", "size": [50, 50]}
sorl-thumbnail||image||00795722a333a3a4e1f10f1c41ac8c02	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/MULjyl.jpg", "size": [300, 300]}
sorl-thumbnail||image||788c9dd2a5bf8de8485b74e561e6fe11	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/54/b7/54b714c533285e5462a7d00498aa06a2.jpg", "size": [130, 130]}
sorl-thumbnail||image||185c3ccd5b092b755f9d694decb1b3f4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/fe/3b/fe3b67827f55c3531ee3e5d259a713bd.jpg", "size": [130, 130]}
sorl-thumbnail||image||7457cbd069172743ca93ff39defab09a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/RivieraJewelers.jpg", "size": [3264, 1840]}
sorl-thumbnail||image||e5323594e809b50c88c7f9b63a1b613f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/da/d9/dad9e9dbe83205632c1f9ea00905bf5e.jpg", "size": [50, 50]}
sorl-thumbnail||image||0981dc3fcaf74507979cda10c717df56	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/oUoP_N.jpg", "size": [180, 104]}
sorl-thumbnail||image||df3d2a4e6c370bac1c8b87912918b572	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1d/5e/1d5ee4ac7381258c14d695ef1520aa1d.jpg", "size": [130, 130]}
sorl-thumbnail||image||bbbbee635c320633490fe99dd77dad2d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/CMU_Logo.jpg", "size": [180, 179]}
sorl-thumbnail||image||1481c7a86ed94a0b20ee5d662cf761d2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/fFb0rU.jpg", "size": [200, 120]}
sorl-thumbnail||image||9addbbfb23dc9b5547478f6a6b540492	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/84/b6/84b6af466cc2921b75c102f790151608.jpg", "size": [50, 50]}
sorl-thumbnail||image||dea49d9fa0c4dcc9e6a530209b3ce917	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/24/0e/240e735532c62bc0907dd953a920fe24.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||8373289e84074148ec08f905e09775fd	["0d3e35b29189f82c512515228ed11122", "bd15fef6659ddc60bbdad144a09e2acc", "8a411412dc13c1bc342458107df1367f"]
sorl-thumbnail||image||bfb9ad6cdf969222f3c6470ae30c715a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Tamarind.jpg", "size": [2121, 1657]}
sorl-thumbnail||image||dfb2507740b76e2950559a256437b584	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/0a/57/0a57165d49011a342936bb9dab29ce6b.jpg", "size": [50, 50]}
sorl-thumbnail||image||f6299f8af15f51c2e7d46b9842ee8d05	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/89/76/8976183d6f0f8226fdfc8d4e97ebca58.jpg", "size": [130, 130]}
sorl-thumbnail||image||f48ff66cd175029080f620f3659f75c4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/42/a4/42a4510c30e7c555d493c4db3bb154ea.jpg", "size": [130, 130]}
sorl-thumbnail||image||ce72b3b0eb333beb890fdf0ddf76bb1a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Q0rXpI.jpg", "size": [200, 133]}
sorl-thumbnail||image||d99aea2eac7fcc72736d38f42f4817e5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/50/56/5056a34fa02978841695da63e594562f.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||1129910d13155b994998191583215455	["07977510a329de056e9efda4ad81e2b8", "f6299f8af15f51c2e7d46b9842ee8d05"]
sorl-thumbnail||image||3e204237a2470d70c4773736b7edb691	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/09/ec/09ecd69696240eeae269b211fb40ea8c.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||ce72b3b0eb333beb890fdf0ddf76bb1a	["d99aea2eac7fcc72736d38f42f4817e5", "3e204237a2470d70c4773736b7edb691"]
sorl-thumbnail||image||736449be53078b147d345a7ea96af9d4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/NUK8qs.jpg", "size": [200, 133]}
sorl-thumbnail||image||4e1dad6b4938f719b8dbe051ae8f68db	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/2e/c3/2ec3658df288b92659d41ad3d1e379aa.jpg", "size": [50, 50]}
sorl-thumbnail||image||1d95059e93e0038cbb2b57abce4218c8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/09/f7/09f7a8bcd04218a847140de159aad390.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||736449be53078b147d345a7ea96af9d4	["1d95059e93e0038cbb2b57abce4218c8", "4e1dad6b4938f719b8dbe051ae8f68db"]
sorl-thumbnail||image||1129910d13155b994998191583215455	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/jgSmLZ.jpg", "size": [180, 180]}
sorl-thumbnail||image||07977510a329de056e9efda4ad81e2b8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/54/a1/54a10080630703b975fe0d1c46d3e9c0.jpg", "size": [50, 50]}
sorl-thumbnail||image||2f78c455ab74c09a3860538d94adea1d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/GGzHbz.jpg", "size": [180, 180]}
sorl-thumbnail||image||bb27c3f46b35a399047d0601cbad620d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1b/aa/1baab0067696f8683ee0b03e1ba1b0bb.jpg", "size": [50, 50]}
sorl-thumbnail||image||ab5c3ff6ee6def068dbadc0e16421ac8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/58/26/5826e9cbe47e04c010c4bfc4977c4bf5.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||0665d93190fc0aec731c5a78469b02ac	["250fce2507d940f0e6ae99b3be1bceb3", "788c9dd2a5bf8de8485b74e561e6fe11", "9a1edcd737f6795a10a8b76baa537cd6"]
sorl-thumbnail||image||8373289e84074148ec08f905e09775fd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/JjWFBV.jpg", "size": [180, 270]}
sorl-thumbnail||image||0d3e35b29189f82c512515228ed11122	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/17/0e/170e7713f0d495e85e583e09f055aa6c.jpg", "size": [50, 50]}
sorl-thumbnail||image||bd15fef6659ddc60bbdad144a09e2acc	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/df/ff/dfff9b1f499bcee014437cad2c81f4ef.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||bfb9ad6cdf969222f3c6470ae30c715a	["f48ff66cd175029080f620f3659f75c4", "197e189b4c82c94fd09b79cbf983f6a1", "dfb2507740b76e2950559a256437b584"]
sorl-thumbnail||image||3027023d91b93dd0a58f2e6f3c3c1866	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/35/95/35957589d23f409a629a2989246df1ef.jpg", "size": [50, 50]}
sorl-thumbnail||image||670d165bb6ab217c82a04b3f2c9d0913	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/knit.jpg", "size": [340, 500]}
sorl-thumbnail||image||59ad2404846a358d3cf41eb0541b447d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d6/10/d6100fd0f72a51be1841eb2841dd94db.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||1481c7a86ed94a0b20ee5d662cf761d2	["dea49d9fa0c4dcc9e6a530209b3ce917", "1c979eae7b906a772d8d492e39142346", "9addbbfb23dc9b5547478f6a6b540492"]
sorl-thumbnail||thumbnails||7457cbd069172743ca93ff39defab09a	["6620019ec0f96c9a359dcaab61fb0ebf", "df3d2a4e6c370bac1c8b87912918b572", "e5323594e809b50c88c7f9b63a1b613f"]
sorl-thumbnail||image||7263f366bcc4642fb63a7d3f39d8c377	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f4/9c/f49ce6229acfc4cdff848508c97e671a.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||d6211518d7289e41898c9a77b0688be0	["26992f03e7add60e290a79370ca0eb79", "18cde2cb5f2d20bb5040a168fc43cd7e", "0851bb3b383bf43e5cf68a5a7c82be99"]
sorl-thumbnail||image||c3390abf9e9f42309f5710392d7339d2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d8/a3/d8a3861509a8ae4ec3467f91b928b9a2.jpg", "size": [130, 130]}
sorl-thumbnail||image||0b6712ae60d48fafee434104e99c9fba	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/wHQXO3.jpg", "size": [200, 191]}
sorl-thumbnail||image||b26240f26a001b2e27e723d660acf123	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ef/ab/efab4abc9a6d0de3748a02cf3acedbef.jpg", "size": [50, 50]}
sorl-thumbnail||image||cb7d8ebc8a7183e7be7ac5b06df7e075	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c1/ce/c1ced40ea135b780fbb415b2e44ee96b.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||0b6712ae60d48fafee434104e99c9fba	["cb7d8ebc8a7183e7be7ac5b06df7e075", "b26240f26a001b2e27e723d660acf123"]
sorl-thumbnail||image||7e00a99b21c979d75158246d55b86a76	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/HurleyAssociates.jpg", "size": [1689, 1513]}
sorl-thumbnail||image||11b19910e18a5f4c7ceabcf0c2b0df8c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f9/ba/f9baf026b435195c01823ffb5c40ca24.jpg", "size": [50, 50]}
sorl-thumbnail||image||a99c56a01037d8d0200987d5cf60aade	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/CornerStore.jpg", "size": [1465, 1101]}
sorl-thumbnail||image||98dc6a829230f6415e6ec49b2f7362fc	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/17/1f/171fddeb5a7c733d4ad0aef37642bbfc.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||f7cbba997a4a8b7327fe4032dac3045d	["2a92c58a5912cfb99459c15b3f43a3aa", "7f4ca7aadec454c9c17ed1b6fc46a44c", "ccafa13c34b236c9e9e677ad0df6d37e"]
sorl-thumbnail||image||d6211518d7289e41898c9a77b0688be0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/FirstNationalBank.jpg", "size": [769, 805]}
sorl-thumbnail||image||26992f03e7add60e290a79370ca0eb79	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/51/b3/51b3588b002edc3aeaa86d18d4c87a8b.jpg", "size": [50, 50]}
sorl-thumbnail||image||0851bb3b383bf43e5cf68a5a7c82be99	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/cf/bb/cfbbb69a1a8421f03985b2a2b67a22da.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||00795722a333a3a4e1f10f1c41ac8c02	["38d10da7c4c1bf56e4068cb4aeddf099", "7263f366bcc4642fb63a7d3f39d8c377", "c3390abf9e9f42309f5710392d7339d2"]
sorl-thumbnail||image||5b82c721100c09b7a1b871250d5e8889	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/_3rZ4S.jpg", "size": [180, 180]}
sorl-thumbnail||image||dcc259f810dd5eb6b28021a078fa532e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/08/a7/08a7c175bbab910d8666b430ff7b37f1.jpg", "size": [50, 50]}
sorl-thumbnail||image||ee99a68cf5cd642cb332e8f5f91adb27	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/2b/f9/2bf9218d1ec69a427114d0ef0cc5ae75.jpg", "size": [50, 50]}
sorl-thumbnail||image||323fb4fa732bad4517611d7038d666b2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/7c/f1/7cf1d561f7aabdd58c7740f1128b4df9.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||5b82c721100c09b7a1b871250d5e8889	["dcc259f810dd5eb6b28021a078fa532e", "323fb4fa732bad4517611d7038d666b2"]
sorl-thumbnail||image||f7cbba997a4a8b7327fe4032dac3045d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/iwqBxN.jpg", "size": [200, 150]}
sorl-thumbnail||image||2a92c58a5912cfb99459c15b3f43a3aa	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e6/f0/e6f0e5b6a1ff93d23a199003a325d45b.jpg", "size": [50, 50]}
sorl-thumbnail||image||17ddba9d0e4f2bd8c4714cb92042734c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f7/46/f746b43e4ea536137f3994a1c30955e0.jpg", "size": [130, 130]}
sorl-thumbnail||image||7f4ca7aadec454c9c17ed1b6fc46a44c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/4a/f4/4af43288e3e8553a8eb4dddafbbff589.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||9eebc58fdf5e6c74f38187c13fcf72b4	["deb2c8502012297376162fe013f4f372", "17ddba9d0e4f2bd8c4714cb92042734c"]
sorl-thumbnail||image||9085c288098b05d9f9450cf429d342c1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/98/85/988523a4207435863eaa5c2700dcd6d5.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||a99c56a01037d8d0200987d5cf60aade	["9085c288098b05d9f9450cf429d342c1", "ee99a68cf5cd642cb332e8f5f91adb27"]
sorl-thumbnail||image||9eebc58fdf5e6c74f38187c13fcf72b4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/DanasDunkinDuds.jpg", "size": [3264, 1840]}
sorl-thumbnail||image||deb2c8502012297376162fe013f4f372	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/0b/37/0b37e0208d812206a50381190f030211.jpg", "size": [50, 50]}
sorl-thumbnail||image||583fd08911cf5842c639e1bac1396c1b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d2/ac/d2ac9bd664bfd9710dc16f9c4848c73f.jpg", "size": [50, 50]}
sorl-thumbnail||image||07bd57b87b4b568af3ecd128fc4193e5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/OaklandMiniMarket.jpg", "size": [3264, 1840]}
sorl-thumbnail||image||fb492a3d553b11f522be6899b75adf26	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/LasPalmas.jpg", "size": [1840, 3264]}
sorl-thumbnail||image||72b97931d7ad4e81800326afd1d0012a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/9c/5d/9c5d8003aeef9ee839fdd438da246a37.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||07bd57b87b4b568af3ecd128fc4193e5	["72b97931d7ad4e81800326afd1d0012a", "583fd08911cf5842c639e1bac1396c1b"]
sorl-thumbnail||image||7abaaded6ecb376b8e5d43e286272c8a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e0/b9/e0b9f8b552a308d8883deca95bb2717b.jpg", "size": [50, 50]}
sorl-thumbnail||image||5fad5a5fda488ec8b4db9c115bb26acb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/cf/30/cf30fd51608ff326559b1507ef5f33b8.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||fb492a3d553b11f522be6899b75adf26	["185c3ccd5b092b755f9d694decb1b3f4", "7abaaded6ecb376b8e5d43e286272c8a"]
sorl-thumbnail||image||bd5b0c27a24f569778c86bce9873724d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/ItsDogginIt.jpg", "size": [3264, 1840]}
sorl-thumbnail||image||97602da5ea3ac84622b0e2baa116a2ea	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/72/3f/723fa9da1671d47617d6b3c1f83a1d5b.jpg", "size": [50, 50]}
sorl-thumbnail||image||9545160b4b53ac33433de9e6542d20c6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/SzjZ10.gif", "size": [198, 126]}
sorl-thumbnail||image||181b5328fa7039c36ee6e782736019cf	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/10/ee/10ee691610730cc80106103af53f2545.jpg", "size": [50, 50]}
sorl-thumbnail||image||b8edff44b29f44e78c15979b3a8236ff	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/8c/64/8c6420b6a9374ca543f4c46d983396ed.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||0a4551cf2529fc3d127c55e51759a6e3	["181b5328fa7039c36ee6e782736019cf", "239bc4a2f705bfa1d07476df56b5a413", "96abfda1cd835850723be9cf3f252226"]
sorl-thumbnail||image||2e8c14d111409fa5ae2b4cab6c3d55bf	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/fZVryU.jpg", "size": [200, 134]}
sorl-thumbnail||image||cfd739ce9a56a39789d1a2ff1964f8e0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c0/5e/c05ea1a237873e1e62be508a4d7cf28e.jpg", "size": [50, 50]}
sorl-thumbnail||image||367fbc2586df6292c0061c35e38b143f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/34/ba/34ba576f693f2fa918c89fd2064f7f74.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||2e8c14d111409fa5ae2b4cab6c3d55bf	["367fbc2586df6292c0061c35e38b143f", "cfd739ce9a56a39789d1a2ff1964f8e0"]
sorl-thumbnail||image||93cd15e15aa8df1d055acfb9d3068020	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/oI0u4N.jpg", "size": [180, 121]}
sorl-thumbnail||image||7a22ef6d58eaa6e7c56dfbf81f73c119	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6a/b8/6ab8867c2e1d7b32fae0a3e3c4d1147b.jpg", "size": [50, 50]}
sorl-thumbnail||image||fda07219c2fc29516dff75b6365ad88e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6d/8e/6d8e4c3e142d49217d7fff60a430e59e.jpg", "size": [130, 130]}
sorl-thumbnail||image||f0d060d16d0193cc1b528fcc3d4613eb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/90/ec/90ec2b9da38dc20f9e7afd298dba11e8.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||a6400738c2e5073a95f6b8216e680a15	["a181272126b3f34821f470825439dba1", "512bbe8c4a75e32b531e30e7b3a44691", "e352cde4096e91e45af4d551b0edc3e9", "a51573ef5bd964caa5ba6e42a836919c"]
sorl-thumbnail||image||323787f75eb842386189b70ea0bbaf73	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/znZT0n.jpg", "size": [180, 180]}
sorl-thumbnail||image||0ec92fcd1531972c71972e8a65b5b5b3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/bf/92/bf92e0eb59b6c0f2ebd960f400f9da6c.jpg", "size": [50, 50]}
sorl-thumbnail||image||bc1c301cf5602413c268ad57664a5de4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/07/f6/07f633680ee28fe634fcf2ce6ca16198.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||bd5b0c27a24f569778c86bce9873724d	["b8edff44b29f44e78c15979b3a8236ff", "71a60c811d07cb7fecfbcb95f9529e4a", "97602da5ea3ac84622b0e2baa116a2ea"]
sorl-thumbnail||image||edf2f2e81695030cc4e29c2b5a513d44	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/ZJ2Z2B.jpg", "size": [650, 488]}
sorl-thumbnail||image||31e6aba35602ff6a6460cab390185505	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/04/c3/04c3671f8f1348273a452a87e721536c.jpg", "size": [50, 50]}
sorl-thumbnail||image||59e307aa9a4e3388ea2c0b1b28303c85	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/bc/fd/bcfd1a573a14fd704f3f917ce65ab860.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||edf2f2e81695030cc4e29c2b5a513d44	["31e6aba35602ff6a6460cab390185505", "59e307aa9a4e3388ea2c0b1b28303c85"]
sorl-thumbnail||image||8eacd37cf3d7763f24fc28666373d778	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/M34h5G.jpg", "size": [385, 385]}
sorl-thumbnail||image||1d49780a490c7de1e603705e52279422	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/bd/76/bd76cfb89be34f8e1bde56b8a83abb7a.jpg", "size": [50, 50]}
sorl-thumbnail||image||a6400738c2e5073a95f6b8216e680a15	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/n4pM7E.jpg", "size": [200, 150]}
sorl-thumbnail||image||a181272126b3f34821f470825439dba1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a6/2e/a62e09a92a1166b71efe320061ba8b25.jpg", "size": [50, 50]}
sorl-thumbnail||image||512bbe8c4a75e32b531e30e7b3a44691	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ec/49/ec49da4a7ac5de89c1a17e21e321f443.jpg", "size": [130, 130]}
sorl-thumbnail||image||0a4551cf2529fc3d127c55e51759a6e3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/GarageDoorSaloon.jpg", "size": [1840, 3264]}
sorl-thumbnail||image||879eacdc876876ace28da05d51dddd2d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/8GNn7y.gif", "size": [198, 126]}
sorl-thumbnail||image||239bc4a2f705bfa1d07476df56b5a413	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e3/53/e35395daefadc52e780d2a3290661cef.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||879eacdc876876ace28da05d51dddd2d	["63cf1e6af289e6e2c50fec2e30b4705b", "787b2635a2c1f8c34abaaf5eab853f03", "c9c839b95f86cd9800ea7af3a60dc1ee"]
sorl-thumbnail||image||63cf1e6af289e6e2c50fec2e30b4705b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b1/57/b157f02c3a032f8535a40848497f4339.jpg", "size": [50, 50]}
sorl-thumbnail||image||787b2635a2c1f8c34abaaf5eab853f03	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/bc/c3/bcc3f5347b4dc1eb695063693bfbe142.jpg", "size": [130, 130]}
sorl-thumbnail||image||e3965f83e9cd968adaa774c5615be21d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/94/4a/944a4abffdaf6c37488f24659d0fee79.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||323787f75eb842386189b70ea0bbaf73	["bc1c301cf5602413c268ad57664a5de4", "fe0e9d49366862d1f827b539848a2e71", "0ec92fcd1531972c71972e8a65b5b5b3"]
sorl-thumbnail||image||329b9e658957365d8598faf709fe41fa	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/cjRkbU.gif", "size": [198, 126]}
sorl-thumbnail||image||3f1bc37e5818597ddb5843f91aa0d3e5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d5/b9/d5b97a87f804f754420decc721857802.jpg", "size": [50, 50]}
sorl-thumbnail||image||6041a9381fb6f02609c34ef26c96a32a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/80/04/8004caac4793f6446d957de4882285ba.jpg", "size": [130, 130]}
sorl-thumbnail||image||fd16f495e2cfc23f62183afde4bac77f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d6/c9/d6c9a932dd66647bd73bafd4c82c586c.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||9545160b4b53ac33433de9e6542d20c6	["5ccd2460c358e9f29a701c7ab9111cd0", "d108446526985cd7a431990ac0dba6f5", "b050e1efc169be7365cf44d03280ae90"]
sorl-thumbnail||image||d108446526985cd7a431990ac0dba6f5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/56/c3/56c3d3a6893b4e540ee8ca222a9e930c.jpg", "size": [50, 50]}
sorl-thumbnail||image||5ccd2460c358e9f29a701c7ab9111cd0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d7/52/d752d9e3485e764811150d2349a9f465.jpg", "size": [130, 130]}
sorl-thumbnail||image||c3cbc6e5053f08c35ac9e3a3dfdbdc68	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/QCue1R.jpg", "size": [180, 39]}
sorl-thumbnail||image||4d706357ba4d39d2f2ab4b78274716c8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/9e/bf/9ebfcc98adcde0bca4a0b01d7478ad51.jpg", "size": [50, 50]}
sorl-thumbnail||image||e88fe632b1c04d4a45f9b09ba37a6cda	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/fd/fa/fdfae9db5fa3e4fbabbc648b960e76ad.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||c3cbc6e5053f08c35ac9e3a3dfdbdc68	["e88fe632b1c04d4a45f9b09ba37a6cda", "4d706357ba4d39d2f2ab4b78274716c8"]
sorl-thumbnail||image||69639113852293c1aebad5fa0ddb5657	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/G4W7aH.jpg", "size": [180, 270]}
sorl-thumbnail||image||4bd11b128392aefba404536e78d7e95d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d5/d5/d5d59c02090f837c0b678b178acf18dc.jpg", "size": [50, 50]}
sorl-thumbnail||image||7f80ca98586b3dda073a83e420aab37d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/yjY6bm.jpg", "size": [180, 188]}
sorl-thumbnail||image||22bf8bcc8263d8fed713f3d3f138d9ae	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1f/f3/1ff32a5edaee178a4f2807645963e55c.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||69639113852293c1aebad5fa0ddb5657	["4bd11b128392aefba404536e78d7e95d", "22bf8bcc8263d8fed713f3d3f138d9ae"]
sorl-thumbnail||image||e434b5715cfee47a615a312ede0d6346	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/HxiL7P.jpg", "size": [180, 270]}
sorl-thumbnail||image||24ae24f7bb70fcd8be0dfeaa81146ba1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c1/e7/c1e7efb086345eca1102bb4d7f287d09.jpg", "size": [50, 50]}
sorl-thumbnail||image||57f49221bc051d3260e3c14927b41765	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/16/26/1626ef85860fbb1e6ad3f82bfc616574.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||329b9e658957365d8598faf709fe41fa	["fd16f495e2cfc23f62183afde4bac77f", "3f1bc37e5818597ddb5843f91aa0d3e5", "e713ca9983229ce066f2527b3e64d514"]
sorl-thumbnail||image||7dfaa27629db1cd8da925d6c90a32264	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/ZEpE1J.jpg", "size": [180, 540]}
sorl-thumbnail||image||dce97a3a83d51dcc190fcc08c0b0f41e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/32/1f/321ffc69011b705ec0c075f791bcf7dd.jpg", "size": [50, 50]}
sorl-thumbnail||image||a018b433f20fb152ec1488c09c517b9f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3f/c8/3fc80c4a716fc7554d936c55aad40e1b.jpg", "size": [50, 50]}
sorl-thumbnail||image||9470a9fe1e8f8247937ca2969f22f18d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/26/01/26019db6d089d566447af540d9a90164.jpg", "size": [50, 50]}
sorl-thumbnail||image||83544e4ec65a8a1ef0a8659425a7dfeb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/4b/2f/4b2fb59e123ebdde85165a5ec686c392.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||7f80ca98586b3dda073a83e420aab37d	["83544e4ec65a8a1ef0a8659425a7dfeb", "9470a9fe1e8f8247937ca2969f22f18d"]
sorl-thumbnail||image||da8104651099ec8efaba790e4c24db84	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/dp6CsD.jpg", "size": [180, 244]}
sorl-thumbnail||image||fc76f3561b126d871a17c9b94210146a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/94/41/94413bb5b2a30cdcdb81f3f01e5c79d3.jpg", "size": [50, 50]}
sorl-thumbnail||image||b4af5f847e8ef83a448b4db9d7924b0f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/09/be/09be91a7abe80f1de422fccb0e7cc6d5.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||da8104651099ec8efaba790e4c24db84	["b4af5f847e8ef83a448b4db9d7924b0f", "fc76f3561b126d871a17c9b94210146a"]
sorl-thumbnail||image||68acc4ecaaf5f3d316284fd9cefd4059	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/diyDHk.jpg", "size": [160, 160]}
sorl-thumbnail||image||57071e6ce4def879de515075588e95d1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/di__I2.jpg", "size": [120, 120]}
sorl-thumbnail||image||96e80b2f650e77ae8589110b3ce7d1c1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/04/94/0494332d03fba8b95a6f2aefdb66b091.jpg", "size": [130, 130]}
sorl-thumbnail||image||6f37f10ddfbec93ffabfa7b7808ab295	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e0/5c/e05cbb8dddf309580a72d90bb8a3e9a2.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||68acc4ecaaf5f3d316284fd9cefd4059	["5e9e6dd29acfee8a9a1ebd443c7becd9", "96e80b2f650e77ae8589110b3ce7d1c1", "a018b433f20fb152ec1488c09c517b9f"]
sorl-thumbnail||image||1c23d6140096b99857ba637527e18cc4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/m92HLs.jpg", "size": [180, 121]}
sorl-thumbnail||image||adbce61abf56ca51a9580d76bdeffe73	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3a/5f/3a5f877ad3eea04ae2930891c9f1719d.jpg", "size": [130, 130]}
sorl-thumbnail||image||3742cf101b99d38b6d2e258b7fc175ad	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/KaT3TN.jpg", "size": [180, 135]}
sorl-thumbnail||image||e26670bacb063cb7d7b007df952663db	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/5f/39/5f39be057e785abc75cda6b59f1c40cd.jpg", "size": [50, 50]}
sorl-thumbnail||image||431fb30c8f915fcfde11c8c616cbdbdd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/49/ae/49ae78a361bc9fe28ee9dd69ab00b89a.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||57071e6ce4def879de515075588e95d1	["6f37f10ddfbec93ffabfa7b7808ab295", "adbce61abf56ca51a9580d76bdeffe73", "da24fb533de854ffaa492d4d1e39af49"]
sorl-thumbnail||image||eaea3118136cad4d302ce6b6b1892452	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/p6fUWj.jpg", "size": [180, 141]}
sorl-thumbnail||image||4838e26e874b77c29a23305995d6514b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e2/a2/e2a2260b1ef8453a749b43b96eed8fad.jpg", "size": [50, 50]}
sorl-thumbnail||image||9e1afba2ed0a9dcc06f7748d901b948d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/4c/0a/4c0a5dfecb05794a7a0fc60d6729ea9d.jpg", "size": [50, 50]}
sorl-thumbnail||image||f6c16ed43fb811330014765edf695972	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/17/71/17718910eaab089a9eee589d860a9018.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||eaea3118136cad4d302ce6b6b1892452	["4838e26e874b77c29a23305995d6514b", "f6c16ed43fb811330014765edf695972"]
sorl-thumbnail||image||48b7253f03666fc2baac4df991733fcd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/qmCBkZ.jpg", "size": [180, 99]}
sorl-thumbnail||image||de045966a76201dc53011655ac1f8815	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d6/47/d647a7ab7d3e45b87842814a476359dd.jpg", "size": [50, 50]}
sorl-thumbnail||image||69f96849e6c2eca99195b8c27f2abe8f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/fe/da/fedad51eb8dc79bc657098f4c69535ec.jpg", "size": [130, 130]}
sorl-thumbnail||image||0f8275268c02695fcaf2e70f9e834985	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/dkOVh1.jpg", "size": [180, 131]}
sorl-thumbnail||image||30b2e3e7ffdc53b114b836eef9f634e3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/bf/88/bf88d3829c752aacefd0034fbb3e26b5.jpg", "size": [50, 50]}
sorl-thumbnail||image||df170b6fd3c5fa73473c885f27de17fb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d9/97/d9971b22e720b740b79ca2f617b90011.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||47a39c7caf4e3bb5e6b0a100d5cf5788	["0d50b51bea3b7b8ae3c2349e2b8c349a", "180b5a671b4a4a03f25ac6caedd6e560", "485643212bd55f477fd94f4990c92a19"]
sorl-thumbnail||image||49ecd3aefefe93062513ab41065a5360	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/xz0foo.jpg", "size": [180, 161]}
sorl-thumbnail||image||47e447270a5b9a451220834884890579	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c8/8a/c88a8f0325c1c9a09130d448ab6dad92.jpg", "size": [50, 50]}
sorl-thumbnail||image||9a8786cbd6dcab9b616c17d68546d2b3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/35/6b/356bc539d48179fa6a54e09fb4944c95.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||49ecd3aefefe93062513ab41065a5360	["9a8786cbd6dcab9b616c17d68546d2b3", "47e447270a5b9a451220834884890579"]
sorl-thumbnail||image||d33c1817d238409ff32d9f00712d9a50	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/25/89/2589f8bd469c2bf8b3e335af52330f29.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||1c23d6140096b99857ba637527e18cc4	["9e1afba2ed0a9dcc06f7748d901b948d", "d33c1817d238409ff32d9f00712d9a50"]
sorl-thumbnail||image||47a39c7caf4e3bb5e6b0a100d5cf5788	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/y7Y8hP.jpg", "size": [180, 96]}
sorl-thumbnail||image||0d50b51bea3b7b8ae3c2349e2b8c349a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/59/5e/595e2905e30e081b36b8aaec3f6d9302.jpg", "size": [50, 50]}
sorl-thumbnail||image||5b2460d71f3d09147783eca5e91decb8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/0IALur.jpg", "size": [180, 214]}
sorl-thumbnail||image||485643212bd55f477fd94f4990c92a19	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/61/26/6126f7836813b5731dae3c146dbe3e58.jpg", "size": [130, 130]}
sorl-thumbnail||image||47ad5cc61331b7db9665ddc3185b81ff	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/drZqAz.jpg", "size": [180, 254]}
sorl-thumbnail||image||5b77ed45416b545ea25d650f892ea798	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/18/64/1864d115a135990bcc9bde71166f6b21.jpg", "size": [50, 50]}
sorl-thumbnail||image||86d86cbbd147f4321563d69c0f331cb8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/db/b2/dbb25d000c6b38e3ad3f7621a298fd83.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||47ad5cc61331b7db9665ddc3185b81ff	["5b77ed45416b545ea25d650f892ea798", "86d86cbbd147f4321563d69c0f331cb8"]
sorl-thumbnail||image||383dff0facbc9e0ac5dc60b990bee691	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/79/74/7974af91ec32cb723facd758708fc664.jpg", "size": [50, 50]}
sorl-thumbnail||image||fe0e9d49366862d1f827b539848a2e71	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ee/72/ee7237203145706e0406f77af061464e.jpg", "size": [80, 80]}
sorl-thumbnail||thumbnails||5b2460d71f3d09147783eca5e91decb8	["a3c0d2a041dc1558acbcede21d610ae6", "383dff0facbc9e0ac5dc60b990bee691"]
sorl-thumbnail||thumbnails||0f8275268c02695fcaf2e70f9e834985	["8b553c32174c322032de12afad8235fc", "df170b6fd3c5fa73473c885f27de17fb", "30b2e3e7ffdc53b114b836eef9f634e3"]
sorl-thumbnail||image||558e012fe2875fbc3998103cc8905967	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/CMU_Logo.jpg", "size": [180, 179]}
sorl-thumbnail||image||a3c0d2a041dc1558acbcede21d610ae6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b6/b3/b6b37892ed5af36910e3567e38d4de72.jpg", "size": [130, 130]}
sorl-thumbnail||image||c28d3b0d0f207a096efeed9f66406353	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/glnlRE.jpg", "size": [180, 83]}
sorl-thumbnail||image||db17dd0228a20744b500dcdc4f7a0f2d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a8/3f/a83f638366a7ada4a99f9920a78379da.jpg", "size": [50, 50]}
sorl-thumbnail||image||880240a9eaeb71d2a41f811404818494	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/5d/8e/5d8ee8c2e9960dead0eed684760c193c.jpg", "size": [50, 50]}
sorl-thumbnail||image||651b49c0c00ce53cb68a3cd190f8f9e2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/5e/dd/5edda068cd8ecc85a1d03806bab85e8e.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||c28d3b0d0f207a096efeed9f66406353	["651b49c0c00ce53cb68a3cd190f8f9e2", "db17dd0228a20744b500dcdc4f7a0f2d"]
sorl-thumbnail||image||f50f899ee8f787a0e4c682a97ec0f327	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/ZGqqyH.jpg", "size": [180, 173]}
sorl-thumbnail||image||0dd90f0664512081c093d4ea8ba56f9a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ce/0f/ce0f87a921cdeae47eed1553187ab8ea.jpg", "size": [50, 50]}
sorl-thumbnail||image||a1b28f1f49fa05e361b4335b2a44e1f4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d4/0c/d40c75bbce00bd27e28b715f9b56102d.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||f50f899ee8f787a0e4c682a97ec0f327	["a1b28f1f49fa05e361b4335b2a44e1f4", "0dd90f0664512081c093d4ea8ba56f9a"]
sorl-thumbnail||image||e4451c01426f733d82ca65b9dcd729ae	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/At_qMf.jpg", "size": [179, 173]}
sorl-thumbnail||image||9f418fd3e8b8e78cb1fca4f309421241	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/26/07/260764f3c3aa9d48d4bd4274c2fd7034.jpg", "size": [50, 50]}
sorl-thumbnail||image||a31d6681d070d10c32ecbf4bb8aef317	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/4c/3c/4c3c9f6934b436416a2f5fbc4640f7a9.jpg", "size": [130, 130]}
sorl-thumbnail||image||0ab924c145fb54a5c70e45c427397ce0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a2/de/a2de81c1ac6dde4b5936b82bcffb26c4.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||e4451c01426f733d82ca65b9dcd729ae	["9f418fd3e8b8e78cb1fca4f309421241", "0ab924c145fb54a5c70e45c427397ce0"]
sorl-thumbnail||image||5b86824b7a7358e4fef09303875f031c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/wFLXl0.jpg", "size": [179, 234]}
sorl-thumbnail||image||df3c63256f362645130d53abda27778e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/cd/4b/cd4b809185ad8cf28fdf91f0331e3976.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||29fbd36eff0d70228f1000961ec6b980	["c95ca2075749e704a92ebe409f685a1b", "a31d6681d070d10c32ecbf4bb8aef317"]
sorl-thumbnail||image||4147a83477311d2607e61056c5855bb4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e0/30/e030cbf303da540be4bdafb3e8329ecf.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||5b86824b7a7358e4fef09303875f031c	["df3c63256f362645130d53abda27778e", "4147a83477311d2607e61056c5855bb4"]
sorl-thumbnail||image||536c2880aa87d1e00623e3eaba78841d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/OymKIZ.jpg", "size": [180, 119]}
sorl-thumbnail||image||0c9440e1bb9d3d4e5a78e7e52757f616	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/43/eb/43ebdf16a79fed953ba14c783138d55d.jpg", "size": [50, 50]}
sorl-thumbnail||image||1014adc7a4ee21b29d0ac7d7412dc22e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/46/4a/464a86d05660dd7d8d67df75199e95a7.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||536c2880aa87d1e00623e3eaba78841d	["0c9440e1bb9d3d4e5a78e7e52757f616", "1014adc7a4ee21b29d0ac7d7412dc22e"]
sorl-thumbnail||image||29fbd36eff0d70228f1000961ec6b980	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/vO68yL.jpg", "size": [180, 152]}
sorl-thumbnail||image||c95ca2075749e704a92ebe409f685a1b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/82/25/8225691a39c7ff4829ed1cb2fe94aee3.jpg", "size": [50, 50]}
sorl-thumbnail||image||bb4a317a6c13871c65ab3fc15e9b257f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/wf9yLx.jpg", "size": [180, 119]}
sorl-thumbnail||image||eb75a7dd59fdae85abb2c4ee8458934b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e9/2c/e92c0d88a8506d7bd933b5192fa01b5f.jpg", "size": [50, 50]}
sorl-thumbnail||image||bcef2b5baa09101fad79a36ab8105206	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/52/5f/525f28ce584b88b218a28c73b04b4184.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||bb4a317a6c13871c65ab3fc15e9b257f	["eb75a7dd59fdae85abb2c4ee8458934b", "bcef2b5baa09101fad79a36ab8105206"]
sorl-thumbnail||image||4cf90d3026355b79530d9a3d2f1b1149	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/edOXua.gif", "size": [198, 126]}
sorl-thumbnail||image||94371a03742be05bbb30b3c187a31289	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/09/7e/097eb18f9898b5e36dfe454066ac151d.jpg", "size": [94, 80]}
sorl-thumbnail||image||2810269edcf6bf60116bdd77faba3022	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ff/26/ff2612df12d3f701cf47b2238dd9de5a.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||4cf90d3026355b79530d9a3d2f1b1149	["2810269edcf6bf60116bdd77faba3022", "880240a9eaeb71d2a41f811404818494"]
sorl-thumbnail||image||778ff7d71ee1a2ef055008b972666e1e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/ICLY4k.jpg", "size": [180, 123]}
sorl-thumbnail||image||cfa66d286141c2d92cc8fd4d08cdf00c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1d/ef/1defdaf7b7d6845e8347de57b3e3d454.jpg", "size": [50, 50]}
sorl-thumbnail||image||29f0517f6915300d5d837f28affa68c7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ae/15/ae153bd2a90e5eaca113a9697365d6bb.jpg", "size": [200, 200]}
sorl-thumbnail||image||a7fe8dc129719f763752d8a986cba472	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a1/6a/a16a8f7f34da05649a05f1205e173ad4.jpg", "size": [200, 200]}
sorl-thumbnail||image||76bdad7cd2cf7f802f1689110b793ba5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a4/28/a4287d630487a42132ad61e1fab307bd.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||778ff7d71ee1a2ef055008b972666e1e	["76bdad7cd2cf7f802f1689110b793ba5", "cfa66d286141c2d92cc8fd4d08cdf00c"]
sorl-thumbnail||image||767054205eda2edf4259d5529851245c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/VikfI7.jpg", "size": [180, 112]}
sorl-thumbnail||image||86e58e92bba68a0dda8071f68c44f474	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b0/27/b02779241b5c67eec1b16cd5990a262d.jpg", "size": [50, 50]}
sorl-thumbnail||image||3aff5e0a0ecda7565d718eebba7f91c4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a2/48/a248da219ebf67cd2118f9db3d04f231.jpg", "size": [130, 130]}
sorl-thumbnail||image||46526f779691da3e210568e1affaa6b8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/QACH7r.png", "size": [200, 126]}
sorl-thumbnail||image||9507cb5e9cae949d56fe5754be990ada	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/7c/b7/7cb72461cec9d7a4f3228c3a4f8c17b2.jpg", "size": [50, 50]}
sorl-thumbnail||image||cbc2afead02c0dcafbdd88a3bf5d6e2a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/Shamballa-bracelet.jpg", "size": [300, 287]}
sorl-thumbnail||image||50dcbddf5983e36b400fada5d092e92b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1c/55/1c55e4984f2a5923ca2841c3dccf1621.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||46526f779691da3e210568e1affaa6b8	["50dcbddf5983e36b400fada5d092e92b", "9507cb5e9cae949d56fe5754be990ada"]
sorl-thumbnail||image||4b6ccbb91b70b04896ff838f94e21205	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/32dRyd.jpg", "size": [180, 150]}
sorl-thumbnail||image||f78ff2097478e2aeee03cfaed337a111	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d3/9a/d39ae16127e8ced9bb215d10dbbf9e51.jpg", "size": [50, 50]}
sorl-thumbnail||image||76e776fafe3b010f85f0fadc41e9756a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/8e/35/8e355222e065aa3ec4f5662722c978f2.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||4b6ccbb91b70b04896ff838f94e21205	["f78ff2097478e2aeee03cfaed337a111", "76e776fafe3b010f85f0fadc41e9756a"]
sorl-thumbnail||image||5bfb2fe1c7644ca87ec322a3f1b3b09f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/2WpTpE.png", "size": [200, 150]}
sorl-thumbnail||image||130b88f5f984836496b8f304a17e7b4c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/88/5b/885b7bc4fdff9c415cb1d44baf31ad25.jpg", "size": [50, 50]}
sorl-thumbnail||image||8111e8caedeee324c2e28b6dc8ce3a67	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/04/3e/043e53a3b2e54190cf0828f865d82af4.jpg", "size": [50, 50]}
sorl-thumbnail||image||e3a94ba250521fce12391a6e04ffdd6a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ab/dc/abdcf3259174613b19490e33f0f23c15.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||5bfb2fe1c7644ca87ec322a3f1b3b09f	["e3a94ba250521fce12391a6e04ffdd6a", "130b88f5f984836496b8f304a17e7b4c"]
sorl-thumbnail||image||c430c2ff2a8f300ca65556f5bb9cbe53	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/skYbFm.jpg", "size": [180, 50]}
sorl-thumbnail||image||6cce0f0064987b1a7d9befb456f3b7d7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/07/43/074356bcf499a643afb3d0415271e5c0.jpg", "size": [50, 50]}
sorl-thumbnail||image||e88658f57868f93fb2ab9c6ae182a530	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/fa/9d/fa9d117f63aea885f25e9ef52c0e4533.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||c430c2ff2a8f300ca65556f5bb9cbe53	["6cce0f0064987b1a7d9befb456f3b7d7", "e88658f57868f93fb2ab9c6ae182a530"]
sorl-thumbnail||image||425d3878a51ad9e69757fb3cd28d67c5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6c/32/6c329f281eb5e6c690f96b95cf555da0.jpg", "size": [200, 200]}
sorl-thumbnail||image||7f4099518a48da9842c3f8bb71d22da1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/84/de/84de6c2fb97a962c1fe2203c770868f0.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||3742cf101b99d38b6d2e258b7fc175ad	["425d3878a51ad9e69757fb3cd28d67c5", "431fb30c8f915fcfde11c8c616cbdbdd", "e26670bacb063cb7d7b007df952663db"]
sorl-thumbnail||image||d3fde9e217464b438e850037073e2f45	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d9/df/d9df7c0fabb5274cb89c387a4e4912ae.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||7e00a99b21c979d75158246d55b86a76	["11b19910e18a5f4c7ceabcf0c2b0df8c", "98dc6a829230f6415e6ec49b2f7362fc", "29f0517f6915300d5d837f28affa68c7"]
sorl-thumbnail||image||5142ca8c9fd7929703c71a22821b47b6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/55/0a/550aa2bcb4a16ba61669e89ee945829a.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||628e56a1dcb013f462c5d9a335baf552	["482451e3ec597ca7511682b29c679395", "5142ca8c9fd7929703c71a22821b47b6", "b8c79edf79d6d518fb5484a771fa3879", "20548dd82b6a2a8d2199ace684a7b83e"]
sorl-thumbnail||image||c1b7fda907bb0a727330b07228c2ab0a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c6/a3/c6a3fc6dbf25cf12da89e49a8eb12251.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||93cd15e15aa8df1d055acfb9d3068020	["f0d060d16d0193cc1b528fcc3d4613eb", "c1b7fda907bb0a727330b07228c2ab0a", "7a22ef6d58eaa6e7c56dfbf81f73c119"]
sorl-thumbnail||image||e352cde4096e91e45af4d551b0edc3e9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/47/74/47746d8ba23d2b6c402dbe78d29722c0.jpg", "size": [200, 200]}
sorl-thumbnail||image||71a60c811d07cb7fecfbcb95f9529e4a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ae/bc/aebc64de4a21fb3d15fe8d9f57569e73.jpg", "size": [200, 200]}
sorl-thumbnail||image||ba9f4cea7a00ab61961a1c964db068e4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f0/8d/f08d3ac5f8c17a38ecd9ae6f01b9f6ff.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||fdc8a7cbb6620b6268c2a3ec270ff122	["94371a03742be05bbb30b3c187a31289", "193eebdf1e50e3f0aa29c22dc77cc6a7", "604e0cf42bcada413c7c4136295b467f", "ba9f4cea7a00ab61961a1c964db068e4"]
sorl-thumbnail||thumbnails||767054205eda2edf4259d5529851245c	["86e58e92bba68a0dda8071f68c44f474", "ee03686101cf6c563ea0c580933ee3f7", "3aff5e0a0ecda7565d718eebba7f91c4"]
sorl-thumbnail||image||2c340e0ab744a97693b5387ba7489ea2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/38/b7/38b7bb915b366562b194cd37f5aa63d8.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||670d165bb6ab217c82a04b3f2c9d0913	["e3965f83e9cd968adaa774c5615be21d", "2c340e0ab744a97693b5387ba7489ea2", "5fad5a5fda488ec8b4db9c115bb26acb"]
sorl-thumbnail||image||4d76ba759dcc69efe12f047db8dee11b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/19/66/19660a1ea1f55a65348d71a044bc821c.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||78df97456f8a9a1a4ff9a6bf927520d0	["434d036f253d9991f2c12650b7bdb273", "5cde9c17a47978a2ed8b0158f08da4c1", "4d76ba759dcc69efe12f047db8dee11b", "63d8697c6a6bf832e0f803f01a15965e"]
sorl-thumbnail||image||5f8199d5b9b8e2835ba4e0b8945ed6c1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/18/06/1806ae786dc90441e86e9ad2a1867602.jpg", "size": [200, 200]}
sorl-thumbnail||image||5e9e6dd29acfee8a9a1ebd443c7becd9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e1/1a/e11aa7ebd7420f7c09fe47e67bcbfd66.jpg", "size": [200, 200]}
sorl-thumbnail||image||ee03686101cf6c563ea0c580933ee3f7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/64/85/64854856819c8ef1f7e67f871d2952ad.jpg", "size": [200, 200]}
sorl-thumbnail||image||8c54dc0faacdd9b266b54805c5458353	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/bf/42/bf42de7dcffbc0467627129598f47170.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||e434b5715cfee47a615a312ede0d6346	["8c54dc0faacdd9b266b54805c5458353", "24ae24f7bb70fcd8be0dfeaa81146ba1", "57f49221bc051d3260e3c14927b41765"]
sorl-thumbnail||image||042ef52d127996acd5bf294c50ab8b6d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1a/1f/1a1f24abf389476195da81ad27fe1011.jpg", "size": [200, 200]}
sorl-thumbnail||image||603909850a294010c63f3392871d6d02	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/29/7a/297a32fac3143abcbcea0c87f1d05235.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||336432243e38dbbde98e527f1ac30fb2	["a10b8ec49b909f502e802ac73fee231e", "d7ca5f127f1f1ccf0b066bac81a26c08", "603909850a294010c63f3392871d6d02"]
sorl-thumbnail||image||c3c6a1679f4046e16efb64d774265099	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3a/a0/3aa055f5aef447b7add6b38a413b62cf.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||cbc2afead02c0dcafbdd88a3bf5d6e2a	["7f4099518a48da9842c3f8bb71d22da1", "c3c6a1679f4046e16efb64d774265099", "2e7aaffd2890f8aada52b72e7c0997db", "8111e8caedeee324c2e28b6dc8ce3a67"]
sorl-thumbnail||image||ed14012b73c932a7f8ba9d1ddc03f575	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a1/90/a19079e08b1d509c8ba13159ae70f784.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||ab903a95b553281c43ade60f9cb0c9d5	["ed14012b73c932a7f8ba9d1ddc03f575", "f224ec5c659b4fde5e9c53a0de0ff932", "88dba9b2886fb560b624a7c96053fe57"]
sorl-thumbnail||image||09b6b55f1a467cc7e62830d1554cd024	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e3/13/e31373cf454918747df39c1abbe1595d.jpg", "size": [200, 200]}
sorl-thumbnail||image||65c93ba85a1592a32792ee8a77e2a9cf	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/4d/8f/4d8f6d9aaf99c6bb19a2d3c145c0fc6b.jpg", "size": [200, 200]}
sorl-thumbnail||image||d39147007424515ce3a7d10270484fff	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ec/5b/ec5b6ed23016449d47c7bf730ae434cc.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||dc8227ef09fa66e068635aa7b71a2525	["d39147007424515ce3a7d10270484fff", "5b50260753350cf22fe93790e9017a35", "9b925050cf0510b145d68361e9cc8631"]
sorl-thumbnail||image||379762564c880b31b2178acd4b26786b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/21/69/2169d58072d808edfe280c31ba7eb60b.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||269cd618763d8f431bf32616931d1512	["e6b3aeae65f8838e9e9dd78e016372f5", "379762564c880b31b2178acd4b26786b", "7b5dd75977f052173bcc8f806857b567"]
sorl-thumbnail||image||006b5a68f9b3cde954d3b967df9d966f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/22/18/2218ad05ea094c560375647082ed2d83.jpg", "size": [200, 200]}
sorl-thumbnail||image||e4800a815eed7e88c23f5a8ca11f79e1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/be/c6/bec66fce1212f990c4ac600e3c5ea070.jpg", "size": [200, 200]}
sorl-thumbnail||image||9f04caef7e4c088d13f4a9d83f9c8f92	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ab/e2/abe288060977671699b5a10cdd7de8bf.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||2e25e5bd69883eaa3ad0e5ce7e55fa71	["6fab6309c39647261cf86b7b435a7d96", "507d0f8e601bf40a9e0826f86c528de5", "9f04caef7e4c088d13f4a9d83f9c8f92"]
sorl-thumbnail||image||b657775b083de0a89e67f02a72b4a0e7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3d/6d/3d6d7cf007b723a44a1f490ab1a53184.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||8c7f36878f7a67c45eeed69d2c691841	["45ac48538020b01d78dfd08397f85ea9", "af5fb37a77ef0837a8e5f9e1d4ce4b86", "b657775b083de0a89e67f02a72b4a0e7"]
sorl-thumbnail||image||33aeaff506beee6a7f5e2fcdcf3e247c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/11/8f/118fa9a338d13ce14069dcefb80bfca2.jpg", "size": [200, 200]}
sorl-thumbnail||image||424e26867bab3f592ccffd902426696c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/72/f0/72f0abc27339ab51f43a3df784bfa704.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||de67eeef36f55370425be630b4057604	["52f1205254a7b0d8bf297b9a2291ed00", "61a96efac42ba6d01196448decfc0407", "dc9fa6e6a6b3c33d4ce86bffaff85c87"]
sorl-thumbnail||image||6ad32d1b254a0fd5668c2d7400040aa9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/94/6d/946d08f0bebf7d87a9748bcd325e311a.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||a0ecf6450a462cfdbb158d5bb7c99878	["186a4a9b0ab7f10104f5975090db4694", "6ad32d1b254a0fd5668c2d7400040aa9", "000ff92f1778a216ef0cfcfaa18d3a8d"]
sorl-thumbnail||image||c68fda062596edeb4c222b03b667456c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3f/f6/3ff67931cd2e02470520a240febabad5.jpg", "size": [200, 200]}
sorl-thumbnail||image||51859bb2cf58858df08645bf67fcba79	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e0/8b/e08bdc2cf158fa3dd589726122c1326e.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||f8e782d29791341bdd486f9b05437823	["7d54ae8d48f740dff6af217d3b2efeeb", "f7ca2bdc90b488bb7b2e0dce9f00446e", "51859bb2cf58858df08645bf67fcba79"]
sorl-thumbnail||image||eeb62b1f995450649be2e388213a8ea1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/66/a1/66a1ec69936251a2a881a0b735231375.jpg", "size": [200, 200]}
sorl-thumbnail||image||18bedd2df0b53972303f900a1bc22b87	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/5d/4a/5d4ac8cd5259a51835fd47eb7e3229de.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||0e4c039027ba87588808b489db0547d6	["18bedd2df0b53972303f900a1bc22b87", "428e91d6345033c6f97f0529d31a9b13", "8310f48d2c24fd6cb9dda1f42b76c43d"]
sorl-thumbnail||image||6411b92ad92a4fcb8fcf0fc00279d604	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/35/94/359455222cfc6ca6b1cb1958081d35ec.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||a1375ffe22a354ee077701969c727c5d	["6411b92ad92a4fcb8fcf0fc00279d604", "bcf2a4084122e9747143291f9a4dab62", "420dee957f9cb7a18c7f17166373f006"]
sorl-thumbnail||image||98662c818aaeae828236bda97cb86b8e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/92/62/9262072536888cc54a2ad1f9d9d22d36.jpg", "size": [200, 200]}
sorl-thumbnail||image||697105a2bd51a8a734c1cd576edae7aa	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/0f/6f/0f6fd24fe1a2546dbec830c15885e4a4.jpg", "size": [200, 200]}
sorl-thumbnail||image||ca29c5180c2d41f0af1961551b56f403	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e9/cb/e9cb802541fc0d229988d7bbcb496f69.jpg", "size": [200, 200]}
sorl-thumbnail||image||6620019ec0f96c9a359dcaab61fb0ebf	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f2/6f/f26f039c1640a5c732424b086f23e288.jpg", "size": [200, 200]}
sorl-thumbnail||image||c8231accbad0fbc6fa47b9db94a8bce3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b6/d5/b6d55150851eee5e64cd1266128241f6.jpg", "size": [200, 200]}
sorl-thumbnail||image||446b834189025c1811fd305d895ca5ce	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d9/01/d901448796a8868e9e13eb08c33e64ea.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||9f62df41667f500ef729b4f8ee87c704	["50f7d3b4f5ccee2ffe3afec837b330c1", "a7fe8dc129719f763752d8a986cba472", "eaca9277da45a5237debe8e725054f19"]
sorl-thumbnail||image||fe994d45cd054f48be7afb4983ec4d7a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c2/c7/c2c7dc26d375bc8544211b2989421d0a.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||d775ae2d8d6bf23f357ab4f4d761e393	["48287df9fce0ed315d0d84f1435c5374", "fe994d45cd054f48be7afb4983ec4d7a", "5bd09848ff48b8d32f9c77226b48def4"]
sorl-thumbnail||image||40524bbd2f3d3fa3888eb4501086b557	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/58/a2/58a271e093484999b9bf5e96b87c952d.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||237e7e8aa25049ec92652091ffdf3cc9	["2b534d6563062d47483e82f52ba35ebe", "1364e2bbc44118ba83e83cae6a44fb7f", "40524bbd2f3d3fa3888eb4501086b557"]
sorl-thumbnail||thumbnails||4dc73637ab7a1ce9a3018193c37d12de	["6a48ce8371c6a690334b6f4a8343bad1", "da1924e791fa0922b4f712e98d014801", "c998c82a9f632e222dadc0547def4428"]
sorl-thumbnail||image||d8bc59e4a509a84bd3f0b6fe6cf26f6b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/7c/c8/7cc8589f1cbb2d336ba55878e7b10ace.jpg", "size": [200, 200]}
sorl-thumbnail||image||9a6cf89324e981e183247ac648a69db1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a5/31/a5316f464f251a2594171e9c2deac712.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||82f9c9571328af473acaa7676ceabd2b	["ea1ef5298076711df898e568b4a40b24", "76e505620c9d3ba5fe9ec4ab80255156", "9a6cf89324e981e183247ac648a69db1"]
sorl-thumbnail||image||d173dd0016c524b9147037d811687be1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f5/26/f5262670ce6f96652ea19b1e6a5a9e23.jpg", "size": [200, 200]}
sorl-thumbnail||image||4179464921297d7d3a9799a8ccbf51a6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/2c/4c/2c4ce630a26a508362fbca8af09d972c.jpg", "size": [200, 200]}
sorl-thumbnail||image||972fd82fee6ab9c53536822bb4446fc5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/02/a0/02a0e79915c4ed608f650112468154de.jpg", "size": [200, 200]}
sorl-thumbnail||image||215856c66e6f06f5a1c832dd0cdb5c4a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e3/e2/e3e2aa2ca2fb1804989058271245b83e.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||80e7a8f3f71276c76e8e0fcf789cbe7a	["121adb6924471e480664ff472bef099a", "1df2fa9e6379df0ebfa07a8a79977968", "215856c66e6f06f5a1c832dd0cdb5c4a"]
sorl-thumbnail||image||1abbdcc231c694dbedc2372361ffd3a8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e0/b2/e0b280f86dfca80bc23fa11fdaa4e7b9.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||9731f2a550248e07f4e4d1450639e66d	["1abbdcc231c694dbedc2372361ffd3a8", "fef8333fdaeca4feeecf05d2c679e3d1", "99d06795b71e99b82bbec98117532eea", "48c47023172185d0c3b557074fdef889"]
sorl-thumbnail||image||0b117c37e43cae96000887e0c0940fe7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/fd/45/fd454acd81191cad12a4b27f466c7bcc.jpg", "size": [200, 200]}
sorl-thumbnail||image||1ad9dfc1a1062406f9f48c802c3d077b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/9b/36/9b362b68a4d4fba898d4ba13896491f2.jpg", "size": [200, 200]}
sorl-thumbnail||image||31a141a9f9142f28f1948929737b4151	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e5/aa/e5aa2dc17ff89dcffb69d6e2c75139c7.jpg", "size": [200, 200]}
sorl-thumbnail||image||aa4e1ac5df0177e2bb359b020176ce6c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e5/3a/e53aec9686ce3532dafdf2899a451a58.jpg", "size": [200, 200]}
sorl-thumbnail||image||cc52495ad31724477fffba5a82490763	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/cc/fc/ccfc0629d767a4ff4a5a55e58f861281.jpg", "size": [200, 200]}
sorl-thumbnail||image||3462a9d4a2f53c448f001af048587ddb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1e/7a/1e7a5a135f4af97d7822c21acac239e0.jpg", "size": [50, 50]}
sorl-thumbnail||image||2fd9b49d04906389d8bef10bcc9df513	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/df/76/df76a1315aa2a8b3c5ab631c110b441f.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||bbbbee635c320633490fe99dd77dad2d	["3462a9d4a2f53c448f001af048587ddb", "0b8d4acbe6cbc35a953521cb9a026ac5", "2fd9b49d04906389d8bef10bcc9df513"]
sorl-thumbnail||image||2e8fc62188c27090c081f58f16090544	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/9c/e8/9ce80e5c472cc9bef213314ab563008f.jpg", "size": [50, 50]}
sorl-thumbnail||image||de1f66ff4688b4a8b71315204a2bbe85	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/59/cc/59ccccaf3190429b83ffc9cb4d11fe15.jpg", "size": [200, 200]}
sorl-thumbnail||image||ee3dd7a6ce75f124f49c4dce88202b13	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/73/dc/73dc9acb4109bedbe2431408f6e0b05e.jpg", "size": [130, 130]}
sorl-thumbnail||image||78ee33dc00b57f50a07ae274e153341c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/CMU_Logo_1.jpg", "size": [180, 179]}
sorl-thumbnail||image||a1f7b28b61c321311731029dc93fd0ef	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/80/56/80560d5e5eef0f9dfa508e3ef5e6ed9f.jpg", "size": [50, 50]}
sorl-thumbnail||image||8c103a3cf7c254079c3cd7181b5bc6b1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c3/21/c321b9025e0327e81fa67bf5235b13e3.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||99031c9bad7e27581029e54ffa0e6d9f	["2f696639ea5e27b2561ec73cfbeacee7", "8b32a8164e0f0b7cabbfa75435eaf80b", "bddb5a5258a661c9312ed0f70ad5a479"]
sorl-thumbnail||image||b447e66b2c8c8f753269ef921a7478d1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/CMU_Logo_2.jpg", "size": [180, 179]}
sorl-thumbnail||image||1ca8e1f9becefddcbb00d4f0e1b4b44f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1b/c5/1bc581b9c773715a34769aef70dfb5a7.jpg", "size": [50, 50]}
sorl-thumbnail||image||fdff0247c284d4cde6f876dbb6d51d56	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/8d/62/8d6222099d62ad45ec004d16424e782e.jpg", "size": [200, 200]}
sorl-thumbnail||image||2fd90be5cafc3c3364bd258f8279b0bf	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/28/66/28664fac57b0486a093690e36e8c253a.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||898bd9ffbcb0bc194af9872c5329d220	["e774b7f6d51c4054c04fd3bec3fd1fce", "6e5e386526540ba78bf8eb8c87e562f2", "9ee18c701e1ce8531893cf2674a84e21"]
sorl-thumbnail||image||248830da4ea8ecafa23a96e807f41eb3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/CMU_Logo_1.jpg", "size": [180, 179]}
sorl-thumbnail||image||d8fadb277e9c9b711b650f1885aa2460	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/df/e6/dfe688bdf01f04a0199e6594ab92a7d0.jpg", "size": [50, 50]}
sorl-thumbnail||image||aa3b693a8d07fb509f5d5c141e7ef82c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d5/0e/d50e1775aed85a496f3bfc251c20f0ac.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||78ee33dc00b57f50a07ae274e153341c	["a1f7b28b61c321311731029dc93fd0ef", "8c103a3cf7c254079c3cd7181b5bc6b1", "f41cb19b03e76aedf7d03b79815c1ed9"]
sorl-thumbnail||image||9683ba2603b21dc706f2d617a5b91729	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/CMU_Logo_3.jpg", "size": [180, 179]}
sorl-thumbnail||image||9b5d67a8549d5c8d92897895bae710cd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/15/e0/15e01c172352a14e55557607e7354537.jpg", "size": [50, 50]}
sorl-thumbnail||image||898bd9ffbcb0bc194af9872c5329d220	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/Oakland_Abbey_Road.jpg", "size": [640, 426]}
sorl-thumbnail||image||3c20fedcf4edea652d48508871404093	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/78/78/7878721ea3d5a7d95f706907b0fa54c7.jpg", "size": [130, 130]}
sorl-thumbnail||image||c66d05a1fa23abec34e84f298c67d5d8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/42/48/42484d9c45656e2d9ad67712b95e5902.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||9683ba2603b21dc706f2d617a5b91729	["3c20fedcf4edea652d48508871404093", "9b5d67a8549d5c8d92897895bae710cd", "c66d05a1fa23abec34e84f298c67d5d8"]
sorl-thumbnail||image||338764028d3291bc6a112cce2656c9a7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/cb/a0/cba0fab821e0b36f5d17f380b05671cd.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||01f586e500800a271b8280fd8ebfd44b	["338764028d3291bc6a112cce2656c9a7", "95781c3d82b87f864eb9a4cc1697f560", "682883711b8094e71dc8a56ff0ca9f96"]
sorl-thumbnail||image||442a54aefd61e60110a380d27080880c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d0/3f/d03f9e91a2549e45c635e3e156005700.jpg", "size": [200, 200]}
sorl-thumbnail||image||6e5e386526540ba78bf8eb8c87e562f2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a0/fc/a0fcc05726afa27864aca9966b5db242.jpg", "size": [50, 50]}
sorl-thumbnail||image||7f92bfbb88df18a7d7b805fe3e7a218b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/157989_73877691965_505892_n.jpg", "size": [180, 180]}
sorl-thumbnail||image||e774b7f6d51c4054c04fd3bec3fd1fce	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d9/38/d938b6b2bddc3e2a38f45d5492f728e0.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||7f92bfbb88df18a7d7b805fe3e7a218b	["ac10efeaf2b01fb8e60086b7da1e78d9", "70c651a62bb0ca37e6ca0ba745fb1d49", "279addc55ae345840a7f56ae11a510d9"]
sorl-thumbnail||image||99031c9bad7e27581029e54ffa0e6d9f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/CMU_Logo_4.jpg", "size": [180, 179]}
sorl-thumbnail||image||bddb5a5258a661c9312ed0f70ad5a479	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6f/15/6f15ca747065a1c3aab170e82b30b7b4.jpg", "size": [50, 50]}
sorl-thumbnail||image||2f696639ea5e27b2561ec73cfbeacee7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/69/54/6954f03626239d422515e2b38954fd61.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||558e012fe2875fbc3998103cc8905967	["2e8fc62188c27090c081f58f16090544", "b3a5dbf0e340e02f702c1439a53b91e3", "ee3dd7a6ce75f124f49c4dce88202b13"]
sorl-thumbnail||image||70c651a62bb0ca37e6ca0ba745fb1d49	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e2/35/e235643bb960172f6a1fca1ceb703cf8.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||b447e66b2c8c8f753269ef921a7478d1	["2fd90be5cafc3c3364bd258f8279b0bf", "ac8c50dec85748ea606d8552c3c1d749", "1ca8e1f9becefddcbb00d4f0e1b4b44f"]
sorl-thumbnail||thumbnails||248830da4ea8ecafa23a96e807f41eb3	["aa3b693a8d07fb509f5d5c141e7ef82c", "a606bd5db2d97245740e01d4d37395ef", "d8fadb277e9c9b711b650f1885aa2460"]
sorl-thumbnail||image||279addc55ae345840a7f56ae11a510d9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/7b/3a/7b3a0eba035ce960eadf82ad4c806947.jpg", "size": [130, 130]}
sorl-thumbnail||image||73f219c7f07ce1474784860ff27f8fe6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/157989_73877691965_505892_n_1.jpg", "size": [180, 180]}
sorl-thumbnail||image||978f291d5d94d7e61da10244f1c6dcb2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b1/51/b151e1a1f049aa34193b2e721c48c611.jpg", "size": [50, 50]}
sorl-thumbnail||image||507f4a13e147290411fa96f70d3c2cdd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/7e/2c/7e2c2076ead64618b10919251f76bfe9.jpg", "size": [130, 130]}
sorl-thumbnail||image||308962acc3cd8b78a90dead6bcac8b3f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/db/5a/db5ac289fca8f6207e0cb379593817ea.jpg", "size": [200, 200]}
sorl-thumbnail||image||b715b58957a25718f87da1ac634b8638	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/music_hall.jpg", "size": [450, 328]}
sorl-thumbnail||image||16a72bec50279ea17b6f3018bac45852	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e4/fe/e4fef57bc0663641a601d7262c2e914e.jpg", "size": [50, 50]}
sorl-thumbnail||image||794f34da73cd507550611e4da7fdd794	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/14/1e/141eac1a0942b6b27a7a6e16ba2d93ea.jpg", "size": [200, 200]}
sorl-thumbnail||image||c25cf836cd9c1f410c41d1fd53445845	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/fc/f0/fcf0f6c9c91d3e9ee00101ee701c3fc6.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||c0e8e958eab933a30d0c25f0d3c730fb	["e1ad9cd6bc4bcbee2ba1b43c553f9375", "66fc6502b278741574b12005cd662060", "8f9739f57434d56a9bd316d672f9712c"]
sorl-thumbnail||image||c0e8e958eab933a30d0c25f0d3c730fb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/HouseFront.png", "size": [400, 300]}
sorl-thumbnail||image||66fc6502b278741574b12005cd662060	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/73/46/73469435253f5aebb33f5f1d09e66c02.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||73f219c7f07ce1474784860ff27f8fe6	["978f291d5d94d7e61da10244f1c6dcb2", "507f4a13e147290411fa96f70d3c2cdd", "794f34da73cd507550611e4da7fdd794"]
sorl-thumbnail||image||e1ad9cd6bc4bcbee2ba1b43c553f9375	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d8/9f/d89fb4ab5a5db46702084a82a52a2d24.jpg", "size": [130, 130]}
sorl-thumbnail||image||ee08cd32f81df6eb6087daaf2dead4fa	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/HouseFront.png", "size": [400, 300]}
sorl-thumbnail||image||e72163a3fdd42a11f9c7e47c2b5a4476	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/79/bd/79bd6a01368a0818ba647ee2198f51f8.jpg", "size": [50, 50]}
sorl-thumbnail||image||d75072cd2752cecd6ae3d7b0c25b3c71	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/2e/e7/2ee7307a7c3ef81db73606c073cc2aa2.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||b715b58957a25718f87da1ac634b8638	["c25cf836cd9c1f410c41d1fd53445845", "16a72bec50279ea17b6f3018bac45852", "036d4ebdd958d943875f9d98caa71fc3"]
sorl-thumbnail||image||5b0e67a4ee5036445902ff2941c85b1d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/Comic_Book.jpg", "size": [180, 236]}
sorl-thumbnail||image||0c6f8e845adb610fd572d532391ac305	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ff/57/ff572507bd4ef27cac90210083a8eda9.jpg", "size": [50, 50]}
sorl-thumbnail||image||96abfda1cd835850723be9cf3f252226	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3b/68/3b68f0f989a3ddf6a16f464c73dea987.jpg", "size": [200, 200]}
sorl-thumbnail||image||db7de898ae8d94879bf4490c73828f61	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1a/82/1a8238336a8a6cbb62eb9b084b4ba2d2.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||ee08cd32f81df6eb6087daaf2dead4fa	["2d9100078716ea32d42de310bbf09601", "e72163a3fdd42a11f9c7e47c2b5a4476", "d75072cd2752cecd6ae3d7b0c25b3c71"]
sorl-thumbnail||image||c64a02b7abe0bd0c9b039dbb3aafd9aa	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ca/bb/cabb140c518c1ed56af81074a876cedd.jpg", "size": [200, 200]}
sorl-thumbnail||image||08698dc68cc61a2b0a2d6f7dcd093dc1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/72/fc/72fc73645386e4c57f08fe1f2cd45e85.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||e4d0c53e3be948a67929b63ff1ffc250	["19f839050dcfd5858f4556ff12c2a1af", "08698dc68cc61a2b0a2d6f7dcd093dc1", "1df513926a2fb6f20282601f043f7f68"]
sorl-thumbnail||image||10903beeffeb7bb30019cf70f86aaa4c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ea/f4/eaf4389d24834a84b79477adab77bf58.jpg", "size": [200, 200]}
sorl-thumbnail||image||ac8c50dec85748ea606d8552c3c1d749	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b7/ae/b7ae657e38bc58b1e932b055901b2af2.jpg", "size": [200, 200]}
sorl-thumbnail||image||9ee18c701e1ce8531893cf2674a84e21	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/38/6c/386c594db91eb2bdfe288fe766105289.jpg", "size": [200, 200]}
sorl-thumbnail||image||ac10efeaf2b01fb8e60086b7da1e78d9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3b/da/3bdad5f7275b803c186aaf5d61f48d2e.jpg", "size": [200, 200]}
sorl-thumbnail||image||ccafa13c34b236c9e9e677ad0df6d37e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6c/86/6c86b9782ee2812298a107fedf0bd989.jpg", "size": [200, 200]}
sorl-thumbnail||image||e6547c1a720ef372222839c9bf3bbe17	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/91/da/91da27649c01adc9a642791a9b5e658a.jpg", "size": [200, 200]}
sorl-thumbnail||image||20d55468d6cb73ec344a294f3480f1bb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Comfort_Zone.JPG", "size": [221, 173]}
sorl-thumbnail||image||0dde829e06413b254f666a9fa58aa033	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/06/3e/063e1f06582861bdd93f1ddbdbf2565e.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||5b0e67a4ee5036445902ff2941c85b1d	["b59546cdd1c21e0344d7a7f12b6fef8d", "0c6f8e845adb610fd572d532391ac305", "db7de898ae8d94879bf4490c73828f61"]
sorl-thumbnail||image||93dc80b9d33ada37695d8524eec6b8e9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3a/47/3a477390c38df3703cd5c46dd1b52b85.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||20d55468d6cb73ec344a294f3480f1bb	["0dde829e06413b254f666a9fa58aa033", "93dc80b9d33ada37695d8524eec6b8e9"]
sorl-thumbnail||image||6fab18232e29c6182f7214dda2b374b0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1c/1d/1c1df272475003c40b2ba4ab1a9c2b7d.jpg", "size": [200, 200]}
sorl-thumbnail||image||e6065b9bf30067bdf2dc497276d0387e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/97/07/97074a9a8320a9f1b8db120b7671a42d.jpg", "size": [200, 200]}
sorl-thumbnail||image||a606bd5db2d97245740e01d4d37395ef	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ac/fc/acfc53b62f6b63d1ba1973ede94bd63b.jpg", "size": [200, 200]}
sorl-thumbnail||image||4343e1f203a56337b14a4f485c391f8c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/30/b2/30b222cd4b378fd590f98cc2aadf6b45.jpg", "size": [200, 200]}
sorl-thumbnail||image||b59546cdd1c21e0344d7a7f12b6fef8d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/86/6a/866ac1d3bfba38110de5e5b12b36fb82.jpg", "size": [200, 200]}
sorl-thumbnail||image||4cd0624a1f7ac2ca7a95683582417e75	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a8/b5/a8b5bde5b68e83dcbf4e7ee2a6b49ecf.jpg", "size": [200, 200]}
sorl-thumbnail||image||2d9100078716ea32d42de310bbf09601	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f2/05/f205fe8782c15a5c9731d0736e11f24b.jpg", "size": [200, 200]}
sorl-thumbnail||image||caa31c58a650af754298ba1841f4520e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ec/34/ec341e8551d2873e4e39b2b3628af306.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||0a622a61ece9526c3669211db667043d	["117cbdb9cbe971f83c975fab42c55722", "96f2ffed6cf43c22b31f72d346c67b68", "caa31c58a650af754298ba1841f4520e"]
sorl-thumbnail||image||acaf8cea9459139970c828c8a0697b7d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b5/db/b5db5de014cf08ebf67ad4353008348c.jpg", "size": [200, 200]}
sorl-thumbnail||image||f41cb19b03e76aedf7d03b79815c1ed9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/2c/6c/2c6cfd3873220efc9961d749d905cd09.jpg", "size": [200, 200]}
sorl-thumbnail||image||afdae4ffe18a2c3b72d93663234a9c0d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/04/53/04534d9ba124dd7e3edee5835072d43f.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||99bbadbb03007e25c85dddc9d8fb5e74	["04365375df66c171b633c5bbe4a9ee86", "afdae4ffe18a2c3b72d93663234a9c0d", "bf9f3f0dd66d55ebaeb197a2f787cfae"]
sorl-thumbnail||image||3f362f707496693c7b7f6699d47f1eaf	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/bb/2b/bb2bd62af3194639542bebfd67dcea55.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||9a0b38d5781bffd3367dad2f8cb5f629	["3f362f707496693c7b7f6699d47f1eaf", "1eef92955ea3b1eda960d2851272facf", "73cc87e5709934c3d69ce2d2d92775a9"]
sorl-thumbnail||image||0b8d4acbe6cbc35a953521cb9a026ac5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a6/f8/a6f82d2c671ec4f43c4e6c49ab207910.jpg", "size": [200, 200]}
sorl-thumbnail||image||2c6556c37aabb7dbff7a59a4a718098b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/62/d7/62d7158323f8d25f06e13872c5d64d13.jpg", "size": [200, 200]}
sorl-thumbnail||image||b62837514e4606d25d0bb1fb03c10358	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/16/ad/16ad88f1e9fcd1aaa8bdf1ecf84c0433.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||e04eed67fe35feade0955b8b5e1aa537	["b62837514e4606d25d0bb1fb03c10358", "4d22603413d0127e38fe3cd968554dd2", "0f0880ec082f34b55528185cc57a1a97"]
sorl-thumbnail||image||8b32a8164e0f0b7cabbfa75435eaf80b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e2/af/e2af2c94427bcf436888c1cdb25da9f3.jpg", "size": [200, 200]}
sorl-thumbnail||image||daeb55c6b05e9abe7a81f27a953bec0c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/9c/a3/9ca3e225b06b50da712d0f95619d9bae.jpg", "size": [200, 200]}
sorl-thumbnail||image||bb5553d53965eb390d000f3f37c64ec5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/fb/dc/fbdc0683537bccfb7bda72c6b58834e7.jpg", "size": [200, 200]}
sorl-thumbnail||image||12eb211f5e5ac226fe01367dbb7eaad0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/09/a1/09a1150c6fde2bb1d5e2b8f337e121a7.jpg", "size": [200, 200]}
sorl-thumbnail||image||91c1b1cde7ef8646ea9d782cad7fcd04	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/71/78/7178877c3241d5f1895f7d3546267c41.jpg", "size": [200, 200]}
sorl-thumbnail||image||4b0a8ff1a00dd7627ffd51febe4e2055	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d8/92/d8922c8a3e88d2d367a8831f04335b8b.jpg", "size": [200, 200]}
sorl-thumbnail||image||cc824db1091bb8f4b148a1663428ab6d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/31/0e/310ef62d2b8720922717250ef8f2ea59.jpg", "size": [200, 200]}
sorl-thumbnail||image||2dc8d3226f3c00842dc2f56adf52abb7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/01/6d/016ded26c9f3f91f9672a5702091edc7.jpg", "size": [200, 200]}
sorl-thumbnail||image||036d4ebdd958d943875f9d98caa71fc3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c4/56/c4566b1824cd2e6f0d37f4a0258604f7.jpg", "size": [200, 200]}
sorl-thumbnail||image||c9c839b95f86cd9800ea7af3a60dc1ee	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ee/92/ee9250aacd7445bfd27d7b34a7019900.jpg", "size": [200, 200]}
sorl-thumbnail||image||d3d9903c5f03c117890d9bd7ffe4d3cc	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ed/5f/ed5f40d0d7819cd737266f1e2f280b7a.jpg", "size": [200, 200]}
sorl-thumbnail||image||b73e32ad1244feb24b6a9373b57ab451	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/db/a2/dba2630fba35b65c514342899701542d.jpg", "size": [200, 200]}
sorl-thumbnail||image||617aa8656d8a8a57de498dcdd8db1a96	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ea/ab/eaab9decfe29aee444452bb89749a4d1.jpg", "size": [200, 200]}
sorl-thumbnail||image||f51d7b0cb1c10dbfa6b4e8fd16293fbf	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a6/d0/a6d0a6fecbf9b0bf2da54bfcc59d99cf.jpg", "size": [200, 200]}
sorl-thumbnail||image||460a368f4547276296aa65fd24db70df	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/73/b6/73b6ac798f85a0e73a889ba654a43fa7.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||435f0c5f25e25b1405d31e69cfed6c96	["d3703c950e5db46aaca65fd24f7b5d8a", "460a368f4547276296aa65fd24db70df", "7518e3a897d73a339145b20c15fc0d10"]
sorl-thumbnail||image||1626201d216b1f9fe7929161c739b50c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/68/c1/68c11893680a051bdd9c93811e1c1600.jpg", "size": [200, 200]}
sorl-thumbnail||image||ff6d213db20135c90feaec0b1e0e29c0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/fd/66/fd66ee16e11d630a0f075e7f0e20b3b5.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||63859ce5ec1345598c43a534946323f8	["e7e2fd7e374ff1cac3dc2664975800da", "ff6d213db20135c90feaec0b1e0e29c0", "2f7a291f513638fe900734985e70377a"]
sorl-thumbnail||image||3b366a1fe5fcdfbd8b3d414db6fc6920	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/99/5e/995ebb57b3f5fd276c8bec9e4cf6fad2.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||0981dc3fcaf74507979cda10c717df56	["3027023d91b93dd0a58f2e6f3c3c1866", "3b366a1fe5fcdfbd8b3d414db6fc6920", "59ad2404846a358d3cf41eb0541b447d"]
sorl-thumbnail||image||8f9739f57434d56a9bd316d672f9712c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c6/a7/c6a7220490b4a02cbc383dc1972d0e32.jpg", "size": [200, 200]}
sorl-thumbnail||image||b1b0bb6a3a8a739d100ae21232b29a99	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/a/20090612mf_fleury_cup_500hp.jpg", "size": [500, 488]}
sorl-thumbnail||image||905552586fe8d9bb1b6a5096b38dbd06	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/99/65/9965656f801e53a50e93fca89a6ecf75.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||b1b0bb6a3a8a739d100ae21232b29a99	["905552586fe8d9bb1b6a5096b38dbd06"]
sorl-thumbnail||image||25aa7de0b51756e30d6da1754dc1db6c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/a/Moses_in_a_Bag.jpg", "size": [900, 1596]}
sorl-thumbnail||image||1a45c57c02b2d38612f5767f95c53e92	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/92/2b/922b9422c7af742b526ff5a150e2a9a1.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||25aa7de0b51756e30d6da1754dc1db6c	["1a45c57c02b2d38612f5767f95c53e92"]
sorl-thumbnail||image||5d7418b7411287c7aa1397e11a3d3ba3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/35/15/3515460700d054259c3149736efdda87.jpg", "size": [200, 200]}
sorl-thumbnail||image||60bf1cd8b256ccb4fa72b1f26440655b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/a/Brett_headshot.jpg", "size": [1000, 669]}
sorl-thumbnail||image||2a06635f158808b575e061325c9c8af8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/5d/dd/5ddde1ac9dbafddf36d8a8f8871d7a66.jpg", "size": [130, 130]}
sorl-thumbnail||image||af7a63689c44e404d93800b62f91a2c0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ce/b0/ceb0b3cdfb9b4bac8ac6250318afd9c9.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||b9b20057edf418f2661fcaff59447863	["6ef17978a965f17d777a38361dcf7ba7", "89352258401e1404cdec6e95575e83c8", "af7a63689c44e404d93800b62f91a2c0"]
sorl-thumbnail||image||2d45cdd4e2ed49746e3bd75c355a847b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/4d/34/4d34429035bf81215473a7c70121403e.jpg", "size": [200, 200]}
sorl-thumbnail||image||e0a5112735ef93b6e3b1d19f810106fd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/32/97/3297851607c4bc1df45e6b06e32b6059.jpg", "size": [200, 200]}
sorl-thumbnail||image||73410dcdcb5f18ea7c0ea71f48c722ce	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/87/6b/876b549b994c4d11271049057bba2576.jpg", "size": [200, 200]}
sorl-thumbnail||image||839ab817bba5b6aa75b9b1aa9dedd3db	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a1/10/a110d23145672eb18c16bc359153d517.jpg", "size": [200, 200]}
sorl-thumbnail||image||db087a392f5dae7a7a7bd92703b89041	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a6/50/a650a9ad32938e72bfa08c6e506cac85.jpg", "size": [200, 200]}
sorl-thumbnail||image||ce1a2262ba1747a9e10e3c785be98605	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/7c/06/7c069b841c75c03284c3e62d4d4b1130.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||45b778a051481f604fa0ad31bccf1598	["67ef21c5f167d51332dc9007e376fa35", "ce1a2262ba1747a9e10e3c785be98605", "6d0e90b91fa5d3956b3bce88c197f331"]
sorl-thumbnail||image||d3acb6cd86d67697966fbba1c2d8ac05	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/cd/01/cd0170bccf1d8e2cf193843dcb5290fe.jpg", "size": [200, 200]}
sorl-thumbnail||image||1c979eae7b906a772d8d492e39142346	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3f/94/3f9472d8399cef5b9ddacdc69ec3cd4d.jpg", "size": [200, 200]}
sorl-thumbnail||image||c1fc2e844934d47d29859abd9dfe89ac	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/56/88/5688e5c00961d29f1e78581d1ff52243.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||2f78c455ab74c09a3860538d94adea1d	["c1fc2e844934d47d29859abd9dfe89ac", "bb27c3f46b35a399047d0601cbad620d", "ab5c3ff6ee6def068dbadc0e16421ac8"]
sorl-thumbnail||image||b3a5dbf0e340e02f702c1439a53b91e3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e4/03/e403dc3b53f8cd5425adc76a0256fc0e.jpg", "size": [200, 200]}
sorl-thumbnail||image||fa82f3353ced5e91d34ce0c644a973d1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/fa/2b/fa2b0a36fabe1975c2d0c7c9ee0df183.jpg", "size": [200, 200]}
sorl-thumbnail||image||8a411412dc13c1bc342458107df1367f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/2b/3d/2b3db6acb8b7bfd4adc8fdec372bfb1d.jpg", "size": [200, 200]}
sorl-thumbnail||image||b9c238e03683f96812d474cb5876ea8a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/9b/92/9b922b89e9906c07bc383e22b66d347b.jpg", "size": [200, 200]}
sorl-thumbnail||image||6c2a59098934dd7fd382214d41634190	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/da/fe/dafe68432d8607203fb2d1f3cd35d539.jpg", "size": [200, 200]}
sorl-thumbnail||image||c5c8a784235b39074d8dfc2c81186cb2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/0b/e1/0be150e205a51584686e8ac188d1b67d.jpg", "size": [200, 200]}
sorl-thumbnail||image||da6067d1f3501c40c36bf769f0e47d89	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ba/13/ba13afd05445db13484d971b3d996da6.jpg", "size": [200, 200]}
sorl-thumbnail||image||ac19d200d3f5a4727af7026a630537f5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/4d/5e/4d5e761b23bbc09f58ff35a4eb0e5896.jpg", "size": [200, 200]}
sorl-thumbnail||image||18cde2cb5f2d20bb5040a168fc43cd7e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/16/7f/167fc30d80befed5cd0e43969fbf54cc.jpg", "size": [200, 200]}
sorl-thumbnail||image||e16763b1dc6bfafefe9f12d1ed8a688b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a3/8c/a38c36321a8b24510734465645523047.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||aec1747b72a8313e021669d7ea8e30dd	["f1d4a7094b515fafeffff4016ea260ca", "e16763b1dc6bfafefe9f12d1ed8a688b", "90d84a9489178e6c24212ab97be1b808"]
sorl-thumbnail||image||5d7406c9e6fb955948f754b2c280a882	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/53/94/5394ff510068ecf0d023b9c4f6fb8e2a.jpg", "size": [200, 200]}
sorl-thumbnail||image||b37bfb5c471be8ff356b9fb975b0a047	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/fe/b7/feb7a9a430b4fc5776552788ae6276c1.jpg", "size": [200, 200]}
sorl-thumbnail||image||2337607ebaa22484e61548f151991d1b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ce/de/cedebce7912b9ceafd67987b04269a9d.jpg", "size": [200, 200]}
sorl-thumbnail||image||3d73c82092e4906b726963082c799b49	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/53/3b/533b276a4bc298c0824367c998b1a4c8.jpg", "size": [200, 200]}
sorl-thumbnail||image||fc26f375abff5eb595e28168db4ead58	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/93/ca/93cab8048dcb44a0c8851e1282201406.jpg", "size": [200, 200]}
sorl-thumbnail||image||fbeccd7822ceb03c5ff174cd03926d6b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/49/4c/494cf688f3c7f7b463f5ff0c7b05daca.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||34a33979f5844147e4ca298a2603611b	["33b51687648b7a290e9bf9fac663231e", "fbeccd7822ceb03c5ff174cd03926d6b", "8e80b364c4d07ecff86e3caf0fd8c0a8"]
sorl-thumbnail||image||3bc8481feb137caf8a2633dada2165e8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e2/fb/e2fb40e731174d1258e50e5c5014a051.jpg", "size": [200, 200]}
sorl-thumbnail||image||355b4ce38a80b82ea6e0ce32a99353fb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/33/30/3330e4873100f7190a34859f830c1d38.jpg", "size": [200, 200]}
sorl-thumbnail||image||292916fc235b50fa3f78ab0b238680a2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/images.jpg", "size": [267, 189]}
sorl-thumbnail||image||837c3f9d432f765359f572df948241a4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/db/0b/db0b0ab6ca434d608d5aa9c569406381.jpg", "size": [50, 50]}
sorl-thumbnail||image||6642d629dc941891f34e9d16501b6c82	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/10/6a/106a150ffb733ba85e5e2896c6967da7.jpg", "size": [200, 200]}
sorl-thumbnail||image||144ecad8d17633e2a29b38458c7506dc	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b6/f4/b6f4e97fb65b3c00b1b31f43b9cf412c.jpg", "size": [130, 130]}
sorl-thumbnail||image||3ebe5b0298f66414f9a49a5ec8d2b4fa	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/a/Profile.jpg", "size": [720, 504]}
sorl-thumbnail||image||e713ca9983229ce066f2527b3e64d514	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/95/e7/95e7a400029b608805f547be3003a644.jpg", "size": [200, 200]}
sorl-thumbnail||image||38d10da7c4c1bf56e4068cb4aeddf099	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/7c/4f/7c4fb98b6c181683fe2a8ff6c4633a28.jpg", "size": [200, 200]}
sorl-thumbnail||image||f1791b9be0ff3beb75aa8467e1678e8e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d5/1f/d51fb083c1321cc4547cbc6b9be032f8.jpg", "size": [200, 200]}
sorl-thumbnail||image||e5886d3be3b2ab03d3e226676ec2cd75	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/84/4b/844bd4d1c1bad0236c14417b5c911585.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||8eacd37cf3d7763f24fc28666373d778	["fda07219c2fc29516dff75b6365ad88e", "e5886d3be3b2ab03d3e226676ec2cd75", "1d49780a490c7de1e603705e52279422"]
sorl-thumbnail||image||ea648a039c914546b95a2cc97fdcb949	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/13/ea/13eadf8c4a508e08a08ca48bac0ffe9f.jpg", "size": [200, 200]}
sorl-thumbnail||image||3954c253c83b4fcdff20836cd2a8f1db	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/61/2c/612ca6efa2f8f6d77a20b87948f37e8a.jpg", "size": [200, 200]}
sorl-thumbnail||image||a02f611db43f1db91507d97f68e40a47	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/38/b8/38b8de2521c9057a6ea2980b0ae197e7.jpg", "size": [200, 200]}
sorl-thumbnail||image||04606fb23c02deca3d4f50d30f80bed3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6d/88/6d88b4f6e0045f3a4fb33b047443b7b3.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||7bf9a4635d72aa5afcacf7c05b51eb63	["f8e9b2a5f141918091fbf7bfb78214c5", "05c0c69391bcb8dd0ccd675d6ce6b4a7", "a02f611db43f1db91507d97f68e40a47"]
sorl-thumbnail||image||6c50e074e279dc92d3032585a0980589	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/64/60/64609fefe87d4dd4de3445832e713e9c.jpg", "size": [200, 200]}
sorl-thumbnail||image||8f475ebe4e315de160d8139a6b44dc91	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ef/e7/efe722cb9e26aaeeda38b0ab9ec45dd7.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||f196331a42a919e39b0ea4edd58b4f13	["8f475ebe4e315de160d8139a6b44dc91", "612e46f46632521ee15a47280f453049", "198069be6d55cef7d5bb6a5c4fe5f590"]
sorl-thumbnail||image||fca8157e89c7825b028f0bead6359696	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/41/bc/41bc2332b37ad63272dd8695d2f9a285.jpg", "size": [200, 200]}
sorl-thumbnail||image||efd8704f9089ae700212b3c00aac6633	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/7e/02/7e02db6e0f6834b804cf7e5a257c0806.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||c36152f38d9fff445ce06360d0429868	["c098ff742b5791b51ef3a2197c91e7b7", "3064734cc994c662567072dfc8827602", "efd8704f9089ae700212b3c00aac6633"]
sorl-thumbnail||thumbnails||292916fc235b50fa3f78ab0b238680a2	["fc0fd01c8376740711035b0acf5230d0", "144ecad8d17633e2a29b38458c7506dc", "837c3f9d432f765359f572df948241a4"]
sorl-thumbnail||image||fc0fd01c8376740711035b0acf5230d0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/9f/4e/9f4e39a1bc96dcc035be797871d91563.jpg", "size": [200, 200]}
sorl-thumbnail||image||470d66c7ce776280fc268163abd400eb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6b/e3/6be3cead69dc7571519a3e8e3270937a.jpg", "size": [200, 200]}
sorl-thumbnail||image||8ceef53392d17f4094418de3d938c2e6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/86/fd/86fd5f1f67e9748cc2ed0aceb49160d4.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||69197fe273498332b0a40bc40d6b85f0	["8ea4feb8ade7ff8a805bb3895fee1dc7", "8ceef53392d17f4094418de3d938c2e6", "ad9233fc9e30f02be72e2b8e00f3115c"]
sorl-thumbnail||image||3ddae10719e81b7f7c6736caa748f65c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/42/65/42651ddc9a4651b46ab0a9ce171d3bee.jpg", "size": [200, 200]}
sorl-thumbnail||image||2617de6a1ce8e9a629c96a1400562475	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f3/6e/f36e88a8e03e3c9084dd2a9c903ebcc1.jpg", "size": [200, 200]}
sorl-thumbnail||image||9888f96eb442f089b905b773f826ed36	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b0/ee/b0eedbfbc060d30af62b8b95120dfb75.jpg", "size": [200, 200]}
sorl-thumbnail||image||10cf8e7073fc9e11325fad1c4c7987d0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/69/43/69431fd968fdcfb1c7f950bb19aaa983.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||72d1d34b7538f53adc395e19c8a83d0a	["d2a7697d9bebad661d9b5c4d00fe53db", "10cf8e7073fc9e11325fad1c4c7987d0", "58c03ecde603ac96c6f8cc1bcfe47481"]
sorl-thumbnail||image||c8be0c29f0f988b06571758b3ff6ab1e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6f/14/6f14c41415033fb6a144fc90baea370b.jpg", "size": [200, 200]}
sorl-thumbnail||image||b3d062e0b4e8322fd9b11c718b6edbb0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/43/75/4375b7effdd068508b4e3a02eaedab8c.jpg", "size": [200, 200]}
sorl-thumbnail||image||2150e767d0668fe173420f524106c45b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/50/8b/508b3ea8841e15afca210ed1ed4cea6f.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||bc2e766fdc85177ffd72e56c95720383	["129b6416d5c3fe6b6dec0a86bb967077", "2150e767d0668fe173420f524106c45b", "168d7b5c54eb8f2dd0b88bf250cb05b8"]
sorl-thumbnail||image||a57fd11f595fcb33939249f3db8f0ac5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/a/favicon.ico", "size": [16, 16]}
sorl-thumbnail||image||7d3a1aeedd0004b4fad39d906d51f1cb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/cf/52/cf52f3633f0929f925174b6d9e8e057a.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||a57fd11f595fcb33939249f3db8f0ac5	["7d3a1aeedd0004b4fad39d906d51f1cb"]
sorl-thumbnail||image||bed9c6c75cb732d6e74fcc8604e899db	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/a/photo.jpg", "size": [200, 200]}
sorl-thumbnail||image||91c858b11ffbe62e30ba052d92ced1f5	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/de/a0/dea00ac438ba4bb94f16b6b0eb10be1b.jpg", "size": [130, 130]}
sorl-thumbnail||image||650c8d8b2a98ed557573a94c3ad92091	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/be/15/be152f9218576ff216e757c850a950ab.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||317080d46b897a6d97f9ed628d695000	["650c8d8b2a98ed557573a94c3ad92091", "53eaeda3622cde261ff3bc058a73c5fb", "629400a63c5554b54d3274ce50f836ab"]
sorl-thumbnail||image||6837ae47feda951c4903c0dff8b5e9df	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/5e/7f/5e7f5a362217996194948acf35f2f5fc.jpg", "size": [200, 200]}
sorl-thumbnail||image||4f9793521466c244941fd132f72565a8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a2/af/a2af1e2df2f0b0637c356321246ab1c6.jpg", "size": [200, 200]}
sorl-thumbnail||image||359c80b85110de758ee3ff04912e59f7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6a/8a/6a8aecae502cf08a634dfa0d600abbd9.jpg", "size": [200, 200]}
sorl-thumbnail||image||d36720b909b348f9adaea74416556578	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/87/63/87633013d8b569d4ffe235baaa98dfe8.jpg", "size": [200, 200]}
sorl-thumbnail||image||72317d6a4f5fee68a39fa31a0d36c56a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/da/ee/daee2fcb1effb99d209d4792514f8eb8.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||82e821b3797b8e8dcde53407733c8b66	["c622fd2c11223583a67eae31491673ac", "7b051195e020e6c5ae2075494827e531", "72317d6a4f5fee68a39fa31a0d36c56a"]
sorl-thumbnail||image||9a1edcd737f6795a10a8b76baa537cd6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/94/ab/94abd8e3ce65ae71bc00fa3e38c951c0.jpg", "size": [200, 200]}
sorl-thumbnail||image||06bd17ec17dc95459057455d7c07bc0d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c6/d2/c6d2b8e38961a47b9fb2d0370f3b0481.jpg", "size": [200, 200]}
sorl-thumbnail||image||fd9a8de6fea4d2f14461010d32210d6d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/38/73/38737f07e08af85acee3c8f3ab21162c.jpg", "size": [200, 200]}
sorl-thumbnail||image||b050e1efc169be7365cf44d03280ae90	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b8/12/b812fc2e2447aa023015eb6d157aecd9.jpg", "size": [200, 200]}
sorl-thumbnail||image||1d8f532a670ff644758713dec0fcb086	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/50/d9/50d9ff97af7699b615646a44356c116a.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||a7e2929d0dee6a7649de707ffe07156b	["00fadf797ccad558354bb64f574ac815", "1d8f532a670ff644758713dec0fcb086", "f7fe764442e0f675ff3535d863a47f8f"]
sorl-thumbnail||image||5ee3af9af7f38b46a7463a64ea4b19fb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1c/ad/1cadb992eadbda355ecdb7125c45591c.jpg", "size": [200, 200]}
sorl-thumbnail||image||eec2425de3d825b2dadd98f22d7d742c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/03/a3/03a335b9e5e52ceb63b86bf293edd087.jpg", "size": [200, 200]}
sorl-thumbnail||image||f07d982e98672bbde01627e298df149c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/9f/c7/9fc7083ce7b593b4d286b128c7f9139e.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||bed9c6c75cb732d6e74fcc8604e899db	["91c858b11ffbe62e30ba052d92ced1f5", "b26717dc646dd7bdd669298ed1bcac50"]
sorl-thumbnail||image||f1500c237a4b6a2ddb190eea8ed419ee	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6b/75/6b7584281d4e739c370ed314ea502aa5.jpg", "size": [200, 200]}
sorl-thumbnail||image||057009a3b6af532939be315cbd52fa54	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/09/3a/093add810cbc94b6932e7ccb0ed0f7d8.jpg", "size": [200, 200]}
sorl-thumbnail||image||e8c93f528fc666cfff7669c37b34e7d1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/41/b6/41b63a0431b26fd381c11b51256f4e84.jpg", "size": [200, 200]}
sorl-thumbnail||image||a7fe400ae7c28f2f45cd2e37be2f0df8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/cd/76/cd766e7d9235d3a5184ca7eed57b7d57.jpg", "size": [200, 200]}
sorl-thumbnail||image||e5e5dee0e80ebb85a1af0b770786eef7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/80/20/8020765305f7a4e25250d3c9012433b5.jpg", "size": [200, 200]}
sorl-thumbnail||image||75fdced91ce79be1caa5502647e2ce51	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/a/GAPCandOtrip2009_543.jpg", "size": [819, 614]}
sorl-thumbnail||image||023a20a4c7a2202f6d78f14cd275f6eb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/8b/fb/8bfbf424f78e328b56be804dabdfcd97.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||75fdced91ce79be1caa5502647e2ce51	["023a20a4c7a2202f6d78f14cd275f6eb"]
sorl-thumbnail||image||c1ed1243a0b55d85746ac768df0506d7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/8f/06/8f068735a1803117b7ebae7c537f0cad.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||d4177310a5f11ffa88fed96fc14b2ba0	["c07fa5a6fe38448fb72fc31a7bf84a86", "b0124f1ee7209934e0c4a9e6eec89715", "c1ed1243a0b55d85746ac768df0506d7"]
sorl-thumbnail||image||5bf6143a91346e783265b0a945bbddb1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/a/GAPCandOtrip2009_543_1.jpg", "size": [819, 614]}
sorl-thumbnail||image||f04099a018a325d9764c1a7ca9d84fb3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/67/96/6796abf770c8cf9cb022e07494a98cb6.jpg", "size": [130, 130]}
sorl-thumbnail||image||b85470706c774a0d5eee7d20075d5a23	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/4a/2f/4a2fedb2f9be1654a333d38bdd593a2f.jpg", "size": [50, 50]}
sorl-thumbnail||image||274a26c7be9fb22c96d794d3360b420f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/a/greg.jpg", "size": [604, 453]}
sorl-thumbnail||image||688ff9abf2ad9594a5c6d5f746bee2a6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/dc/cd/dccda122df88d020524388c3f888eeba.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||274a26c7be9fb22c96d794d3360b420f	["688ff9abf2ad9594a5c6d5f746bee2a6"]
sorl-thumbnail||image||68ffb6febbf83df64ea675f1a0c09a03	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/07/9f/079f5a1746d0e25f8a9c74ebf041c61b.jpg", "size": [20, 20]}
sorl-thumbnail||thumbnails||5bf6143a91346e783265b0a945bbddb1	["68ffb6febbf83df64ea675f1a0c09a03", "f04099a018a325d9764c1a7ca9d84fb3"]
sorl-thumbnail||image||f0c0a08138965f665b765f7a85522eb6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1b/6c/1b6ca5e3f9e33322b5de11af2a93463a.jpg", "size": [20, 20]}
sorl-thumbnail||thumbnails||60bf1cd8b256ccb4fa72b1f26440655b	["f0c0a08138965f665b765f7a85522eb6", "2a06635f158808b575e061325c9c8af8"]
sorl-thumbnail||image||197e189b4c82c94fd09b79cbf983f6a1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3b/48/3b489a6b7239a56a33fe6c430e41aaeb.jpg", "size": [200, 200]}
sorl-thumbnail||image||cfe41f6721aa98abc25947bc08949334	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/a/app-icon-square.png", "size": [325, 325]}
sorl-thumbnail||image||649f9e5fd7de3b849ec3d221473aa768	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/dc/3d/dc3db28b0c786d96c749bdd0c8b24959.jpg", "size": [130, 130]}
sorl-thumbnail||image||3774d83f6fdf565f48ecdd522a0e3e4a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6d/8b/6d8bce01693bb40c4ca5cde440d1178e.jpg", "size": [20, 20]}
sorl-thumbnail||thumbnails||cfe41f6721aa98abc25947bc08949334	["649f9e5fd7de3b849ec3d221473aa768", "3774d83f6fdf565f48ecdd522a0e3e4a"]
sorl-thumbnail||image||88341621f63890d9cf3b70559cda4ad3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/261079_371455053761_598444707_n.jpg", "size": [180, 174]}
sorl-thumbnail||image||23290ea21797840399b9d56ef17b32bd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/64/6e/646e453052252723e0880fa4d08dc8db.jpg", "size": [130, 130]}
sorl-thumbnail||image||31a8cb221972fa3ae4df4bb2f244a18a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/5d/2c/5d2c1a823f904c1c38e3e1b025291527.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||48b7253f03666fc2baac4df991733fcd	["31a8cb221972fa3ae4df4bb2f244a18a", "69f96849e6c2eca99195b8c27f2abe8f", "de045966a76201dc53011655ac1f8815"]
sorl-thumbnail||image||496e6fd7a0562b8b010c0610f1f29eb9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/157904_414026435290572_113862470_n.jpg", "size": [180, 99]}
sorl-thumbnail||image||027f368059295c42878b8060c20e992b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/0c/e5/0ce557e881cbc8da77e03e52864c69fa.jpg", "size": [50, 50]}
sorl-thumbnail||image||5a8fb5b61de95743dce31add5d6bf25d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/16/0e/160eb514fc8c4de4a1cc5fd089dfaabf.jpg", "size": [130, 130]}
sorl-thumbnail||image||82465afc65658d962d4229346736f183	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c6/f0/c6f086f1ea386ab76603f0c289a24a52.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||496e6fd7a0562b8b010c0610f1f29eb9	["5a8fb5b61de95743dce31add5d6bf25d", "82465afc65658d962d4229346736f183", "027f368059295c42878b8060c20e992b"]
sorl-thumbnail||image||b26717dc646dd7bdd669298ed1bcac50	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/dc/ad/dcadc96a349857520bccd49212771b2b.jpg", "size": [20, 20]}
sorl-thumbnail||image||89ac99f1c2b83a897e5a65eb9dc89c57	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/7b/d7/7bd7bcda8619eafb06ce1d020f246411.jpg", "size": [80, 80]}
sorl-thumbnail||image||303dcc3345b34c17b131c6897ebde4d2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/25/de/25de3dc5ea209d80cd32e2f031c4a12b.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||3ebe5b0298f66414f9a49a5ec8d2b4fa	["303dcc3345b34c17b131c6897ebde4d2"]
sorl-thumbnail||image||73c75fce899cb9a08fccb67ad5f14304	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/Pitt.jpg", "size": [180, 180]}
sorl-thumbnail||image||d33530c2378cdaeb8530682c126eb539	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c8/85/c8853da70b0d0b5c084c16ba2bd6be2c.jpg", "size": [50, 50]}
sorl-thumbnail||image||bea521b1e118107b657c61a7a4392739	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/7d/52/7d5271a9c3341d55e0923c6d44021e36.jpg", "size": [130, 130]}
sorl-thumbnail||image||18a92aacee6a6f1c200a53209791c231	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/a/316752_10150364109521797_505861796_7934370_1084012133_n.jpg", "size": [640, 480]}
sorl-thumbnail||image||14d6b8d78d67785f58475628d039d1a0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/66/38/6638ed673fa0c047174e341a47abba1f.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||73c75fce899cb9a08fccb67ad5f14304	["14d6b8d78d67785f58475628d039d1a0", "d33530c2378cdaeb8530682c126eb539", "bea521b1e118107b657c61a7a4392739"]
sorl-thumbnail||image||a8e2661f33caa6fcd5436a75c77d1f31	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/Pitt_1.jpg", "size": [180, 180]}
sorl-thumbnail||image||b4eae6322884a43c315c067c92981ce9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/32/25/322550f49f022e385b378edbfbadcf45.jpg", "size": [50, 50]}
sorl-thumbnail||image||24bc7df24399bb24098c936f8b791884	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/29/66/29668e3d4cba2c8e3c7a451d9fae253f.jpg", "size": [130, 130]}
sorl-thumbnail||image||fca544caa29edabbf7e485fa16172d0a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/29/2b/292b1493aefa68da1da6794a894eaf80.jpg", "size": [130, 130]}
sorl-thumbnail||image||1130445c1e3ffa58f63ab6982e40788a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/Pitt_2.jpg", "size": [180, 180]}
sorl-thumbnail||image||841258797ad6a97c1f3a5b96864c46bb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6f/df/6fdfa6706b6e5e466e3453dc2dffbb5b.jpg", "size": [50, 50]}
sorl-thumbnail||image||dc8508610136bd3327802ba3cccf118d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b9/88/b98882791d14101acc549c885a6577bc.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||18a92aacee6a6f1c200a53209791c231	["fca544caa29edabbf7e485fa16172d0a"]
sorl-thumbnail||image||7a2e8d661823682fd8cbd0ebe0d6c1eb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/24/93/2493ed4878239ae94432d9cc71d06695.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||a8e2661f33caa6fcd5436a75c77d1f31	["7a2e8d661823682fd8cbd0ebe0d6c1eb", "24bc7df24399bb24098c936f8b791884", "b4eae6322884a43c315c067c92981ce9"]
sorl-thumbnail||image||ef3373ba50c3b03a2c67fba1264479c1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/96/4f/964fa2d909736eaa945bedcc0b499f2e.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||1130445c1e3ffa58f63ab6982e40788a	["dc8508610136bd3327802ba3cccf118d", "841258797ad6a97c1f3a5b96864c46bb", "ef3373ba50c3b03a2c67fba1264479c1"]
sorl-thumbnail||image||950907c02fd85b2dfd55fd3d8cce5d84	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/a/P1050012.JPG", "size": [3264, 1840]}
sorl-thumbnail||image||3f1e2950fa538e6e14d21a2c82ff76a1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/84/b8/84b8c2a26292ae1b449627768e79b944.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||950907c02fd85b2dfd55fd3d8cce5d84	["3f1e2950fa538e6e14d21a2c82ff76a1"]
sorl-thumbnail||image||d0211141a35e4f9e14b064d76e171f6a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f8/0f/f80f6bad6569ad7a34d28dc637f5f81a.jpg", "size": [80, 80]}
sorl-thumbnail||image||75a82969d84092ad7e4f0c0a0fca508b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b4/d5/b4d515733b398619a29bf9b5818bf782.jpg", "size": [110, 80]}
sorl-thumbnail||thumbnails||935850d633b8f1d8eedcb10c0ddef84c	["e0a5112735ef93b6e3b1d19f810106fd", "5035b5762b512eb412970f23c421c897", "75a82969d84092ad7e4f0c0a0fca508b", "007d4f81792daa9bce5f6c19c07ae811"]
sorl-thumbnail||image||2bfb7b70f1613e80d4b152ff35a55745	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/34/d8/34d8c167c2d1025880cdf0fc71287e24.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||6aa00fd975862640d7df757c953c9dfd	["2bfb7b70f1613e80d4b152ff35a55745", "a1fdb470d96650c2aa271b5356e30309", "986e4b661324bd5564f149469bc2050a"]
sorl-thumbnail||image||e2724d0ca61e44d8f7c3978cd1f68fd3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/May_Market_Left-PS.jpg", "size": [300, 185]}
sorl-thumbnail||image||cb91b2e3041be2cd2f659fa866703ad1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/bb/9e/bb9e791ca47537860aad08995759e903.jpg", "size": [50, 50]}
sorl-thumbnail||image||5ccce3425596633ee7e4592ed9719e88	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/34/7c/347c7384e4654dfa27cdc99aa44aea9b.jpg", "size": [200, 200]}
sorl-thumbnail||image||aeace57956a177771260323dccda165e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/54/3c/543c5733222b543f0414efa42d5ef155.jpg", "size": [130, 130]}
sorl-thumbnail||image||38389535133c82ac3b6f7df0ff1342ee	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ce/e2/cee205e7096c6d70db34ffbf4bc78802.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||e2724d0ca61e44d8f7c3978cd1f68fd3	["aeace57956a177771260323dccda165e", "5ccce3425596633ee7e4592ed9719e88", "cb91b2e3041be2cd2f659fa866703ad1"]
sorl-thumbnail||image||80e971586a811c8d84801d8072fee4b7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/Disc._Garden_Image.jpg", "size": [200, 135]}
sorl-thumbnail||image||a93946768685c72df2dda7edd75533f7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/96/9a/969a7eb45f3c8d4f26e9bea3d70e72b9.jpg", "size": [50, 50]}
sorl-thumbnail||image||8a44ece4845053cafda837e2b4d61402	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/60/0c/600c1506d7ee2d7663f2c46f0c7850d2.jpg", "size": [130, 130]}
sorl-thumbnail||image||39f64146dea2ad6170da3fac489a16a3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/17/b9/17b9f8c40a9b3d67cfdb070e98a5b82e.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||80e971586a811c8d84801d8072fee4b7	["39f64146dea2ad6170da3fac489a16a3", "a93946768685c72df2dda7edd75533f7", "8a44ece4845053cafda837e2b4d61402"]
sorl-thumbnail||image||dcbb39961ae54076530ed3d5e5c92029	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/Schenley_Plaza.JPG", "size": [655, 346]}
sorl-thumbnail||image||a49962933f760c9f313c1e16cdd2c7f9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ca/12/ca12e07fcc80668cab64cc1ae5814b23.jpg", "size": [50, 50]}
sorl-thumbnail||image||3c74b37d6cf25d1968457164e3b7ef9f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/Schenley_Plaza_5.JPG", "size": [655, 346]}
sorl-thumbnail||image||3d8da924260e218d153af4ea202fb0b8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/53/8b/538b11ad76feddd42ad35e4fc5780c3d.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||dcbb39961ae54076530ed3d5e5c92029	["a49962933f760c9f313c1e16cdd2c7f9", "3d8da924260e218d153af4ea202fb0b8"]
sorl-thumbnail||image||2b3f7a14ca5bbb4de34a31d45236c684	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/Childrens_Festival.jpg", "size": [1636, 1183]}
sorl-thumbnail||image||32962abbe5255f13e71d83d81ef6f521	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/03/c5/03c59275799aecec2355734f8cc38071.jpg", "size": [50, 50]}
sorl-thumbnail||image||2be71cf837273745c46dadaae8476c59	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/7d/ab/7dab15d23b8997dc6e0652648e6edc75.jpg", "size": [130, 130]}
sorl-thumbnail||image||0aed51d400c8e2580d8a0a0060e7980f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c3/9f/c39f0ea3439136e8a1049527c7048228.jpg", "size": [130, 130]}
sorl-thumbnail||image||bc3f75214496a09a65b46d6ed88ce3a6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/eb/4f/eb4f51265608134c77a373d70b5f73c4.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||2b3f7a14ca5bbb4de34a31d45236c684	["32962abbe5255f13e71d83d81ef6f521", "2be71cf837273745c46dadaae8476c59", "bc3f75214496a09a65b46d6ed88ce3a6"]
sorl-thumbnail||image||579e76e5f72d937285ff2677bcfce7f2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/Schenley_Plaza.JPG", "size": [655, 346]}
sorl-thumbnail||image||e65c08785c1addde00aa888eb8668e20	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/31/c5/31c5028aaf7b0606612484b528bd2086.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||ea1cd87199fae1ffb08c3f64f0af1fdb	["f5d73afd785aa85f7faf45013353d667", "4ceff40f23e9a38ebe26d8ff23042333", "e282fdc309a7b07554f6ae1f36348ef2"]
sorl-thumbnail||image||1c3ebd6fa070770fd57faf5cd191b30a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/a6/01/a601936085ae95bdc2f5899587cb421b.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||3c74b37d6cf25d1968457164e3b7ef9f	["3cc58a3fa067704f668a8ffa4df3207d", "e08a5d0d029221ea8fb32f224e027d67", "58af0d0d20d95179d236bffa6b4eb53f"]
sorl-thumbnail||image||ba1a16b9f69e886afed3405138261dcd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/Schenley_Plaza_1.JPG", "size": [655, 346]}
sorl-thumbnail||image||68a1ce93a706a958042c6e6b63e5fd1b	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/59/3f/593fa3c579daa7167503ba32ca050dfc.jpg", "size": [50, 50]}
sorl-thumbnail||image||bf4cee2bece9ca5b737d759560a4bf0d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/36/c0/36c018cf0f87dae7d60c1aae92ab67ba.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||6b9550d05e7669e80849d998be0c26e3	["7392e04d39de9c7e57d2809a6a67e145", "0aed51d400c8e2580d8a0a0060e7980f", "b6be9c3eb64a21e6a149ff5efd48de8f"]
sorl-thumbnail||image||6b9550d05e7669e80849d998be0c26e3	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/Schenley_Plaza_2.JPG", "size": [655, 346]}
sorl-thumbnail||image||7392e04d39de9c7e57d2809a6a67e145	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/49/0f/490f65e691720d7674a131dab9081ad2.jpg", "size": [50, 50]}
sorl-thumbnail||image||ea1cd87199fae1ffb08c3f64f0af1fdb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/Schenley_Plaza_3.JPG", "size": [655, 346]}
sorl-thumbnail||image||f5d73afd785aa85f7faf45013353d667	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/7a/61/7a6182324d7868b4ac764e081a68c4ca.jpg", "size": [50, 50]}
sorl-thumbnail||image||4ceff40f23e9a38ebe26d8ff23042333	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/e5/f0/e5f08459a16d0720d82d1d4cafcc22c1.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||579e76e5f72d937285ff2677bcfce7f2	["e65c08785c1addde00aa888eb8668e20", "1c3ebd6fa070770fd57faf5cd191b30a", "8c050d168db95949b6cb0303eb5962f4"]
sorl-thumbnail||image||aeba5bea62a46cac7b1cba1be9d1a737	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/Schenley_Plaza_4.JPG", "size": [655, 346]}
sorl-thumbnail||image||508517a11e300f0e0d6bf73d3a9fbf03	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ee/c3/eec3d48a891290b53f3f4d25533d3872.jpg", "size": [50, 50]}
sorl-thumbnail||image||58f44d7d8a12a71ad2419712c63e79bb	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b6/80/b68020a99086daef584d5204fdc1221d.jpg", "size": [130, 130]}
sorl-thumbnail||image||58af0d0d20d95179d236bffa6b4eb53f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c4/3e/c43eb2c8a5b6d82658ea6497f5962d52.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||ba1a16b9f69e886afed3405138261dcd	["78e296c4ac3c251ae3ba0d2d26f9a452", "68a1ce93a706a958042c6e6b63e5fd1b", "bf4cee2bece9ca5b737d759560a4bf0d"]
sorl-thumbnail||image||e08a5d0d029221ea8fb32f224e027d67	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/48/91/48915fb9d3f8484598db64c01b6c1415.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||aeba5bea62a46cac7b1cba1be9d1a737	["508517a11e300f0e0d6bf73d3a9fbf03", "93bee4a17bf621e3df5d069915e2ce90", "58f44d7d8a12a71ad2419712c63e79bb"]
sorl-thumbnail||image||e42c990da1364578fc29a5bd70b538f9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/188154_38014611787_6126162_n.jpg", "size": [180, 180]}
sorl-thumbnail||image||699e28f3453810ab7e3b0e24c3110c39	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d6/b4/d6b4ed75702495b5cc7fd50f2790de62.jpg", "size": [50, 50]}
sorl-thumbnail||image||a6c1ad8388c62b8c3e7a55efcbb6ed91	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/5a/02/5a02e2e94c086034460353d99be1104a.jpg", "size": [130, 130]}
sorl-thumbnail||image||0d40893b501a00e5a85dfe6b883633e9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/9f/fa/9ffa1338a58309b924b24d08a3c64c36.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||9c53a58111112cff628f80aaf35d8e38	["1614a2c74f7a7e56e5dc6b0e9ac58d33", "58739496566bf4a64a83851ae0d3c8db", "d84039a6401220f26593f3798e2d7aa7"]
sorl-thumbnail||image||8233527ee410eb464a98cfd7b5d306bd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/157989_73877691965_505892_n_2.jpg", "size": [180, 180]}
sorl-thumbnail||image||58747eaf88ac8be8b265f89f1c81e7c1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/88/31/88313ec4321884ba1da14fca787b0912.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||b61e627db49eb7360e4f81903a2cef0f	["789c3892c079d93f2a8b69c53be82fee", "5d9782448bb42bc9cf6606e19854d3e8", "f799f61da9ee098648e93df90198e6dc"]
sorl-thumbnail||image||62ab42d22ddbe6c7ca037793f3507927	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b8/72/b8729b3a745cd36441ccaa3d5a1a7e5a.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||20b4e77563b44e7895242ac8d6d5a3e9	["a6c1ad8388c62b8c3e7a55efcbb6ed91", "60d3edd3307ab16358f726d81aa61463", "b666620d9d2bae47662ccd746ee53fb2"]
sorl-thumbnail||image||9c53a58111112cff628f80aaf35d8e38	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/Soldiers_and_Sailors.jpg", "size": [281, 276]}
sorl-thumbnail||image||1614a2c74f7a7e56e5dc6b0e9ac58d33	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/53/ce/53cee608572283ae36bdc882f62008f5.jpg", "size": [50, 50]}
sorl-thumbnail||image||d84039a6401220f26593f3798e2d7aa7	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c1/12/c112318e7d87ec80bf2f875c79ca43be.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||b8b304aa968f1636296bf943b937843f	["466ae2963f477b46ea9e0358d83551fd", "ca077236a0a5835dce7a86ffb64e3b22", "89d086a4321eb7f4108dbad7a0d06e95"]
sorl-thumbnail||image||be7de77a26a79d5830c612e097001805	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/WQED.jpg", "size": [511, 510]}
sorl-thumbnail||image||eb38faae9f0c102fba996939ab7ddbd6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/63/b2/63b2346763012e6ff314a1e2220b0e89.jpg", "size": [50, 50]}
sorl-thumbnail||image||b8b304aa968f1636296bf943b937843f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/157989_73877691965_505892_n_4.jpg", "size": [180, 180]}
sorl-thumbnail||image||7b6c88a0225f3b0048353969c4fd680c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/68/b2/68b2c204b8e3b81806e3f204880774d3.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||be7de77a26a79d5830c612e097001805	["eb38faae9f0c102fba996939ab7ddbd6", "7b6c88a0225f3b0048353969c4fd680c"]
sorl-thumbnail||image||b61e627db49eb7360e4f81903a2cef0f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/WQED.jpg", "size": [511, 510]}
sorl-thumbnail||image||789c3892c079d93f2a8b69c53be82fee	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/2c/ac/2cac05a10d93a957c32611383756ef9e.jpg", "size": [50, 50]}
sorl-thumbnail||image||5d9782448bb42bc9cf6606e19854d3e8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/4c/18/4c182a3f578c68c2545e8974fdfb8e04.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||01f894427c638adb1f0d1e1bbbea27b4	["e6ab83c6cc1d5431d7d96b5c6f281d43", "d1977d3e6b411d8e3d02e07d6f09d2fc", "17921083c9e5639b61a0716c63e29902"]
sorl-thumbnail||image||20b4e77563b44e7895242ac8d6d5a3e9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/157989_73877691965_505892_n_3.jpg", "size": [180, 180]}
sorl-thumbnail||image||b666620d9d2bae47662ccd746ee53fb2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d1/39/d13991045a917c6f9e4ab39fb80abba7.jpg", "size": [50, 50]}
sorl-thumbnail||image||49ed9e6f7e92dec3f5ab4b80130365d9	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/CMU_Logo_5.jpg", "size": [180, 179]}
sorl-thumbnail||image||89d086a4321eb7f4108dbad7a0d06e95	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/fb/f0/fbf0311ded0ee241c25f9736ed732e45.jpg", "size": [50, 50]}
sorl-thumbnail||image||ca077236a0a5835dce7a86ffb64e3b22	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/21/2d/212dc9b9c795dc056a004c083a4b0cea.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||49ed9e6f7e92dec3f5ab4b80130365d9	["390201556b51c3950c4aa46fe66bb91d", "031bc89012f7f1eb4f0b113f38815531", "783a0abad834c44513308e1614e4d5fc"]
sorl-thumbnail||image||01f894427c638adb1f0d1e1bbbea27b4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/Soldiers_and_Sailors_1.jpg", "size": [281, 276]}
sorl-thumbnail||image||17921083c9e5639b61a0716c63e29902	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/db/10/db10ae9bf20f789599f7797186040da4.jpg", "size": [50, 50]}
sorl-thumbnail||image||d1977d3e6b411d8e3d02e07d6f09d2fc	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/da/05/da05b977c0bdc20ad3d034e4adc405fd.jpg", "size": [130, 130]}
sorl-thumbnail||image||031bc89012f7f1eb4f0b113f38815531	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/59/56/5956d44a9bf0d66d19147c30f7cecb87.jpg", "size": [50, 50]}
sorl-thumbnail||image||783a0abad834c44513308e1614e4d5fc	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1e/a0/1ea06766033cb15348b059c9ee1cd49d.jpg", "size": [130, 130]}
sorl-thumbnail||image||19145d374274c4fc21c88035c979581e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/be/e8/bee81ffb8087bbe92bd7aeb71f84500f.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||e42c990da1364578fc29a5bd70b538f9	["0d40893b501a00e5a85dfe6b883633e9", "699e28f3453810ab7e3b0e24c3110c39", "19145d374274c4fc21c88035c979581e"]
sorl-thumbnail||image||78e296c4ac3c251ae3ba0d2d26f9a452	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/85/b3/85b3e2d61ec7a6c053e5cb5706737845.jpg", "size": [200, 200]}
sorl-thumbnail||image||58739496566bf4a64a83851ae0d3c8db	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f5/64/f56473cea13443c9cba068fad448e4a3.jpg", "size": [200, 200]}
sorl-thumbnail||image||466ae2963f477b46ea9e0358d83551fd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/93/88/9388dac41e369abdddb05a64564459e6.jpg", "size": [200, 200]}
sorl-thumbnail||image||da413b4d064619c5e1328895bad132c8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/41/2c/412c8ab60fcd1375c83e80592cad999d.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||8233527ee410eb464a98cfd7b5d306bd	["62ab42d22ddbe6c7ca037793f3507927", "da413b4d064619c5e1328895bad132c8", "58747eaf88ac8be8b265f89f1c81e7c1"]
sorl-thumbnail||image||60d3edd3307ab16358f726d81aa61463	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/40/47/4047b4726b0e63e1f44109d75dcea9c0.jpg", "size": [200, 200]}
sorl-thumbnail||image||b6be9c3eb64a21e6a149ff5efd48de8f	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d3/51/d351b9a399104213244dbb178723d774.jpg", "size": [200, 200]}
sorl-thumbnail||image||f799f61da9ee098648e93df90198e6dc	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/4f/0f/4f0f920a10dbbcc3c8dab592a2d36f7e.jpg", "size": [200, 200]}
sorl-thumbnail||image||e282fdc309a7b07554f6ae1f36348ef2	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/5f/6c/5f6c8e8c0c4fc8b887ef5dfc46e1579c.jpg", "size": [200, 200]}
sorl-thumbnail||image||e6ab83c6cc1d5431d7d96b5c6f281d43	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/7e/7c/7e7ce8bea27db2094cba80507f84bc6c.jpg", "size": [200, 200]}
sorl-thumbnail||image||a5bb99c1380f508d6e1eb922a8ac33a1	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/Degas_Dancers.JPG", "size": [900, 640]}
sorl-thumbnail||image||7096029db65ec168a8e13f237db3d788	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/41/80/41804d08c0614b49aa9c7749a42589c4.jpg", "size": [50, 50]}
sorl-thumbnail||image||79458296bebeb7150b70bac398732150	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/41/98/4198606b9e078520d0867f3f5bd683af.jpg", "size": [130, 130]}
sorl-thumbnail||image||45f143c1a36069021ea9a4454b321093	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/47/23/47233732192b0b0dc8257cf56eeb1dc0.jpg", "size": [107, 80]}
sorl-thumbnail||image||8c050d168db95949b6cb0303eb5962f4	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/2f/79/2f7926a8e2de245e8ee1fbb17232a8ef.jpg", "size": [200, 200]}
sorl-thumbnail||image||3cc58a3fa067704f668a8ffa4df3207d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/4e/74/4e74b861edfa21f248f75d2d5bdff8a7.jpg", "size": [200, 200]}
sorl-thumbnail||image||05008bd5311a5d1f7bca60dff103a152	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6d/a4/6da4d80b672199b62ea9ccf5512238ab.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||a5bb99c1380f508d6e1eb922a8ac33a1	["7096029db65ec168a8e13f237db3d788", "05008bd5311a5d1f7bca60dff103a152", "79458296bebeb7150b70bac398732150"]
sorl-thumbnail||image||93bee4a17bf621e3df5d069915e2ce90	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/df/b1/dfb18ca6830c9f609f19732f3c7204aa.jpg", "size": [200, 200]}
sorl-thumbnail||image||390201556b51c3950c4aa46fe66bb91d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/fe/17/fe1737b0535dc4ee4f09cfc73c60124f.jpg", "size": [200, 200]}
sorl-thumbnail||image||dd5fb8f8c2392fed295c0ccff2f30291	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/IMGP1100.JPG", "size": [3648, 2736]}
sorl-thumbnail||image||06dd6b2d344459495a18f8891a54bc1d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/cf/c4/cfc406640e6c4a033b1d0d81f9ab5c8b.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||dd5fb8f8c2392fed295c0ccff2f30291	["06dd6b2d344459495a18f8891a54bc1d", "45f143c1a36069021ea9a4454b321093", "29d8d91f4749b36b7abea4ae4d60c5b0"]
sorl-thumbnail||image||29d8d91f4749b36b7abea4ae4d60c5b0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/60/82/60820fd40c3d6620cfd7d7656ca984d8.jpg", "size": [130, 130]}
sorl-thumbnail||image||e83713754f994c3438ecc3842ccf7516	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/LOGO_003.JPG", "size": [262, 393]}
sorl-thumbnail||image||7f350d8adb846782f0a0959006aa07fd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/3a/7a/3a7aef714744fade92b26f61392672c2.jpg", "size": [50, 50]}
sorl-thumbnail||image||df546229ce5c850cdd2f560e236fbdd0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/Degas_Dancers_1.JPG", "size": [900, 640]}
sorl-thumbnail||image||faa221832655be70de30022d8eb72080	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1b/f2/1bf207982fc14c0978189ae5ff3b1da0.jpg", "size": [130, 130]}
sorl-thumbnail||image||fb111a0cd17fd8a22da7d65fe7fde1fd	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/40/e4/40e46bd8ade83b72b343c09e5792004b.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||e83713754f994c3438ecc3842ccf7516	["faa221832655be70de30022d8eb72080", "7f350d8adb846782f0a0959006aa07fd", "fb111a0cd17fd8a22da7d65fe7fde1fd"]
sorl-thumbnail||image||dc92eaa45bc300f135bb8141470b534c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/18/ca/18ca6535bd32402a04d4338568e47f16.jpg", "size": [50, 50]}
sorl-thumbnail||image||d3cd53b1f37ed6dd92f288ae5f73d92c	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/05/f1/05f1a886ab79f16d67bb068f0917e41f.jpg", "size": [130, 130]}
sorl-thumbnail||image||65368ec59b077a43ec16e5ca9a3d84a8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/eb/15/eb157377d62440987bae71d82592de74.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||df546229ce5c850cdd2f560e236fbdd0	["dc92eaa45bc300f135bb8141470b534c", "65368ec59b077a43ec16e5ca9a3d84a8", "d3cd53b1f37ed6dd92f288ae5f73d92c"]
sorl-thumbnail||image||87262f29154e9fa12606d4be1926545a	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/taste.tif", "size": [511, 700]}
sorl-thumbnail||image||1291c5217b9ea3ce41e487fccecfb6c6	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/c8/80/c880ede4b27a7a34a623d645f08c8c90.jpg", "size": [50, 50]}
sorl-thumbnail||image||bac2880f57d91e10de294adab880163e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/72/52/725200af72453cb041ece082ae02cc86.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||87262f29154e9fa12606d4be1926545a	["bac2880f57d91e10de294adab880163e", "1291c5217b9ea3ce41e487fccecfb6c6"]
sorl-thumbnail||image||8161ad0286edc5aa0784e00ba9047af8	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/p/TheO.jpg", "size": [500, 333]}
sorl-thumbnail||image||6e9a908f105e9f462cd733492ec09557	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/bb/18/bb1890663a4fca60133299777143e665.jpg", "size": [50, 50]}
sorl-thumbnail||image||87797ebee1cbdf52a48b0f2f3704410d	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/bb/41/bb4137be8fcf2304b3ed2e41477881d5.jpg", "size": [130, 130]}
sorl-thumbnail||thumbnails||8161ad0286edc5aa0784e00ba9047af8	["87797ebee1cbdf52a48b0f2f3704410d", "6e9a908f105e9f462cd733492ec09557"]
sorl-thumbnail||image||56252e1e5fc50674b6f803b576571ba0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/Penn_Future.jpg", "size": [279, 227]}
sorl-thumbnail||image||b946171613ec255e722b7ecc79846c36	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/d2/51/d25188d76bb69aa3256bb661ba1b2c9e.jpg", "size": [50, 50]}
sorl-thumbnail||image||83eab7446642ded002722bc881cca0e0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/6d/c7/6dc7504a503700d3e0b60b6d6dad5807.jpg", "size": [130, 130]}
sorl-thumbnail||image||bf338a0df6737f647a310af454b11704	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f2/20/f220bb7c1d74c0ca589db4f2b5726f89.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||56252e1e5fc50674b6f803b576571ba0	["83eab7446642ded002722bc881cca0e0", "bf338a0df6737f647a310af454b11704", "b946171613ec255e722b7ecc79846c36"]
sorl-thumbnail||image||618ab4dfdcc0e3a7da417875ee52f145	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/banner_nodate.jpg", "size": [626, 150]}
sorl-thumbnail||image||7c991bab21e8adba3faffd9fe4d69f86	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f7/78/f77856d76bf6fe9670569e452a514151.jpg", "size": [50, 50]}
sorl-thumbnail||image||383b2995159269783189083178706d64	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/1f/14/1f148f68a3b4519fc579dc5c463eca0c.jpg", "size": [130, 130]}
sorl-thumbnail||image||da85cb2153a3abc9829439e35766b10e	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/f5/6e/f56e7cda7fecfa152f03007f87fabac2.jpg", "size": [130, 130]}
sorl-thumbnail||image||d26f050b0c44f2385482f7d1abb11611	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/05/a3/05a363337d384436ab1828abc2bbed7e.jpg", "size": [200, 200]}
sorl-thumbnail||thumbnails||618ab4dfdcc0e3a7da417875ee52f145	["da85cb2153a3abc9829439e35766b10e", "d26f050b0c44f2385482f7d1abb11611", "7c991bab21e8adba3faffd9fe4d69f86"]
sorl-thumbnail||image||79233d8b132dc927398b8b277726b4c0	{"storage": "django.core.files.storage.FileSystemStorage", "name": "img/e/Oakland.jpg", "size": [430, 336]}
sorl-thumbnail||image||0f860172d2b7b989bb75f99e09d4bd33	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/98/30/9830a6990f04c374b9c945ec3ffd29da.jpg", "size": [50, 50]}
sorl-thumbnail||thumbnails||79233d8b132dc927398b8b277726b4c0	["0f860172d2b7b989bb75f99e09d4bd33", "ac88571c74efdbf780609b9856ad9b06", "383b2995159269783189083178706d64"]
sorl-thumbnail||image||ac88571c74efdbf780609b9856ad9b06	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/8c/a8/8ca887199281b0fe80e3bb57f34a329b.jpg", "size": [200, 200]}
sorl-thumbnail||image||fee913e821d3f842464b24ecee6aa916	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/ae/32/ae3263edacadad4cf682faa9a69f801d.jpg", "size": [110, 80]}
sorl-thumbnail||thumbnails||72ae94434fdb3e331e718422f19b4ae2	["9cc84c9a224d1725c038d010468012a1", "cc824db1091bb8f4b148a1663428ab6d", "fee913e821d3f842464b24ecee6aa916", "6812fa6549777735adb6a12cc2baf31a"]
sorl-thumbnail||image||aad934347f24d623a10ba4b7a51b7d21	{"storage": "django.core.files.storage.FileSystemStorage", "name": "cache/b7/f2/b7f25d35d40af0d39d1e297ee0cb1b8a.jpg", "size": [83, 80]}
sorl-thumbnail||thumbnails||88341621f63890d9cf3b70559cda4ad3	["aad934347f24d623a10ba4b7a51b7d21", "b85470706c774a0d5eee7d20075d5a23", "23290ea21797840399b9d56ef17b32bd"]
\.


--
-- Name: accounts_betamember_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY accounts_betamember
    ADD CONSTRAINT accounts_betamember_pkey PRIMARY KEY (id);


--
-- Name: accounts_organization_adm_organization_id_59bd672eb8f326c3_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY accounts_organization_administrators
    ADD CONSTRAINT accounts_organization_adm_organization_id_59bd672eb8f326c3_uniq UNIQUE (organization_id, user_id);


--
-- Name: accounts_organization_administrators_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY accounts_organization_administrators
    ADD CONSTRAINT accounts_organization_administrators_pkey PRIMARY KEY (id);


--
-- Name: accounts_organization_est_organization_id_4895d2ddfdf4a120_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY accounts_organization_establishments
    ADD CONSTRAINT accounts_organization_est_organization_id_4895d2ddfdf4a120_uniq UNIQUE (organization_id, place_id);


--
-- Name: accounts_organization_establishments_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY accounts_organization_establishments
    ADD CONSTRAINT accounts_organization_establishments_pkey PRIMARY KEY (id);


--
-- Name: accounts_organization_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY accounts_organization
    ADD CONSTRAINT accounts_organization_pkey PRIMARY KEY (id);


--
-- Name: accounts_userprofile_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY accounts_userprofile
    ADD CONSTRAINT accounts_userprofile_pkey PRIMARY KEY (id);


--
-- Name: accounts_userprofile_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY accounts_userprofile
    ADD CONSTRAINT accounts_userprofile_user_id_key UNIQUE (user_id);


--
-- Name: auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions_group_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_key UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_message_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_message
    ADD CONSTRAINT auth_message_pkey PRIMARY KEY (id);


--
-- Name: auth_permission_content_type_id_codename_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_key UNIQUE (content_type_id, codename);


--
-- Name: auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- Name: auth_user_groups_user_id_group_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_key UNIQUE (user_id, group_id);


--
-- Name: auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_user_user_permissions_user_id_permission_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_key UNIQUE (user_id, permission_id);


--
-- Name: auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- Name: chatter_post_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY chatter_post
    ADD CONSTRAINT chatter_post_pkey PRIMARY KEY (id);


--
-- Name: django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type_app_label_model_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_key UNIQUE (app_label, model);


--
-- Name: django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: django_site_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY django_site
    ADD CONSTRAINT django_site_pkey PRIMARY KEY (id);


--
-- Name: events_attendee_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY events_attendee
    ADD CONSTRAINT events_attendee_pkey PRIMARY KEY (id);


--
-- Name: events_event_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY events_event
    ADD CONSTRAINT events_event_pkey PRIMARY KEY (id);


--
-- Name: events_event_tags_event_id_555ca681719d3195_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY events_event_tags
    ADD CONSTRAINT events_event_tags_event_id_555ca681719d3195_uniq UNIQUE (event_id, tag_id);


--
-- Name: events_event_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY events_event_tags
    ADD CONSTRAINT events_event_tags_pkey PRIMARY KEY (id);


--
-- Name: events_eventmeta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY events_eventmeta
    ADD CONSTRAINT events_eventmeta_pkey PRIMARY KEY (id);


--
-- Name: events_icalendarfeed_cand_icalendarfeed_id_5e1bc1471257369_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY events_icalendarfeed_candidate_places
    ADD CONSTRAINT events_icalendarfeed_cand_icalendarfeed_id_5e1bc1471257369_uniq UNIQUE (icalendarfeed_id, place_id);


--
-- Name: events_icalendarfeed_candidate_places_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY events_icalendarfeed_candidate_places
    ADD CONSTRAINT events_icalendarfeed_candidate_places_pkey PRIMARY KEY (id);


--
-- Name: events_icalendarfeed_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY events_icalendarfeed
    ADD CONSTRAINT events_icalendarfeed_pkey PRIMARY KEY (id);


--
-- Name: events_role_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY events_role
    ADD CONSTRAINT events_role_pkey PRIMARY KEY (id);


--
-- Name: feedback_genericfeedbackcomment_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY feedback_genericfeedbackcomment
    ADD CONSTRAINT feedback_genericfeedbackcomment_pkey PRIMARY KEY (id);


--
-- Name: news_article_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY news_article
    ADD CONSTRAINT news_article_pkey PRIMARY KEY (id);


--
-- Name: news_article_related_events_article_id_726c227c54c23e81_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY news_article_related_events
    ADD CONSTRAINT news_article_related_events_article_id_726c227c54c23e81_uniq UNIQUE (article_id, event_id);


--
-- Name: news_article_related_events_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY news_article_related_events
    ADD CONSTRAINT news_article_related_events_pkey PRIMARY KEY (id);


--
-- Name: news_article_related_places_article_id_505f4cd2cca1e6cb_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY news_article_related_places
    ADD CONSTRAINT news_article_related_places_article_id_505f4cd2cca1e6cb_uniq UNIQUE (article_id, place_id);


--
-- Name: news_article_related_places_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY news_article_related_places
    ADD CONSTRAINT news_article_related_places_pkey PRIMARY KEY (id);


--
-- Name: places_favorite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY places_favorite
    ADD CONSTRAINT places_favorite_pkey PRIMARY KEY (id);


--
-- Name: places_location_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY places_location
    ADD CONSTRAINT places_location_pkey PRIMARY KEY (id);


--
-- Name: places_place_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY places_place
    ADD CONSTRAINT places_place_pkey PRIMARY KEY (id);


--
-- Name: places_place_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY places_place_tags
    ADD CONSTRAINT places_place_tags_pkey PRIMARY KEY (id);


--
-- Name: places_place_tags_place_id_48fa9f73d476dfa0_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY places_place_tags
    ADD CONSTRAINT places_place_tags_place_id_48fa9f73d476dfa0_uniq UNIQUE (place_id, tag_id);


--
-- Name: places_placemeta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY places_placemeta
    ADD CONSTRAINT places_placemeta_pkey PRIMARY KEY (id);


--
-- Name: south_migrationhistory_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY south_migrationhistory
    ADD CONSTRAINT south_migrationhistory_pkey PRIMARY KEY (id);


--
-- Name: specials_coupon_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY specials_coupon
    ADD CONSTRAINT specials_coupon_pkey PRIMARY KEY (id);


--
-- Name: specials_coupon_uuid_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY specials_coupon
    ADD CONSTRAINT specials_coupon_uuid_uniq UNIQUE (uuid);


--
-- Name: specials_special_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY specials_special
    ADD CONSTRAINT specials_special_pkey PRIMARY KEY (id);


--
-- Name: specials_special_tags_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY specials_special_tags
    ADD CONSTRAINT specials_special_tags_pkey PRIMARY KEY (id);


--
-- Name: specials_special_tags_special_id_3b4e08fd732d7ba_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY specials_special_tags
    ADD CONSTRAINT specials_special_tags_special_id_3b4e08fd732d7ba_uniq UNIQUE (special_id, tag_id);


--
-- Name: specials_specialmeta_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY specials_specialmeta
    ADD CONSTRAINT specials_specialmeta_pkey PRIMARY KEY (id);


--
-- Name: tags_tag_name_uniq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tags_tag
    ADD CONSTRAINT tags_tag_name_uniq UNIQUE (name);


--
-- Name: tags_tag_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tags_tag
    ADD CONSTRAINT tags_tag_pkey PRIMARY KEY (id);


--
-- Name: tastypie_apiaccess_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tastypie_apiaccess
    ADD CONSTRAINT tastypie_apiaccess_pkey PRIMARY KEY (id);


--
-- Name: tastypie_apikey_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tastypie_apikey
    ADD CONSTRAINT tastypie_apikey_pkey PRIMARY KEY (id);


--
-- Name: tastypie_apikey_user_id_key; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tastypie_apikey
    ADD CONSTRAINT tastypie_apikey_user_id_key UNIQUE (user_id);


--
-- Name: thumbnail_kvstore_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY thumbnail_kvstore
    ADD CONSTRAINT thumbnail_kvstore_pkey PRIMARY KEY (key);


--
-- Name: accounts_organization_administrators_organization_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX accounts_organization_administrators_organization_id ON accounts_organization_administrators USING btree (organization_id);


--
-- Name: accounts_organization_administrators_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX accounts_organization_administrators_user_id ON accounts_organization_administrators USING btree (user_id);


--
-- Name: accounts_organization_establishments_organization_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX accounts_organization_establishments_organization_id ON accounts_organization_establishments USING btree (organization_id);


--
-- Name: accounts_organization_establishments_place_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX accounts_organization_establishments_place_id ON accounts_organization_establishments USING btree (place_id);


--
-- Name: auth_group_permissions_group_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_group_permissions_group_id ON auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_group_permissions_permission_id ON auth_group_permissions USING btree (permission_id);


--
-- Name: auth_message_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_message_user_id ON auth_message USING btree (user_id);


--
-- Name: auth_permission_content_type_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_permission_content_type_id ON auth_permission USING btree (content_type_id);


--
-- Name: auth_user_groups_group_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_groups_group_id ON auth_user_groups USING btree (group_id);


--
-- Name: auth_user_groups_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_groups_user_id ON auth_user_groups USING btree (user_id);


--
-- Name: auth_user_user_permissions_permission_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_permission_id ON auth_user_user_permissions USING btree (permission_id);


--
-- Name: auth_user_user_permissions_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX auth_user_user_permissions_user_id ON auth_user_user_permissions USING btree (user_id);


--
-- Name: chatter_post_author_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX chatter_post_author_id ON chatter_post USING btree (author_id);


--
-- Name: django_admin_log_content_type_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_admin_log_content_type_id ON django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_admin_log_user_id ON django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX django_session_expire_date ON django_session USING btree (expire_date);


--
-- Name: events_attendee_event_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX events_attendee_event_id ON events_attendee USING btree (event_id);


--
-- Name: events_attendee_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX events_attendee_user_id ON events_attendee USING btree (user_id);


--
-- Name: events_event_place_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX events_event_place_id ON events_event USING btree (place_id);


--
-- Name: events_event_tags_event_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX events_event_tags_event_id ON events_event_tags USING btree (event_id);


--
-- Name: events_event_tags_tag_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX events_event_tags_tag_id ON events_event_tags USING btree (tag_id);


--
-- Name: events_eventmeta_event_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX events_eventmeta_event_id ON events_eventmeta USING btree (event_id);


--
-- Name: events_icalendarfeed_candidate_places_icalendarfeed_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX events_icalendarfeed_candidate_places_icalendarfeed_id ON events_icalendarfeed_candidate_places USING btree (icalendarfeed_id);


--
-- Name: events_icalendarfeed_candidate_places_place_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX events_icalendarfeed_candidate_places_place_id ON events_icalendarfeed_candidate_places USING btree (place_id);


--
-- Name: events_icalendarfeed_owner_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX events_icalendarfeed_owner_id ON events_icalendarfeed USING btree (owner_id);


--
-- Name: events_role_event_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX events_role_event_id ON events_role USING btree (event_id);


--
-- Name: events_role_organization_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX events_role_organization_id ON events_role USING btree (organization_id);


--
-- Name: feedback_genericfeedbackcomment_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX feedback_genericfeedbackcomment_user_id ON feedback_genericfeedbackcomment USING btree (user_id);


--
-- Name: news_article_related_events_article_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX news_article_related_events_article_id ON news_article_related_events USING btree (article_id);


--
-- Name: news_article_related_events_event_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX news_article_related_events_event_id ON news_article_related_events USING btree (event_id);


--
-- Name: news_article_related_places_article_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX news_article_related_places_article_id ON news_article_related_places USING btree (article_id);


--
-- Name: news_article_related_places_place_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX news_article_related_places_place_id ON news_article_related_places USING btree (place_id);


--
-- Name: places_favorite_place_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX places_favorite_place_id ON places_favorite USING btree (place_id);


--
-- Name: places_favorite_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX places_favorite_user_id ON places_favorite USING btree (user_id);


--
-- Name: places_place_location_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX places_place_location_id ON places_place USING btree (location_id);


--
-- Name: places_place_tags_place_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX places_place_tags_place_id ON places_place_tags USING btree (place_id);


--
-- Name: places_place_tags_tag_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX places_place_tags_tag_id ON places_place_tags USING btree (tag_id);


--
-- Name: places_placemeta_place_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX places_placemeta_place_id ON places_placemeta USING btree (place_id);


--
-- Name: specials_coupon_special_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX specials_coupon_special_id ON specials_coupon USING btree (special_id);


--
-- Name: specials_coupon_user_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX specials_coupon_user_id ON specials_coupon USING btree (user_id);


--
-- Name: specials_special_place_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX specials_special_place_id ON specials_special USING btree (place_id);


--
-- Name: specials_special_tags_special_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX specials_special_tags_special_id ON specials_special_tags USING btree (special_id);


--
-- Name: specials_special_tags_tag_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX specials_special_tags_tag_id ON specials_special_tags USING btree (tag_id);


--
-- Name: specials_specialmeta_special_id; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX specials_specialmeta_special_id ON specials_specialmeta USING btree (special_id);


--
-- Name: tags_tag_name; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX tags_tag_name ON tags_tag USING btree (name);


--
-- Name: tags_tag_name_like; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX tags_tag_name_like ON tags_tag USING btree (name varchar_pattern_ops);


--
-- Name: article_id_refs_id_2deec71f2bc8ddb3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY news_article_related_places
    ADD CONSTRAINT article_id_refs_id_2deec71f2bc8ddb3 FOREIGN KEY (article_id) REFERENCES news_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: article_id_refs_id_4e4016bf7a835e64; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY news_article_related_events
    ADD CONSTRAINT article_id_refs_id_4e4016bf7a835e64 FOREIGN KEY (article_id) REFERENCES news_article(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_message_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_message
    ADD CONSTRAINT auth_message_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_groups_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_fkey FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_user_user_permissions_permission_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_permission_id_fkey FOREIGN KEY (permission_id) REFERENCES auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: author_id_refs_id_167d9328f14e3320; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY chatter_post
    ADD CONSTRAINT author_id_refs_id_167d9328f14e3320 FOREIGN KEY (author_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: content_type_id_refs_id_728de91f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_permission
    ADD CONSTRAINT content_type_id_refs_id_728de91f FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_content_type_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_fkey FOREIGN KEY (content_type_id) REFERENCES django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: event_id_refs_id_14ae6a5e7cf46e38; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY news_article_related_events
    ADD CONSTRAINT event_id_refs_id_14ae6a5e7cf46e38 FOREIGN KEY (event_id) REFERENCES events_event(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: event_id_refs_id_215e7a458d395f50; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY events_role
    ADD CONSTRAINT event_id_refs_id_215e7a458d395f50 FOREIGN KEY (event_id) REFERENCES events_event(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: event_id_refs_id_2c200544fd0e2f02; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY events_attendee
    ADD CONSTRAINT event_id_refs_id_2c200544fd0e2f02 FOREIGN KEY (event_id) REFERENCES events_event(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: event_id_refs_id_69024429493505ba; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY events_event_tags
    ADD CONSTRAINT event_id_refs_id_69024429493505ba FOREIGN KEY (event_id) REFERENCES events_event(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: event_id_refs_id_ee6f87693215acc; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY events_eventmeta
    ADD CONSTRAINT event_id_refs_id_ee6f87693215acc FOREIGN KEY (event_id) REFERENCES events_event(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: feedback_genericfeedbackcomment_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY feedback_genericfeedbackcomment
    ADD CONSTRAINT feedback_genericfeedbackcomment_user_id_fkey FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: group_id_refs_id_3cea63fe; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_group_permissions
    ADD CONSTRAINT group_id_refs_id_3cea63fe FOREIGN KEY (group_id) REFERENCES auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: icalendarfeed_id_refs_id_460dd9b596fbef4f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY events_icalendarfeed_candidate_places
    ADD CONSTRAINT icalendarfeed_id_refs_id_460dd9b596fbef4f FOREIGN KEY (icalendarfeed_id) REFERENCES events_icalendarfeed(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: location_id_refs_id_49fc4cb9accc1b74; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY places_place
    ADD CONSTRAINT location_id_refs_id_49fc4cb9accc1b74 FOREIGN KEY (location_id) REFERENCES places_location(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization_id_refs_id_1d21c5197e521455; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY accounts_organization_administrators
    ADD CONSTRAINT organization_id_refs_id_1d21c5197e521455 FOREIGN KEY (organization_id) REFERENCES accounts_organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization_id_refs_id_2960dcee9e00f4fb; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY accounts_organization_establishments
    ADD CONSTRAINT organization_id_refs_id_2960dcee9e00f4fb FOREIGN KEY (organization_id) REFERENCES accounts_organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: organization_id_refs_id_41565d02f339784b; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY events_role
    ADD CONSTRAINT organization_id_refs_id_41565d02f339784b FOREIGN KEY (organization_id) REFERENCES accounts_organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: owner_id_refs_id_4e46bbc2589cdf59; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY events_icalendarfeed
    ADD CONSTRAINT owner_id_refs_id_4e46bbc2589cdf59 FOREIGN KEY (owner_id) REFERENCES accounts_organization(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: place_id_refs_id_1e71441f567f320; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY places_placemeta
    ADD CONSTRAINT place_id_refs_id_1e71441f567f320 FOREIGN KEY (place_id) REFERENCES places_place(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: place_id_refs_id_231f082df2539f3c; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY events_icalendarfeed_candidate_places
    ADD CONSTRAINT place_id_refs_id_231f082df2539f3c FOREIGN KEY (place_id) REFERENCES places_place(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: place_id_refs_id_5756d2c862d7d7a5; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY places_favorite
    ADD CONSTRAINT place_id_refs_id_5756d2c862d7d7a5 FOREIGN KEY (place_id) REFERENCES places_place(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: place_id_refs_id_6014fad3e9932395; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY events_event
    ADD CONSTRAINT place_id_refs_id_6014fad3e9932395 FOREIGN KEY (place_id) REFERENCES places_place(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: place_id_refs_id_756eeb148cdc95d6; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY places_place_tags
    ADD CONSTRAINT place_id_refs_id_756eeb148cdc95d6 FOREIGN KEY (place_id) REFERENCES places_place(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: place_id_refs_id_785bb17b4ada05a; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY accounts_organization_establishments
    ADD CONSTRAINT place_id_refs_id_785bb17b4ada05a FOREIGN KEY (place_id) REFERENCES places_place(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: place_id_refs_id_78ded4dd185236eb; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY news_article_related_places
    ADD CONSTRAINT place_id_refs_id_78ded4dd185236eb FOREIGN KEY (place_id) REFERENCES places_place(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: place_id_refs_id_7ab47e57f350ce3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY specials_special
    ADD CONSTRAINT place_id_refs_id_7ab47e57f350ce3 FOREIGN KEY (place_id) REFERENCES places_place(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: special_id_refs_id_610ca774363fe842; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY specials_special_tags
    ADD CONSTRAINT special_id_refs_id_610ca774363fe842 FOREIGN KEY (special_id) REFERENCES specials_special(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: special_id_refs_id_6c697f0ee8b314d3; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY specials_coupon
    ADD CONSTRAINT special_id_refs_id_6c697f0ee8b314d3 FOREIGN KEY (special_id) REFERENCES specials_special(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: special_id_refs_id_774ff87c46f90758; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY specials_specialmeta
    ADD CONSTRAINT special_id_refs_id_774ff87c46f90758 FOREIGN KEY (special_id) REFERENCES specials_special(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tag_id_refs_id_2dd121bf531389f8; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY places_place_tags
    ADD CONSTRAINT tag_id_refs_id_2dd121bf531389f8 FOREIGN KEY (tag_id) REFERENCES tags_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tag_id_refs_id_74729033a2ca44b0; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY specials_special_tags
    ADD CONSTRAINT tag_id_refs_id_74729033a2ca44b0 FOREIGN KEY (tag_id) REFERENCES tags_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: tag_id_refs_id_75100d2e8f2d64f2; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY events_event_tags
    ADD CONSTRAINT tag_id_refs_id_75100d2e8f2d64f2 FOREIGN KEY (tag_id) REFERENCES tags_tag(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_15535b85e2f00479; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY accounts_organization_administrators
    ADD CONSTRAINT user_id_refs_id_15535b85e2f00479 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_332d09f456bfdb62; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY tastypie_apikey
    ADD CONSTRAINT user_id_refs_id_332d09f456bfdb62 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_3f88da15a4d12d92; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY specials_coupon
    ADD CONSTRAINT user_id_refs_id_3f88da15a4d12d92 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_6280a4b981d7010f; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY accounts_userprofile
    ADD CONSTRAINT user_id_refs_id_6280a4b981d7010f FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_65bc0d8c6b05e17d; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY events_attendee
    ADD CONSTRAINT user_id_refs_id_65bc0d8c6b05e17d FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_706a31f150331d70; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY places_favorite
    ADD CONSTRAINT user_id_refs_id_706a31f150331d70 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_831107f1; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_groups
    ADD CONSTRAINT user_id_refs_id_831107f1 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: user_id_refs_id_f2045483; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY auth_user_user_permissions
    ADD CONSTRAINT user_id_refs_id_f2045483 FOREIGN KEY (user_id) REFERENCES auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

